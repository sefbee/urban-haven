/*!
 * Font Awesome Pro 7.3.0 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license (Commercial License)
 * Copyright 2026 Fonticons, Inc.
 */
(function () {
  'use strict';

  var _WINDOW = {};
  var _DOCUMENT = {};
  try {
    if (typeof window !== 'undefined') _WINDOW = window;
    if (typeof document !== 'undefined') _DOCUMENT = document;
  } catch (e) {} // eslint-disable-line no-empty

  var _ref = _WINDOW.navigator || {},
    _ref$userAgent = _ref.userAgent,
    userAgent = _ref$userAgent === void 0 ? '' : _ref$userAgent;
  var WINDOW = _WINDOW;
  var DOCUMENT = _DOCUMENT;
  var IS_BROWSER = !!WINDOW.document;
  var IS_DOM = !!DOCUMENT.documentElement && !!DOCUMENT.head && typeof DOCUMENT.addEventListener === 'function' && typeof DOCUMENT.createElement === 'function';
  var IS_IE = ~userAgent.indexOf('MSIE') || ~userAgent.indexOf('Trident/');

  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _arrayWithoutHoles(r) {
    if (Array.isArray(r)) return _arrayLikeToArray(r);
  }
  function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[r] = t, e;
  }
  function _iterableToArray(r) {
    if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
  }
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function (r) {
        return Object.getOwnPropertyDescriptor(e, r).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
        _defineProperty(e, r, t[r]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
        Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
      });
    }
    return e;
  }
  function _toConsumableArray(r) {
    return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }

  var _cl;
  var rl = {
      classic: {
        fa: "solid",
        fas: "solid",
        "fa-solid": "solid",
        far: "regular",
        "fa-regular": "regular",
        fal: "light",
        "fa-light": "light",
        fat: "thin",
        "fa-thin": "thin",
        fab: "brands",
        "fa-brands": "brands"
      },
      duotone: {
        fa: "solid",
        fad: "solid",
        "fa-solid": "solid",
        "fa-duotone": "solid",
        fadr: "regular",
        "fa-regular": "regular",
        fadl: "light",
        "fa-light": "light",
        fadt: "thin",
        "fa-thin": "thin"
      },
      sharp: {
        fa: "solid",
        fass: "solid",
        "fa-solid": "solid",
        fasr: "regular",
        "fa-regular": "regular",
        fasl: "light",
        "fa-light": "light",
        fast: "thin",
        "fa-thin": "thin"
      },
      "sharp-duotone": {
        fa: "solid",
        fasds: "solid",
        "fa-solid": "solid",
        fasdr: "regular",
        "fa-regular": "regular",
        fasdl: "light",
        "fa-light": "light",
        fasdt: "thin",
        "fa-thin": "thin"
      },
      slab: {
        "fa-regular": "regular",
        faslr: "regular"
      },
      "slab-press": {
        "fa-regular": "regular",
        faslpr: "regular"
      },
      "slab-duo": {
        "fa-regular": "regular",
        fasldr: "regular"
      },
      "slab-press-duo": {
        "fa-regular": "regular",
        faslpdr: "regular"
      },
      thumbprint: {
        "fa-light": "light",
        fatl: "light"
      },
      vellum: {
        "fa-solid": "solid",
        favs: "solid"
      },
      pixel: {
        "fa-regular": "regular",
        fapr: "regular"
      },
      mosaic: {
        "fa-solid": "solid",
        fams: "solid"
      },
      whiteboard: {
        "fa-semibold": "semibold",
        fawsb: "semibold"
      },
      notdog: {
        "fa-solid": "solid",
        fans: "solid"
      },
      "notdog-duo": {
        "fa-solid": "solid",
        fands: "solid"
      },
      etch: {
        "fa-solid": "solid",
        faes: "solid"
      },
      graphite: {
        "fa-thin": "thin",
        fagt: "thin"
      },
      jelly: {
        "fa-regular": "regular",
        fajr: "regular"
      },
      "jelly-fill": {
        "fa-regular": "regular",
        fajfr: "regular"
      },
      "jelly-duo": {
        "fa-regular": "regular",
        fajdr: "regular"
      },
      chisel: {
        "fa-regular": "regular",
        facr: "regular"
      },
      utility: {
        "fa-semibold": "semibold",
        fausb: "semibold"
      },
      "utility-duo": {
        "fa-semibold": "semibold",
        faudsb: "semibold"
      },
      "utility-fill": {
        "fa-semibold": "semibold",
        faufsb: "semibold"
      }
    };
  var u = "classic",
    l = "duotone",
    h = "sharp",
    t = "sharp-duotone",
    g = "chisel",
    n = "etch",
    m = "graphite",
    p = "jelly",
    s = "jelly-duo",
    y = "jelly-fill",
    w = "mosaic",
    x = "notdog",
    e = "notdog-duo",
    b = "pixel",
    c = "slab",
    o = "slab-duo",
    I = "slab-press",
    a = "slab-press-duo",
    r = "thumbprint",
    v = "utility",
    i = "utility-duo",
    F = "utility-fill",
    d = "vellum",
    S = "whiteboard",
    A = "Classic",
    P = "Duotone",
    j = "Sharp",
    B = "Sharp Duotone",
    N = "Chisel",
    D = "Etch",
    k = "Graphite",
    T = "Jelly",
    C = "Jelly Duo",
    W = "Jelly Fill",
    R = "Mosaic",
    K = "Notdog",
    L = "Notdog Duo",
    U = "Pixel",
    J = "Slab",
    _ = "Slab Duo",
    M = "Slab Press",
    E = "Slab Press Duo",
    G = "Thumbprint",
    V = "Utility",
    z = "Utility Duo",
    O = "Utility Fill",
    Y = "Vellum",
    q = "Whiteboard",
    cl = (_cl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, u, A), l, P), h, j), t, B), g, N), n, D), m, k), p, T), s, C), y, W), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, w, R), x, K), e, L), b, U), c, J), o, _), I, M), a, E), r, G), v, V), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, i, z), F, O), d, Y), S, q));
  var Al = {
      classic: {
        900: "fas",
        400: "far",
        normal: "far",
        300: "fal",
        100: "fat"
      },
      duotone: {
        900: "fad",
        400: "fadr",
        300: "fadl",
        100: "fadt"
      },
      sharp: {
        900: "fass",
        400: "fasr",
        300: "fasl",
        100: "fast"
      },
      "sharp-duotone": {
        900: "fasds",
        400: "fasdr",
        300: "fasdl",
        100: "fasdt"
      },
      slab: {
        400: "faslr"
      },
      "slab-press": {
        400: "faslpr"
      },
      "slab-duo": {
        400: "fasldr"
      },
      "slab-press-duo": {
        400: "faslpdr"
      },
      vellum: {
        900: "favs"
      },
      mosaic: {
        900: "fams"
      },
      pixel: {
        400: "fapr"
      },
      whiteboard: {
        600: "fawsb"
      },
      thumbprint: {
        300: "fatl"
      },
      notdog: {
        900: "fans"
      },
      "notdog-duo": {
        900: "fands"
      },
      etch: {
        900: "faes"
      },
      graphite: {
        100: "fagt"
      },
      chisel: {
        400: "facr"
      },
      jelly: {
        400: "fajr"
      },
      "jelly-fill": {
        400: "fajfr"
      },
      "jelly-duo": {
        400: "fajdr"
      },
      utility: {
        600: "fausb"
      },
      "utility-duo": {
        600: "faudsb"
      },
      "utility-fill": {
        600: "faufsb"
      }
    };
  var $l = {
      chisel: {
        regular: "facr"
      },
      classic: {
        brands: "fab",
        light: "fal",
        regular: "far",
        solid: "fas",
        thin: "fat"
      },
      duotone: {
        light: "fadl",
        regular: "fadr",
        solid: "fad",
        thin: "fadt"
      },
      etch: {
        solid: "faes"
      },
      graphite: {
        thin: "fagt"
      },
      jelly: {
        regular: "fajr"
      },
      "jelly-duo": {
        regular: "fajdr"
      },
      "jelly-fill": {
        regular: "fajfr"
      },
      mosaic: {
        solid: "fams"
      },
      notdog: {
        solid: "fans"
      },
      "notdog-duo": {
        solid: "fands"
      },
      pixel: {
        regular: "fapr"
      },
      sharp: {
        light: "fasl",
        regular: "fasr",
        solid: "fass",
        thin: "fast"
      },
      "sharp-duotone": {
        light: "fasdl",
        regular: "fasdr",
        solid: "fasds",
        thin: "fasdt"
      },
      slab: {
        regular: "faslr"
      },
      "slab-duo": {
        regular: "fasldr"
      },
      "slab-press": {
        regular: "faslpr"
      },
      "slab-press-duo": {
        regular: "faslpdr"
      },
      thumbprint: {
        light: "fatl"
      },
      utility: {
        semibold: "fausb"
      },
      "utility-duo": {
        semibold: "faudsb"
      },
      "utility-fill": {
        semibold: "faufsb"
      },
      vellum: {
        solid: "favs"
      },
      whiteboard: {
        semibold: "fawsb"
      }
    };
  var rt = {
      kit: {
        fak: "kit",
        "fa-kit": "kit"
      },
      "kit-duotone": {
        fakd: "kit-duotone",
        "fa-kit-duotone": "kit-duotone"
      }
    },
    it = ["kit"];
  var H = "kit",
    f = "kit-duotone",
    Q = "Kit",
    X = "Kit Duotone",
    ht = _defineProperty(_defineProperty({}, H, Q), f, X);
  var mt = {
    kit: {
      "fa-kit": "fak"
    },
    "kit-duotone": {
      "fa-kit-duotone": "fakd"
    }
  };
  var It = {
      kit: {
        fak: "fa-kit"
      },
      "kit-duotone": {
        fakd: "fa-kit-duotone"
      }
    };
  var St = {
      kit: {
        kit: "fak"
      },
      "kit-duotone": {
        "kit-duotone": "fakd"
      }
    };

  var _jl;
  var l$1 = {
      GROUP: "duotone-group",
      SWAP_OPACITY: "swap-opacity",
      PRIMARY: "primary",
      SECONDARY: "secondary"
    };
  var g$1 = "classic",
    a$1 = "duotone",
    m$1 = "sharp",
    t$1 = "sharp-duotone",
    p$1 = "chisel",
    y$1 = "etch",
    b$1 = "graphite",
    w$1 = "jelly",
    e$1 = "jelly-duo",
    x$1 = "jelly-fill",
    c$1 = "mosaic",
    I$1 = "notdog",
    o$1 = "notdog-duo",
    v$1 = "pixel",
    F$1 = "slab",
    r$1 = "slab-duo",
    S$1 = "slab-press",
    i$1 = "slab-press-duo",
    d$1 = "thumbprint",
    A$1 = "utility",
    f$1 = "utility-duo",
    P$1 = "utility-fill",
    u$1 = "vellum",
    j$1 = "whiteboard",
    B$1 = "Classic",
    N$1 = "Duotone",
    D$1 = "Sharp",
    k$1 = "Sharp Duotone",
    C$1 = "Chisel",
    T$1 = "Etch",
    L$1 = "Graphite",
    W$1 = "Jelly",
    R$1 = "Jelly Duo",
    K$1 = "Jelly Fill",
    U$1 = "Mosaic",
    J$1 = "Notdog",
    _$1 = "Notdog Duo",
    M$1 = "Pixel",
    E$1 = "Slab",
    G$1 = "Slab Duo",
    O$1 = "Slab Press",
    V$1 = "Slab Press Duo",
    z$1 = "Thumbprint",
    Y$1 = "Utility",
    $$1 = "Utility Duo",
    q$1 = "Utility Fill",
    H$1 = "Vellum",
    Q$1 = "Whiteboard",
    jl$1 = (_jl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, g$1, B$1), a$1, N$1), m$1, D$1), t$1, k$1), p$1, C$1), y$1, T$1), b$1, L$1), w$1, W$1), e$1, R$1), x$1, K$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, c$1, U$1), I$1, J$1), o$1, _$1), v$1, M$1), F$1, E$1), r$1, G$1), S$1, O$1), i$1, V$1), d$1, z$1), A$1, Y$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, f$1, $$1), P$1, q$1), u$1, H$1), j$1, Q$1));
  var X$1 = "kit",
    h$1 = "kit-duotone",
    Z$1 = "Kit",
    ll$1 = "Kit Duotone",
    ws = _defineProperty(_defineProperty({}, X$1, Z$1), h$1, ll$1);
  var ra = {
      classic: {
        "fa-brands": "fab",
        "fa-duotone": "fad",
        "fa-light": "fal",
        "fa-regular": "far",
        "fa-solid": "fas",
        "fa-thin": "fat"
      },
      duotone: {
        "fa-regular": "fadr",
        "fa-light": "fadl",
        "fa-thin": "fadt"
      },
      sharp: {
        "fa-solid": "fass",
        "fa-regular": "fasr",
        "fa-light": "fasl",
        "fa-thin": "fast"
      },
      "sharp-duotone": {
        "fa-solid": "fasds",
        "fa-regular": "fasdr",
        "fa-light": "fasdl",
        "fa-thin": "fasdt"
      },
      slab: {
        "fa-regular": "faslr"
      },
      "slab-press": {
        "fa-regular": "faslpr"
      },
      "slab-duo": {
        "fa-regular": "fasldr"
      },
      "slab-press-duo": {
        "fa-regular": "faslpdr"
      },
      pixel: {
        "fa-regular": "fapr"
      },
      mosaic: {
        "fa-solid": "fams"
      },
      vellum: {
        "fa-solid": "favs"
      },
      whiteboard: {
        "fa-semibold": "fawsb"
      },
      thumbprint: {
        "fa-light": "fatl"
      },
      notdog: {
        "fa-solid": "fans"
      },
      "notdog-duo": {
        "fa-solid": "fands"
      },
      etch: {
        "fa-solid": "faes"
      },
      graphite: {
        "fa-thin": "fagt"
      },
      jelly: {
        "fa-regular": "fajr"
      },
      "jelly-fill": {
        "fa-regular": "fajfr"
      },
      "jelly-duo": {
        "fa-regular": "fajdr"
      },
      chisel: {
        "fa-regular": "facr"
      },
      utility: {
        "fa-semibold": "fausb"
      },
      "utility-duo": {
        "fa-semibold": "faudsb"
      },
      "utility-fill": {
        "fa-semibold": "faufsb"
      }
    },
    al$1 = {
      classic: ["fas", "far", "fal", "fat", "fad"],
      duotone: ["fadr", "fadl", "fadt"],
      sharp: ["fass", "fasr", "fasl", "fast"],
      "sharp-duotone": ["fasds", "fasdr", "fasdl", "fasdt"],
      slab: ["faslr"],
      "slab-press": ["faslpr"],
      "slab-duo": ["fasldr"],
      "slab-press-duo": ["faslpdr"],
      pixel: ["fapr"],
      mosaic: ["fams"],
      vellum: ["favs"],
      whiteboard: ["fawsb"],
      thumbprint: ["fatl"],
      notdog: ["fans"],
      "notdog-duo": ["fands"],
      etch: ["faes"],
      graphite: ["fagt"],
      jelly: ["fajr"],
      "jelly-fill": ["fajfr"],
      "jelly-duo": ["fajdr"],
      chisel: ["facr"],
      utility: ["fausb"],
      "utility-duo": ["faudsb"],
      "utility-fill": ["faufsb"]
    },
    da = {
      classic: {
        fab: "fa-brands",
        fad: "fa-duotone",
        fal: "fa-light",
        far: "fa-regular",
        fas: "fa-solid",
        fat: "fa-thin"
      },
      duotone: {
        fadr: "fa-regular",
        fadl: "fa-light",
        fadt: "fa-thin"
      },
      sharp: {
        fass: "fa-solid",
        fasr: "fa-regular",
        fasl: "fa-light",
        fast: "fa-thin"
      },
      "sharp-duotone": {
        fasds: "fa-solid",
        fasdr: "fa-regular",
        fasdl: "fa-light",
        fasdt: "fa-thin"
      },
      slab: {
        faslr: "fa-regular"
      },
      "slab-press": {
        faslpr: "fa-regular"
      },
      "slab-duo": {
        fasldr: "fa-regular"
      },
      "slab-press-duo": {
        faslpdr: "fa-regular"
      },
      pixel: {
        fapr: "fa-regular"
      },
      mosaic: {
        fams: "fa-solid"
      },
      vellum: {
        favs: "fa-solid"
      },
      whiteboard: {
        fawsb: "fa-semibold"
      },
      thumbprint: {
        fatl: "fa-light"
      },
      notdog: {
        fans: "fa-solid"
      },
      "notdog-duo": {
        fands: "fa-solid"
      },
      etch: {
        faes: "fa-solid"
      },
      graphite: {
        fagt: "fa-thin"
      },
      jelly: {
        fajr: "fa-regular"
      },
      "jelly-fill": {
        fajfr: "fa-regular"
      },
      "jelly-duo": {
        fajdr: "fa-regular"
      },
      chisel: {
        facr: "fa-regular"
      },
      utility: {
        fausb: "fa-semibold"
      },
      "utility-duo": {
        faudsb: "fa-semibold"
      },
      "utility-fill": {
        faufsb: "fa-semibold"
      }
    },
    el$1 = ["solid", "regular", "light", "thin", "duotone", "brands", "semibold"],
    sl$1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    ol$1 = sl$1.concat([11, 12, 13, 14, 15, 16, 17, 18, 19, 20]),
    rl$1 = ["aw", "fw", "pull-left", "pull-right"],
    ga = [].concat(_toConsumableArray(Object.keys(al$1)), el$1, rl$1, ["2xs", "xs", "sm", "lg", "xl", "2xl", "beat", "beat-fade", "border", "bounce", "buzz", "canvas-square", "canvas-roomy", "fade", "flip-360", "flip-both", "flip-horizontal", "flip-vertical", "flip", "float", "inverse", "jello", "layers", "layers-bottom-left", "layers-bottom-right", "layers-counter", "layers-text", "layers-top-left", "layers-top-right", "li", "pull-end", "pull-start", "pulse", "rotate-180", "rotate-270", "rotate-90", "rotate-by", "shake", "spin-pulse", "spin-reverse", "spin", "spin-snap", "spin-snap-4", "spin-snap-8", "stack-1x", "stack-2x", "stack", "swing", "ul", "wag", "width-auto", "width-fixed", l$1.GROUP, l$1.SWAP_OPACITY, l$1.PRIMARY, l$1.SECONDARY]).concat(sl$1.map(function (s) {
      return "".concat(s, "x");
    })).concat(ol$1.map(function (s) {
      return "w-".concat(s);
    }));

  var NAMESPACE_IDENTIFIER = '___FONT_AWESOME___';
  var PRODUCTION = function () {
    try {
      return "production" === 'production';
    } catch (e$$1) {
      return false;
    }
  }();
  function familyProxy(obj) {
    // Defaults to the classic family if family is not available
    return new Proxy(obj, {
      get: function get(target, prop) {
        return prop in target ? target[prop] : target[u];
      }
    });
  }
  var _PREFIX_TO_STYLE = _objectSpread2({}, rl);

  // We changed FACSSClassesToStyleId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _PREFIX_TO_STYLE below, so we are manually adding
  // {'fa-duotone': 'duotone'}
  _PREFIX_TO_STYLE[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    'fa-duotone': 'duotone'
  }), rl[u]), rt['kit']), rt['kit-duotone']);
  var PREFIX_TO_STYLE = familyProxy(_PREFIX_TO_STYLE);
  var _STYLE_TO_PREFIX = _objectSpread2({}, $l);

  // We changed FAStyleIdToShortPrefixId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _STYLE_TO_PREFIX below, so we are manually adding {duotone: 'fad'}
  _STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    duotone: 'fad'
  }), _STYLE_TO_PREFIX[u]), St['kit']), St['kit-duotone']);
  var STYLE_TO_PREFIX = familyProxy(_STYLE_TO_PREFIX);
  var _PREFIX_TO_LONG_STYLE = _objectSpread2({}, da);
  _PREFIX_TO_LONG_STYLE[u] = _objectSpread2(_objectSpread2({}, _PREFIX_TO_LONG_STYLE[u]), It['kit']);
  var PREFIX_TO_LONG_STYLE = familyProxy(_PREFIX_TO_LONG_STYLE);
  var _LONG_STYLE_TO_PREFIX = _objectSpread2({}, ra);
  _LONG_STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2({}, _LONG_STYLE_TO_PREFIX[u]), mt['kit']);
  var LONG_STYLE_TO_PREFIX = familyProxy(_LONG_STYLE_TO_PREFIX);
  var _FONT_WEIGHT_TO_PREFIX = _objectSpread2({}, Al);
  var FONT_WEIGHT_TO_PREFIX = familyProxy(_FONT_WEIGHT_TO_PREFIX);
  var RESERVED_CLASSES = [].concat(_toConsumableArray(it), _toConsumableArray(ga));

  function bunker(fn) {
    try {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      fn.apply(void 0, args);
    } catch (e) {
      if (!PRODUCTION) {
        throw e;
      }
    }
  }

  var w$2 = WINDOW || {};
  if (!w$2[NAMESPACE_IDENTIFIER]) w$2[NAMESPACE_IDENTIFIER] = {};
  if (!w$2[NAMESPACE_IDENTIFIER].styles) w$2[NAMESPACE_IDENTIFIER].styles = {};
  if (!w$2[NAMESPACE_IDENTIFIER].hooks) w$2[NAMESPACE_IDENTIFIER].hooks = {};
  if (!w$2[NAMESPACE_IDENTIFIER].shims) w$2[NAMESPACE_IDENTIFIER].shims = [];
  var namespace = w$2[NAMESPACE_IDENTIFIER];

  function normalizeIcons(icons) {
    return Object.keys(icons).reduce(function (acc, iconName) {
      var icon = icons[iconName];
      var expanded = !!icon.icon;
      if (expanded) {
        acc[icon.iconName] = icon.icon;
      } else {
        acc[iconName] = icon;
      }
      return acc;
    }, {});
  }
  function defineIcons(prefix, icons) {
    var params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var _params$skipHooks = params.skipHooks,
      skipHooks = _params$skipHooks === void 0 ? false : _params$skipHooks;
    var normalized = normalizeIcons(icons);
    if (typeof namespace.hooks.addPack === 'function' && !skipHooks) {
      namespace.hooks.addPack(prefix, normalizeIcons(icons));
    } else {
      namespace.styles[prefix] = _objectSpread2(_objectSpread2({}, namespace.styles[prefix] || {}), normalized);
    }

    /**
     * Font Awesome 4 used the prefix of `fa` for all icons. With the introduction
     * of new styles we needed to differentiate between them. Prefix `fa` is now an alias
     * for `fas` so we'll ease the upgrade process for our users by automatically defining
     * this as well.
     */
    if (prefix === 'fas') {
      defineIcons('fa', icons);
    }
  }

  var icons = {
    "question": [360, 540, [10067, 10068, 61736], "3f", "M108 360c0 13.1 3.5 25.4 9.6 36-6.1 10.6-9.6 22.9-9.6 36l0 36c0 39.8 32.2 72 72 72s72-32.2 72-72l0-36c0-13.1-3.5-25.4-9.6-36 2.4-4.2 4.5-8.7 6-13.5 65.4-26.9 111.6-91.2 111.6-166.5l0-36C360 80.6 279.4 0 180 0S0 80.6 0 180l0 36c0 39.8 32.2 72 72 72 22.1 0 41.8-9.9 55-25.6-11.4 16.4-19 36.8-19 61.6l0 36zM36 180c0-79.5 64.5-144 144-144s144 64.5 144 144c0 63-40.4 116.5-96.7 136-6.2 2.2-10.7 7.5-11.8 14-2.9 17-17.7 30-35.5 30-19.9 0-36-16.1-36-36 0-41.3 33-66.7 59.6-75.9 28.3-9.8 48.4-36.6 48.4-68.1 0-39.8-32.2-72-72-72s-72 32.2-72 72c0 19.9-16.1 36-36 36s-36-16.1-36-36zM180 396c19.8 0 36 16.3 36 36 0 19.9-16.1 36-36 36s-36-16.1-36-36c0-19.7 16.2-36 36-36z"],
    "minus": [468, 540, [8211, 8722, 10134, "subtract"], "f068", "M72 180c-39.8 0-72 32.2-72 72l0 36c0 39.8 32.2 72 72 72l324 0c39.8 0 72-32.2 72-72l0-36c0-39.8-32.2-72-72-72L72 180zm360 72c0 19.9-16.1 36-36 36L72 288c-19.9 0-36-16.1-36-36s16.1-36 36-36l324 0c19.9 0 36 16.1 36 36z"],
    "microphone-slash": [504, 540, [], "f131", "M21.1 21.1C49.2-7 94.8-7 122.9 21.1l49.7 49.7c19.7-21.4 48-34.8 79.4-34.8 59.6 0 108 48.4 108 108l0 45.6c10.6-6.1 22.9-9.6 36-9.6 39.8 0 72 32.2 72 72 0 33.4-7.6 64.9-21.1 93.1l36 36C497 395.1 504 413.6 504 432l0 36c0 18.4-7 36.9-21.1 50.9-28.1 28.1-73.7 28.1-101.8 0l-57.1-57.1 0 6.2c0 39.8-32.2 72-72 72s-72-32.2-72-72l0-12.3c-83.9-29.7-144-109.6-144-203.7 0-21.5 9.4-40.7 24.3-53.9L21.1 158.9C7 144.9 0 126.4 0 108L0 69.8c0-18 8.5-36.1 21.1-48.7zM150.1 288L85.8 223.6c-8.4 6.6-13.8 16.8-13.8 28.4 0 82.4 55.3 151.9 130.9 173.2 7.7 2.2 13.1 9.3 13.1 17.3l0 25.5c0 19.9 16.1 36 36 36s36-16.1 36-36l0-25.5c0-4.6 1.7-8.8 4.6-12.1L216 353.9C185.3 343 161 318.7 150.1 288zm269.5 29.8c8-20.4 12.4-42.6 12.4-65.8 0-19.9-16.1-36-36-36s-36 16.1-36 36c0 2-.1 4-.2 6l59.8 59.8zM324 222.2l0-78.2c0-39.8-32.2-72-72-72-21.5 0-40.7 9.4-53.9 24.3L324 222.2zM46.5 97.5l360 360c14.1 14.1 36.9 14.1 50.9 0s14.1-36.9 0-50.9l-360-360c-14.1-14.1-36.9-14.1-50.9 0-14.1 14.1-14.1 36.9 0 50.9z"],
    "car": [540, 540, [128664, "automobile"], "f1b9", "M171 324a27 27 0 1 0 0-54 27 27 0 1 0 0 54zm171-27a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zm-90-18c-9.9 0-18 8.1-18 18s8.1 18 18 18l36 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-36 0zM166.2 36c-31.8 0-59.8 20.9-69 51.3L85.6 126 72 126c-39.8 0-72 32.2-72 72l0 36c0 33.5 22.9 61.7 54 69.7L54 450c0 39.8 32.2 72 72 72l18 0c39.8 0 72-32.2 72-72l0-18 108 0 0 18c0 39.8 32.2 72 72 72l18 0c39.8 0 72-32.2 72-72l0-146.3c31.1-8 54-36.2 54-69.7l0-36c0-39.8-32.2-72-72-72l-13.6 0-11.6-38.7c-9.1-30.5-37.2-51.3-69-51.3L166.2 36zM116.4 148.8l15.3-51.1C136.3 82.4 150.3 72 166.2 72l207.6 0c15.9 0 29.9 10.4 34.5 25.7l15.3 51.1c.1 .3 .2 .5 .2 .8l16 53.2c-8-3.1-16.7-4.8-25.8-4.8l-288 0c-9.1 0-17.8 1.7-25.8 4.8l16-53.2c.1-.3 .2-.5 .2-.8zM90 270c0-19.9 16.1-36 36-36l288 0c19.9 0 36 16.1 36 36l0 90-360 0 0-90zM450 396l0 18c0 19.9-16.1 36-36 36l-18 0c-19.9 0-36-16.1-36-36l0-18 90 0zM90 414l0-18 90 0 0 18c0 19.9-16.1 36-36 36l-18 0c-19.9 0-36-16.1-36-36zM504 198c0 13.7-7.7 25.7-19 31.8L465.2 162c20.6 0 38.8 14.2 38.8 36zM36 198c0-21.8 18.2-36 38.8-36L55 229.8c-11.3-6.1-19-18-19-31.8z"],
    "filter": [432, 540, [], "f0b0", "M72 36l288 0c39.8 0 72 32.2 72 72l0 90c0 19.1-7.6 37.4-21.1 50.9L306 353.8 306 432c0 19.1-7.6 37.4-21.1 50.9l-36 36c-20.6 20.6-51.6 26.8-78.5 15.6S126 497.1 126 468l0-114.2-104.9-104.9C7.6 235.4 0 217.1 0 198l0-90C0 68.8 32.8 36 72 36zm90 396c0 14.6 8.8 27.7 22.2 33.3s28.9 2.5 39.2-7.8l36-36c6.8-6.8 10.5-15.9 10.5-25.5l0-85.6c0-4.8 1.9-9.4 5.3-12.7L385.5 187.5c6.8-6.8 10.5-15.9 10.5-25.5l0-54c0-19.9-16.1-36-36-36L72 72c-19.6 0-36 16.4-36 36l0 54c0 9.5 3.8 18.7 10.5 25.5L156.7 297.6c3.4 3.4 5.3 8 5.3 12.7L162 432z"],
    "envelope": [504, 540, [128386, 9993, 61443], "f0e0", "M504 126l0 288c0 39.8-32.2 72-72 72L72 486c-39.8 0-72-32.2-72-72 0-96 0-192 0-288 0-39.8 32.2-72 72-72l360 0c39.8 0 72 32.2 72 72zm-468-.3L230.4 263.4c12.5 8.9 30.7 8.9 43.2 0L468 125.7C467.8 106 451.8 90 432 90L72 90c-19.8 0-35.8 16-36 35.7zm0 44.1l0 208.6c.2 19.7 16.3 35.5 36 35.5l360 0c19.9 0 36-16.1 36-36l0-208.2-173.6 122.9c-24.9 17.7-59.9 17.7-84.9 0L36 169.8z"],
    "at": [504, 540, [61946], "40", "M252 216a36 36 0 1 0 0 72 36 36 0 1 0 0-72zM0 252C0 112.8 112.8 0 252 0S504 112.8 504 252l0 36c0 69.6-56.4 126-126 126-15.7 0-30.9-1.2-45.9-6.3-2.6 1.8-5.3 3.4-8.1 5l0 55.3c0 39.8-32.2 72-72 72-139.2 0-252-112.8-252-252l0-36zm36 0c0 119.3 96.7 216 216 216 19.9 0 36-16.1 36-36s-16.1-36-36-36c-79.5 0-144-64.5-144-144s64.5-144 144-144 144 64.5 144 144c0 9.9-8.1 18-18 18s-18-8.1-18-18c0-59.6-48.4-108-108-108s-108 48.4-108 108 48.4 108 108 108c25.1 0 48.1-8.5 66.4-22.8 5.2-4.1 12.3-5 18.4-2.3 13.2 5.9 26.9 7.1 41.2 7.1 49.7 0 90-40.3 90-90 0-119.3-96.7-216-216-216S36 132.7 36 252z"],
    "truck": [504, 540, [128666, 9951], "f0d1", "M342 108l0 18 90 0c39.8 0 72 32.2 72 72l0 180c0 33.5-22.9 61.7-54 69.7 0 38.6-32.7 74.3-72 74.3-39.8 0-72-32.2-72-72l-108 0c0 39.8-32.2 72-72 72-41 0-72-34.2-72-74.3-31.1-8-54-36.2-54-69.7L0 108C0 68.2 32.2 36 72 36l198 0c39.8 0 72 32.2 72 72zM36 108l0 234c0 17.2 12 31.6 28.1 35.1 12.6-21 35.6-35.1 61.9-35.1 26.7 0 49.9 14.5 62.4 36l117.6 0 0-270c0-19.9-16.1-36-36-36L72 72c-19.9 0-36 16.1-36 36zM342 234l126 0 0-36c0-19.9-16.1-36-36-36l-90 0 0 72zm0 36l0 81.6c10.6-6.1 22.9-9.6 36-9.6 26.3 0 49.3 14.1 61.9 35.1 16.1-3.6 28.1-18 28.1-35.1l0-72-126 0zm0 144a36 36 0 1 0 72 0 36 36 0 1 0 -72 0zM126 450a36 36 0 1 0 0-72 36 36 0 1 0 0 72z"],
    "bell": [432, 540, [128276, 61602], "f0f3", "M162 180c0-29.8 24.2-54 54-54 9.9 0 18-8.1 18-18s-8.1-18-18-18c-49.7 0-90 40.3-90 90l0 18c0 9.9 8.1 18 18 18s18-8.1 18-18l0-18zM216 0C116.6 0 36 80.6 36 180l0 99.6C14.5 292.1 0 315.3 0 342l0 36c0 39.8 32.2 72 72 72l37.5 0c8.6 51.1 53 90 106.5 90s97.9-38.9 106.5-90l37.5 0c39.8 0 72-32.2 72-72l0-36c0-26.7-14.5-49.9-36-62.4l0-99.6C396 80.6 315.4 0 216 0zM396 342c0 19.9-16.1 36-36 36L72 378c-19.9 0-36-16.1-36-36 0-15.6 10-29 24-34 7.2-2.5 12-9.3 12-17L72 180c0-79.5 64.5-144 144-144s144 64.5 144 144l0 111.1c0 7.6 4.8 14.4 12 17 14 5 24 18.3 24 34zM216 468c-33.5 0-61.7-22.9-69.7-54l139.5 0c-8 31.1-36.2 54-69.7 54z"],
    "mobile": [324, 540, [128241, "mobile-android", "mobile-phone"], "f3ce", "M189 387c0 14.9-12.1 27-27 27s-27-12.1-27-27 12.1-27 27-27 27 12.1 27 27zM126 90c-9.9 0-18 8.1-18 18s8.1 18 18 18l72 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-72 0zM72 18C32.2 18 0 50.2 0 90L0 450c0 39.8 32.2 72 72 72l180 0c39.8 0 72-32.2 72-72l0-360c0-39.8-32.2-72-72-72L72 18zM288 414c0 19.9-16.1 36-36 36L72 450c-19.9 0-36-16.1-36-36L36 90c0-19.9 16.1-36 36-36l180 0c19.9 0 36 16.1 36 36l0 324z"],
    "trophy": [540, 540, [127942], "f091", "M540 201.6c0 26.6-14.7 51-38.1 63.5L400.1 319.4c-6 9.4-12.3 18-18.8 25.8 29.4 9.1 50.7 36.4 50.7 68.8l0 36c0 39.8-32.2 72-72 72l-180 0c-39.8 0-72-32.2-72-72l0-36c0-32.3 21.3-59.7 50.7-68.8-6.5-7.8-12.8-16.4-18.8-25.8L38.1 265.1C14.7 252.6 0 228.2 0 201.6L0 144c0-39.8 32.2-72 72-72l20.2 .1C100.2 41 128.4 18 162 18l216 0c33.6 0 61.8 23 69.8 54.1L468 72c39.8 0 72 32.2 72 72l0 57.6zM162 54c-19.9 0-36 16.1-36 36 0 70.1 16.1 144.6 62.7 198.9 13 15.2 26.2 26.2 37.6 34.1 4.9 3.4 7.8 8.9 7.8 14.8l0 22.2c0 9.9-8.1 18-18 18l-36 0c-19.9 0-36 16.1-36 36s16.1 36 36 36l180 0c19.9 0 36-16.1 36-36s-16.1-36-36-36l-36 0c-9.9 0-18-8.1-18-18l0-22.2c0-5.9 2.9-11.5 7.8-14.8 11.3-7.8 24.5-18.9 37.6-34.1 46.6-54.4 62.7-128.8 62.7-198.9 0-19.9-16.1-36-36-36L162 54zm306 54c-6.1 0-12.2 .1-18.3 0-1.7 47-9.9 86.7-22.2 120l57.5-30.7c11.7-6.3 19.1-18.5 19.1-31.8l0-21.6c0-19.9-16.1-36-36-36zM112.6 228C100.2 194.7 92 155 90.3 108L72 108c-19.9 0-36 16.1-36 36l0 21.6c0 13.3 7.3 25.5 19.1 31.8L112.6 228z"],
    "signal-bars-fair": [468, 540, ["signal-alt-2"], "f692", "M252 252c0-39.8-32.2-72-72-72s-72 32.2-72 72l0 9.6c-10.6-6.1-22.9-9.6-36-9.6-39.8 0-72 32.2-72 72L0 432c0 39.8 32.2 72 72 72 21.5 0 40.8-9.4 54-24.4 13.2 14.9 32.5 24.4 54 24.4 39.8 0 72-32.2 72-72l0-180zM216 396c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-144c0-19.9 16.1-36 36-36s36 16.1 36 36l0 144zM36 396l0-72c0-19.9 16.1-36 36-36s36 16.1 36 36l0 72c0 19.9-16.1 36-36 36s-36-16.1-36-36z"],
    "gift": [432, 540, [127873], "f06b", "M432 180c0-39.8-32.2-72-72-72l0-36c0-18.4-7-36.9-21.1-50.9-28.1-28.1-73.7-28.1-101.8 0L216 42.2 194.9 21.1C166.8-7 121.2-7 93.1 21.1 80.5 33.7 72 51.8 72 69.8L72 108c-39.8 0-72 32.2-72 72L0 432c0 39.8 32.2 72 72 72l288 0c39.8 0 72-32.2 72-72l0-252zM118.5 46.5c14.1-14.1 36.9-14.1 50.9 0l33.8 33.8c6.9 6.9 18.5 6.9 25.5 0l33.8-33.8c14.1-14.1 36.9-14.1 50.9 0s14.1 36.9 0 50.9l-10.5 10.5-173.8 0-10.5-10.5c-14.1-14.1-14.1-36.9 0-50.9zM72 144l72 0 0 126-108 0 0-90c0-19.9 16.1-36 36-36zm72 162l0 126-72 0c-19.9 0-36-16.1-36-36l0-90 108 0zM252 144l0 288-72 0 0-288 72 0zm36 126l0-126 72 0c19.9 0 36 16.1 36 36l0 90-108 0zm0 36l108 0 0 90c0 19.9-16.1 36-36 36l-72 0 0-126z"],
    "gauge": [504, 540, ["dashboard", "gauge-med", "tachometer-alt-average"], "f624", "M234 235.8c-41.1 8.3-72 44.7-72 88.2 0 49.7 40.3 90 90 90s90-40.3 90-90c0-43.5-30.9-79.9-72-88.2L270 108c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 127.8zM252 378a54 54 0 1 1 0-108 54 54 0 1 1 0 108zm72-225a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zM153 126a27 27 0 1 1 0 54 27 27 0 1 1 0-54zM378 243a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zM99 216a27 27 0 1 1 0 54 27 27 0 1 1 0-54zM0 252C0 112.8 112.8 0 252 0S504 112.8 504 252l0 36c0 139.2-112.8 252-252 252S0 427.2 0 288l0-36zm36 0a216 216 0 1 0 432 0 216 216 0 1 0 -432 0z"],
    "signal": [468, 540, [128246, "signal-5", "signal-perfect"], "f012", "M396 36c-39.8 0-72 32.2-72 72l0 9.6c-10.6-6.1-22.9-9.6-36-9.6-39.8 0-72 32.2-72 72l0 9.6c-10.6-6.1-22.9-9.6-36-9.6-39.8 0-72 32.2-72 72l0 9.6c-10.6-6.1-22.9-9.6-36-9.6-39.8 0-72 32.2-72 72L0 432c0 39.8 32.2 72 72 72 21.5 0 40.8-9.4 54-24.4 13.2 14.9 32.5 24.4 54 24.4s40.8-9.4 54-24.4c13.2 14.9 32.5 24.4 54 24.4s40.8-9.4 54-24.4c13.2 14.9 32.5 24.4 54 24.4 39.8 0 72-32.2 72-72l0-324c0-39.8-32.2-72-72-72zm-36 72c0-19.9 16.1-36 36-36s36 16.1 36 36l0 288c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-288zM252 180c0-19.9 16.1-36 36-36s36 16.1 36 36l0 216c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-216zM144 252c0-19.9 16.1-36 36-36s36 16.1 36 36l0 144c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-144zM36 324c0-19.9 16.1-36 36-36s36 16.1 36 36l0 72c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-72z"],
    "share-nodes": [504, 540, ["share-alt"], "f1e0", "M360 0c-51.9 0-95.3 36.6-105.6 85.4L142.2 149.5c-10.8-3.6-22.3-5.5-34.2-5.5-59.6 0-108 48.4-108 108l0 36c0 59.6 48.4 108 108 108 11.9 0 23.4-1.9 34.2-5.5l112.2 64.1c10.4 48.8 53.7 85.4 105.6 85.4 59.6 0 108-48.4 108-108l0-36c0-59.6-48.4-108-108-108-11.9 0-23.4 1.9-34.2 5.5l-41.2-23.5 41.2-23.5c10.8 3.6 22.3 5.5 34.2 5.5 59.6 0 108-48.4 108-108l0-36C468 48.4 419.6 0 360 0zm72 108c0 39.8-32.2 72-72 72-10.2 0-19.9-2.1-28.6-5.9-5.2-2.3-11.2-1.9-16.1 .9L207.9 236.4c-11.9 6.8-11.9 24.5 0 31.3L315.3 329c4.9 2.8 10.9 3.1 16.1 .9 8.7-3.8 18.4-5.9 28.6-5.9 39.8 0 72 32.2 72 72s-32.2 72-72 72c-36.7 0-67.1-27.5-71.5-63.1-.7-5.6-4-10.6-8.9-13.4L152.7 319c-4.9-2.8-10.9-3.1-16.1-.9-8.7 3.8-18.4 5.9-28.6 5.9-39.8 0-72-32.2-72-72s32.2-72 72-72c10.2 0 19.9 2.1 28.6 5.9 5.2 2.3 11.2 1.9 16.1-.9l126.9-72.5c4.9-2.8 8.2-7.8 8.9-13.4 4.4-35.5 34.7-63.1 71.5-63.1 39.8 0 72 32.2 72 72z"],
    "percent": [432, 540, [62101, 62785, "percentage"], "25", "M108 36C48.4 36 0 84.4 0 144l0 36c0 50.5 34.6 92.9 81.5 104.7L21.1 345.1C7 359.1 0 377.6 0 396l0 36c0 18.4 7 36.9 21.1 50.9 28.1 28.1 73.7 28.1 101.8 0l93.1-93.1 0 6.2c0 59.6 48.4 108 108 108s108-48.4 108-108l0-36c0-50.5-34.6-92.9-81.5-104.7l60.4-60.4C425 180.9 432 162.4 432 144l0-36c0-18.4-7-36.9-21.1-50.9-28.1-28.1-73.7-28.1-101.8 0l-93.1 93.1 0-6.2c0-59.6-48.4-108-108-108zM396 360a72 72 0 1 1 -144 0 72 72 0 1 1 144 0zM334.5 82.5c14.1-14.1 36.9-14.1 50.9 0s14.1 36.9 0 50.9l-288 288c-14.1 14.1-36.9 14.1-50.9 0s-14.1-36.9 0-50.9l288-288zM180 144a72 72 0 1 1 -144 0 72 72 0 1 1 144 0z"],
    "magnifying-glass": [504, 540, [128269, "search"], "f002", "M306 225a99 99 0 1 1 -198 0 99 99 0 1 1 198 0zm-38.6 18c-7.8-26-31.9-45-60.4-45s-52.6 18.9-60.4 45c7.7 26 31.9 45 60.4 45s52.7-19 60.4-45zm137.7 78.3c5.8-19.1 8.9-39.3 8.9-60.3l0-36c0-114.3-92.7-207-207-207S0 110.7 0 225l0 36c0 114.3 92.7 207 207 207 30.8 0 60.1-6.7 86.4-18.8l69.7 69.7c28.1 28.1 73.7 28.1 101.8 0 14.1-14.1 21.1-32.5 21.1-50.9l0-36c0-18.4-7-36.9-21.1-50.9l-59.8-59.8zM207 396a171 171 0 1 1 0-342 171 171 0 1 1 0 342zm232.5 10.5c14.1 14.1 14.1 36.9 0 50.9s-36.9 14.1-50.9 0l-62.8-62.8c19.8-13.9 37-31.1 50.9-50.9l62.8 62.8z"],
    "palette": [504, 540, [127912], "f53f", "M252 144a27 27 0 1 0 0-54 27 27 0 1 0 0 54zM90 252a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zm238.4-76.4a27 27 0 1 0 38.2-38.2 27 27 0 1 0 -38.2 38.2zM137.4 328.4a27 27 0 1 1 38.2 38.2 27 27 0 1 1 -38.2-38.2zm0-152.7a27 27 0 1 0 38.2-38.2 27 27 0 1 0 -38.2 38.2zM252 0C112.8 0 0 112.8 0 252l0 36C0 427.2 112.8 540 252 540l18 0c31.7 0 59.7-20.8 68.9-51.1 2-6.6 3-13.5 3.1-20.2l0-35.8c.3-23.9-11.4-47-32.1-60.8l-12.2-8.2c3.5-2.4 7.5-3.9 12.1-3.9L432 360c39.8 0 72-32.2 72-72l0-36C504 112.8 391.2 0 252 0zm0 36c119.3 0 216 96.7 216 216 0 19.9-16.1 36-36 36l-122.2 0c-31.9 0-57.8 25.9-57.8 57.8 0 19.3 9.7 37.4 25.7 48.1L290 402c10.1 6.8 15.9 18.2 16 30-.2 19.3-16.5 36-36 36l-18 0C132.7 468 36 371.3 36 252S132.7 36 252 36z"],
    "key": [504, 540, [128273], "f084", "M414 162a72 72 0 1 1 -144 0 72 72 0 1 1 144 0zm-40.8 18c-6.3-10.8-17.9-18-31.2-18s-24.9 7.2-31.2 18c6.2 10.8 17.9 18 31.2 18s25-7.2 31.2-18zM144 180C144 80.6 224.6 0 324 0S504 80.6 504 180l0 36c0 99.4-80.6 180-180 180l-72 0 0 23.3c0 12.9-5.1 25.3-14.3 34.5S216.2 468 203.3 468l-23.3 0 0 25.8c0 11.3-4.5 22.1-12.5 30.1-10.3 10.3-24.2 16.1-38.8 16.1L72 540c-39.8 0-72-32.2-72-72l0-85.6c0-19.1 7.6-37.4 21.1-50.9L146 206.6c-1.3-8.7-2-17.6-2-26.6zm0 277.8l0-43.8c0-9.9 8.1-18 18-18l41.3 0c6.8 0 12.7-6 12.7-12.7l0-41.3c0-9.9 8.1-18 18-18l90 0c79.5 0 144-64.5 144-144S403.5 36 324 36 180 100.5 180 180c0 10 1 19.7 2.9 29.1 1.2 5.9-.6 12.1-4.9 16.3L46.5 356.9C39.8 363.7 36 372.8 36 382.4L36 432c0 19.9 16.1 36 36 36l56.7 0c5.5 0 15.3-3.3 15.3-10.2z"],
    "skull": [468, 540, [128128], "f54c", "M144 126a72 72 0 1 0 0 144 72 72 0 1 0 0-144zm31.2 90c-6.2 10.8-17.9 18-31.2 18s-25-7.2-31.2-18c6.2-10.8 17.9-18 31.2-18s25 7.2 31.2 18zM396 198a72 72 0 1 1 -144 0 72 72 0 1 1 144 0zm-40.8 18c-6.2-10.8-17.9-18-31.2-18s-25 7.2-31.2 18c6.2 10.8 17.9 18 31.2 18s25-7.2 31.2-18zM246.7 275.3l36 36c7 7 7 18.4 0 25.5s-18.4 7-25.5 0l-23.3-23.3-23.3 23.3c-7 7-18.4 7-25.5 0s-7-18.4 0-25.5l36-36c7-7 18.4-7 25.5 0zM0 234C0 104.8 104.8 0 234 0S468 104.8 468 234l0 36c0 66.4-27.6 126.3-72 168.9l0 29.1c0 39.8-32.2 72-72 72l-180 0c-39.8 0-72-32.2-72-72l0-29.1C27.6 396.3 0 336.4 0 270l0-36zm36 0c0 58.6 25.5 111.3 66 147.6 3.8 3.4 6 8.3 6 13.4l0 37c0 19.9 16.1 36 36 36l0-54c0-9.9 8.1-18 18-18s18 8.1 18 18l0 54 36 0 0-54c0-9.9 8.1-18 18-18s18 8.1 18 18l0 54 36 0 0-54c0-9.9 8.1-18 18-18s18 8.1 18 18l0 54c19.9 0 36-16.1 36-36l0-37c0-5.1 2.2-10 6-13.4 40.5-36.3 66-88.9 66-147.6 0-109.4-88.6-198-198-198S36 124.6 36 234z"],
    "tree": [396, 540, [127794], "f1bb", "M221.1 44.3l108 90c8.4 7 13 17.2 13 27.7-.2 19.3-16.5 36-36 36l-25 0c-7.5 0-14.3 4.7-16.9 11.8s-.6 15 5.2 19.9l78.2 67c11.4 9.8 15.6 25.7 10.3 39.8S339.1 360 324 360L72 360c-15.1 0-28.5-9.4-33.8-23.5s-1.1-30 10.3-39.8l78.2-67c5.7-4.9 7.8-12.8 5.2-19.9S122.6 198 115 198l-25 0c-19.5 0-35.8-16.7-36-36 0-10.5 4.6-20.7 13-27.7l108-90c13.4-11.1 32.7-11.1 46.1 0zM43.9 106.7C27 120.8 17.8 141.5 18 162.8L18 198c0 8.2 1.4 16.5 4.3 24.5 4.4 12.3 12 22.8 21.6 30.8L25.1 269.3C8.8 283.4-.1 303.6 0 324.4L0 360c0 8.4 1.5 16.8 4.5 25 10.5 28.3 37.4 47 67.5 47l54 0 0 36c0 39.8 32.2 72 72 72s72-32.2 72-72l0-36 54 0c30.1 0 57.1-18.8 67.5-47 3-8.2 4.5-16.6 4.5-25l0-35.6c.1-20.7-8.8-41-25.1-55l-18.7-16.1c9.6-8 17.1-18.5 21.6-30.8 2.9-8 4.3-16.3 4.3-24.5l0-35.3c.2-21.2-9-41.9-25.9-56l-108-90c-26.7-22.3-65.5-22.3-92.2 0l-108 90zM234 432c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-36 72 0 0 36z"],
    "flower": [504, 540, [127804, 10047], "f7ff", "M353.3 68.7c3.2 13 4 26.8 2.5 40.7 12.8-5.7 26.2-9.2 39.5-10.2 36.1-2.6 71.5 13.8 88.6 53.7 5.9 13.9 10.6 28.3 14 43 1.9 8.4 2.5 16.8 2.5 25.5l0 34.5c-1.1 37.5-26.7 67-60.6 80.5 .7 1.5 1.3 3 1.9 4.5 4.8 11.9 7.2 24.3 7.2 37.1l0 36.2c-.6 24.8-12.3 47.3-30.8 63.5-11.3 9.9-23.6 18.9-36.6 26.6-37.3 22.3-75.6 14.7-103.2-8.6-10.2-8.6-19-19.3-26-31.5-7 12.2-15.8 22.9-26 31.5-27.7 23.3-65.9 30.9-103.2 8.6-12.9-7.7-25.2-16.6-36.6-26.6-18.6-16.2-30.3-38.8-30.9-63.6l0-36.2c0-12.8 2.4-25.2 7.2-37.1 .6-1.5 1.3-3 1.9-4.5-34-13.5-59.5-43-60.6-80.6l0-34.5c0-8.6 .6-17 2.5-25.4 3.3-14.7 8-29.1 14-43.1 17-39.9 52.5-56.3 88.6-53.7 13.3 1 26.7 4.5 39.5 10.2-1.5-13.9-.7-27.8 2.5-40.8 8.7-35.1 35.2-63.7 78.4-67.7 15-1.4 30.2-1.4 45.3 0 43.3 3.9 69.8 32.6 78.4 67.7zM91.5 378.2c.5 13.1 6.2 25.7 18.5 36.4 9.8 8.5 20.3 16.2 31.4 22.8 22.5 13.4 44.2 9.4 61.6-5.3 21.3-18 31.2-46.4 31.2-73.7-33.8-5.7-62.4-27.1-77.7-56.5-25.9 8.4-49.9 26.7-60.4 52.5-3.1 7.7-4.5 15.5-4.5 23.8zm321.4 0c0-8.2-1.4-16.1-4.5-23.8-10.5-25.8-34.5-44-60.4-52.4-15.4 29.4-43.9 50.8-77.7 56.5 0 27.3 9.9 55.7 31.2 73.7 17.4 14.7 39.1 18.7 61.5 5.3 11.2-6.7 21.7-14.3 31.4-22.8 12.3-10.8 18.1-23.4 18.5-36.4zm-208.7-223c14.5-7.2 30.8-11.2 48-11.2s33.6 4 48 11.2c16-22.1 24.7-50.9 18.1-78-5.5-22.1-20.6-38.1-46.7-40.5-12.9-1.2-25.9-1.1-38.8 0-26.1 2.4-41.3 18.4-46.7 40.5-6.7 27.1 2.1 55.9 18.1 77.9zm156 96.8c0 5.4-.4 10.6-1.1 15.8 25.9 8.4 56.1 7.8 79.7-6.9 19.3-12 29.9-31.4 24-56.9-2.9-12.7-6.9-25-12-36.9-10.3-24.1-30.2-33.6-52.9-31.9-27.8 2-52.5 19.2-68.5 41.3 19.1 19.5 30.8 46.2 30.8 75.6zM145.4 267.8c-.8-5.2-1.1-10.4-1.1-15.8 0-29.4 11.8-56.1 30.8-75.6-16-22.1-40.8-39.3-68.6-41.3-22.7-1.6-42.6 7.8-52.9 31.9-5.1 12-9.1 24.3-12 36.9-5.8 25.5 4.7 44.9 24 56.9 23.7 14.7 53.8 15.3 79.7 6.9zM252.2 180a72 72 0 1 0 0 144 72 72 0 1 0 0-144z"],
    "camera": [504, 540, [62258, "camera-alt"], "f030", "M360 234a108 108 0 1 1 -216 0 108 108 0 1 1 216 0zM182.3 252c8 31.1 36.2 54 69.7 54s61.7-22.9 69.7-54c-8-31.1-36.2-54-69.7-54s-61.7 22.9-69.7 54zM0 162L0 396c0 39.8 32.2 72 72 72l360 0c39.8 0 72-32.2 72-72l0-234c0-39.8-32.2-72-72-72l-13.6 0c-9.5 0-18.7-3.8-25.5-10.5L352.5 39.1C339 25.6 320.7 18 301.6 18l-99.3 0c-19.1 0-37.4 7.6-50.9 21.1L111.1 79.5C104.3 86.2 95.2 90 85.6 90L72 90C32.2 90 0 122.2 0 162zm36 0c0-19.9 16.1-36 36-36l13.6 0c19.1 0 37.4-7.6 50.9-21.1l40.4-40.4c6.8-6.8 15.9-10.5 25.5-10.5l99.3 0c9.5 0 18.7 3.8 25.5 10.5l40.4 40.4C381 118.4 399.3 126 418.4 126l13.6 0c19.9 0 36 16.1 36 36l0 198c0 19.9-16.1 36-36 36L72 396c-19.9 0-36-16.1-36-36l0-198z"],
    "eye": [504, 540, [128065], "f06e", "M252 162a90 90 0 1 0 0 180 90 90 0 1 0 0-180zm0 144c-23.6 0-43.7-15.2-51-36.3 11.2-20.3 25.9-35.7 51-35.7s39.8 15.5 51 35.7c-7.3 21.1-27.4 36.3-51 36.3zM246.2 54c-63.1 0-123 27.6-164 75.4L17.3 205.1C5.8 218.6 0 235.3 0 252l0 36c0 16.7 5.8 33.4 17.3 46.9l64.9 75.7c41 47.9 100.9 75.4 164 75.4l11.5 0c63.1 0 123-27.6 164-75.4l64.9-75.7C498.2 321.4 504 304.7 504 288l0-36c0-16.7-5.8-33.4-17.3-46.9l-64.9-75.7C380.7 81.6 320.8 54 257.8 54l-11.5 0zM468 252c0 8.4-2.9 16.7-8.7 23.4l-64.9 75.7C360.2 391 310.3 414 257.8 414l-11.5 0c-52.5 0-102.5-23-136.7-62.9L44.7 275.4C38.9 268.7 36 260.4 36 252s2.9-16.7 8.7-23.4l64.9-75.7C143.8 113 193.7 90 246.2 90l11.5 0c52.5 0 102.5 23 136.7 62.9l64.9 75.7c5.8 6.7 8.7 15.1 8.7 23.4z"],
    "trash": [432, 540, [], "f1f8", "M180 288c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 18c0 19.9 16.1 36 36 36l72 0c19.9 0 36-16.1 36-36l0-18c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 18-72 0 0-18zM0 144c0-41 34.2-72 74.3-72 8-31.1 36.2-54 69.7-54l144 0c33.5 0 61.7 22.9 69.7 54 40.1 0 74.3 31 74.3 72l0 36c0 29.3-17.5 54.5-42.5 65.7L377.9 454c-2.1 38.2-33.7 68-71.9 68l-180 0c-38.2 0-69.8-29.9-71.9-68L42.5 245.7C17.5 234.5 0 209.3 0 180l0-36zm396 0c0-19.9-16.1-36-36-36l-18 0c-9.8 0-18-8.2-18-18 0-19.9-16.1-36-36-36L144 54c-19.9 0-36 16.1-36 36 0 9.9-8.1 18-18 18l-18 0c-19.9 0-36 16.1-36 36s16.1 36 36 36l288 0c19.9 0 36-16.1 36-36zM78.9 216L90.1 416c1.1 19.1 16.8 34 35.9 34l180 0c19.1 0 34.9-14.9 35.9-34l11.1-200-274.1 0z"],
    "equals": [432, 540, [62764], "3d", "M0 144c0-39.8 32.2-72 72-72l288 0c39.8 0 72 32.2 72 72l0 36c0 39.8-32.2 72-72 72L72 252c-39.8 0-72-32.2-72-72l0-36zm36 0c0 19.9 16.1 36 36 36l288 0c19.9 0 36-16.1 36-36s-16.1-36-36-36L72 108c-19.9 0-36 16.1-36 36zM0 360c0-39.8 32.2-72 72-72l288 0c39.8 0 72 32.2 72 72l0 36c0 39.8-32.2 72-72 72L72 468c-39.8 0-72-32.2-72-72l0-36zm36 0c0 19.9 16.1 36 36 36l288 0c19.9 0 36-16.1 36-36s-16.1-36-36-36L72 324c-19.9 0-36 16.1-36 36z"],
    "expand": [432, 540, [], "f065", "M0 234c0 13.1 3.5 25.4 9.6 36-6.1 10.6-9.6 22.9-9.6 36L0 432c0 39.2 32.8 72 72 72l90 0c21.5 0 40.8-9.4 54-24.4 13.2 14.9 32.5 24.4 54 24.4l90 0c39.2 0 72-32.8 72-72l0-126c0-13.1-3.5-25.4-9.6-36 6.1-10.6 9.6-22.9 9.6-36l0-126c0-39.2-32.8-72-72-72l-90 0c-21.5 0-40.8 9.4-54 24.4-13.2-14.9-32.5-24.4-54-24.4L72 36C32.8 36 0 68.8 0 108L0 234zM36 108c0-19.6 16.4-36 36-36l90 0c19.9 0 36 16.1 36 36s-16.1 36-36 36l-36 0c-9.8 0-18 8.2-18 18l0 36c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-90zM72 270c19.8 0 36 16.3 36 36l0 36c0 9.8 8.2 18 18 18l36 0c19.9 0 36 16.1 36 36s-16.1 36-36 36l-90 0c-19.6 0-36-16.4-36-36l0-90c0-19.7 16.2-36 36-36zm324-72c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-36c0-9.8-8.2-18-18-18l-36 0c-19.9 0-36-16.1-36-36s16.1-36 36-36l90 0c19.6 0 36 16.4 36 36l0 90zm-36 72c19.8 0 36 16.3 36 36l0 90c0 19.6-16.4 36-36 36l-90 0c-19.9 0-36-16.1-36-36s16.1-36 36-36l36 0c9.8 0 18-8.2 18-18l0-36c0-19.7 16.2-36 36-36zm-62.4 0c-6.1 10.6-9.6 22.9-9.6 36l0 18-18 0c-21.5 0-40.8 9.4-54 24.4-13.2-14.9-32.5-24.4-54-24.4l-18 0 0-18c0-13.1-3.5-25.4-9.6-36 6.1-10.6 9.6-22.9 9.6-36l0-18 18 0c21.5 0 40.8-9.4 54-24.4 13.2 14.9 32.5 24.4 54 24.4l18 0 0 18c0 13.1 3.5 25.4 9.6 36z"],
    "stop": [432, 540, [9209], "f04d", "M72 36C32.2 36 0 68.2 0 108L0 432c0 39.8 32.2 72 72 72l288 0c39.8 0 72-32.2 72-72l0-324c0-39.8-32.2-72-72-72L72 36zm324 72l0 288c0 19.9-16.1 36-36 36L72 432c-19.9 0-36-16.1-36-36l0-288c0-19.9 16.1-36 36-36l288 0c19.9 0 36 16.1 36 36z"],
    "angle-left": [324, 540, [8249], "f104", "M0 251.9c0-18.4 7-36.8 21.1-50.9l144-144C193.2 29 238.8 29 266.9 57.1 280.3 70.5 288 89 288 108l0 36c0 18.4-7 36.9-21.1 50.9l-75.1 75.1 75.1 75.1C280.3 358.5 288 377 288 396l0 36.1c0 18.4-7 36.8-21.1 50.9-28.1 28.1-73.7 28.1-101.8 0l-144-144C7 324.9 0 306.4 0 288l0-36.1zM241.5 421.5c14-14 14-36.9 0-50.9L135.6 264.7c-6.9-6.9-6.9-18.5 0-25.5L241.5 133.5c14-14 14-37 0-50.9-14.1-14.1-36.9-14.1-50.9 0l-144 144c-14.1 14.1-14.1 36.9 0 50.9l144 144c14.1 14.1 36.9 14.1 50.9 0z"],
    "circle-half-stroke": [504, 540, [9680, "adjust"], "f042", "M0 288C0 348.4 21.2 403.8 56.7 447.2 102.9 503.8 173.2 540 252 540 391.2 540 504 427.2 504 288 504 153.9 399.2 44.2 267 36.4 259.6 15.2 239.1-1 213.4 2.9 92.5 21.5 0 125.9 0 252l0 36zM218.9 38.5C225.7 37.5 234 43.2 234 54l0 396C234 460.8 225.7 466.5 218.9 465.5 115.3 449.5 36 360 36 252S115.3 54.5 218.9 38.5zM468 288c0 114.2-88.7 207.8-201 215.5 1.9-5.6 3-11.5 3-17.5l0-55.1C341 422 396 361.4 396 288S341 154 270 145.1l0-72.4c110.9 9.1 198 102 198 215.3zM270 394.5l0-213c51.1 8.6 90 53 90 106.5s-38.9 97.9-90 106.5z"],
    "clock": [504, 540, [128339, "clock-four"], "f017", "M270 108c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 129.1c0 14.3 5.7 28.1 15.8 38.2l61.5 61.5c7 7 18.4 7 25.5 0s7-18.4 0-25.5l-61.5-61.5c-3.4-3.4-5.3-8-5.3-12.7L270 108zM252 0C112.8 0 0 112.8 0 252l0 36C0 427.2 112.8 540 252 540S504 427.2 504 288l0-36C504 112.8 391.2 0 252 0zm0 468a216 216 0 1 1 0-432 216 216 0 1 1 0 432z"],
    "book": [396, 540, [128212], "f02d", "M198 162c-9.9 0-18 8.1-18 18s8.1 18 18 18l90 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-90 0zm-18 72c-9.9 0-18 8.1-18 18s8.1 18 18 18l126 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-126 0zM72 36C32.2 36 0 68.2 0 108L0 432c0 39.8 32.2 72 72 72l252 0c39.8 0 72-32.2 72-72l0-324c0-39.8-32.2-72-72-72L72 36zm0 36l18 0 0 360-18 0c-19.9 0-36-16.1-36-36l0-288c0-19.9 16.1-36 36-36zm54 0l198 0c19.9 0 36 16.1 36 36l0 288c0 19.9-16.1 36-36 36l-198 0 0-360z"],
    "paper-plane": [540, 540, [61913], "f1d8", "M33 46C22.9 59.1 17.9 74.9 18 90.6l0 35.9c.1 15.4 5.2 30.9 15.2 43.7l77.6 99.8-77.6 99.8C23.1 382.8 18 398.4 18 414l0 36c0 15.5 5 31 15 44 20.1 26 55.2 35.1 85.4 22.2l378-162C522.8 342.8 540 316.8 540 288l0-36c0-28.8-17.2-54.8-43.6-66.2l-378-162C88.2 10.9 53.1 20 33 46zm71.2 10.9l378 162c13.2 5.7 21.8 18.7 21.8 33.1s-8.6 27.4-21.8 33.1l-378 162c-15.1 6.5-32.6 1.9-42.7-11.1-10-12.9-10-31.1 .1-44.1 31.6-40.6 63.2-81.3 94.8-121.9L306 270c9.9 0 18-8.1 18-18s-8.1-18-18-18l-149.6 0-94.8-121.9c-5-6.4-7.5-14-7.6-21.7 0-8.1 2.5-16 7.5-22.4 10-13 27.6-17.6 42.7-11.1z"],
    "heart": [504, 540, [128153, 128154, 128155, 128156, 128420, 129293, 129294, 129505, 9829, 10084, 61578], "f004", "M36 180c0 32.6 12.9 63.9 36 86.9L226.5 421.5c6.8 6.8 15.9 10.5 25.5 10.5s18.7-3.8 25.5-10.5L432 266.9c23.1-23.1 36-54.3 36-86.9 0-59.6-48.4-108-108-108-39.3 0-73.7 20.9-92.6 52.4-3.3 5.4-9.1 8.7-15.4 8.7s-12.2-3.3-15.4-8.7C217.7 92.9 183.3 72 144 72 84.4 72 36 120.4 36 180zM0 180c0-79.5 64.5-144 144-144 43 0 81.6 18.9 108 48.8 26.4-29.9 65-48.8 108-48.8 79.5 0 144 64.5 144 144l0 36c0 42.1-16.7 82.6-46.5 112.4L302.9 482.9C289.4 496.4 271.1 504 252 504s-37.4-7.6-50.9-21.1L46.5 328.4C16.7 298.6 0 258.1 0 216l0-36z"],
    "font-awesome": [432, 540, [62501, 62694, "font-awesome-flag", "font-awesome-logo-full"], "f2b4", "M431.9 184c-.5 8.3-2.4 16.5-5.7 24.3l-21.7 43.7 21.7 43.6c3.9 9.1 5.8 18.7 5.8 28.4l-.2 40.9c-2.5 37-34.2 67.1-71.8 67.1l-216 0 0 18c0 39.8-32.2 72-72 72S0 489.8 0 450L0 90c0-39.8 32.2-72 72-72 33.5 0 61.7 22.9 69.7 54L360 72c39.6 0 72 33 72 72l-.1 40zM144 108l0 252 216 0c28.5 0 42.3-28.6 32.2-52.1l-32.9-65.8c-2.5-5.1-2.5-11 0-16.1l32.9-65.8c10.1-23.5-3.7-52.1-32.2-52.1l-216 0zM72 450c19.9 0 36-16.1 36-36l0-324c0-19.9-16.1-36-36-36S36 70.1 36 90l0 324c0 19.9 16.1 36 36 36z"],
    "forward": [576, 540, [9193], "f04e", "M288 189L151.2 86.4c-21.8-16.4-51-19-75.4-6.8S36 116.7 36 144l0 252c0 27.3 15.4 52.2 39.8 64.4s53.6 9.6 75.4-6.8L288 351 288 396c0 27.3 15.4 52.2 39.8 64.4s53.6 9.6 75.4-6.8l144-108C565.3 332 576 310.7 576 288l0-36c0-22.7-10.7-44-28.8-57.6l-144-108c-21.8-16.4-51-19-75.4-6.8S288 116.7 288 144l0 45zM129.6 115.2l144 108C282.7 230 288 240.7 288 252s-5.3 22-14.4 28.8l-144 108c-10.9 8.2-25.5 9.5-37.7 3.4S72 373.6 72 360l0-216c0-13.6 7.7-26.1 19.9-32.2s26.8-4.8 37.7 3.4zM324 144c0-13.6 7.7-26.1 19.9-32.2s26.8-4.8 37.7 3.4l144 108C534.7 230 540 240.7 540 252s-5.3 22-14.4 28.8l-144 108c-10.9 8.2-25.5 9.5-37.7 3.4S324 373.6 324 360l0-216z"],
    "triangle": [504, 540, [9650], "f2ec", "M252 18c-26.1 0-50.2 14.2-62.9 37L9.1 379C3 389.9 0 402 0 414.1l0 35.9C0 489 32.7 522 72 522l360 0c39.3 0 72-33 72-72.1l0-36c0-12-3-24.1-9.1-34.9L314.9 55C302.2 32.2 278.1 18 252 18zm0 36c13.1 0 25.1 7.1 31.5 18.5l180 324c6.2 11.2 6 24.7-.4 35.7S444.8 450 432 450L72 450c-12.8 0-24.6-6.8-31-17.7-6.3-10.7-6.7-24.5-.4-35.7l180-324C226.9 61.1 238.9 54 252 54z"],
    "star-half": [504, 540, [61731], "f089", "M34.9 287.7c22.3 18.5 40.2 33.5 53.7 44.7L76.6 380c-1.5 5.9-2.2 11.9-2.2 17.8l0 35.6 0 0c0 22.7 10.7 44.7 29.7 58.5 23.8 17.3 55.8 18.4 80.7 2.7L245 456.6c15.7-9.9 25.2-27.1 25.2-45.7l0-374.9c0-9.8-4-19.3-11.3-25.8-7.6-6.8-18.8-10.2-30.3-6.2-19.4 6.7-35.4 21.5-43.3 41.3l-29.6 74-79.5 5.3c-29.4 2-54.6 21.6-63.7 49.6-2.4 7.3-3.5 14.7-3.5 22.1l0 36.4 0 .1c.1 20.9 9.3 41.2 25.9 55zM234.2 40.8l0 334.1c0 6.2-3.2 11.9-8.4 15.2l-60.2 37.9c-12.5 7.8-28.4 7.3-40.3-1.3-5.2-3.8-9.2-8.8-11.7-14.4-3.2-7.2-4.1-15.5-2-23.5l22.3-88.2c1.7-6.7-.6-13.8-5.9-18.2L58 224c-8.4-7-13-17.3-13-27.8 0-3.7 .6-7.3 1.8-10.9 4.5-14 17.2-23.8 31.9-24.8l90.8-6c6.9-.5 12.9-4.8 15.5-11.3l33.8-84.5c3.1-7.7 8.6-13.9 15.4-17.8z"],
    "arrow-down-to-line": [360, 540, ["arrow-to-bottom"], "f33d", "M342 216.4c.1-9.4-1.7-18.9-5.5-28-11.1-26.9-37.4-44.4-66.5-44.4l-18 0 0-54c0-39.8-32.2-72-72-72s-72 32.2-72 72l0 54-18 0c-29.1 0-55.4 17.5-66.5 44.4-3.8 9.1-5.5 18.6-5.5 28l0 35.9c.1 18.6 7.4 36.9 21.1 50.6L78.2 342 72 342c-39.8 0-72 32.2-72 72l0 36c0 39.8 32.2 72 72 72l216 0c39.8 0 72-32.2 72-72l0-36c0-39.8-32.2-72-72-72l-6.2 0 39.1-39.1c13.7-13.7 21-31.9 21.1-50.5l0-36zm-36-.6c0 9.3-3.7 18.7-10.5 25.6l-90 90c-14.1 14.1-36.8 14.1-50.9 0l-90-90c-6.8-6.8-10.5-16.3-10.5-25.6 0-4.6 .9-9.2 2.7-13.7 5.6-13.5 18.7-22.2 33.3-22.2l36 0c9.8 0 18-8.2 18-18l0-72c0-19.9 16.1-36 36-36s36 16.1 36 36l0 72c0 9.9 8.1 18 18 18l36 0c14.6 0 27.7 8.8 33.3 22.2 1.8 4.4 2.7 9.1 2.7 13.7zM72 378l216 0c19.9 0 36 16.1 36 36s-16.1 36-36 36L72 450c-19.9 0-36-16.1-36-36s16.1-36 36-36z"],
    "fire": [396, 540, [128293], "f06d", "M164.1 235.3c-7.5-10.1-23.4-9.3-29.9 1.5l-12.5 20.9c-8.8 14.6-13.4 31.3-13.4 48.3 0 49.3 40.9 90 91.1 90 49 0 88.9-39.8 88.9-87.8 0-6.7-1-13.3-2.2-19.9-1.8-9.8-11.5-16.4-21.3-14.4-38 7.7-77.6-7.4-100.7-38.5zm-11.5 40.8c28.1 25.8 64.2 37.5 99.6 35.5-1.8 26.4-24.6 48.4-52.8 48.4-30.6 0-55.1-24.9-55.1-54 0-10.5 2.9-20.9 8.3-29.9zm42.6-273C167.1-25 121.5-25 93.4 3.1 77.1 19.3 70.3 41.4 72.8 62.5l3.6 32.1c1.7 15.7-1.7 31.5-9.8 45L29.1 202.1C10.2 233.5 .3 269.4 .3 306l0 36c0 110.2 90.6 198 199.1 198 107.3 0 196.9-86.9 196.9-195.8 0-13 .7-26.2 0-39.1-.2-10.7-1.2-21.4-3.1-31.9l-16-88c-5.4-29.5-28.4-52.6-57.9-58-25.1-4.6-50.4 4.5-66.9 23.2l0-9.5c0-51.7-20.5-101.3-57.1-137.8zM360.3 308.2c0 88.7-73 159.8-160.9 159.8-89.1 0-163.1-72.1-163.1-162 0-30.1 8.2-59.6 23.7-85.4l37.5-62.4c12.2-20.3 17.3-44 14.7-67.5l-3.6-32.3c-1.3-10.6 2.2-21.7 10.3-29.8 14.1-14.1 36.9-14.1 50.9 0 29.8 29.8 46.5 70.2 46.5 112.4l0 34.5c0 27.4 38.1 39.2 52.8 14.6l6.3-10.5c7.7-12.9 22.6-19.6 37.3-16.9s26.3 14.2 29 29l16 88c1.7 9.4 2.6 19 2.6 28.6z"],
    "rectangle-vertical": [360, 540, ["rectangle-portrait"], "f2fb", "M0 90C0 50.2 32.2 18 72 18l216 0c39.8 0 72 32.2 72 72l0 360c0 39.8-32.2 72-72 72L72 522c-39.8 0-72-32.2-72-72L0 90zm36 0l0 324c0 19.9 16.1 36 36 36l216 0c19.9 0 36-16.1 36-36l0-324c0-19.9-16.1-36-36-36L72 54C52.1 54 36 70.1 36 90z"],
    "print": [504, 540, [128424, 128438, 9113], "f02f", "M387 252a27 27 0 1 0 0-54 27 27 0 1 0 0 54zM126 72c0-39.8 32.2-72 72-72L306 0c39.8 0 72 32.2 72 72l0 54c69.6 0 126 56.4 126 126l0 126c0 39.8-32.2 72-72 72l-54 0c0 39.8-32.2 72-72 72l-108 0c-39.8 0-72-32.2-72-72l-54 0c-39.8 0-72-32.2-72-72L0 252c0-69.6 56.4-126 126-126l0-54zm216 0c0-19.9-16.1-36-36-36L198 36c-19.9 0-36 16.1-36 36l0 54 180 0 0-54zM36 252l0 90c0 19.9 16.1 36 36 36l54 0 0-36c0-39.8 32.2-72 72-72l108 0c39.8 0 72 32.2 72 72l0 36 54 0c19.9 0 36-16.1 36-36l0-90c0-49.7-40.3-90-90-90l-252 0c-49.7 0-90 40.3-90 90zm126 90l0 72c0 19.9 16.1 36 36 36l108 0c19.9 0 36-16.1 36-36l0-72c0-19.9-16.1-36-36-36l-108 0c-19.9 0-36 16.1-36 36z"],
    "users": [504, 540, [], "f0c0", "M432 216c0 14.8-3.6 28.7-9.9 41 36.1 21.2 64 55.8 76.1 98.2 2.8 9.7 5.8 19.2 5.8 29.4l0 36c0 36.1-29.3 65.4-65.4 65.4L66.1 486C29.6 486 0 456.4 0 419.9l0-36c0-11 3.3-21.5 6-32 12.1-48.4 43.3-88.1 84.3-111.8-11.5-17.2-18.2-37.8-18.2-60.1l0-36c0-59.6 48.4-108 108-108 48.5 0 89.5 31.9 103.2 75.9 15.8-13.6 36.3-21.9 58.8-21.9 49.7 0 90 40.3 90 90l0 36zM108 144a72 72 0 1 0 144 0 72 72 0 1 0 -144 0zM468 384.6c0-6.7-2.6-13.2-4.4-19.5-16.1-56.3-67.5-95.1-126.1-95.1-9.1 0-18 .9-26.6 2.7 20.4 21.7 35.5 48.7 43.1 79.2 2.6 10.5 6 21.1 6 32 0 10.8-2.6 21.1-7.2 30.1l85.9 0c16.2 0 29.3-13.2 29.4-29.4zM293.9 414c16.6 0 30.1-13.5 30.1-30.1 0-7.9-3-15.8-4.9-23.3-16-63.8-73.3-108.6-139.1-108.6S56.9 296.8 40.9 360.6C39 368.1 36 376.1 36 383.9 36 400.5 49.5 414 66.1 414l227.8 0zM342 126a54 54 0 1 0 0 108 54 54 0 1 0 0-108z"],
    "alarm-clock": [504, 540, [9200], "f34e", "M252 126c9.9 0 18 8.1 18 18l0 100.5 48.7 48.7c7 7 7 18.4 0 25.5s-18.4 7-25.5 0L244.5 270c-6.8-6.8-10.5-15.9-10.5-25.5L234 144c0-9.9 8.1-18 18-18zM0 108l0 36c0 32.7 14.6 62.1 37.6 81.9-1 8.6-1.6 17.3-1.6 26.1l0 36c0 23.5 3.8 46.2 10.7 67.4l-7.7 7.7C25 377.1 18 395.6 18 414l0 36c0 18.4 7 36.9 21.1 50.9 28.1 28.1 73.7 28.1 101.8 0l18-18C187.1 496.4 218.7 504 252 504s64.9-7.6 93.1-21.1l18 18c28.1 28.1 73.7 28.1 101.8 0 14.1-14.1 21.1-32.5 21.1-50.9l0-38.2c-.5-17.7-7.6-35.2-21.1-48.7l-7.7-7.7c7-21.2 10.7-43.9 10.7-67.4l0-36c0-8.8-.5-17.6-1.6-26.1 23-19.8 37.6-49.1 37.6-81.9l0-36c0-59.6-48.4-108-108-108-35.5 0-67.1 17.2-86.8 43.7-18.2-5-37.4-7.7-57.2-7.7s-39 2.7-57.2 7.7C175.1 17.2 143.5 0 108 0 48.4 0 0 48.4 0 108zm36 0c0-39.8 32.2-72 72-72 19.9 0 37.8 8 50.9 21.1-44.5 21.3-80.5 57.3-101.8 101.8-13-13-21.1-31-21.1-50.9zm432 0c0 19.9-8 37.8-21.1 50.9-21.3-44.5-57.3-80.5-101.8-101.8 13-13 31-21.1 50.9-21.1 39.8 0 72 32.2 72 72zM72 252a180 180 0 1 1 360 0 180 180 0 1 1 -360 0zm3.9 125.2c14 19.7 31.2 36.9 50.9 50.9l-11.4 11.4c-14.1 14.1-36.9 14.1-50.9 0s-14.1-36.9 0-50.9l11.4-11.4zm301.2 50.9c19.7-14 36.9-31.2 50.9-50.9l11.4 11.4c14.1 14.1 14.1 36.9 0 50.9s-36.9 14.1-50.9 0l-11.4-11.4z"],
    "database": [360, 540, [], "f1c0", "M0 432c0 33.2 30.8 55.2 58.1 67.4 32.1 14.3 75.2 22.6 121.9 22.6s89.7-8.4 121.9-22.6C329.2 487.2 360 465.2 360 432l0-324C360 74.8 329.2 52.8 301.9 40.6 269.7 26.4 226.7 18 180 18S90.3 26.4 58.1 40.6C30.8 52.8 0 74.8 0 108L0 432zM36 108C36 90.9 59.9 79.2 72.8 73.5 99.3 61.7 137.2 54 180 54s80.7 7.7 107.2 19.5C300.1 79.2 324 90.9 324 108l0 18c0 17.1-23.9 28.8-36.8 34.5-26.5 11.8-64.4 19.5-107.2 19.5s-80.7-7.7-107.2-19.5C59.9 154.8 36 143.1 36 126l0-18zm288 73.4l0 34.6c0 17.1-23.9 28.8-36.8 34.5-26.5 11.8-64.4 19.5-107.2 19.5s-80.7-7.7-107.2-19.5C59.9 244.8 36 233.1 36 216l0-34.6C77.5 208.6 131.5 216 180 216s102.5-7.4 144-34.6zm0 90l0 34.6c0 17.1-23.9 28.8-36.8 34.5-26.5 11.8-64.4 19.5-107.2 19.5s-80.7-7.7-107.2-19.5C59.9 334.8 36 323.1 36 306l0-34.6C77.5 298.6 131.5 306 180 306s102.5-7.4 144-34.6zm-288 90C77.5 388.6 131.5 396 180 396s102.5-7.4 144-34.6l0 34.6c0 17.1-23.9 28.8-36.8 34.5-26.5 11.8-64.4 19.5-107.2 19.5s-80.7-7.7-107.2-19.5C59.9 424.8 36 413.1 36 396l0-34.6z"],
    "newspaper": [504, 540, [128240], "f1ea", "M180 180c0-19.9 16.1-36 36-36l36 0c19.9 0 36 16.1 36 36l0 54c0 19.9-16.1 36-36 36l-36 0c-19.9 0-36-16.1-36-36l0-54zm72 0l-36 0 0 54 36 0 0-54zm90-36c-9.9 0-18 8.1-18 18s8.1 18 18 18l72 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-72 0zm0 90c-9.9 0-18 8.1-18 18s8.1 18 18 18l72 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-72 0zM198 324c-9.9 0-18 8.1-18 18s8.1 18 18 18l216 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-216 0zM162 54c-39.8 0-72 32.2-72 72l-18 0c-39.8 0-72 32.2-72 72L0 396c0 49.7 40.3 90 90 90l324 0c49.7 0 90-40.3 90-90l0-270c0-39.8-32.2-72-72-72L162 54zm306 72l0 234c0 29.8-24.2 54-54 54L90 414c-29.8 0-54-24.2-54-54l0-162c0-19.9 16.1-36 36-36l18 0 0 180c0 9.9 8.1 18 18 18s18-8.1 18-18l0-216c0-19.9 16.1-36 36-36l270 0c19.9 0 36 16.1 36 36z"],
    "location-arrow": [540, 540, [], "f124", "M42.5 186.3C15.6 198.4-.9 225.5 0 254.4L.7 297c.5 32.8 33.7 59.6 64.1 62.7l121.4 12.1 12.1 121.4c3.2 32.4 27.9 58.7 60.1 63.9s63.9-11.8 77.2-41.5l162-360c4.2-9.4 6.3-19.4 6.3-29.3l0-35.8c.1-18.9-7.2-37.4-21.1-51.3-21.2-21.2-53.2-27-80.5-14.7l-360 162zm415-121.8c10.6 10.6 13.5 26.6 7.4 40.2l-162 360c-6.7 14.9-22.5 23.4-38.6 20.8s-28.4-15.7-30-31.9l-13.6-136c-.9-8.5-7.6-15.3-16.1-16.1l-136-13.6c-16.2-1.6-29.3-13.9-31.9-30-2.6-15.8 6.1-32 20.8-38.6l360-162c13.6-6.1 29.7-3.2 40.2 7.4z"],
    "city": [432, 540, [127961], "f64f", "M108 216c9.9 0 18 8.1 18 18l0 36c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-36c0-9.9 8.1-18 18-18zm0 108c9.9 0 18 8.1 18 18l0 36c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-36c0-9.9 8.1-18 18-18zM270 108c9.9 0 18 8.1 18 18l0 36c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-36c0-9.9 8.1-18 18-18zm72 0c9.9 0 18 8.1 18 18l0 36c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-36c0-9.9 8.1-18 18-18zM288 234c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 36c0 9.9 8.1 18 18 18s18-8.1 18-18l0-36zm72 0c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 36c0 9.9 8.1 18 18 18s18-8.1 18-18l0-36zM288 342c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 36c0 9.9 8.1 18 18 18s18-8.1 18-18l0-36zm72 0c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 36c0 9.9 8.1 18 18 18s18-8.1 18-18l0-36zM180 90c0-39.8 32.2-72 72-72l108 0c39.8 0 72 32.2 72 72l0 360c0 39.8-32.2 72-72 72L72 522c-39.8 0-72-32.2-72-72L0 198c0-39.8 32.2-72 72-72l108 0 0-36zM36 414c0 19.9 16.1 36 36 36l108 0 0-288-108 0c-19.9 0-36 16.1-36 36l0 216zm360 0l0-324c0-19.9-16.1-36-36-36L252 54c-19.9 0-36 16.1-36 36l0 360 144 0c19.9 0 36-16.1 36-36z"],
    "arrow-right-to-bracket": [504, 540, ["sign-in"], "f090", "M0 288c0 39.8 32.2 72 72 72l108 0c0 29.1 17.5 55.4 44.4 66.5 14.8 6.1 30.7 7 45.6 3.2 0 40.1 31 74.3 72 74.3l36 0c69.6 0 126-56.4 126-126l0-216c0-69.6-56.4-126-126-126l-36 0c-39.8 0-72 32.2-72 72 0 .8 0 1.5 0 2.3-14.8-3.8-30.8-2.9-45.6 3.2-26.9 11.1-44.4 37.4-44.4 66.5L72 180c-38.3 0-69.6 29.9-71.9 67.6-.1 .7-.1 1.4-.1 2.2L0 288zM468 162l0 180c0 49.7-40.3 90-90 90l-36 0c-19.9 0-36-16.1-36-36s16.1-36 36-36l36 0c9.8 0 18-8.2 18-18l0-180c0-9.9-8.1-18-18-18l-36 0c-19.9 0-36-16.1-36-36s16.1-36 36-36l36 0c49.7 0 90 40.3 90 90zm-190.5-7.5l72 72c14.1 14.1 14.1 36.9 0 50.9l-72 72c-10.3 10.3-25.8 13.4-39.2 7.8S216 338.6 216 324l0-18c0-9.8-8.2-18-18-18L72 288c-19.9 0-36-16.1-36-36s16.1-36 36-36l126 0c9.9 0 18-8.1 18-18l0-18c0-14.6 8.8-27.7 22.2-33.3s28.9-2.5 39.2 7.8z"],
    "video-slash": [504, 540, [], "f4e2", "M21.1 21.1C49.2-7 94.8-7 122.9 21.1L191.8 90 288 90c39.8 0 72 32.2 72 72l0 24.2 21.1-21.1c20.6-20.6 51.6-26.8 78.5-15.6S504 186.9 504 216l0 144c0 12.9-3.4 25.3-9.6 36 6.4 11.1 9.6 23.6 9.6 36l0 36c0 18.4-7 36.9-21.1 50.9-28.1 28.1-73.7 28.1-101.8 0l-48.4-48.4C320.4 480.2 304.9 486 288 486L72 486c-39.8 0-72-32.2-72-72L0 162c0-9.6 1.9-18.7 5.2-27-3.5-8.6-5.2-17.8-5.2-27L0 69.8c0-.7 0-1.5 .1-2.2 1-16.9 8-33.6 21-46.5zM306.9 444.7L36 173.8 36 414c0 19.9 16.1 36 36 36l216 0c6.9 0 13.4-1.9 18.9-5.3zM445.8 182.7c-13.5-5.6-28.9-2.5-39.2 7.8l-36 36c-6.8 6.8-10.5 15.9-10.5 25.5l0 6.2 108 108 0-150.2c0-14.6-8.8-27.7-22.2-33.3zM227.8 126l96.2 96.2 0-60.2c0-19.9-16.1-36-36-36l-60.2 0zM36 72c0 9.2 3.5 18.4 10.5 25.5l360 360c14.1 14.1 36.9 14.1 50.9 0s14.1-36.9 0-50.9l-360-360c-14.1-14.1-36.9-14.1-50.9 0-7 7-10.5 16.2-10.5 25.5z"],
    "comment": [504, 540, [128489, 61669], "f075", "M0 225C0 90 124.5 0 252 0S504 90 504 225l0 36c0 88.9-53 169.2-134.6 204.2l-161 69c-30 12.8-64.8 3.9-85-21.7-10.2-13-15.4-28.8-15.4-44.5l0-22.4C45 406.8 0 341.6 0 261l0-36zm36 0c0 72 43.6 130.4 106.3 162.6 9.2 4.7 12.5 16.7 7.1 25.5-7.9 12.7-7 29.2 2.3 41.1 10.1 12.8 27.5 17.3 42.5 10.8l161-69C423.6 366.8 468 299.5 468 225 468 115.5 365.8 36 252 36S36 115.5 36 225z"],
    "video": [504, 540, ["video-camera"], "f03d", "M0 126C0 86.2 32.2 54 72 54l216 0c39.8 0 72 32.2 72 72l0 24.2 21.1-21.1c20.6-20.6 51.6-26.8 78.5-15.6S504 150.9 504 180l0 180c0 29.1-17.5 55.4-44.4 66.5s-57.9 5-78.5-15.6L360 389.8 360 414c0 39.8-32.2 72-72 72L72 486c-39.8 0-72-32.2-72-72L0 126zm324 0c0-19.9-16.1-36-36-36L72 90c-19.9 0-36 16.1-36 36l0 252c0 19.9 16.1 36 36 36l216 0c19.9 0 36-16.1 36-36l0-252zM468 324l0-144c0-14.6-8.8-27.7-22.2-33.3s-28.9-2.5-39.2 7.8l-36 36c-6.8 6.8-10.5 15.9-10.5 25.5l0 72c0 9.5 3.8 18.7 10.5 25.5l36 36c10.3 10.3 25.8 13.4 39.2 7.8S468 338.6 468 324z"],
    "clipboard": [360, 540, [128203], "f328", "M108 198c-9.9 0-18 8.1-18 18s8.1 18 18 18l144 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-144 0zM90 288c0-9.9 8.1-18 18-18l144 0c9.9 0 18 8.1 18 18s-8.1 18-18 18l-144 0c-9.9 0-18-8.1-18-18zm18 54c-9.9 0-18 8.1-18 18s8.1 18 18 18l144 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-144 0zM162 0c-33.5 0-61.7 22.9-69.7 54L72 54C32.2 54 0 86.2 0 126L0 450c0 39.8 32.2 72 72 72l216 0c39.8 0 72-32.2 72-72l0-324c0-39.8-32.2-72-72-72l-20.3 0c-8-31.1-36.2-54-69.7-54L162 0zM72 90l20.3 0c8 31.1 36.2 54 69.7 54l36 0c33.5 0 61.7-22.9 69.7-54L288 90c19.9 0 36 16.1 36 36l0 288c0 19.9-16.1 36-36 36L72 450c-19.9 0-36-16.1-36-36l0-288c0-19.9 16.1-36 36-36zm54-18c0-19.9 16.1-36 36-36l36 0c19.9 0 36 16.1 36 36s-16.1 36-36 36l-36 0c-19.9 0-36-16.1-36-36z"],
    "laptop": [540, 540, [128187], "f109", "M54 290.3L54 108c0-39.8 32.2-72 72-72l288 0c39.8 0 72 32.2 72 72l0 182.3c31.1 8 54 36.2 54 69.7l0 36c0 39.8-32.2 72-72 72L72 468c-39.8 0-72-32.2-72-72l0-36c0-33.5 22.9-61.7 54-69.7zM90 108l0 180 54 0 0-144c0-9.9 8.1-18 18-18l216 0c9.9 0 18 8.1 18 18l0 144 54 0 0-180c0-19.9-16.1-36-36-36L126 72c-19.9 0-36 16.1-36 36zm90 90l0 90 180 0 0-90-180 0zM72 324c-19.9 0-36 16.1-36 36s16.1 36 36 36l396 0c19.9 0 36-16.1 36-36s-16.1-36-36-36L72 324z"],
    "thumbs-down": [504, 540, [128078, 61576], "f165", "M108 18c18.7 0 35.8 7.1 48.6 18.8 1.7-.5 3.5-.8 5.4-.8l234 0c39.8 0 72 32.2 72 72l0 24.4c11.2 12.7 18 29.4 18 47.6l0 24.4c11.2 12.7 18 29.4 18 47.6l0 36c0 39.8-32.2 72-72 72l-81.7 0c1.2 4.6 2.2 9.3 3.2 14l5.2 25.9c1 5 1.5 10 1.4 15l0 34.5c.4 33.9-23.4 64.4-57.9 71.3-39 7.8-76.9-17.5-84.7-56.5l-5.2-25.9c-5.6-27.9-19.3-53.5-39.4-73.6l-7.8-7.8c-4.2-4.2-7.8-8.9-10.8-13.8-12.5 10.5-28.7 16.9-46.3 16.9l-36 0c-39.8 0-72-32.2-72-72L0 90C0 50.2 32.2 18 72 18l36 0zM252.7 421c3.9 19.5 22.9 32.1 42.4 28.2s32.1-22.9 28.2-42.4l-5.2-25.9c-4.7-23.4-12.6-45.8-23.5-66.8-2.9-5.6-2.7-12.3 .6-17.6s9.1-8.7 15.4-8.7L432 288c19.9 0 36-16.1 36-36 0-12.7-6.6-23.9-16.6-30.4-8-5.1-10.7-15.7-6-24 2.9-5.2 4.6-11.2 4.6-17.6 0-12.7-6.6-23.9-16.6-30.4-8-5.1-10.7-15.7-6-24 2.9-5.2 4.6-11.2 4.6-17.6 0-19.9-16.1-36-36-36l-216 0 0 197.9c0 4.9 .5 7.7 2.1 12.1 1.7 4.9 4.5 9.5 8.5 13.4l7.8 7.8c25.1 25.1 42.3 57.1 49.2 92l5.2 25.9zM72 288l36 0c19.9 0 36-16.1 36-36l0-162c0-19.9-16.1-36-36-36L72 54C52.1 54 36 70.1 36 90l0 162c0 19.9 16.1 36 36 36z"],
    "utensils": [432, 540, [127860, 61685, "cutlery"], "f2e7", "M324 18c-29.7 0-57.5 12.1-76.9 31.6-8.5-18.6-27.3-31.6-49.1-31.6-13.8 0-26.4 5.2-36 13.8-9.6-8.6-22.2-13.8-36-13.8S99.6 23.2 90 31.8C80.4 23.2 67.8 18 54 18 24.2 18 0 42.2 0 72L0 196.7c0 36.1 18 69.8 48.1 89.9L54 290.5 54 450c0 39.8 32.2 72 72 72s72-32.2 72-72l0-159.5 5.9-3.9c4.3-2.9 8.3-6 12.1-9.4l0 10.8c0 26.7 14.5 49.9 36 62.4l0 99.6c0 39.8 32.2 72 72 72s72-32.2 72-72l0-360c0-39.8-32.2-72-72-72zM72 72l0 72c0 9.9 8.1 18 18 18s18-8.1 18-18l0-72c0-9.9 8.1-18 18-18s18 8.1 18 18l0 72c0 9.9 8.1 18 18 18s18-8.1 18-18l0-72c0-9.9 8.1-18 18-18s18 8.1 18 18l0 88.7c0 24.1-12 46.6-32.1 59.9L170 229.9c-5 3.3-8 9-8 15L162 414c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-169.1c0-6-3-11.6-8-15l-13.9-9.3C48 207.3 36 184.8 36 160.7L36 72c0-9.9 8.1-18 18-18s18 8.1 18 18zm180 53.1c0-39.3 32.7-71.1 72-71.1 19.9 0 36 16.1 36 36l0 324c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-111.1c0-7.6-4.8-14.4-12-17-14-5-24-18.3-24-34l0-126.9z"],
    "microphone": [432, 540, [], "f130", "M216 0C156.4 0 108 48.4 108 108l0 45.6c-10.6-6.1-22.9-9.6-36-9.6-39.8 0-72 32.2-72 72l0 36c0 94.1 60.1 174.1 144 203.7l0 12.3c0 39.8 32.2 72 72 72s72-32.2 72-72l0-12.3C371.9 426.1 432 346.1 432 252l0-36c0-39.8-32.2-72-72-72-13.1 0-25.4 3.5-36 9.6l0-45.6C324 48.4 275.6 0 216 0zM324 216c0-19.9 16.1-36 36-36s36 16.1 36 36c0 82.4-55.3 151.9-130.9 173.2-7.7 2.2-13.1 9.3-13.1 17.3l0 25.5c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-25.5c0-8.1-5.4-15.1-13.1-17.3-75.6-21.4-130.9-90.9-130.9-173.2 0-19.9 16.1-36 36-36s36 16.1 36 36c0 59.6 48.4 108 108 108s108-48.4 108-108zm-180 0l0-108c0-39.8 32.2-72 72-72s72 32.2 72 72l0 108c0 39.8-32.2 72-72 72s-72-32.2-72-72z"],
    "crown": [504, 540, [128081], "f521", "M56.2 449.5l-54-216C.7 227.7 0 221.8 0 216l0-36c0-15.9 5.3-31.5 15.2-44.3 13.6-17.5 34.6-27.7 56.8-27.7 29.7 0 58.5-15.1 83.6-36.7 13.6-11.6 26.5-24.9 36.7-39.6 13.4-19.8 35.7-31.7 59.7-31.7s46.3 11.9 59.7 31.7c10.2 14.7 23.1 28 36.7 39.6 25.1 21.5 54 36.7 83.6 36.7 22.2 0 43.1 10.2 56.8 27.7 10 12.8 15.2 28.4 15.2 44.3l0 36c0 5.8-.7 11.7-2.1 17.5l-54 216C439.8 481.5 411 504 378 504l-252 0c-33 0-61.8-22.5-69.9-54.5zM126 432l252 0c16.5 0 30.9-11.2 34.9-27.3l54-216c2.7-10.8 .3-22.1-6.6-30.9S443.1 144 432 144c-41.8 0-78.7-21-107.1-45.3-13.8-11.8-26.4-25.1-37.6-39.4-9.2-11.8-18.2-23.2-35.3-23.2s-26.1 11.4-35.3 23.2c-11.2 14.3-23.8 27.6-37.6 39.4-28.3 24.3-65.2 45.3-107.1 45.3-11.1 0-21.6 5.1-28.4 13.8s-9.2 20.1-6.5 30.9l54 216c4 16 18.4 27.3 34.9 27.3zm97.3-255.9c6.9-8.9 17.5-14.1 28.7-14.1s21.8 5.2 28.7 14.1l51.9 66.8c6 7.8 9.3 17.3 9.3 27.2s-3.3 19.4-9.3 27.2l-51.9 66.8c-6.9 8.9-17.5 14.1-28.7 14.1s-21.8-5.2-28.7-14.1l-51.9-66.8c-6-7.8-9.3-17.3-9.3-27.2s3.3-19.4 9.3-27.2l51.9-66.8zm-23.5 99l51.9 66.8c.2 .2 .5 .2 .6 0l51.9-66.8c2.2-2.9 2.2-7.2 0-10.1l-51.9-66.8c-.2-.2-.5-.2-.6 0l-51.9 66.8c-2.2 2.9-2.2 7.2 0 10.1z"],
    "arrow-up-wide-short": [540, 540, ["sort-amount-up"], "f161", "M0 180.6c-.1-18.9 7.2-37.6 21.1-51.5l72-72c28.1-28.1 73.7-28.1 101.8 0l61.6 61.6C266.8 91.4 293.1 72 324 72l144 0c39.8 0 72 32.2 72 72l0 36c0 33.6-23 61.8-54 69.7 .4 12.7 0 25.5 0 38.3 0 33.6-23 61.8-54 69.7 .4 12.7 0 25.5 0 38.3 0 39.8-32.2 72-72 72l-36 0c-39.8 0-72-32.2-72-72l0-36c0-13.1 3.5-25.4 9.6-36-6.1-10.6-9.6-22.9-9.6-36l0-9.6c-10.7 6.2-23.1 9.6-36 9.6l0 144c0 39.8-32.2 72-72 72s-72-32.2-72-72l0-144C32.5 288-.3 254.6 0 215.4l0-34.9zm46.5-26c-10.3 10.3-13.3 25.9-7.8 39.2 5.6 13.5 18.7 22.2 33.3 22.2l18 0c9.9 0 18 8.1 18 18l0 162c0 19.9 16.1 36 36 36 19.8 0 35.9-16 36-35.8L180 234c0-9.8 8.2-18 18-18l18 0c14.6 0 27.7-8.8 33.3-22.2s2.5-28.9-7.8-39.2l-72-72c-14.1-14.1-36.9-14.1-50.9 0l-72 72zM324 324c-19.8 0-36 16.3-36 36 0 19.9 16.1 36 36 36l36 0c19.9 0 36-16.1 36-36s-16.1-36-36-36l-36 0zm126-72c0-19.9-16.1-36-36-36l-90 0c-19.9 0-36 16.1-36 36s16.1 36 36 36l90 0c19.9 0 36-16.1 36-36zm54-108c0-19.9-16.1-36-36-36l-144 0c-19.9 0-36 16.1-36 36s16.1 36 36 36l144 0c19.9 0 36-16.1 36-36z"],
    "sun": [504, 540, [9728], "f185", "M193.8 29.6C207.4 11 229 0 252 0s44.6 11 58.2 29.6l21.6 29.7 36.3-5.7c22.7-3.6 45.8 3.9 62.1 20.2 6.1 6.1 11 13.2 14.5 20.8 4.4 9.5 6.6 19.9 6.6 30.4l0 36c0 5-.7 9.9-1.5 14.9l24.6 17.9C493 207.4 504 229 504 252l0 36c0 23-11 44.6-29.6 58.2l-23.1 16.8 0 52.3c0 18.9-7.5 37.2-21.1 50.8-16.3 16.3-39.4 23.8-62.1 20.2l-36.3-5.7-21.6 29.7C296.6 529 275 540 252 540s-44.6-11-58.2-29.6l-21.6-29.7-36.3 5.7c-22.7 3.6-45.8-3.9-62.1-20.2-13.6-13.6-21.1-31.9-21.1-50.8l0-52.3-23.1-16.8C11 332.6 0 311 0 288l0-36c0-23 11-44.6 29.6-58.2l24.6-17.9c-.8-4.9-1.5-9.8-1.5-14.9l0-36c0-10.6 2.2-20.9 6.6-30.4 3.5-7.6 8.4-14.7 14.5-20.8 16.3-16.3 39.4-23.8 62.1-20.2l36.3 5.7 21.6-29.7zM252 36c-11.5 0-22.3 5.5-29.1 14.8L194.8 89.4c-4 5.5-10.7 8.2-17.3 7.2l-47.1-7.4c-11.4-1.8-22.9 2-31 10.1-8.1 8.1-11.9 19.8-10.1 31l7.4 47.1c1 6.7-1.7 13.4-7.2 17.3L50.8 222.9C41.5 229.7 36 240.5 36 252s5.5 22.3 14.8 29.1l38.6 28.1c5.5 4 8.2 10.7 7.2 17.3l-7.4 47.1c-1.8 11.4 2 22.9 10.1 31s19.7 11.9 31 10.1l47.1-7.4c6.7-1 13.4 1.7 17.3 7.2l28.1 38.6c6.8 9.3 17.6 14.8 29.1 14.8s22.3-5.5 29.1-14.8l28.1-38.6c4-5.5 10.7-8.2 17.3-7.2l47.1 7.4c11.4 1.8 22.9-2 31-10.1s11.9-19.7 10.1-31l-7.4-47.1c-1-6.7 1.7-13.4 7.2-17.3l38.6-28.1c9.3-6.8 14.8-17.6 14.8-29.1s-5.5-22.3-14.8-29.1l-38.6-28.1c-5.5-4-8.2-10.7-7.2-17.3l7.4-47.1c1.8-11.3-2-23-10.1-31-8.1-8.1-19.7-11.9-31-10.1l-47.1 7.4c-6.7 1-13.4-1.7-17.3-7.2L281.1 50.8C274.3 41.5 263.5 36 252 36zm0 324a108 108 0 1 1 0-216 108 108 0 1 1 0 216zM180 252a72 72 0 1 0 144 0 72 72 0 1 0 -144 0z"],
    "image": [432, 540, [], "f03e", "M216 180a72 72 0 1 1 -144 0 72 72 0 1 1 144 0zm-72-36a36 36 0 1 0 0 72 36 36 0 1 0 0-72zM72 36C32.2 36 0 68.2 0 108L0 432c0 39.8 32.2 72 72 72l288 0c39.8 0 72-32.2 72-72l0-324c0-39.8-32.2-72-72-72L72 36zM396 226.5l-84.7 84.7c-12.9 12.9-33.7 12.9-46.5 0-26.9-26.9-70.5-26.9-97.5 0L52.4 426.2C42.5 419.8 36 408.6 36 396l0-288c0-19.9 16.1-36 36-36l288 0c19.9 0 36 16.1 36 36l0 118.5zM97.5 432l95.3-95.3c12.9-12.9 33.7-12.9 46.5 0 26.9 26.9 70.5 26.9 97.5 0L396 277.5 396 396c0 19.9-16.1 36-36 36L97.5 432z"],
    "notdef": [360, 540, [], "e1fe", "M54.1 58.8C59.4 55.7 65.5 54 72 54l216 0c6.5 0 12.6 1.7 17.9 4.8L180 222.5 54.1 58.8zM324 94.3L324 409.7 202.7 252 324 94.3zM305.9 445.2c-5.3 3-11.4 4.8-17.9 4.8L72 450c-6.5 0-12.6-1.7-17.9-4.8L180 281.5 305.9 445.2zM36 409.7L36 94.3 157.3 252 36 409.7zM0 90L0 450c0 39.8 32.2 72 72 72l216 0c39.8 0 72-32.2 72-72l0-360c0-39.8-32.2-72-72-72L72 18C32.2 18 0 50.2 0 90z"],
    "pencil": [468, 540, [9999, 61504, "pencil-alt"], "f303", "M292.2 42.4C307.8 26.8 328.9 18 351 18s43.2 8.8 58.8 24.4l33.8 33.8C459.2 91.8 468 112.9 468 135l0 36c0 22.1-8.8 43.2-24.4 58.8L221.8 451.7c-9.1 9.1-20 16.1-32 20.6L65.5 518.9c-5.4 2-11.2 3.1-17 3.1-26.8 0-48.5-21.7-48.5-48.5l0-36c0-5.8 1-11.6 3.1-17L49.7 296.3c4.5-12 11.5-23 20.6-32L292.2 42.4zM270 115.5L102 283.5 202.5 384 370.5 216 270 115.5zm126 75.1l22.2-22.2C427 159.5 432 147.5 432 135s-5-24.5-13.8-33.4L384.4 67.8C375.5 59 363.5 54 351 54s-24.5 5-33.4 13.8L295.5 90 396 190.5zm-223.9 214L81.5 313.9 36.8 433.1c-3.7 9.8 6.5 19.6 16.1 16.1l119.2-44.7z"],
    "lightbulb": [360, 540, [128161], "f0eb", "M126 180c0-29.8 24.2-54 54-54 9.9 0 18-8.1 18-18s-8.1-18-18-18c-49.7 0-90 40.3-90 90 0 9.9 8.1 18 18 18s18-8.1 18-18zM0 180C0 80.6 80.6 0 180 0S360 80.6 360 180l0 36c0 59.1-23 106.7-58.6 151.9-19.1 24.2-31.4 39.8-31.4 64.1l0 18c0 49.7-40.3 90-90 90s-90-40.3-90-90l0-18C90 407.7 77.7 392.1 58.6 367.9 23 322.7 0 275.1 0 216l0-36zM180 36c-79.5 0-144 64.5-144 144 0 57.6 20.1 89.8 41.3 117.3 10.6 13.8 23.3 28.1 33.1 44.7l139.3 0c9.8-16.7 22.5-31 33.1-44.7 21.1-27.5 41.3-59.7 41.3-117.3 0-79.5-64.5-144-144-144zM126 396l0 18c0 29.8 24.2 54 54 54s54-24.2 54-54l0-18c0-6.3 .6-12.3 1.7-18l-111.3 0c1.1 5.7 1.7 11.7 1.7 18z"],
    "code": [540, 540, [], "f121", "M334.3 37.5c15.4 4.6 25.5 18.7 25.7 34 0 .2 0 .3 0 .5l0 .8c-.1 3.2-.6 6.4-1.5 9.5l-108 360c-5.7 19-25.8 29.9-44.8 24.1-15.1-4.5-25.7-18.8-25.7-34.5 0-3.4 .5-6.9 1.5-10.3l108-360c5.7-19 25.8-29.9 44.8-24.1zM396 73.6C396.7 42 376.4 12.6 344.7 3 306.6-8.4 266.5 13.2 255 51.3L216 181.4c0-19.5-7.2-38.4-21.1-52.3-28.1-28.1-73.7-28.1-101.8 0l-72 72C8.5 213.7 0 231.8 0 249.8L0 288c0 18.4 7 36.9 21.1 50.9l63 63c16.5 16.5 39.1 23.3 60.6 20.4-.5 3.8-.7 7.6-.6 11.3l0 32.9c-.6 31.5 19.6 60.9 51.3 70.4 38.1 11.4 78.2-10.2 89.7-48.3l39-130.1c0 19.6 7.1 38.4 21.1 52.3 28.1 28.1 73.7 28.1 101.8 0l72-72C533 324.9 540 306.4 540 288l0-36c0-18.4-7-36.9-21.1-50.9l-63-63c-16.5-16.5-39.1-23.3-60.6-20.4 .4-2.7 .6-5.4 .6-8l0-.4 0-35.6zM36 252c0-9.2 3.5-18.4 10.5-25.5l72-72c14.1-14.1 36.9-14.1 50.9 0 14.1 14.1 14.1 36.9 0 50.9l-33.8 33.8c-3.4 3.4-5.3 8-5.3 12.7s1.9 9.4 5.3 12.7l24.8 24.8c14.1 14.1 14.1 36.9 0 50.9s-36.9 14.1-50.9 0l-63-63c-7-7-10.5-16.2-10.5-25.5zm394.5-88.5l63 63c14.1 14.1 14.1 36.9 0 50.9l-72 72c-14.1 14.1-36.9 14.1-50.9 0s-14.1-36.9 0-50.9l33.8-33.8c7-7 7-18.4 0-25.5l-24.8-24.8c-14.1-14.1-14.1-36.9 0-50.9s36.9-14.1 50.9 0z"],
    "address-card": [504, 540, [62140, "contact-card", "vcard"], "f2bb", "M306 162c-9.9 0-18 8.1-18 18s8.1 18 18 18l90 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-90 0zm0 72c-9.9 0-18 8.1-18 18s8.1 18 18 18l90 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-90 0zm0 72c-9.9 0-18 8.1-18 18s8.1 18 18 18l90 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-90 0zm-93.6-38.6c13.3-13.1 21.6-31.3 21.6-51.4 0-39.8-32.2-72-72-72s-72 32.2-72 72c0 20.1 8.3 38.4 21.6 51.4-23.9 16.2-39.6 43.5-39.6 74.6 0 9.9 8.1 18 18 18s18-8.1 18-18c0-29.8 24.2-54 54-54s54 24.2 54 54c0 9.9 8.1 18 18 18s18-8.1 18-18c0-31-15.7-58.4-39.6-74.6zM162 252a36 36 0 1 1 0-72 36 36 0 1 1 0 72zM0 126C0 86.2 32.2 54 72 54l360 0c39.8 0 72 32.2 72 72l0 288c0 39.8-32.2 72-72 72L72 486c-39.8 0-72-32.2-72-72L0 126zM432 90L72 90c-19.9 0-36 16.1-36 36l0 252c0 19.9 16.1 36 36 36l360 0c19.9 0 36-16.1 36-36l0-252c0-19.9-16.1-36-36-36z"],
    "angle-right": [324, 540, [8250], "f105", "M324 251.9c0-18.4-7-36.8-21.1-50.9l-144-144C130.8 29 85.2 29 57.1 57.1 43.7 70.5 36 89 36 108l0 36c0 18.4 7 36.9 21.1 50.9l75.1 75.1-75.1 75.1C43.7 358.5 36 377 36 396L36 432c0 18.4 7 36.8 21.1 50.9 28.1 28.1 73.7 28.1 101.8 0l144-144C317 324.9 324 306.4 324 288l0-36.1zM82.5 421.5c-14-14-14-36.9 0-50.9L188.4 264.7c6.9-6.9 6.9-18.5 0-25.5L82.5 133.5c-14-14-14-37 0-50.9 14.1-14.1 36.9-14.1 50.9 0l144 144c14.1 14.1 14.1 36.9 0 50.9l-144 144c-14.1 14.1-36.9 14.1-50.9 0z"],
    "face-meh": [504, 540, [128528, "meh"], "f11a", "M126 270c-9.9 0-18 8.1-18 18s8.1 18 18 18l252 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-252 0zm0-90c0-9.9 8.1-18 18-18l72 0c9.9 0 18 8.1 18 18s-8.1 18-18 18l-72 0c-9.9 0-18-8.1-18-18zm162-18c-9.9 0-18 8.1-18 18s8.1 18 18 18l72 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-72 0zM252 0C112.8 0 0 112.8 0 252l0 36C0 427.2 112.8 540 252 540S504 427.2 504 288l0-36C504 112.8 391.2 0 252 0zm0 468a216 216 0 1 1 0-432 216 216 0 1 1 0 432z"],
    "map": [504, 540, [128506, 62072], "f279", "M0 126C0 95 19.8 67.5 49.2 57.7l108-36c18.1-6 37.9-4.6 55 3.9l117.3 58.7 79.7-26.6c22-7.3 46.1-3.6 64.9 9.9S504 102.9 504 126l0 288c0 31-19.8 58.5-49.2 68.3l-108 36c-18.1 6-37.9 4.6-55-3.9l-117.3-58.7-79.7 26.6c-22 7.3-46.1 3.6-64.9-9.9S0 437.1 0 414L0 126zM162 58.1L60.6 91.8C45.9 96.7 36 110.5 36 126l0 252c0 24.2 24.5 41.8 47.4 34.2l78.6-26.2 0-327.9zm36 333.2l108 54 0-332.5-108-54 0 332.5zm245.4 20.9c14.7-4.9 24.6-18.7 24.6-34.2l0-252c0-24.2-24.5-41.8-47.4-34.2l-78.6 26.2 0 327.9 101.4-33.8z"],
    "thumbtack": [504, 540, [128204, 128392, "thumb-tack"], "f08d", "M374.9 21.1C346.8-7 301.2-7 273.1 21.1 261.7 32.4 255 46.7 252.8 61.4l-99 63C125.5 101.1 83.6 102.6 57.1 129.1 43 143.1 36 161.6 36 180l0 36c0 18.4 7 36.9 21.1 50.9L96.2 306 39.1 363.1C25 377.1 18 395.6 18 414l0 36c0 18.4 7 36.9 21.1 50.9 28.1 28.1 73.7 28.1 101.8 0l75.1-75.1 57.1 57.1c28.1 28.1 73.7 28.1 101.8 0 14.1-14.1 21.1-32.5 21.1-50.9l0-36.5c-.1-9.1-1.8-18.2-5.3-26.8l51.9-81.5c14.8-2.2 29-9 40.3-20.3 14.1-14.1 21.1-32.5 21.1-50.9l0-36c0-18.4-7-36.9-21.1-50.9l-108-108zM190.5 364.4l-75.1 75.1c-14.1 14.1-36.9 14.1-50.9 0s-14.1-36.9 0-50.9l75.1-75.1 50.9 50.9zM457.5 154.5c14.1 14.1 14.1 36.9 0 50.9-7 7-16.1 10.5-25.3 10.5-6.1 0-11.8 3.2-15.1 8.3L341.6 342.8c-4.5 7.1-3.5 16.4 2.5 22.4l5.4 5.4c14.1 14.1 14.1 36.9 0 50.9s-36.9 14.1-50.9 0l-216-216c-14.1-14.1-14.1-36.9 0-50.9s36.9-14.1 50.9 0l5.4 5.4c6 6 15.3 7 22.4 2.5L279.7 87c5.2-3.3 8.3-9 8.3-15.1 0-9.2 3.5-18.3 10.5-25.3 14.1-14.1 36.9-14.1 50.9 0l108 108z"],
    "money-bill-wave": [504, 540, [], "f53a", "M162 252c0-55.7 36.8-108 90-108s90 52.3 90 108-36.8 108-90 108-90-52.3-90-108zm90-72c-26.3 0-54 28.3-54 72s27.7 72 54 72 54-28.3 54-72-27.7-72-54-72zm252-54c0-21.2-9.3-41.3-25.5-54.9S441 51.5 420.2 55l-48.9 8.2c-29.2 4.9-59.1 3.7-87.9-3.5l-27.8-6.9c-47.9-12-97.8-14-146.5-5.9L60.2 55C25.4 60.8 0 90.8 0 126L0 414c0 21.2 9.3 41.3 25.5 54.9S63 488.5 83.8 485l48.9-8.2c29.2-4.9 59.2-3.7 87.9 3.5l27.8 6.9c47.9 12 97.8 14 146.5 5.9l48.9-8.2c34.7-5.8 60.2-35.8 60.2-71l0-288zM143.4 78.9c34.7-2.7 69.6 .3 103.4 8.7l27.8 6.9c28.1 7 57.2 9.1 85.9 6.3 5.4 54.6 51.5 97.2 107.5 97.2l0 108c-59.6 0-108 48.4-108 108 0 3.8 .2 7.5 .6 11.1-34.7 2.7-69.6-.3-103.4-8.7l-27.8-6.9c-28.1-7-57.2-9.1-85.9-6.3-5.4-54.6-51.5-97.2-107.5-97.2l0-108c59.6 0 108-48.4 108-108 0-3.8-.2-7.5-.6-11.1zM437.9 413.5l-41.6 6.9C392.6 379 426.2 342 468 342l0 36c0 17.6-12.7 32.6-30.1 35.5zM36 378l0-36c37.9 0 69 29.3 71.8 66.5l-29.9 5C56.3 417.1 36 399.9 36 378zm0-216l0-36c0-17.6 12.7-32.6 30.1-35.5l41.6-6.9C111.4 125 77.8 162 36 162zm432-36l0 36c-37.9 0-69-29.3-71.8-66.5l29.9-5C447.7 86.9 468 104.1 468 126z"],
    "folder": [504, 540, [128193, 128447, 61716, "folder-blank"], "f07b", "M504 414c0 39.8-32.2 72-72 72L72 486c-39.8 0-72-32.2-72-72L0 90C0 50.2 32.2 18 72 18l100 0c21.9 0 42.6 9.9 56.2 27l39.6 49.5C274.7 103 285 108 296 108l136 0c39.8 0 72 32.2 72 72l0 234zM72 414l360 0c19.9 0 36-16.1 36-36l0-198c0-19.9-16.1-36-36-36l-136 0c-21.9 0-42.6-9.9-56.2-27L200.2 67.5C193.3 59 183 54 172 54L72 54C52.1 54 36 70.1 36 90l0 288c0 19.9 16.1 36 36 36z"],
    "arrow-up-from-bracket": [432, 540, [], "e09a", "M0 342c0-39.8 32.2-72 72-72 33.5 0 61.7 22.9 69.7 54l2.3 0 0-72c-29.1 0-55.4-17.5-66.5-44.4-3.6-8.7-5.4-18-5.5-27.1l0-35.9c-.1-18.9 7.2-37.6 21.1-51.5l72-72C193.2-7 238.8-7 266.9 21.1l72 72c13.9 13.9 21.2 32.6 21.1 51.5l0 36c-.1 9.1-1.9 18.3-5.5 27-11.1 26.9-37.4 44.4-66.5 44.4l0 72 2.3 0c8-31.1 36.2-54 69.7-54 39.8 0 72 32.2 72 72l0 72c0 69.6-56.4 126-126 126l-180 0C56.4 540 0 483.6 0 414l0-72zm396 36l0-36c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 36c0 9.9-8.1 18-18 18l-180 0c-4.8 0-9.4-1.9-12.7-5.3s-5.3-8-5.3-12.7l0-36c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 36c0 49.7 40.3 90 90 90l180 0c49.7 0 90-40.3 90-90zM252 198c0-9.8 8.2-18 18-18l18 0c14.6 0 27.7-8.8 33.3-22.2 5.5-13.3 2.4-29.1-7.8-39.2l-72-72c-14.1-14.1-36.9-14.1-50.9 0l-72 72c-10.2 10.2-13.3 26-7.8 39.2 5.6 13.5 18.7 22.2 33.3 22.2l18 0c9.9 0 18 8.1 18 18l0 126c0 19.8 16.1 35.9 35.9 36 19.6-.1 36.1-16.3 36.1-36l0-126z"],
    "cloud": [540, 540, [9729], "f0c2", "M297 36C242.2 36 194.1 64.8 167.1 108.1 105.8 110.1 56.4 159.3 54.1 220.5 21.4 243.3 0 281.1 0 324l0 36c0 69.6 56.4 126 126 126l279 0c64.6 0 117-52.4 117-117l0-36c0-50.2-31.6-92.9-75.9-109.6 2.5-11.1 3.9-22.6 3.9-34.4 0-84.5-68.5-153-153-153zM486 333c0 44.7-36.3 81-81 81l-279 0c-49.7 0-90-40.3-90-90 0-33.3 18.1-62.5 45.1-78 8.2-4.7 8.9-12.6 8.9-21 0-44.7 36.3-81 81-81 8.9 0 17.6-.3 22.4-9.4 19.6-37.3 58.7-62.6 103.6-62.6 64.6 0 117 52.4 117 117 0 14.3-2.6 27.9-7.2 40.5-3.8 10.3 2.8 21.9 13.5 23.9 37.4 7.1 65.7 40.1 65.7 79.6z"],
    "circle": [504, 540, [128308, 128309, 128992, 128993, 128994, 128995, 128996, 9679, 9898, 9899, 11044, 61708, 61915], "f111", "M0 252C0 112.8 112.8 0 252 0S504 112.8 504 252l0 36c0 139.2-112.8 252-252 252S0 427.2 0 288l0-36zm36 0a216 216 0 1 0 432 0 216 216 0 1 0 -432 0z"],
    "backward": [576, 540, [9194], "f04a", "M288 189L424.8 86.4c21.8-16.4 51-19 75.4-6.8S540 116.7 540 144l0 252c0 27.3-15.4 52.2-39.8 64.4s-53.6 9.6-75.4-6.8L288 351 288 396c0 27.3-15.4 52.2-39.8 64.4s-53.6 9.6-75.4-6.8l-144-108C10.7 332 0 310.7 0 288l0-36c0-22.7 10.7-44 28.8-57.6l144-108c21.8-16.4 51-19 75.4-6.8S288 116.7 288 144l0 45zm158.4-73.8l-144 108C293.3 230 288 240.7 288 252s5.3 22 14.4 28.8l144 108c10.9 8.2 25.5 9.5 37.7 3.4S504 373.6 504 360l0-216c0-13.6-7.7-26.1-19.9-32.2s-26.8-4.8-37.7 3.4zM252 144c0-13.6-7.7-26.1-19.9-32.2s-26.8-4.8-37.7 3.4l-144 108C41.3 230 36 240.7 36 252s5.3 22 14.4 28.8l144 108c10.9 8.2 25.5 9.5 37.7 3.4S252 373.6 252 360l0-216z"],
    "link": [504, 540, [128279, "chain"], "f0c1", "M323.8 0C276 0 230.2 19 196.4 52.8L165.1 84.1c-16.5 16.5-23.3 39.1-20.4 60.6-21.5-2.9-44 3.9-60.6 20.4L52.8 196.4C19 230.2 0 276 0 323.8l0 36c0 99.5 80.7 180.2 180.2 180.2 47.8 0 93.6-19 127.4-52.8l31.3-31.3c16.5-16.5 23.3-39.1 20.4-60.6 21.5 2.9 44-3.9 60.6-20.4l31.3-31.3C485 309.8 504 264 504 216.2l0-36C504 80.7 423.3 0 323.8 0zM108 323.6c-.1 18.6 6.9 37.1 21.1 51.3 14.4 14.4 33.4 21.4 52.3 21.1 18.7-.3 36.6-7.9 49.8-21.1l31.3-31.3c14.1-14.1 36.9-14.1 50.9 0s14.1 36.9 0 50.9l-31.3 31.3c-27 27-63.9 42.2-102.1 42.2-79.6 0-144-64.6-144-144.2 0-38.2 15.2-74.9 42.2-102l31.3-31.3c14.1-14.1 36.9-14.1 50.9 0s14.1 36.9 0 50.9l-31.3 31.3c-13.5 13.5-21.1 31.8-21.1 50.9zm266.9-92.4c13.5-13.5 21.1-31.9 21.1-51 0-18.4-7.1-37.1-21.1-51.1-14.2-14.2-32.7-21.2-51.3-21.1-19.1 .1-37.4 7.7-50.9 21.1l-31.3 31.3c-14.1 14.1-36.9 14.1-50.9 0s-14.1-36.9 0-50.9l31.3-31.3c27-27 63.7-42.2 102-42.2 79.6 0 144.2 64.6 144.2 144.2 0 38.2-15.2 74.9-42.2 102l-31.3 31.3c-14.1 14.1-36.9 14.1-50.9 0s-14.1-36.9 0-50.9l31.3-31.3zM360 179.9c0 9.2-3.5 18.5-10.5 25.5l-144 144c-6.8 6.8-16.3 10.4-25.3 10.5-20 0-36.2-16.2-36.2-36.2 .1-9.1 3.6-18.3 10.5-25.2l144-144c7-7 16.1-10.5 25.2-10.5 19.9 0 36.1 16.1 36.3 35.9z"],
    "backward-step": [432, 540, ["step-backward"], "f048", "M180 144c0-39.8-32.2-72-72-72L72 72C32.2 72 0 104.2 0 144L0 396c0 39.8 32.2 72 72 72l36 0c39.8 0 72-32.2 72-72l0-45 136.8 102.6c21.8 16.4 51 19 75.4 6.8S432 423.3 432 396l0-252c0-27.3-15.4-52.2-39.8-64.4s-53.6-9.6-75.4 6.8L180 189 180 144zM396 360c0 13.6-7.7 26.1-19.9 32.2s-26.8 4.8-37.7-3.4l-144-108C185.3 274 180 263.3 180 252s5.3-22 14.4-28.8l144-108c10.9-8.2 25.5-9.5 37.7-3.4S396 130.4 396 144l0 216zm-252 0c0 19.9-16.1 36-36 36l-36 0c-19.9 0-36-16.1-36-36l0-216c0-19.9 16.1-36 36-36l36 0c19.9 0 36 16.1 36 36l0 216z"],
    "circle-user": [504, 540, [62142, "user-circle"], "f2bd", "M0 252C0 112.8 112.8 0 252 0S504 112.8 504 252l0 36c0 139.2-112.8 252-252 252S0 427.2 0 288l0-36zm36 0c0 47.3 15.2 91.1 41 126.6 7.6-11 16.3-21.1 25.3-30.1 19.3-19.3 45.9-38.3 80.4-49.7-23.7-19.8-38.7-49.6-38.7-82.8 0-59.6 48.4-108 108-108s108 48.4 108 108c0 33.3-15 63-38.7 82.8 34.5 11.4 61.1 30.5 80.4 49.7 9 9 17.6 19.1 25.3 30.1 25.8-35.6 41-79.3 41-126.6 0-119.3-96.7-216-216-216S36 132.7 36 252zm65.5 155c38.9 37.8 92 61 150.5 61s111.6-23.3 150.5-61c-7.2-11.8-16.2-23-26.2-32.9-25.2-25.2-65.5-50-124.3-50s-99.1 24.8-124.3 50c-10 10-19.1 21.1-26.2 32.9zM252 144a72 72 0 1 0 0 144 72 72 0 1 0 0-144z"],
    "hand": [504, 540, [129306, 9995, "hand-paper"], "f256", "M0 325.1c-.2-13.4 3.3-27 10.9-39.2 20.6-33 63.6-43.5 97.1-24.2L108 108c0-39.8 32.2-72 72-72 14.8 0 28.6 4.5 40 12.2 9.8-28 36.6-48.2 68-48.2 39.8 0 72 32.2 72 72l0 9.6c10.6-6.1 22.9-9.6 36-9.6 39.8 0 72 32.2 72 72l0 166.1c0 117-94.9 211.9-211.9 211.9-39.7 0-78.6-11.2-112.3-32.2l-110-68.7C12 407.4 0 383.9 0 360l0-34.9zm36-1.4c.2 11.8 6.2 24.1 16.9 30.9l110 68.7c28 17.5 60.3 26.7 93.2 26.7 97.1 0 175.9-78.7 175.9-175.9L432 144c0-19.9-16.1-36-36-36-19.8 0-35.9 16-36 35.8L360 270c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-198c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 180c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-144c0-19.9-16.1-36-36-36-19.9 0-36 16.1-36 36l0 186.1c0 13.9-15.8 22.6-27.5 15.3L91.1 293.5c-16.9-10.5-39.1-5.4-49.6 11.4-3.6 5.8-5.4 12.3-5.5 18.7z"],
    "thumbs-up": [504, 540, [128077, 61575], "f164", "M154.3 196.9c3-4.9 6.6-9.5 10.8-13.8l7.8-7.8c20.1-20.1 33.8-45.7 39.4-73.6l5.2-25.9c7.8-39 45.7-64.3 84.7-56.5 34.7 6.9 58.5 37.7 57.9 71.9l0 34.7c0 4.7-.5 9.4-1.4 14.1L353.4 166c-.9 4.7-2 9.4-3.2 14l81.7 0c39.8 0 72 32.2 72 72l0 36c0 18.3-6.8 34.9-18 47.6l0 24.4c0 18.3-6.8 34.9-18 47.6l0 24.4c0 39.8-32.2 72-72 72l-240.4 0c-12.7 11.2-29.4 18-47.6 18l-36 0c-39.8 0-72-32.2-72-72L0 252c0-39.8 32.2-72 72-72l36 0c17.6 0 33.8 6.3 46.3 16.9zM252.7 82.9l-5.2 25.9c-7 34.8-24.1 66.8-49.2 92-6.4 6.4-13.1 12.4-16.3 21.2-1.6 4.4-2.1 7.1-2.1 12l0 198 216 0c19.9 0 36-16.1 36-36 0-6.4-1.7-12.4-4.6-17.6-4.7-8.3-2.1-18.9 6-24 10-6.4 16.6-17.6 16.6-30.4 0-6.4-1.7-12.4-4.6-17.6-4.7-8.3-2.1-18.9 6-24 10-6.4 16.6-17.6 16.6-30.4 0-19.9-16.1-36-36-36l-121.4 0c-6.3 0-12.1-3.3-15.4-8.7s-3.5-12.1-.6-17.6c10.9-20.9 18.8-43.4 23.5-66.8 2.1-10.7 5.8-21.9 5.9-32.9 0-16.8-11.8-31.9-28.9-35.3-19.5-3.9-38.5 8.7-42.4 28.2zM36 414c0 19.9 16.1 36 36 36l36 0c19.9 0 36-16.1 36-36l0-162c0-19.9-16.1-36-36-36l-36 0c-19.9 0-36 16.1-36 36l0 162z"],
    "building": [360, 540, [127970, 61687], "f1ad", "M108 90c9.9 0 18 8.1 18 18l0 54c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-54c0-9.9 8.1-18 18-18zm72 0c9.9 0 18 8.1 18 18l0 54c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-54c0-9.9 8.1-18 18-18zm72 0c9.9 0 18 8.1 18 18l0 54c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-54c0-9.9 8.1-18 18-18zM126 234c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 54c0 9.9 8.1 18 18 18s18-8.1 18-18l0-54zm72 0c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 54c0 9.9 8.1 18 18 18s18-8.1 18-18l0-54zm72 0c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 54c0 9.9 8.1 18 18 18s18-8.1 18-18l0-54zM72 18C32.2 18 0 50.2 0 90L0 450c0 39.8 32.2 72 72 72l18 0c39.8 0 72-32.2 72-72l0-18c0-9.9 8.1-18 18-18s18 8.1 18 18l0 18c0 39.8 32.2 72 72 72l18 0c39.8 0 72-32.2 72-72l0-360c0-39.8-32.2-72-72-72L72 18zM324 414c0 19.9-16.1 36-36 36l-18 0c-19.9 0-36-16.1-36-36l0-18c0-29.8-24.2-54-54-54s-54 24.2-54 54l0 18c0 19.9-16.1 36-36 36l-18 0c-19.9 0-36-16.1-36-36L36 90c0-19.9 16.1-36 36-36l216 0c19.9 0 36 16.1 36 36l0 324z"],
    "gear": [468, 540, [9881, "cog"], "f013", "M155.4 61.1C160.8 25.9 191 0 226.6 0l15.3 0c35.5 0 65.8 25.9 71.2 61.1l4.9 31.5c4.3 2.2 8.4 4.7 12.5 7.2l29.8-11.6c33.1-12.9 70.7 .3 88.5 31.1l7.7 13.3c6.6 11.5 9.8 24.1 9.6 36.6l0 35.8c-.2 21-9.5 41.8-26.9 55.8l-11.5 9.2 11.5 9.2c17.7 14.2 27.1 35.3 26.9 56.7l0 35c.1 12.4-3.1 25-9.6 36.4l-7.7 13.3c-17.8 30.8-55.3 44-88.5 31.1l-29.8-11.6c-4.1 2.6-8.2 5-12.5 7.2l-4.9 31.5c-5.4 35.1-35.6 61.1-71.2 61.1l-15.3 0c-35.5 0-65.8-25.9-71.2-61.1l-4.9-31.5c-4.3-2.2-8.4-4.7-12.5-7.2l-29.8 11.6c-33.1 12.9-70.7-.3-88.5-31.1l-7.7-13.3C5.6 396 2.4 383.4 2.5 371l0-35c-.2-21.4 9.2-42.5 26.9-56.7l11.5-9.2-11.5-9.2C12 246.8 2.7 226 2.5 205l0-35.8c-.1-12.5 3-25.1 9.6-36.6l7.7-13.3c17.8-30.8 55.3-44 88.5-31.1L138 99.8c4.1-2.6 8.2-5 12.5-7.2l4.9-31.5zM226.6 36c-17.8 0-32.9 13-35.6 30.5l-6.3 40.8c-.9 6-4.8 11.1-10.3 13.6-8.3 3.8-16.3 8.4-23.7 13.7-4.9 3.5-11.3 4.3-17 2.1l-38.5-15c-16.6-6.4-35.3 .2-44.2 15.6l-7.7 13.3c-8.9 15.4-5.2 35 8.6 46.1l32.2 25.9c4.7 3.8 7.2 9.7 6.7 15.7-.8 9-.8 18.4 0 27.4 .6 6-1.9 11.9-6.7 15.7L52 307.3c-13.9 11.1-17.5 30.7-8.6 46.1L51 366.6c8.9 15.4 27.7 22 44.2 15.6l38.5-15c5.7-2.2 12-1.4 17 2.1 7.4 5.3 15.3 9.9 23.7 13.7 5.5 2.5 9.4 7.6 10.3 13.6l6.3 40.8c2.7 17.6 17.8 30.5 35.6 30.5l15.3 0c17.8 0 32.9-13 35.6-30.5l6.3-40.8c.9-6 4.8-11.1 10.3-13.6 8.3-3.8 16.3-8.4 23.7-13.7 4.9-3.5 11.3-4.3 17-2.1l38.5 15c16.6 6.4 35.3-.2 44.2-15.6l7.7-13.3c8.9-15.4 5.2-35-8.6-46.1l-32.2-25.9c-4.7-3.8-7.2-9.7-6.7-15.7 .8-9 .8-18.4 0-27.4-.6-6 1.9-11.9 6.7-15.7l32.2-25.9c13.9-11.1 17.5-30.7 8.6-46.1l-7.7-13.3c-8.9-15.4-27.7-22-44.2-15.6l-38.5 15c-5.7 2.2-12 1.4-17-2.1-7.4-5.3-15.3-9.9-23.7-13.7-5.5-2.5-9.4-7.6-10.3-13.6l-6.3-40.8C274.8 49 259.7 36 241.9 36l-15.3 0zm79.7 216a72 72 0 1 1 -144 0 72 72 0 1 1 144 0zM203 270c6.2 10.8 17.9 18 31.2 18s25-7.2 31.2-18c-6.3-10.8-17.9-18-31.2-18s-24.9 7.2-31.2 18z"],
    "circle-question": [504, 540, [62108, "question-circle"], "f059", "M225 369a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zM198 198c0-29.8 24.2-54 54-54s54 24.2 54 54c0 20.4-11.3 38.2-28.1 47.4-22.5 12.3-43.9 33.1-43.9 60.6 0 9.9 8.1 18 18 18s18-8.1 18-18c0-13.4 14.8-23.4 25.2-29 27.9-15.3 46.8-44.9 46.8-79 0-49.7-40.3-90-90-90s-90 40.3-90 90c0 9.9 8.1 18 18 18s18-8.1 18-18zM0 252C0 112.8 112.8 0 252 0S504 112.8 504 252l0 36c0 139.2-112.8 252-252 252S0 427.2 0 288l0-36zm36 0a216 216 0 1 0 432 0 216 216 0 1 0 -432 0z"],
    "file": [360, 540, [128196, 128459, 61462], "f15b", "M0 90C0 50.2 32.2 18 72 18l108 0c16.3 0 31.9 6.5 43.5 18L342 154.5c11.5 11.5 18 27.2 18 43.5l0 252c0 39.8-32.2 72-72 72L72 522c-39.8 0-72-32.2-72-72L0 90zm36 0l0 324c0 19.9 16.1 36 36 36l216 0c19.9 0 36-16.1 36-36l0-198-90 0c-39.8 0-72-32.2-72-72l0-90-90 0C52.1 54 36 70.1 36 90zM198 61.5l0 82.5c0 19.9 16.1 36 36 36L316.5 180 198 61.5z"],
    "volume-slash": [576, 540, [128263], "f2e2", "M133.5 46.5c120 120 240 240 360 360 14.1 14.1 14.1 36.9 0 50.9s-36.9 14.1-50.9 0c-120-120-240-240-360-360-14.1-14.1-14.1-36.9 0-50.9s36.9-14.1 50.9 0zM234.6 96.8c4.1-4.1 9.2-6.8 15.2-6.8 11.1 0 20.2 9 20.2 20.2l0 22-35.4-35.4zM306 168.2l0-58c0-31-25.2-56.2-56.2-56.2-15.5 0-29.8 6.5-40.6 17.4L158.9 21.1C130.8-7 85.2-7 57.1 21.1 44.1 34 37.2 50.7 36.1 67.6 36 68.3 36 69.1 36 69.8L36 108c0 18.4 7 36.9 21.1 50.9l3.9 3.9C26.5 168.1 0 198 0 234L0 342c0 39.8 32.2 72 72 72l39.1 0c4.8 0 9.4 1.9 12.7 5.3l86.3 86.3c10.5 10.5 24.8 16.5 39.7 16.5 31 0 56.2-25.2 56.2-56.2l0-58 111.1 111.1c28.1 28.1 73.7 28.1 101.8 0 14.1-14.1 21.1-32.5 21.1-50.9l0-36c0-5.5-.6-11-1.9-16.3 23.9-36.7 37.9-80.6 37.9-127.7 0-92-53.1-171.4-130-209.6-35.6-17.7-78.8-3.2-96.5 32.4s-3.2 78.8 32.4 96.5c29.8 14.8 50 45.4 50 80.7 0 2-.1 4-.2 6L306 168.2zM462.6 324.7c3.5-11.6 5.4-24 5.4-36.7 0-49.4-28.4-92.3-70-112.9-17.8-8.8-25.1-30.5-16.2-48.3s30.5-25.1 48.3-16.2c65.1 32.4 110 99.6 110 177.4 0 33.1-8.1 64.3-22.5 91.7l-55-55zM96.2 198l173.8 173.8 0 94c0 11.1-9 20.2-20.2 20.2-5.4 0-10.5-2.1-14.3-5.9l-86.3-86.3c-10.1-10.1-23.9-15.8-38.2-15.8L72 378c-19.9 0-36-16.1-36-36l0-108c0-19.9 16.1-36 36-36l24.2 0z"],
    "arrow-up": [468, 540, [8593], "f062", "M284.9 21.1C256.8-7 211.2-7 183.1 21.1l-162 162C7 197.1 0 215.6 0 234l0 36c0 18.4 7 36.9 21.1 50.9 28.1 28.1 73.7 28.1 101.8 0L162 281.8 162 468c0 39.8 32.2 72 72 72s72-32.2 72-72l0-186.2 39.1 39.1c28.1 28.1 73.7 28.1 101.8 0 14.1-14.1 21.1-32.5 21.1-50.9l0-36c0-18.4-7-36.9-21.1-50.9l-162-162zM270 238.4L270 432c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-229.6c0-15.7-19.6-23.8-30.7-12.7L97.5 259.5c-14.1 14.1-36.9 14.1-50.9 0s-14.1-36.9 0-50.9l162-162c14.1-14.1 36.9-14.1 50.9 0l162 162c14.1 14.1 14.1 36.9 0 50.9s-36.9 14.1-50.9 0l-69.8-69.8c-11.1-11.1-30.7-3-30.7 12.7l0 36z"],
    "rectangle": [504, 540, [9644, "rectangle-landscape"], "f2fa", "M504 414c0 39.8-32.2 72-72 72L72 486c-39.8 0-72-32.2-72-72 0-96 0-192 0-288 0-39.8 32.2-72 72-72l360 0c39.8 0 72 32.2 72 72l0 288zM36 378.4c.2 19.7 16.3 35.6 36 35.6l360 0c19.9 0 36-16.1 36-36l0-252c0-19.9-16.1-36-36-36L72 90c-19.9 0-36 16.1-36 36l0 252.4z"],
    "grid": [432, 540, ["grid-3"], "e195", "M9.6 270C3.5 259.4 0 247.1 0 234L0 108C0 68.2 32.2 36 72 36l90 0c21.5 0 40.8 9.4 54 24.4 13.2-14.9 32.5-24.4 54-24.4l90 0c39.8 0 72 32.2 72 72l0 126c0 13.1-3.5 25.4-9.6 36 6.1 10.6 9.6 22.9 9.6 36l0 126c0 39.8-32.2 72-72 72l-90 0c-21.5 0-40.8-9.4-54-24.4-13.2 14.9-32.5 24.4-54 24.4l-90 0c-39.8 0-72-32.2-72-72L0 306c0-13.1 3.5-25.4 9.6-36zM36 198c0 19.9 16.1 36 36 36l90 0c19.9 0 36-16.1 36-36l0-90c0-19.9-16.1-36-36-36L72 72c-19.9 0-36 16.1-36 36l0 90zm0 198c0 19.9 16.1 36 36 36l90 0c19.9 0 36-16.1 36-36l0-90c0-19.9-16.1-36-36-36l-90 0c-19.9 0-36 16.1-36 36l0 90zm360 0l0-90c0-19.9-16.1-36-36-36l-90 0c-19.9 0-36 16.1-36 36l0 90c0 19.9 16.1 36 36 36l90 0c19.9 0 36-16.1 36-36zm0-198l0-90c0-19.9-16.1-36-36-36l-90 0c-19.9 0-36 16.1-36 36l0 90c0 19.9 16.1 36 36 36l90 0c19.9 0 36-16.1 36-36z"],
    "shirt": [504, 540, [128085, "t-shirt", "tshirt"], "f553", "M144 18c-11.2 0-22.2 2.6-32.2 7.6l-72 36C15.4 73.8 0 98.7 0 126l0 72c0 25 12.9 48.1 34.1 61.2 19 11.7 42.2 13.9 62.9 6.3L90 413c0 .3 0 .7 0 1l0 36c0 39.8 32.2 72 72 72l180 0c39.8 0 72-32.2 72-72l0-36c0-.3 0-.7 0-1l-7-147.5c20.7 7.7 43.9 5.5 62.9-6.3 21.2-13.1 34.1-36.3 34.1-61.2l0-72c0-27.3-15.4-52.2-39.8-64.4l-72-36c-10-5-21-7.6-32.2-7.6-20.7 0-35.6 14.6-42.3 29.4-11.3 25.1-36.5 42.6-65.7 42.6s-54.5-17.4-65.7-42.6C179.6 32.6 164.7 18 144 18zM468 162c0 12.5-6.5 24.1-17.1 30.6s-23.9 7.2-35 1.6l-22.1-11c-12.1-6-26.7 3.5-26 17L378 414.4c-.2 19.7-16.2 35.6-36 35.6l-180 0c-19.8 0-35.8-15.9-36-35.6l10.2-214.3c.6-13.5-13.9-23-26-17l-22.1 11c-11.2 5.6-24.4 5-35-1.6S36 174.5 36 162l0-36c0-13.6 7.7-26.1 19.9-32.2l72-36c9.2-4.6 20.6-6.6 25.5 4.4 16.9 37.6 54.6 63.8 98.6 63.8s81.7-26.2 98.6-63.8c4.9-11 16.3-9 25.5-4.4l72 36C460.3 99.9 468 112.4 468 126l0 36z"],
    "suitcase": [504, 540, [129523], "f0f2", "M126 126l0-18c0-39.8 32.2-72 72-72l108 0c39.8 0 72 32.2 72 72l0 18 54 0c39.8 0 72 32.2 72 72l0 234c0 39.8-32.2 72-72 72L72 504c-39.8 0-72-32.2-72-72L0 198c0-39.8 32.2-72 72-72l54 0zm36-18l0 18 180 0 0-18c0-19.9-16.1-36-36-36L198 72c-19.9 0-36 16.1-36 36zm180 54l-180 0 0 270 180 0 0-270zm36 270l54 0c19.9 0 36-16.1 36-36l0-198c0-19.9-16.1-36-36-36l-54 0 0 270zm-252 0l0-270-54 0c-19.9 0-36 16.1-36 36l0 198c0 19.9 16.1 36 36 36l54 0z"],
    "play": [504, 540, [9654], "f04b", "M72 90c0-25.6 13.6-49.2 35.7-62.2s49.4-13.1 71.6-.6l288 162C490 202 504 226 504 252l0 36c0 26-14 50-36.7 62.8l-288 162c-22.3 12.5-49.6 12.3-71.6-.6S72 475.6 72 450L72 90zm53.8 355.1c11 6.5 24.7 6.6 35.8 .3l288-162C461 277 468 265 468 252s-7-25-18.4-31.4l-288-162c-11.1-6.3-24.8-6.2-35.8 .3S108 77.2 108 90l0 324c0 12.8 6.8 24.6 17.8 31.1z"],
    "paperclip": [504, 540, [128206], "f0c6", "M504 216.2c0 47.8-19 93.6-52.8 127.4L291.8 503.1C268.1 526.7 236 540 202.6 540 127 540 76.8 478.5 76.3 414l0-27.1C56.4 388 36.2 381.1 21.1 365.9 7 351.9 0 333.4 0 315l0-36c0-18.4 7-36.8 21.1-50.9L196.4 52.8C230.2 19 276 0 323.8 0 423.3 0 504 80.7 504 180.2l0 36zM349.5 154.5c-14.1-14.1-36.9-14-50.9 0-79.4 79.3-132.5 132.5-159.6 159.6-56.8 56.8-16.6 153.8 63.7 153.8 23.9 0 46.8-9.5 63.7-26.4L425.8 282.1c27-27 42.2-63.7 42.2-102 0-79.6-64.6-144.2-144.2-144.2-38.2 0-74.9 15.2-102 42.2L46.5 253.5c-14.1 14.1-14.1 36.9 0 50.9s36.9 14 50.9 0L273.1 129.1c28.1-28.1 73.7-28.1 101.8 0s28.1 73.7 0 101.8L215.2 390.7c-7 7-18.4 7-25.5 0s-7-18.4 0-25.5L349.5 205.5c14.1-14.1 14.1-36.9 0-50.9z"],
    "signal-bars-weak": [468, 540, ["signal-alt-1"], "f691", "M144 432c0 39.8-32.2 72-72 72S0 471.8 0 432L0 324c0-39.8 32.2-72 72-72s72 32.2 72 72l0 108zm-72 0c19.9 0 36-16.1 36-36l0-72c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 72c0 19.9 16.1 36 36 36z"],
    "wrench": [468, 540, [128295], "f0ad", "M90 378a18 18 0 1 1 36 0 18 18 0 1 1 -36 0zm36-189l0 36c0 4.9 .2 9.8 .6 14.6L21.1 345.1C8.5 357.7 0 375.8 0 393.8L0 432c0 18.4 7 36.9 21.1 50.9l18 18c28.1 28.1 73.7 28.1 101.8 0L251.9 390c14.4 3.9 29.5 6 45.1 6 94.4 0 171-76.6 171-171l0-36c0-16.4-2.3-32.2-6.6-47.3-7.9-27.6-40.4-30.1-57-13.5l-87.8 87.8-46.5 0 0-10.5 87.8-87.8c6.8-6.8 10.4-16 10.5-24.8l0-35.9c0-15.1-9.3-28-24-32.3-15-4.3-30.9-6.6-47.3-6.6-94.4 0-171 76.6-171 171zm36 0c0-74.6 60.4-135 135-135 11.5 0 22.7 1.4 33.4 4.2L244.5 144c-6.8 6.8-10.5 15.9-10.5 25.5l0 46.5c0 19.9 16.1 36 36 36l46.5 0c9.5 0 18.7-3.8 25.5-10.5l85.8-85.8c2.7 10.7 4.2 21.8 4.2 33.4 0 74.6-60.4 135-135 135-15.5 0-30.4-2.6-44.3-7.4-6.5-2.3-13.8-.6-18.6 4.3L115.5 439.5c-14.1 14.1-36.9 14.1-50.9 0l-18-18c-14.1-14.1-14.1-36.9 0-50.9L165.2 251.9c4.9-4.9 6.5-12.1 4.3-18.6-4.8-13.9-7.4-28.8-7.4-44.3z"],
    "life-ring": [504, 540, [], "f1cd", "M39.1 39.1l.1-.1C64.1 14.3 102.9 11.3 131.1 30.9 167 11.2 208.2 0 252 0s85 11.2 120.9 30.9c28.1-19.5 67-16.8 92 8.2 14.1 14.1 21.1 32.5 21.1 50.9l0 36c0 7.9-1.3 15.7-3.8 23.2 14 31.4 21.8 66.2 21.8 102.8l0 36c0 36.6-7.8 71.4-21.8 102.8 2.6 7.5 3.8 15.4 3.8 23.2l0 36c0 18.4-7 36.9-21.1 50.9-25 25-63.9 27.8-92 8.2-35.9 19.7-77.1 30.9-120.9 30.9s-85-11.2-120.9-30.9c-28.1 19.5-67 16.8-92-8.2-14.1-14.1-21.1-32.5-21.1-50.9l0-36c0-7.9 1.3-15.7 3.8-23.2-14-31.4-21.8-66.2-21.8-102.8l0-36c0-36.6 7.8-71.4 21.8-102.8-2.6-7.5-3.8-15.4-3.8-23.2l0-36c0-18.4 7-36.9 21.1-50.9zM36 252c0 33.3 7.6 64.9 21.1 93.1L144.2 258c-.2-4-.2-8 0-12L57.1 158.9C43.6 187.1 36 218.7 36 252zM64.5 388.5c-14.1 14.1-14.1 36.9 0 50.9s36.9 14.1 50.9 0l90-90c-22.2-10.6-40.3-28.7-50.9-50.9l-90 90zM258 359.8c-4 .2-8 .2-12 0l-87.1 87.1C187.1 460.4 218.7 468 252 468s64.9-7.6 93.1-21.1L258 359.8zm91.5-61.3c-10.6 22.2-28.7 40.3-50.9 50.9l90 90c14.1 14.1 36.9 14.1 50.9 0s14.1-36.9 0-50.9l-90-90zM359.8 246c.2 4 .2 8 0 12l87.1 87.1C460.4 316.9 468 285.3 468 252s-7.6-64.9-21.1-93.1L359.8 246zm-61.3-91.5c22.2 10.6 40.3 28.7 50.9 50.9l90-90c14.1-14.1 14.1-36.9 0-50.9s-36.9-14.1-50.9 0l-90 90zM246 144.2c4-.2 8-.2 12 0l87.1-87.1C316.9 43.6 285.3 36 252 36s-64.9 7.6-93.1 21.1L246 144.2zm-91.5 61.3c10.6-22.2 28.7-40.3 50.9-50.9l-90-90c-14-14-36.8-13.9-50.9 0-14 14.1-14 36.8 0 50.9l90 90zM252 216c-33.5 0-61.7 22.9-69.7 54 8 31.1 36.2 54 69.7 54s61.7-22.9 69.7-54c-8-31.1-36.2-54-69.7-54z"],
    "calendar": [432, 540, [128197, 128198], "f133", "M234 36c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 18-72 0 0-18c0-9.9-8.1-18-18-18S90 26.1 90 36l0 18-18 0C32.2 54 0 86.2 0 126L0 432c0 39.8 32.2 72 72 72l288 0c39.8 0 72-32.2 72-72l0-306c0-39.8-32.2-72-72-72l-18 0 0-18c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 18-72 0 0-18zM90 90l0 18c0 9.9 8.1 18 18 18s18-8.1 18-18l0-18 72 0 0 18c0 9.9 8.1 18 18 18s18-8.1 18-18l0-18 72 0 0 18c0 9.9 8.1 18 18 18s18-8.1 18-18l0-18 18 0c19.9 0 36 16.1 36 36l0 54-360 0 0-54c0-19.9 16.1-36 36-36l18 0zM36 216l360 0 0 180c0 19.9-16.1 36-36 36L72 432c-19.9 0-36-16.1-36-36l0-180z"],
    "check": [504, 540, [10003, 10004], "f00c", "M0 252c0-18.5 7-36.8 21.1-50.9 28.1-28.1 73.7-28.1 101.8 0L180 258.2 381.1 57.1C409.2 29 454.8 29 482.9 57.1 497 71.1 504 89.6 504 108l0 36c0 18.4-7 36.9-21.1 50.9l-252 252c-28.1 28.1-73.7 28.1-101.8 0l-108-108C7.1 325 .1 306.6 0 288.3L0 252zM457.5 82.5c-14.1-14.1-36.9-14.1-50.9 0L192.7 296.4c-7 7-18.4 7-25.5 0L97.5 226.5c-14.1-14.1-36.9-14.1-50.9 0-7 7-10.5 16.3-10.5 25.5 0 9.2 3.5 18.4 10.5 25.4l108 108c14.1 14.1 36.9 14.1 50.9 0l252-252c14.1-14.1 14.1-36.9 0-50.9z"],
    "chart-bar": [468, 540, ["bar-chart"], "f080", "M216 18c-39.8 0-72 32.2-72 72l0 36-72 0c-39.8 0-72 32.2-72 72L0 450c0 39.8 32.2 72 72 72l324 0c39.8 0 72-32.2 72-72l0-180c0-39.8-32.2-72-72-72l-72 0 0-108c0-39.8-32.2-72-72-72l-36 0zM432 414c0 19.9-16.1 36-36 36l-72 0 0-216 72 0c19.9 0 36 16.1 36 36l0 144zM36 414l0-216c0-19.9 16.1-36 36-36l72 0 0 288-72 0c-19.9 0-36-16.1-36-36zm252 36l-108 0 0-360c0-19.9 16.1-36 36-36l36 0c19.9 0 36 16.1 36 36l0 360z"],
    "house": [432, 540, [127968, 63498, 63500, "home", "home-alt", "home-lg-alt"], "f015", "M0 189c0-21.7 9.8-42.2 26.6-55.9l144-117C197-5.4 235-5.4 261.4 16.1l144 117C422.2 146.8 432 167.3 432 189l0 243c0 39.8-32.2 72-72 72l-36 0c-39.8 0-72-32.2-72-72l0-72c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 72c0 39.8-32.2 72-72 72l-36 0c-39.8 0-72-32.2-72-72L0 189zM193.3 44.1l-144 117C40.9 167.9 36 178.2 36 189l0 207c0 19.9 16.1 36 36 36l36 0c19.9 0 36-16.1 36-36l0-72c0-39.8 32.2-72 72-72s72 32.2 72 72l0 72c0 19.9 16.1 36 36 36l36 0c19.9 0 36-16.1 36-36l0-207c0-10.8-4.9-21.1-13.3-27.9l-144-117c-13.2-10.7-32.2-10.7-45.4 0z"],
    "play-pause": [504, 540, [], "e22f", "M0 144c0-27.3 15.4-52.2 39.8-64.4s53.6-9.6 75.4 6.8L252 189 252 144c0-39.8 32.2-72 72-72 21.5 0 40.8 9.4 54 24.4 13.2-14.9 32.5-24.4 54-24.4 39.8 0 72 32.2 72 72l0 252c0 39.8-32.2 72-72 72-21.5 0-40.8-9.4-54-24.4-13.2 14.9-32.5 24.4-54 24.4-39.8 0-72-32.2-72-72l0-45-136.8 102.6c-21.8 16.4-51 19-75.4 6.8S0 423.3 0 396L0 144zM324 396c19.9 0 36-16.1 36-36l0-216c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 216c0 19.9 16.1 36 36 36zM237.6 223.2l-144-108c-10.9-8.2-25.5-9.5-37.7-3.4S36 130.4 36 144l0 216c0 13.6 7.7 26.1 19.9 32.2s26.8 4.8 37.7-3.4l144-108C246.7 274 252 263.3 252 252s-5.3-22-14.4-28.8zM396 360c0 19.9 16.1 36 36 36s36-16.1 36-36l0-216c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 216z"],
    "sliders": [504, 540, ["sliders-h"], "f1de", "M0 126C0 86.2 32.2 54 72 54l200.3 0c8-31.1 36.2-54 69.7-54s61.7 22.9 69.7 54L432 54c39.8 0 72 32.2 72 72l0 36c0 39.8-32.2 72-72 72l-20.3 0c-8 31.1-36.2 54-69.7 54s-61.7-22.9-69.7-54L72 234c-39.8 0-72-32.2-72-72l0-36zM342 36c-19.9 0-36 16.1-36 36l0 108c0 19.9 16.1 36 36 36s36-16.1 36-36l0-108c0-19.9-16.1-36-36-36zM72 90c-19.9 0-36 16.1-36 36s16.1 36 36 36l198 0 0-72-198 0zm396 36c0-19.9-16.1-36-36-36l-18 0 0 72 18 0c19.9 0 36-16.1 36-36zM0 378c0-39.8 32.2-72 72-72l20.3 0c8-31.1 36.2-54 69.7-54s61.7 22.9 69.7 54L432 306c39.8 0 72 32.2 72 72l0 36c0 39.8-32.2 72-72 72l-200.3 0c-8 31.1-36.2 54-69.7 54s-61.7-22.9-69.7-54L72 486c-39.8 0-72-32.2-72-72l0-36zm162-90c-19.9 0-36 16.1-36 36l0 108c0 19.9 16.1 36 36 36s36-16.1 36-36l0-108c0-19.9-16.1-36-36-36zM72 342c-19.9 0-36 16.1-36 36s16.1 36 36 36l18 0 0-72-18 0zm396 36c0-19.9-16.1-36-36-36l-198 0 0 72 198 0c19.9 0 36-16.1 36-36z"],
    "face-frown": [504, 540, [9785, "frown"], "f119", "M154.4 349.7c-4.3 9-15 12.8-24 8.5s-12.8-15-8.5-24C145 285.7 194.5 252 252 252s107 33.7 130.1 82.3c4.3 9 .4 19.7-8.5 24s-19.7 .4-24-8.5C332.3 313.2 295.1 288 252 288s-80.3 25.2-97.6 61.7zM162 171a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zm153 27a27 27 0 1 0 0-54 27 27 0 1 0 0 54zM252 0C112.8 0 0 112.8 0 252l0 36C0 427.2 112.8 540 252 540S504 427.2 504 288l0-36C504 112.8 391.2 0 252 0zm0 468a216 216 0 1 1 0-432 216 216 0 1 1 0 432z"],
    "forward-step": [432, 540, ["step-forward"], "f051", "M252 144c0-39.8 32.2-72 72-72l36 0c39.8 0 72 32.2 72 72l0 252c0 39.8-32.2 72-72 72l-36 0c-39.8 0-72-32.2-72-72l0-45-136.8 102.6c-21.8 16.4-51 19-75.4 6.8S0 423.3 0 396L0 144c0-27.3 15.4-52.2 39.8-64.4s53.6-9.6 75.4 6.8L252 189 252 144zM36 360c0 13.6 7.7 26.1 19.9 32.2s26.8 4.8 37.7-3.4l144-108C246.7 274 252 263.3 252 252s-5.3-22-14.4-28.8l-144-108c-10.9-8.2-25.5-9.5-37.7-3.4S36 130.4 36 144l0 216zm252 0c0 19.9 16.1 36 36 36l36 0c19.9 0 36-16.1 36-36l0-216c0-19.9-16.1-36-36-36l-36 0c-19.9 0-36 16.1-36 36l0 216z"],
    "wand-magic": [468, 540, ["magic"], "f0d0", "M327.1 39.1c28.1-28.1 73.7-28.1 101.8 0l18 18C461 71.1 468 89.6 468 108l0 36c0 18.4-7 36.9-21.1 50.9l-306 306c-28.1 28.1-73.7 28.1-101.8 0l-18-18C7 468.9 0 450.4 0 432l0-36c0-18.4 7-36.9 21.1-50.9l306-306zM46.5 421.5l18 18c14.1 14.1 36.9 14.1 50.9 0l221.3-221.3-68.9-68.9-221.3 221.3c-14.1 14.1-14.1 36.9 0 50.9zM362.2 192.7l59.3-59.3c14.1-14.1 14.1-36.9 0-50.9l-18-18c-14.1-14.1-36.9-14.1-50.9 0l-59.3 59.3 68.9 68.9z"],
    "sort": [396, 540, ["unsorted"], "f0dc", "M9.6 270c-1.6-2.7-3-5.5-4.2-8.4-3.6-8.7-5.4-18-5.5-27.1l0-35.7c-.2-19 7.1-37.7 21.1-51.7l126-126C175.2-7 220.8-7 248.9 21.1l126 126c13.9 13.9 21.2 32.5 21.1 51.4l0 36.2c-.1 9.1-1.9 18.2-5.5 26.9-1.2 2.9-2.6 5.7-4.2 8.4 1.6 2.7 3 5.5 4.2 8.4 3.8 9.1 5.6 18.7 5.5 28.1l0 35.4c0 18.7-7.3 37.1-21.1 50.9l-126 126c-28.1 28.1-73.7 28.1-101.8 0l-126-126C7.3 379.1 0 360.7 0 342l0-35.5c-.1-9.4 1.7-19 5.5-28 1.2-2.9 2.6-5.7 4.2-8.4zM172.5 46.5l-126 126c-6.9 6.9-10.5 16.1-10.5 25.5 .2 19.3 16.5 36 36 36l252 0c19.5 0 35.9-16.6 36-36 0-9.4-3.7-18.6-10.5-25.5l-126-126c-14.1-14.1-36.9-14.1-50.9 0zM72 270c-19.6 0-36 16.5-36 36 0 9.3 3.7 18.6 10.5 25.5l126 126c14.1 14.1 36.9 14.1 50.9 0l126-126c6.8-6.8 10.5-16.2 10.5-25.5 0-19.5-16.4-36-36-36L72 270z"],
    "user": [432, 540, [128100, 62144, 62470, "user-alt", "user-large"], "f007", "M216 18C146.4 18 90 74.4 90 144l0 36c0 28.5 9.4 54.7 25.4 75.8-25.8 12.2-46.6 28.2-62.8 44.3-19 19-36.8 42.7-47.4 69.1-3.5 8.6-5.2 17.7-5.2 26.8l0 36C0 446.2 4.2 460.3 12.4 472.4 25.8 492.1 48.1 504 72 504l288 0c23.9 0 46.2-11.9 59.6-31.6 8.2-12.1 12.4-26.2 12.4-40.4l0-36c0-9-1.7-18.2-5.2-26.8-10.6-26.5-28.4-50.1-47.4-69.1-16.1-16.1-36.9-32.1-62.8-44.3 15.9-21.1 25.3-47.4 25.3-75.8l0-36c0-69.6-56.4-126-126-126zm0 252c65.2 0 110 27.6 138 55.5 16.7 16.7 31.1 36.3 39.5 57.1 4.4 11.1 3.1 23.6-3.6 33.5S371.9 432 360 432L72 432c-11.9 0-23.1-5.9-29.8-15.8s-8.1-22.5-3.6-33.5c8.3-20.8 22.8-40.4 39.5-57.1 28-28 72.7-55.5 138-55.5zm90-126a90 90 0 1 1 -180 0 90 90 0 1 1 180 0z"],
    "signal-bars": [468, 540, ["signal-alt", "signal-alt-4", "signal-bars-strong"], "f690", "M468 108c0-39.8-32.2-72-72-72s-72 32.2-72 72l0 9.6c-10.6-6.1-22.9-9.6-36-9.6-39.8 0-72 32.2-72 72l0 9.6c-10.6-6.1-22.9-9.6-36-9.6-39.8 0-72 32.2-72 72l0 9.6c-10.6-6.1-22.9-9.6-36-9.6-39.8 0-72 32.2-72 72L0 432c0 39.8 32.2 72 72 72 21.5 0 40.8-9.4 54-24.4 13.2 14.9 32.5 24.4 54 24.4s40.8-9.4 54-24.4c13.2 14.9 32.5 24.4 54 24.4s40.8-9.4 54-24.4c13.2 14.9 32.5 24.4 54 24.4 39.8 0 72-32.2 72-72l0-324zM432 396c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-288c0-19.9 16.1-36 36-36s36 16.1 36 36l0 288zM36 396l0-72c0-19.9 16.1-36 36-36s36 16.1 36 36l0 72c0 19.9-16.1 36-36 36s-36-16.1-36-36zm144 36c-19.9 0-36-16.1-36-36l0-144c0-19.9 16.1-36 36-36s36 16.1 36 36l0 144c0 19.9-16.1 36-36 36zm72-36l0-216c0-19.9 16.1-36 36-36s36 16.1 36 36l0 216c0 19.9-16.1 36-36 36s-36-16.1-36-36z"],
    "snowflake": [504, 540, [10052, 10054], "f2dc", "M252.5 558c-16.6 0-33.1-5.7-46.6-17.1l-66.8-56.6-82.4-29.5c-16.6-5.9-29.8-17.5-38.1-31.9-6.2-10.7-9.6-23.1-9.6-35.8L9 351c0-4.3 .4-8.6 1.2-12.9L22.6 270 10.2 201.9c-.8-4.3-1.2-8.7-1.2-13L9 153c0-12.8 3.4-25.1 9.6-35.9 8.3-14.3 21.6-26 38.2-31.9L139.2 55.7 205.9-.9c26.9-22.8 66.3-22.8 93.1 0l66.8 56.6 82.4 29.5c16.5 5.9 29.9 17.6 38.2 31.9 6.2 10.7 9.6 23.1 9.6 35.9l0 35.9c0 4.3-.4 8.6-1.2 13l-12.4 68.1 12.4 68.1c.8 4.3 1.2 8.6 1.2 12.9l0 36.1c0 12.8-3.4 25.1-9.6 35.9-8.3 14.3-21.6 25.9-38.1 31.9l-82.4 29.5-66.8 56.6c-13.4 11.4-30 17.1-46.6 17.1zm-72-288l-121.3 0-13.6 74.6c-.4 2.2-.6 4.3-.6 6.4l42.6-24.6c8.6-5 19.6-2 24.6 6.6s2 19.6-6.6 24.6L63 382.2c1.8 1.1 3.8 2 5.9 2.7l71.3 25.5 60.7-105.1c5-8.6 16-11.6 24.6-6.6s11.6 16 6.6 24.6l-60.7 105.1 57.8 49c1.7 1.4 3.4 2.7 5.3 3.7l0-49.2c0-9.9 8.1-18 18-18s18 8.1 18 18l0 49.2c1.8-1.1 3.6-2.3 5.3-3.7l57.8-49-60.7-105.1c-5-8.6-2-19.6 6.6-24.6s19.6-2 24.6 6.6l60.7 105.1 71.4-25.5c2.1-.7 4-1.7 5.9-2.7l-42.6-24.6c-8.6-5-11.6-16-6.6-24.6s16-11.6 24.6-6.6L460 351c0-2.1-.2-4.3-.6-6.4l-13.6-74.6-121.3 0c-9.9 0-18-8.1-18-18s8.1-18 18-18l121.3 0 13.6-74.6c.4-2.2 .6-4.3 .6-6.4l-42.6 24.6c-8.6 5-19.6 2-24.6-6.6s-2-19.6 6.6-24.6L442 121.8c-1.8-1.1-3.8-2-5.9-2.7l-71.4-25.5-60.7 105.1c-5 8.6-16 11.6-24.6 6.6s-11.6-16-6.6-24.6l60.7-105.1-57.8-49c-1.7-1.4-3.4-2.7-5.3-3.7l0 49.2c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-49.2c-1.8 1.1-3.6 2.3-5.3 3.7l-57.8 49 60.7 105.1c5 8.6 2 19.6-6.6 24.6s-19.6 2-24.6-6.6L140.2 93.6 68.9 119.1c-2.1 .7-4 1.7-5.9 2.7l42.6 24.6c8.6 5 11.6 16 6.6 24.6s-16 11.6-24.6 6.6L45 153c0 2.1 .2 4.3 .6 6.4l13.6 74.6 121.3 0c9.9 0 18 8.1 18 18s-8.1 18-18 18z"],
    "skull-crossbones": [504, 540, [128369, 9760], "f714", "M113.3 67C80.7 44.2 35.8 52.1 13 84.7 4.2 97.3 0 111.7 0 126l0 36c0 22.7 10.7 45 30.7 59L72 249.9c-.2 13.4-.2 26.8 0 40.2L30.7 319C10.7 333 0 355.3 0 378l0 36c0 14.3 4.2 28.7 13 41.3 22.8 32.6 67.7 40.5 100.3 17.7l18.4-12.9C142.6 485.9 168.2 504 198 504l108 0c29.8 0 55.4-18.1 66.3-43.9L390.7 473c32.6 22.8 77.5 14.9 100.3-17.7 8.8-12.6 13-27 13-41.3l0-36c0-22.7-10.7-45-30.7-59L432 290.1c0-.7 0-1.4 0-2.1l0-36c0-.7 0-1.4 0-2.1L473.3 221c20-14 30.7-36.3 30.7-59l0-36c0-14.3-4.2-28.7-13-41.3-22.8-32.6-67.7-40.5-100.3-17.7L345.9 98.4C318.6 81.7 286.4 72 252 72s-66.6 9.7-93.9 26.4L113.3 67zM86.8 323.7c9.3 21.5 22.7 40.7 39.2 56.9l0 3.6-33.4 23.3c-16.3 11.4-38.7 7.4-50.1-8.8s-7.4-38.7 8.8-50.1l35.5-24.8zM306 432l0-36c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 36-36 0 0-36c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 36c-19.8 0-35.9-16.1-36-35.9l0-23.4c0-5.1-2.2-10-6-13.4-29.5-26.4-48-64.7-48-107.3 0-79.5 64.5-144 144-144s144 64.5 144 144c0 42.6-18.5 80.9-48 107.3-3.8 3.4-6 8.3-6 13.4l0 23.3c0 19.9-16.1 36-36 36zM207 180c-34.8 0-63 28.2-63 63s28.2 63 63 63c17.6 0 33.6-7.2 45-18.9 11.4 11.7 27.4 18.9 45 18.9 34.8 0 63-28.2 63-63s-28.2-63-63-63c-17.6 0-33.6 7.2-45 18.9-11.4-11.7-27.4-18.9-45-18.9zm0 90a27 27 0 1 1 0-54 27 27 0 1 1 0 54zm117-27a27 27 0 1 1 -54 0 27 27 0 1 1 54 0zM42.5 105.4c11.4-16.3 33.8-20.2 50.1-8.8l35.5 24.9c-17.5 16.6-31.6 36.6-41.3 59L51.4 155.5c-16.3-11.4-20.2-33.8-8.8-50.1zm410.1 50.1l-35.5 24.8c-9.7-22.4-23.9-42.4-41.3-59l35.5-24.9c16.3-11.4 38.7-7.4 50.1 8.8s7.4 38.7-8.8 50.1zM378 384.1l0-3.6c16.5-16.1 29.8-35.4 39.2-56.9l35.5 24.8c16.3 11.4 20.3 33.8 8.8 50.1s-33.8 20.3-50.1 8.8L378 384.1z"],
    "ticket": [504, 540, [127903], "f145", "M504 126c0-39.8-32.2-72-72-72L72 54C32.2 54 0 86.2 0 126l0 36c0 15.5 10.3 28.1 22.9 36-12.6 7.9-22.9 20.5-22.9 36l0 72c0 15.5 10.3 28.1 22.9 36-12.6 7.9-22.9 20.5-22.9 36l0 36c0 39.8 32.2 72 72 72l360 0c39.8 0 72-32.2 72-72l0-36c0-15.5-10.3-28.1-22.9-36 12.6-7.9 22.9-20.5 22.9-36l0-72c0-15.5-10.3-28.1-22.9-36 12.6-7.9 22.9-20.5 22.9-36l0-36zM432 414L72 414c-19.8 0-35.9-16.2-36-36 1-2.9 4.9-5 7.4-6.4l.5-.2C60.6 362.2 72 344.5 72 324s-11.4-38.2-28.1-47.4l-.2-.1c-2.6-1.4-6.7-3.7-7.7-6.6l0-35.8c1-3 5.2-5.2 7.7-6.6l.2-.1C60.6 218.2 72 200.5 72 180s-11.4-38.2-28.1-47.4l-.2-.1c-2.6-1.4-6.7-3.7-7.7-6.6 .1-19.8 16.2-35.9 36-35.9l360 0c19.8 0 35.9 16.1 36 35.9-1.1 3-5.2 5.2-7.7 6.6l-.2 .1C443.4 141.8 432 159.5 432 180s11.4 38.2 28.1 47.4l.2 .1c2.6 1.4 6.7 3.7 7.7 6.6l0 35.8c-1 3-5.2 5.2-7.7 6.6l-.2 .1C443.4 285.8 432 303.5 432 324s11.4 38.2 28.1 47.4l.5 .2c2.6 1.4 6.4 3.5 7.4 6.4-.1 19.8-16.2 36-36 36zM280.9 363.3c15.6 9.8 35.5 9.1 50.4-1.7S353 332 348.5 314.2l-8.4-33.1 26.3-21.9c14.1-11.8 19.7-31 14-48.5s-21.5-29.8-39.8-31l-34.1-2.3-12.7-31.7c-6.8-17.1-23.4-28.3-41.8-28.3s-34.9 11.2-41.8 28.3l-12.7 31.7-34.1 2.3c-18.4 1.2-34.1 13.5-39.8 31s-.1 36.7 14 48.5l26.3 21.9-8.4 33.1c-4.5 17.8 2.3 36.6 17.2 47.4s34.9 11.5 50.4 1.7l28.9-18.2 28.9 18.2zM260.4 159.1l16.9 42.3c2.6 6.4 8.6 10.8 15.5 11.3l45.4 3c3.7 .2 6.8 2.7 8 6.2s0 7.3-2.8 9.7l-35 29.1c-5.3 4.4-7.6 11.5-5.9 18.2L313.6 323c.9 3.6-.5 7.3-3.4 9.5s-7 2.3-10.1 .3l-38.5-24.3c-5.9-3.7-13.3-3.7-19.2 0l-38.5 24.3c-3.1 2-7.1 1.8-10.1-.3s-4.3-5.9-3.4-9.5l11.2-44.1c1.7-6.7-.6-13.8-5.9-18.2l-35-29.1c-2.8-2.4-3.9-6.2-2.8-9.7s4.3-6 8-6.2l45.4-3c6.9-.5 12.9-4.8 15.5-11.3l16.9-42.3c1.4-3.4 4.7-5.7 8.4-5.7s7 2.2 8.4 5.7z"],
    "wheelchair": [432, 540, [], "f193", "M108 108l0-36c0-39.8 32.2-72 72-72s72 32.2 72 72l0 36c0 13.1-3.5 25.4-9.6 36l9.6 0c39.8 0 72 32.2 72 72l0 36c28.6 3.6 52.7 24.7 60.5 53.1l27 99c1.9 6.9 2.7 13.8 2.5 20.6l0 34.4c0 31.7-21 60.7-53.1 69.5-38.4 10.5-77.9-12.2-88.4-50.5l-3.1-11.2C244.8 510.5 197.8 540 144 540 64.5 540 0 475.5 0 396l0-36c0-67.1 45.9-123.5 108-139.5l0-31.5c0-14.9 4.6-28.9 12.5-40.5-7.9-11.5-12.5-25.5-12.5-40.5zm72-72a36 36 0 1 0 0 72 36 36 0 1 0 0-72zm72 144l-25.2 0c-6.4 0-12.4-3.4-15.6-9-7.1-12.4-21.2-19.6-36-17.7-17.9 2.4-31.2 17.6-31.2 35.7l0 135c0 19.9 16.1 36 36 36l93.8 0c8.1 0 15.2 5.4 17.4 13.3l16.1 59.2c5.2 19.2 25 30.5 44.2 25.3 18.9-5.2 30.4-25.4 25.3-44.2l-27-99C345.5 298.9 331.2 288 315 288l-81 0c-9.9 0-18-8.1-18-18s8.1-18 18-18c7.3 0 14.8 .6 22-.2 18-2 32-17.3 32-35.8 0-19.9-16.1-36-36-36zM180 396c-39.8 0-72-32.2-72-72l0-65.9c-41.9 14.8-72 54.8-72 101.9 0 59.6 48.4 108 108 108 47 0 87-30.1 101.9-72L180 396z"],
    "bookmark": [360, 540, [128278, 61591], "f02e", "M0 90C0 50.2 32.2 18 72 18l216 0c39.8 0 72 32.2 72 72l0 360c0 29.1-17.5 55.4-44.4 66.5s-57.9 5-78.5-15.6l-57.1-57.1-57.1 57.1c-20.6 20.6-51.6 26.8-78.5 15.6S0 479.1 0 450L0 90zm36 0l0 324c0 14.6 8.8 27.7 22.2 33.3s28.9 2.5 39.2-7.8l69.8-69.8c7-7 18.4-7 25.5 0l69.8 69.8c10.3 10.3 25.8 13.4 39.2 7.8S324 428.6 324 414l0-324c0-19.9-16.1-36-36-36L72 54C52.1 54 36 70.1 36 90z"],
    "bomb": [504, 540, [128163], "f1e2", "M198 216c9.9 0 18-8.1 18-18s-8.1-18-18-18c-59.6 0-108 48.4-108 108 0 9.9 8.1 18 18 18s18-8.1 18-18c0-39.8 32.2-72 72-72zM396 18c-29.8 0-54 24.2-54 54l0 24.2-3.1-3.1C311.1 65.2 266.1 65 237.9 92.3 227.8 90.8 217.5 90 207 90 92.7 90 0 182.7 0 297l0 36C0 447.3 92.7 540 207 540s207-92.7 207-207l0-33.4C426 286 432 269 432 252l0-36c0-6.1-.8-12.1-2.3-18l2.3 0c29.8 0 54-24.2 54-54l0-72c0-29.8-24.2-54-54-54l-36 0zM207 468c-94.4 0-171-76.6-171-171s76.6-171 171-171c11.5 0 22.7 1.1 33.5 3.3 9.7 1.9 15.8-4.5 22-10.7 14.1-14.1 36.9-14.1 50.9 0l72 72c14.1 14.1 14.1 36.9 0 50.9-6.2 6.2-12.7 12.3-10.7 22 2.1 10.8 3.3 22 3.3 33.5 0 94.4-76.6 171-171 171zM432 54c9.9 0 18 8.1 18 18l0 36c0 9.9-8.1 18-18 18l-36 0c-9.9 0-18-8.1-18-18l0-36c0-9.9 8.1-18 18-18l36 0z"],
    "arrow-right": [504, 540, [8594], "f061", "M219.1 39.1c28.1-28.1 73.7-28.1 101.8 0l162 162C497 215.1 504 233.6 504 252l0 36c0 18.4-7 36.9-21.1 50.9l-162 162c-28.1 28.1-73.7 28.1-101.8 0-14-14-21.1-32.5-21.1-50.9l0-36.1c0-21.2 9.5-39.3 24.2-53.9L72 360c-39.8 0-72-32.2-72-72l0-36c0-39.8 32.2-72 72-72l126 0 0-90.1c0-18.4 7-36.8 21.1-50.9zM234 414c0 9.2 3.5 18.4 10.5 25.4 14.1 14.1 36.9 14.1 50.9 0l162-162c14.1-14.1 14.1-36.8 0-50.9l-162-162c-14.1-14.1-36.9-14.1-50.9 0s-14.1 36.9 0 50.9l69.8 69.8c11.1 11.1 3 30.7-12.7 30.7L72 216c-19.9 0-36 16.1-36 36s16.1 36 36 36l229.6 0c15.7 0 23.8 19.6 12.7 30.7l-69.8 69.8c-7 7-10.5 16.3-10.5 25.5z"],
    "battery-bolt": [576, 540, [], "f376", "M246.1 50.1c19.2-28.8 56.3-39.9 88.2-26.3 27 11.5 43.8 37.9 43.7 66.2l72 0c39.8 0 72 32.2 72 72l0 20.3c31.1 8 54 36.2 54 69.7l0 72c0 33.5-22.9 61.7-54 69.7l0 20.3c0 39.8-32.2 72-72 72l-117.5 0-2.6 3.9c-19.2 28.8-56.3 39.9-88.2 26.3-14.8-6.3-26.5-17.1-34.1-30.2L108 486c-39.8 0-72-32.2-72-72l0-252c0-39.8 32.2-72 72-72l111.5 0 26.6-39.9zM195.5 126L108 126c-19.9 0-36 16.1-36 36l0 252c0 19.9 16.1 36 36 36l90 0 0-35.9c0-5.2 .6-10.5 1.7-15.7l8.5-38.4-10.2 0c-26.6 0-51-14.6-63.5-38-5.7-10.6-8.5-22.3-8.5-34l0-36.1c0-13.9 4.1-27.9 12.1-39.9L195.5 126zM356.5 450l93.5 0c19.9 0 36-16.1 36-36l0-36c0-9.9 8.1-18 18-18 19.9 0 36-16.1 36-36l0-72c0-19.9-16.1-36-36-36-9.9 0-18-8.1-18-18l0-36c0-19.9-16.1-36-36-36l-72 0c0 5.2-.6 10.4-1.7 15.6l-8.5 38.4 10.2 0c26.6 0 51 14.6 63.5 38 5.7 10.6 8.5 22.3 8.5 33.9l0 36.1c0 14-4.1 27.9-12.1 39.9L356.5 450zM276 70L168 232c-7.4 11-8.1 25.3-1.8 37s18.5 19 31.7 19l40.7 0c11.3 0 20 10.8 17.6 21.9l-21.4 96.3c-3.8 16.9 5.1 34.1 21 40.9s34.5 1.3 44.1-13.1L408 272c7.4-11 8.1-25.3 1.8-37s-18.5-19-31.7-19l-40.7 0c-11.3 0-20-10.8-17.6-21.9l21.4-96.3c3.8-16.9-5.1-34.1-21-40.9S285.7 55.6 276 70z"],
    "xmark": [432, 540, [128473, 10005, 10006, 10060, 215, "close", "multiply", "remove", "times"], "f00d", "M0 108.4C-.1 89.8 6.9 71.2 21.1 57.1 49.2 29 94.8 29 122.9 57.1l93.1 93.1 93.1-93.1c28.1-28.1 73.7-28.1 101.8 0 13.5 13.5 20.5 31 21.1 48.7l0 38.2c0 18.4-7 36.9-21.1 50.9l-75.1 75.1 75.1 75.1C425 359.1 432 377.6 432 396l0 36c0 18.4-7 36.9-21.1 50.9-28.1 28.1-73.7 28.1-101.8 0l-93.1-93.1-93.1 93.1C94.8 511 49.2 511 21.1 482.9 6.9 468.8-.1 450.2 0 431.7l0-35.3c-.1-18.5 6.9-37.1 21.1-51.2L96.2 270 21.1 194.9C7 180.9 0 162.4 0 144l0-35.6zM46.5 82.5C39.5 89.6 36 98.8 36 108l0 .3c.1 9.1 3.6 18.2 10.5 25.2L152.4 239.3c3.4 3.4 5.3 8 5.3 12.7s-1.9 9.4-5.3 12.7L46.5 370.5c-7 7-10.5 16.5-10.5 25.7 .1 9.1 3.6 18.3 10.5 25.2 14.1 14.1 36.9 14.1 50.9 0L203.3 315.6c7-7 18.4-7 25.5 0L334.5 421.5c14.1 14.1 36.9 14.1 50.9 0s14.1-36.9 0-50.9L279.6 264.7c-7-7-7-18.4 0-25.5L385.5 133.5c14.1-14.1 14.1-36.9 0-50.9s-36.9-14.1-50.9 0L228.7 188.4c-7 7-18.4 7-25.5 0L97.5 82.5c-14.1-14.1-36.9-14.1-50.9 0z"],
    "lock-open": [468, 540, [], "f3c1", "M279 351c9.9 0 18-8.1 18-18s-8.1-18-18-18l-90 0c-9.9 0-18 8.1-18 18s8.1 18 18 18l90 0zM216 126C216 56.4 272.4 0 342 0S468 56.4 468 126l0 36c0 34.5-24.3 63.4-56.7 70.4 1.8 6.2 2.7 12.8 2.7 19.6l0 198c0 39.8-32.2 72-72 72l-216 0c-39.8 0-72-32.2-72-72l0-198c0-39.8 32.2-72 72-72l90 0 0-54zM378 252c0-19.9-16.1-36-36-36l-216 0c-19.9 0-36 16.1-36 36l0 162c0 19.9 16.1 36 36 36l216 0c19.9 0 36-16.1 36-36l0-162zM342 36c-49.7 0-90 40.3-90 90l0 54 72 0 0-54c0-9.9 8.1-18 18-18s18 8.1 18 18c0 19.9 16.1 36 36 36s36-16.1 36-36c0-49.7-40.3-90-90-90z"],
    "droplet": [360, 540, [128167, "tint"], "f043", "M126 306c0-9.9-8.1-18-18-18s-18 8.1-18 18c0 49.7 40.3 90 90 90 9.9 0 18-8.1 18-18s-8.1-18-18-18c-29.8 0-54-24.2-54-54zM52.6 135.6C29.1 180.6 0 246.2 0 306l0 36c0 99.4 80.6 180 180 180s180-80.6 180-180l0-36c0-59.8-29.1-125.4-52.6-170.4-25.2-48.4-52.4-88.4-61.2-101-15.4-22.1-40.3-34.5-66.2-34.5s-50.8 12.5-66.2 34.5c-8.8 12.7-36 52.7-61.2 101zM180 36c14.4 0 28.2 6.9 36.6 19.1 8.4 12.1 34.6 50.7 58.8 97.1 23.3 44.7 48.5 103.4 48.5 153.8 0 79.5-64.5 144-144 144S36 385.5 36 306c0-50.3 25.2-109 48.5-153.8 24.2-46.4 50.4-85 58.8-97.1 8.5-12.2 22.3-19.1 36.6-19.1z"],
    "shop": [540, 540, ["store-alt"], "f54f", "M306 414c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 18c0 39.8-32.2 72-72 72l-36 0c-39.8 0-72-32.2-72-72l0-139.7C21.7 283.2 0 248.4 0 216l0-35.1c-.1-9.7 1.6-19.6 5.2-29.3L27.8 91.2C42.3 52.6 79.2 27 120.5 27l299.1 0c41.3 0 78.2 25.6 92.7 64.2l22.6 60.3c3.6 9.7 5.3 19.6 5.2 29.3l0 35.1c0 32.4-21.7 67.2-54 76.3L486 432c0 39.8-32.2 72-72 72l-36 0c-39.8 0-72-32.2-72-72l0-18zm27-189c24.5 0 45-20.6 45-45 0-9.9 8.1-18 18-18s18 8.1 18 18c0 24.4 20.5 45 45 45 30.5 0 53-31.8 42.1-60.8l-22.6-60.3c-9.2-24.6-32.7-40.9-59-40.9L120.5 63c-26.3 0-49.8 16.3-59 40.9L38.9 164.2c-10.9 29.1 11.6 60.8 42.1 60.8 24.5 0 45-20.6 45-45 0-9.9 8.1-18 18-18s18 8.1 18 18c0 24.4 20.5 45 45 45 24.9 0 45-20.1 45-45 0-9.9 8.1-18 18-18s18 8.1 18 18c0 24.9 20.1 45 45 45zm63 5.9c-14.8 18.3-37.5 30.1-63 30.1s-48.1-11.7-63-30.1c-14.8 18.4-37.6 30.1-63 30.1s-48.1-11.7-63-30.1c-13.5 16.7-33 27.2-54 29.6L90 396c0 19.9 16.1 36 36 36l36 0c19.9 0 36-16.1 36-36l0-18c0-39.8 32.2-72 72-72s72 32.2 72 72l0 18c0 19.9 16.1 36 36 36l36 0c19.9 0 36-16.1 36-36l0-135.5c-21-2.4-40.6-12.9-54-29.6z"],
    "film": [504, 540, [127902, 62368, "film-alt", "film-simple"], "f008", "M0 126L0 414c0 39.8 32.2 72 72 72l360 0c39.8 0 72-32.2 72-72l0-288c0-39.8-32.2-72-72-72L72 54C32.2 54 0 86.2 0 126zm468 36l-90 0 0-72 54 0c19.9 0 36 16.1 36 36l0 36zm0 36l0 108-90 0 0-108 90 0zm0 144l0 36c0 19.9-16.1 36-36 36l-54 0 0-72 90 0zM342 414l-180 0 0-324 180 0 0 324zM72 90l54 0 0 72-90 0 0-36c0-19.9 16.1-36 36-36zm54 108l0 108-90 0 0-108 90 0zM36 378l0-36 90 0 0 72-54 0c-19.9 0-36-16.1-36-36z"],
    "comments": [540, 540, [128490, 61670], "f086", "M0 180C0 75.1 90.3 0 189 0 256.4 0 319.3 34.7 352.9 90 450.9 91 540 165.8 540 270l0 36c0 50.4-21.1 94.3-54 126l0 35.4c.2 20.2-8.2 40-23.7 54-21.2 19.2-51.8 24-77.8 12.2L278.3 485.9c-31.5-14.2-57.9-35.9-77.6-62.6l-45.1 20.3c-26.1 11.7-56.6 6.9-77.8-12.2-15.5-14-23.9-33.8-23.7-54L54 342C21.1 310.3 0 266.4 0 216l0-36zm36 0c0 46.1 22.1 85.4 56.1 111.4 6.1 4.7 8.6 12.7 6.1 20l-6.4 19.2c-4.5 13.4-.5 28.6 10 38.1 10.6 9.6 25.9 12 38.9 6.1l41.1-18.5C169 329.9 162 300.5 162 270 162 179.2 229.6 110.7 311.8 94 283.4 58.4 238 36 189 36 107.1 36 36 97.9 36 180zm315-54c-81.9 0-153 61.9-153 144 0 63.5 37.2 121 95.1 147.1l106.1 47.8c13 5.9 28.3 3.5 38.9-6.1 7.6-6.9 11.8-17.1 11.9-27-.1-10.4-5-20.6-8.3-30.3-2.4-7.3 0-15.3 6.1-20 34-26 56.1-65.3 56.1-111.4 0-82.1-71.1-144-153-144z"],
    "moon": [504, 540, [127769, 9214], "f186", "M272.8 36.4C256.4 11.6 226.3-.5 197.3 6 84.5 31 0 131.5 0 252l0 36c0 139.2 112.8 252 252 252 85.2 0 160.4-42.3 205.9-106.7 8.9-12.6 13.3-27.4 13.2-42.2l0-36c-.1-13.7-4.1-27.3-12-39.2-16.5-24.8-46.5-36.9-75.5-30.4-7.5 1.7-15.4 2.6-23.5 2.6-53.5 0-98-38.9-106.5-90 2.7-16.3 9.1-31.2 18.2-44.2 8.5-12.1 12.9-26.2 13.2-40.3l0-36c.2-14.3-3.8-28.7-12-41.1zm-30 19.9c8.2 12.4 8 28.6-.6 40.7-16.6 23.4-26.3 52-26.3 83 0 79.5 64.5 144 144 144 10.8 0 21.3-1.2 31.3-3.4 14.5-3.2 29.5 2.8 37.8 15.2s8 28.6-.6 40.7c-39.1 55.3-103.6 91.5-176.5 91.5-119.3 0-216-96.7-216-216 0-103.2 72.4-189.4 169.1-210.9 14.5-3.2 29.5 2.8 37.8 15.2z"],
    "plane": [504, 540, [], "f072", "M108 432.6c-.3-26.2 13.8-50.2 36-63l0-4.6-57.9 11.6C50.2 383.8 14.6 362.9 3.4 328 1.1 320.7 0 313.3 0 306l0-34.7c-.5-28.2 15.6-54.9 42.5-67l129.8-58.4 8.1-81.1C184.1 28 215 0 252 0s68 28 71.6 64.8l8.1 81.1 129.8 58.4c26.6 12 42.6 38.3 42.5 66.1l0 35.6c0 7.3-1.1 14.7-3.4 22-11.2 34.9-46.8 55.8-82.7 48.6l-57.9-11.6 0 4.6c22 12.7 36 36.3 36 62.2l0 36.2c0 2.9-.2 5.9-.5 8.8-4.4 36.1-35.1 63.2-71.5 63.2l-144 0c-36.4 0-67-27.1-71.5-63.2-.4-2.9-.5-5.9-.5-8.8l0-35.4zM252 36c-18.5 0-34 14-35.8 32.4L207 159.9c-.6 6.4-4.7 12-10.5 14.6L57.2 237.2c-13.2 5.9-21.2 19.2-21.2 33.5 .1 3.4 .6 6.9 1.7 10.3 5.6 17.4 23.4 27.9 41.3 24.3l102.7-20.5c4.9-1 10.1 .1 14.2 3.1s6.7 7.5 7.3 12.5l7.8 70.6c1 9-4.8 17.3-13.5 19.5l-26.2 6.6c-17.4 4.3-29.2 21.6-27 39.3 2.2 18 17.5 31.6 35.7 31.6l144 0c18.2 0 33.5-13.6 35.7-31.6s-9.4-34.9-27-39.3l-26.2-6.6c-8.7-2.2-14.5-10.5-13.5-19.5l7.8-70.6c.6-5 3.2-9.6 7.3-12.5s9.2-4.1 14.2-3.1L425 305.3c18 3.6 35.8-6.9 41.3-24.3s-2.8-36.3-19.5-43.8L307.5 174.5c-5.9-2.6-9.9-8.2-10.5-14.6l-9.1-91.5C286 50 270.5 36 252 36z"],
    "images": [468, 540, [], "f302", "M198 135a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zM108 90c0-39.8 32.2-72 72-72l216 0c39.8 0 72 32.2 72 72l0 252c0 39.8-32.2 72-72 72l-36 0 0 36c0 39.8-32.2 72-72 72L72 522c-39.8 0-72-32.2-72-72L0 198c0-39.8 32.2-72 72-72l36 0 0-36zm0 72l-36 0c-19.9 0-36 16.1-36 36l0 216c0 19.9 16.1 36 36 36l216 0c19.9 0 36-16.1 36-36l0-36-144 0c-39.8 0-72-32.2-72-72l0-144zM396 54L180 54c-19.9 0-36 16.1-36 36l0 217.5 86.2-86.2c26.9-26.9 70.5-26.9 97.5 0 12.9 12.9 33.7 12.9 46.5 0L432 163.5 432 90c0-19.9-16.1-36-36-36zM164.1 338.3c4.8 2.4 10.2 3.7 15.9 3.7l216 0c19.9 0 36-16.1 36-36l0-91.5-32.3 32.3c-26.9 26.9-70.5 26.9-97.5 0-12.9-12.9-33.7-12.9-46.5 0l-91.6 91.6z"],
    "bag-shopping": [432, 540, ["shopping-bag"], "f290", "M126 90c0-49.7 40.3-90 90-90s90 40.3 90 90l0 18 18 0c35.5 0 65.8 25.9 71.2 61.1l36 234c.6 3.8 .9 7.6 .8 11.3l0 35.6c0 39.2-32.7 72-72 72L72 522C51 522 31 512.8 17.4 496.9 6.1 483.7 0 467.1 0 450l0-36c0-3.6 .3-7.3 .8-10.9l36-234C42.2 133.9 72.5 108 108 108l18 0 0-18zm36 18l108 0 0-18c0-29.8-24.2-54-54-54s-54 24.2-54 54l0 18zM396 414c0-1.8-.1-3.7-.4-5.5l-36-234C356.9 157 341.8 144 324 144l-216 0c-17.8 0-32.9 13-35.6 30.5l-36 234C33.1 430 50.3 450 72 450l288 0c19.7 0 35.9-16.4 36-36z"],
    "phone": [468, 540, [128222, 128379], "f095", "M86.1 30.1c28.6-19 66.6-15.3 90.8 9l45 45C236 98.2 243 116.6 243 135l0 36c0 18.4-7 36.8-21.1 50.9l-34.3 34.3c17.3 22.8 39 42.1 63.8 56.6l48.7-48.7c28.1-28.1 73.7-28.1 101.8 0l45 45c13.4 13.4 20.5 30.9 21.1 48.7l0 38.2c0 13.8-4 27.8-12.1 39.9l-35.5 53.2C407.6 508.9 385.3 522 360 522 161.2 522 0 360.8 0 162l0-36c0-25.4 13.1-47.6 32.9-60.4L86.1 30.1zM196.5 160.5c14-14.1 14.1-36.8 0-50.9l-45-45c-12.1-12.1-31.1-14-45.4-4.5L52.5 95.7c-10 6.4-16.5 17.6-16.5 30.3 0 178.9 145.1 324 324 324 12.7 0 23.9-6.6 30.3-16.5L426 380c9.5-14.3 7.6-33.3-4.5-45.4l-45-45c-14.1-14.1-36.9-14.1-50.9 0l-58.2 58.2c-5.5 5.5-13.9 6.8-20.8 3.3-48.1-24.3-87.3-63.5-111.6-111.6-3.5-6.9-2.2-15.3 3.3-20.8l58.2-58.2z"],
    "leaf": [468, 540, [], "f06c", "M174 46.6c60.7-13.9 142.7-28.6 222-28.6 39.8 0 72 32.2 72 72l0 36c0 79.4-14.6 161.4-28.6 222-22.2 96.5-109.3 156-201.2 156-33.8 0-66.8-6.4-97.3-21.1l-18 18C94.8 529 49.2 529 21.1 500.9 7 486.9 0 468.4 0 450l0-36c0-24.2 12.4-42.2 28.7-58.6-7-21.2-10.7-43.9-10.7-67.4l0-40.2c0-91.9 59.5-179 156-201.2zM432 90c0-3.2-.4-6.4-1.2-9.3L313.5 198 424 198c4.8-35.1 8-72 8-108zM288 172.5L405.3 55.2c-3-.8-6.1-1.2-9.3-1.2-36 0-72.9 3.2-108 8l0 110.5zm-36 36l0-141c-24.1 4.1-48.2 8.8-72 14.6l0 198.4 72-72zM205.5 306l198.4 0c5.8-23.8 10.4-47.9 14.6-72l-141 0-72 72zm-36 36l-30.7 30.7c-7 7-18.4 7-25.5 0s-7-18.4 0-25.5l30.7-30.7 0-221c-58.4 30.1-90 92.1-90 156.4 0 31.9 8.3 61.8 22.8 87.8 3.9 7 2.7 15.8-3 21.5L46.5 388.5c-14.1 14.1-14.1 36.9 0 50.9s36.9 14.1 50.9 0l27.3-27.3c5.7-5.7 14.5-6.9 21.5-3 28.3 15.8 59.7 22.8 92 22.8 63.7 0 123.3-33.9 152.2-90l-221 0z"],
    "universal-access": [432, 540, [], "f29a", "M126 122.1L126 90c0-49.7 40.3-90 90-90s90 40.3 90 90l0 32.1 31.2-10.4c37.7-12.6 78.5 7.8 91.1 45.5 2.6 7.8 3.8 15.8 3.7 23.6l0 35.1c0 30.1-19 58.2-49.2 68.3l-42.6 14.2 18.7 102.6c.8 4.6 1.2 9.2 1.2 13.7l0 35.2c0 34.2-24.3 64.5-59.1 70.9-39.1 7.1-76.6-18.8-83.7-58l-1.2-6.4-1.2 6.4c-7.1 39.1-44.6 65.1-83.7 58-34.8-6.3-59.2-36.7-59.1-70.9l0-34.6c-.1-4.7 .3-9.5 1.2-14.3l18.7-102.6-42.6-14.2C19.1 274.2 0 246.1 0 216l0-35.2c-.1-7.8 1.1-15.8 3.7-23.6 12.6-37.7 53.3-58.1 91.1-45.5L126 122.1zm11.6 327.3c19.6 3.6 38.3-9.4 41.9-29l18.9-103.8c1.6-8.6 9-14.8 17.7-14.8s16.2 6.2 17.7 14.8l18.9 103.8c3.6 19.6 22.3 32.5 41.9 29s32.5-22.3 29-41.9L295.8 255.6c-1.6-8.8 3.5-17.5 12-20.3l63.6-21.2c18.9-6.3 29.1-26.7 22.8-45.5s-26.7-29.1-45.5-22.8l-85.8 28.6c-11 3.7-22.5 5.5-34.2 5.5l-25.3 0c-11.6 0-23.1-1.9-34.2-5.5L83.4 145.8c-18.9-6.3-39.2 3.9-45.5 22.8s3.9 39.2 22.8 45.5l63.6 21.2c8.5 2.8 13.6 11.5 12 20.3L108.6 407.6c-.4 2.2-.6 4.3-.6 6.4 .3 16.8 12.4 32.3 29.6 35.4zM216 36a54 54 0 1 0 0 108 54 54 0 1 0 0-108z"],
    "hourglass": [360, 540, [9203, 62032, "hourglass-empty"], "f254", "M288 18c39.6 0 71.8 32 72 71.6l0 36.4c0 54-22.1 105.9-60.2 144 38 38 60.1 89.8 60.2 143.7l0 36.3c0 39.8-32.2 72-72 72L72 522c-39.8 0-72-32.2-72-72l0-36.3C.1 359.8 22.2 308 60.2 270 22.1 231.9 0 180 0 126L0 89.6C.2 50 32.4 18 72 18l216 0zm36 72c0-19.9-16.1-36-36-36L72 54c-19.9 0-36 16.1-36 36 0 44.1 17.5 86.4 48.7 117.6l31.6 31.6c7 7 7 18.4 0 25.5L84.7 296.4C53.5 327.6 36 369.9 36 414 36 433.9 52.1 450 72 450l216 0c19.9 0 36-16.1 36-36 0-44.1-17.5-86.4-48.7-117.6l-31.6-31.6c-7-7-7-18.4 0-25.5l31.6-31.6C306.5 176.4 324 134.1 324 90zM192.7 188.4c-6.9 6.9-18.5 6.9-25.5 0l-31.6-31.6c-11.1-11.1-3-30.7 12.7-30.7l63.3 0c15.7 0 23.8 19.6 12.7 30.7l-31.6 31.6zm31.6 158.9c11.1 11.1 3 30.7-12.7 30.7l-63.3 0c-15.7 0-23.8-19.6-12.7-30.7l31.6-31.6c6.9-6.9 18.5-6.9 25.5 0l31.6 31.6z"],
    "fish": [540, 540, [128031], "f578", "M351 144a27 27 0 1 0 0-54 27 27 0 1 0 0 54zM320.6 11.4c42.8-5.3 81.6-.6 104.6 3.5 41.9 7.5 74.5 40 82 82 2.9 16.1 6 39.8 5.8 67.2 0 24.5 .6 49-2.4 73.4-5.3 42.9-21.4 95.1-63.7 137.5-53.9 53.9-128.7 69.7-178.7 74.7-3.5 .4-7 .7-10.4 .9l-6.5 45.6c-4.5 31.2-28.7 55.8-59.7 60.9s-61.8-10.7-75.9-38.9l-25.3-50.5-50.5-25.3C15.1 430.1 0 404.9 0 378l0-35.3c0-4.1 .3-8.2 .9-12.3 5-31.1 29.7-55.3 60.9-59.7l45.6-6.5c.3-3.4 .6-6.9 .9-10.4 5-50.1 20.8-124.8 74.7-178.7 42.3-42.3 94.6-58.4 137.5-63.7zm151.1 91.8c-4.8-27.1-25.8-48-52.9-52.9-21.1-3.8-55.9-7.9-93.9-3.2-38 4.7-81.6 18.6-116.5 53.4-45 45-59.6 109.3-64.4 156.9-.8 8.1-1.4 15.9-1.7 23.4-.4 8.6-6.9 15.8-15.4 17l-60.1 8.6c-17.8 2.5-30.9 18.2-30.9 36 .1 13.3 7.7 25.7 19.9 31.9l55.9 27.9c3.5 1.7 6.3 4.6 8 8.1l28 55.9c7 14.1 22.4 22 38 19.4s27.6-14.9 29.9-30.4l8.6-60.1c1.2-8.6 8.4-15 17-15.4 7.4-.3 15.3-.9 23.4-1.7 47.5-4.8 111.9-19.4 156.9-64.4 34.8-34.8 48.7-78.5 53.4-116.5 1.4-11.4 2-22.5 2.1-33 0-20.4-1.7-40.8-5.3-60.9z"],
    "list": [504, 540, ["list-squares"], "f03a", "M126 78.4C139.2 63.4 158.5 54 180 54l252 0c39.8 0 72 32.2 72 72l0 36c0 17-5.9 32.7-15.8 45 9.9 12.3 15.8 28 15.8 45l0 36c0 17-5.9 32.7-15.8 45 9.9 12.3 15.8 28 15.8 45l0 36c0 39.8-32.2 72-72 72l-252 0c-21.5 0-40.8-9.4-54-24.4-13.2 14.9-32.5 24.4-54 24.4-39.8 0-72-32.2-72-72l0-36C0 361 5.9 345.3 15.8 333 5.9 320.7 0 305 0 288l0-36C0 235 5.9 219.3 15.8 207 5.9 194.7 0 179 0 162l0-36c0-39.8 32.2-72 72-72 21.5 0 40.8 9.4 54 24.4zM36 126a36 36 0 1 0 72 0 36 36 0 1 0 -72 0zm0 126a36 36 0 1 0 72 0 36 36 0 1 0 -72 0zm0 126a36 36 0 1 0 72 0 36 36 0 1 0 -72 0zm432 0c0-19.9-16.1-36-36-36l-252 0c-19.9 0-36 16.1-36 36s16.1 36 36 36l252 0c19.9 0 36-16.1 36-36zm0-126c0-19.9-16.1-36-36-36l-252 0c-19.9 0-36 16.1-36 36s16.1 36 36 36l252 0c19.9 0 36-16.1 36-36zm0-126c0-19.9-16.1-36-36-36L180 90c-19.9 0-36 16.1-36 36s16.1 36 36 36l252 0c19.9 0 36-16.1 36-36z"],
    "headphones": [468, 540, [127911, 62863, "headphones-alt", "headphones-simple"], "f025", "M234 0C104.8 0 0 104.8 0 234L0 378c0 69.6 56.4 126 126 126 39.8 0 72-32.2 72-72l0-144c0-28.6-16.7-53.3-40.8-64.9 15.8-25.9 44.3-43.1 76.8-43.1s61 17.2 76.8 43.1C286.7 234.7 270 259.4 270 288l0 144c0 39.8 32.2 72 72 72 69.6 0 126-56.4 126-126l0-144C468 104.8 363.2 0 234 0zM432 253.8c-19.2-19.5-44.6-32.9-73.1-36.7-8.2-61.6-61-109.1-124.9-109.1S117.4 155.5 109.1 217.1c-28.5 3.8-54 17.1-73.1 36.7L36 234C36 124.6 124.6 36 234 36s198 88.6 198 198l0 19.8zM342 252c49.7 0 90 40.3 90 90s-40.3 90-90 90c-19.9 0-36-16.1-36-36l0-108c0-19.9 16.1-36 36-36zM126 432c-49.7 0-90-40.3-90-90s40.3-90 90-90c19.9 0 36 16.1 36 36l0 108c0 19.9-16.1 36-36 36z"],
    "bus": [504, 540, [128653], "f207", "M189 342a27 27 0 1 0 0-54 27 27 0 1 0 0 54zm99-27a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zM72 90c0-39.8 32.2-72 72-72l216 0c39.8 0 72 32.2 72 72l0 18c39.8 0 72 32.2 72 72l0 90c0 39.8-32.2 72-72 72l0 108c0 39.8-32.2 72-72 72s-72-32.2-72-72l-72 0c0 39.8-32.2 72-72 72s-72-32.2-72-72l0-108c-39.8 0-72-32.2-72-72l0-90c0-39.8 32.2-72 72-72l0-18zM36 234c0 19.9 16.1 36 36 36l0-126c-19.9 0-36 16.1-36 36l0 54zm72 144l288 0 0-126-288 0 0 126zM468 234l0-54c0-19.9-16.1-36-36-36l0 126c19.9 0 36-16.1 36-36zM180 414l-72 0c0 19.9 16.1 36 36 36s36-16.1 36-36zm144 0c0 19.9 16.1 36 36 36s36-16.1 36-36l-72 0zM360 54L144 54c-19.9 0-36 16.1-36 36l0 126 288 0 0-126c0-19.9-16.1-36-36-36z"],
    "quote-left": [504, 540, [8220, "quote-left-alt"], "f10d", "M482.3 103.2c-12.6-37.8-53.6-58-91.3-45.5-10.4 3.5-20.1 8.3-28.9 13.2-14.8 8.2-34 21-53.1 40.2-28.1 28.1-54.2 68-66.9 121.9-4.5-5.9-9.6-11.4-15-16.5 15.7-13.6 24.8-33.5 24.8-54.4l0-36c0-7.5-1.2-15.2-3.7-22.8-12.6-37.8-53.6-58-91.3-45.5-10.4 3.5-20.1 8.3-28.9 13.2-14.8 8.2-34 21-53.1 40.2-39.6 39.6-75.1 102.6-75.1 194.9l0 45c0 74.6 60.4 135 135 135 50 0 93.7-27.2 117-67.6 23.3 40.4 67 67.6 117 67.6 74.6 0 135-60.4 135-135l0-36c0-38.9-16.5-74-42.8-98.6 15.7-13.6 24.8-33.5 24.8-54.4l0-36c0-7.6-1.2-15.2-3.7-22.8zM334.5 136.5c16.3-16.3 32.6-27.2 45.1-34.1 7.8-4.3 15.3-8 22.9-10.5 18.9-6.3 39.4 3.9 45.6 22.7 6.2 18.7-3.7 38.9-22.3 45.4-15.8 5.5-30.3 17.1-41.8 28.8-4.5 4.6-6.2 11.3-4.4 17.5s6.7 11 13 12.5c43.2 10.6 75.3 49.7 75.3 96.1 0 54.7-44.3 99-99 99s-99-44.3-99-99l0-9c0-82.2 31.2-136.2 64.5-169.5zM234 315c0 54.7-44.3 99-99 99s-99-44.3-99-99l0-9c0-82.2 31.2-136.2 64.5-169.5 16.3-16.3 32.6-27.2 45.1-34.1 7.8-4.3 15.3-8 22.9-10.5 18.9-6.3 39.4 3.9 45.6 22.7 6.2 18.7-3.7 38.9-22.3 45.4-15.8 5.5-30.3 17.1-41.8 28.8-4.5 4.6-6.2 11.3-4.4 17.5s6.7 11 13 12.5C201.9 229.5 234 268.5 234 315z"],
    "martini-glass": [432, 540, [127864, "glass-martini-alt"], "f57b", "M0 108.7C-.1 99.2 1.7 89.6 5.5 80.4 16.6 53.5 42.9 36 72 36l288 0c29.1 0 55.4 17.5 66.5 44.4 3.8 9.1 5.6 18.8 5.5 28.3l0 34.6c.2 19-7.1 37.7-21.1 51.6l-122.9 122.9 0 24.2 18 0c39.8 0 72 32.2 72 72l0 36c0 39.8-32.2 72-72 72l-180 0c-39.8 0-72-32.2-72-72l0-36c0-39.8 32.2-72 72-72l18 0 0-24.2-122.9-122.9C7.2 181-.2 162.3 0 143.3l0-34.6zM38.7 94.2c-1.8 4.5-2.7 9.6-2.7 14.2 .1 9.2 3.8 18.2 10.5 25L174.7 261.6c3.4 3.4 5.3 8 5.3 12.7l0 85.6c0 9.9-8.1 18-18 18l-36 0c-19.9 0-36 16.1-36 36s16.1 36 36 36l180 0c19.9 0 36-16.1 36-36s-16.1-36-36-36l-36 0c-9.9 0-18-8.1-18-18l0-85.6c0-4.8 1.9-9.4 5.3-12.7L385.5 133.5c6.8-6.8 10.4-15.8 10.5-25 0-4.6-.9-9.7-2.7-14.2-5.6-13.5-18.7-22.2-33.3-22.2L72 72c-14.6 0-27.7 8.8-33.3 22.2z"],
    "rectangle-wide": [576, 540, [], "f2fc", "M576 144c0-39.8-32.2-72-72-72L72 72C32.2 72 0 104.2 0 144L0 360c0 .3 0 .6 0 .8L0 396c0 39.8 32.2 72 72 72l432 0c39.8 0 72-32.2 72-72l0-252zM36 144c0-19.9 16.1-36 36-36l432 0c19.9 0 36 16.1 36 36l0 216c0 19.9-16.1 36-36 36L72 396c-19.7 0-35.7-15.8-36-35.4L36 144z"],
    "angle-down": [432, 540, [8964], "f107", "M0 162l0 36c0 18.4 7 36.9 21.1 50.9l144 144c28.1 28.1 73.7 28.1 101.8 0l144-144C425 234.9 432 216.4 432 198l0-36c0-18.4-7-36.9-21.1-50.9-28.1-28.1-73.7-28.1-101.8 0l-93.1 93.1-93.1-93.1C94.8 83 49.2 83 21.1 111.1 7.7 124.5 0 143.1 0 162zm97.5-25.5L203.3 242.4c6.9 6.9 18.5 6.9 25.5 0L334.5 136.5c14.1-14.1 36.9-14.1 50.9 0s14.1 36.9 0 50.9l-144 144c-14.1 14.1-36.9 14.1-50.9 0l-144-144c-14.1-14.1-14.1-36.9 0-50.9s36.9-14.1 50.9 0z"],
    "chart-pie": [504, 540, ["pie-chart"], "f200", "M309.8 6.6c-29-6.8-53.1 7.7-65.8 29.5-135.4 4.3-243.8 115.4-243.8 251.9 0 139.2 112.8 252 252 252 136.1 0 247.1-107.9 251.8-242.9 .5-15 .2-30.1 .2-45.1 0-119.4-83-219.3-194.4-245.4zM36.1 288c0-113.2 87.1-206.1 198-215.3l0 192.9c0 19.1 7.6 37.4 21.1 50.9L366.7 428c8.9 8.9 20.3 15.3 32.3 18.4-38.5 35.7-90.1 57.6-146.8 57.6-119.3 0-216-96.7-216-216zM301.6 41.7c95.5 22.3 166.6 108.1 166.6 210.3 0 41.8-11.8 80.7-32.3 113.8-8.1 13-28.5 15.9-43.6 .8L280.7 255.1c-6.8-6.8-10.5-15.9-10.5-25.5l0-157.6c0-21.4 16.6-33.8 31.4-30.3z"],
    "inbox": [432, 540, [], "f01c", "M0 108C0 68.2 32.2 36 72 36l288 0c39.8 0 72 32.2 72 72l0 324c0 39.8-32.2 72-72 72L72 504c-39.8 0-72-32.2-72-72L0 108zM396 270l-90 0c0 49.7-40.3 90-90 90s-90-40.3-90-90l-90 0 0 126c0 19.9 16.1 36 36 36l288 0c19.9 0 36-16.1 36-36l0-126zm0-162c0-19.9-16.1-36-36-36L72 72c-19.9 0-36 16.1-36 36l0 126 90 0c19.9 0 36 16.1 36 36 0 29.8 24.2 54 54 54s54-24.2 54-54c0-19.9 16.1-36 36-36l90 0 0-126z"],
    "credit-card": [504, 540, [128179, 62083, "credit-card-alt"], "f09d", "M288 288c-9.9 0-18 8.1-18 18s8.1 18 18 18l90 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-90 0zM0 126C0 86.2 32.2 54 72 54l360 0c39.8 0 72 32.2 72 72l0 288c0 39.8-32.2 72-72 72L72 486c-39.8 0-72-32.2-72-72L0 126zm36 72l0 180c0 19.9 16.1 36 36 36l360 0c19.9 0 36-16.1 36-36l0-180-432 0zm432-36l0-36c0-19.9-16.1-36-36-36L72 90c-19.9 0-36 16.1-36 36l0 36 432 0z"],
    "wand-magic-sparkles": [576, 540, ["magic-wand-sparkles"], "e2ca", "M482.9 39.1C454.8 11 409.2 11 381.1 39.1l-306 306C61 359.1 54 377.6 54 396l0 36c0 18.4 7 36.9 21.1 50.9l18 18c28.1 28.1 73.7 28.1 101.8 0l306-306C515 180.9 522 162.4 522 144l0-36c0-18.4-7-36.9-21.1-50.9l-18-18zM100.5 421.5c-14.1-14.1-14.1-36.9 0-50.9l221.3-221.3 68.9 68.9-221.3 221.3c-14.1 14.1-36.9 14.1-50.9 0l-18-18zm374.9-288l-59.3 59.3-68.9-68.9 59.3-59.3c14.1-14.1 36.9-14.1 50.9 0l18 18c14.1 14.1 14.1 36.9 0 50.9zM216 108l0 36c0 10.5-4.2 20.6-11.6 28.1l-32.3 32.3c-7.5 7.5-17.6 11.6-28.1 11.6s-20.6-4.2-28.1-11.6L83.6 172.1C76.2 164.6 72 154.5 72 144l0-36c0-10.5 4.2-20.6 11.6-28.1l32.3-32.3C123.4 40.2 133.5 36 144 36s20.6 4.2 28.1 11.6l32.3 32.3C211.8 87.4 216 97.5 216 108zm-106.9 2.6l32.3 32.3c1.4 1.4 3.9 1.4 5.3 0l32.3-32.3c1.4-1.4 1.4-3.9 0-5.3L146.6 73.1c-1.4-1.4-3.9-1.4-5.3 0l-32.3 32.3c-1.4 1.4-1.4 3.9 0 5.3zM576 324l0 36c0 10.5-4.2 20.6-11.6 28.1l-32.3 32.3c-7.5 7.5-17.6 11.6-28.1 11.6s-20.6-4.2-28.1-11.6l-32.3-32.3c-7.5-7.5-11.6-17.6-11.6-28.1l0-36c0-10.5 4.2-20.6 11.6-28.1l32.3-32.3c7.5-7.5 17.6-11.6 28.1-11.6s20.6 4.2 28.1 11.6l32.3 32.3c7.5 7.5 11.6 17.6 11.6 28.1zm-106.9 2.6l32.3 32.3c1.4 1.4 3.9 1.4 5.3 0l32.3-32.3c1.4-1.4 1.4-3.9 0-5.3l-32.3-32.3c-1.4-1.4-3.9-1.4-5.3 0l-32.3 32.3c-1.4 1.4-1.4 3.9 0 5.3zM324 468l0-36c0-8.6 3.4-16.9 9.5-23L355 387.5c6.1-6.1 14.4-9.5 23-9.5s16.9 3.4 23 9.5L422.5 409c6.1 6.1 9.5 14.4 9.5 23l0 36c0 8.6-3.4 16.9-9.5 23L401 512.5c-6.1 6.1-14.4 9.5-23 9.5s-16.9-3.4-23-9.5L333.5 491c-6.1-6.1-9.5-14.4-9.5-23zm54-52.5L361.5 432 378 448.5 394.5 432 378 415.5z"],
    "folders": [540, 540, [], "f660", "M0 414c0 39.8 32.2 72 72 72l288 0c39.8 0 72-32.2 72-72l0-36 36 0c39.8 0 72-32.2 72-72l0-144c0-39.8-32.2-72-72-72l-99 0c-11.3 0-22-5.3-28.8-14.4L318.6 46.8C305 28.7 283.7 18 261 18l-81 0c-39.8 0-72 32.2-72 72l0 36-36 0c-39.8 0-72 32.2-72 72L0 414zm180-72l216 0 0 36c0 19.9-16.1 36-36 36L72 414c-19.9 0-36-16.1-36-36l0-180c0-19.9 16.1-36 36-36l36 0 0 108c0 39.8 32.2 72 72 72zm324-72c0 19.9-16.1 36-36 36l-288 0c-19.9 0-36-16.1-36-36l0-180c0-19.9 16.1-36 36-36l81 0c11.3 0 22 5.3 28.8 14.4l21.6 28.8C325 115.3 346.3 126 369 126l99 0c19.9 0 36 16.1 36 36l0 108z"],
    "tv": [432, 540, [63717, "television", "tv-alt"], "f26c", "M108 180c-19.9 0-36 16.1-36 36l0 144c0 19.9 16.1 36 36 36l162 0c19.9 0 36-16.1 36-36l0-144c0-19.9-16.1-36-36-36l-162 0zm0 36l162 0 0 144-162 0 0-144zm225 0a18 18 0 1 1 36 0 18 18 0 1 1 -36 0zm18 72a18 18 0 1 0 0-36 18 18 0 1 0 0 36zm9-180c39.8 0 72 32.2 72 72l0 252c0 39.8-32.2 72-72 72L72 504c-39.8 0-72-32.2-72-72L0 180c0-39.8 32.2-72 72-72l0-38.2c0-.7 0-1.5 .1-2.2 1-16.9 8-33.6 21-46.5 28.1-28.1 73.7-28.1 101.8 0L216 42.2 237.1 21.1C265.2-7 310.8-7 338.9 21.1 353 35.1 360 53.6 360 72l0 36zM169.5 46.5c-14.1-14.1-36.9-14.1-50.9 0s-14.1 36.9 0 50.9l10.5 10.5 173.8 0 10.5-10.5c14.1-14.1 14.1-36.9 0-50.9s-36.9-14.1-50.9 0L228.7 80.4c-6.9 6.9-18.5 6.9-25.5 0L169.5 46.5zM360 144L72 144c-19.9 0-36 16.1-36 36l0 216c0 19.9 16.1 36 36 36l288 0c19.9 0 36-16.1 36-36l0-216c0-19.9-16.1-36-36-36z"],
    "star": [504, 540, [11088, 61446], "f005", "M319 45.3C308.1 17.9 281.6 0 252.2 0s-55.9 17.9-66.9 45.3l-29.6 74-79.5 5.3c-29.4 2-54.6 21.6-63.7 49.6-2.3 7.2-3.5 14.6-3.5 21.9l0 36.6c.1 20.9 9.3 41.2 25.9 55.1l53.7 44.7-12 47.5c-1.5 5.9-2.2 11.9-2.2 17.9l0 35.5c-.1 22.8 10.7 44.7 29.7 58.5 23.8 17.3 55.8 18.4 80.7 2.7l67.4-42.5 67.4 42.5c24.9 15.7 56.9 14.6 80.7-2.7 19-13.8 29.8-35.7 29.7-58.5l0-35.5c0-6-.7-12-2.2-17.9l-12-47.5 53.7-44.7c16.6-13.9 25.8-34.2 25.9-55.1l0-36.6c0-7.3-1.2-14.7-3.5-21.9-9.1-28-34.3-47.6-63.7-49.6l-79.5-5.3-29.6-74zM261.8 379.6c-5.9-3.7-13.3-3.7-19.2 0l-77 48.5c-12.5 7.8-28.4 7.3-40.3-1.3-11.9-8.6-17.4-23.6-13.7-38l22.3-88.2c1.7-6.7-.6-13.8-5.9-18.2L58 224c-8.3-6.9-12.9-17-13-27.5 .1-18.5 15-34.9 33.6-36.1l90.8-6c6.9-.5 12.9-4.8 15.5-11.3l33.8-84.5C224.2 45 237.5 36 252.2 36s28 9 33.4 22.6l33.8 84.5c2.6 6.4 8.6 10.8 15.5 11.3l90.8 6c18.6 1.2 33.5 17.6 33.6 36.1-.1 10.4-4.7 20.5-13 27.5l-69.9 58.3c-5.3 4.4-7.6 11.5-5.9 18.2l22.3 88.2c3.6 14.3-1.8 29.3-13.7 38-11.9 8.7-27.9 9.2-40.3 1.3l-77-48.5z"],
    "flag": [432, 540, [127988, 61725], "f024", "M92.1 30.6c48.9-9.8 99.4-6.6 146.7 9.1 23.5 7.8 48.6 9.4 72.9 4.5l34.2-6.8C389.7 28.6 432 63.3 432 108l0 216c0 34.3-24.2 63.9-57.9 70.6l-34.2 6.8c-48.9 9.8-99.4 6.6-146.7-9.1-15.9-5.3-32.6-7.7-49.2-7.2l0 64.9c0 39.8-32.2 72-72 72S0 489.8 0 450L0 108C0 73.7 24.2 44.1 57.9 37.4l34.2-6.8zM396 108c0-22.4-21.1-39.7-43.1-35.3l-34.2 6.8c-30.4 6.1-61.9 4.1-91.4-5.7-27-9-55.2-13.3-83.4-12.8l0 252c20.5-.5 41 2.6 60.6 9.1 41.3 13.8 85.5 16.5 128.3 8l34.2-6.8c16.8-3.4 28.9-18.1 28.9-35.3l0-180zM108 64.3C93.6 66.6 79.3 69.8 64.9 72.7 48.1 76.1 36 90.8 36 108l0 306c0 19.9 16.1 36 36 36s36-16.1 36-36l0-349.7z"],
    "triangle-exclamation": [504, 540, [9888, "exclamation-triangle", "warning"], "f071", "M252 126c9.9 0 18 8.1 18 18l0 144c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-144c0-9.9 8.1-18 18-18zM225 378a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zM189.1 55c12.7-22.9 36.8-37 62.9-37s50.2 14.2 62.9 37l180 324c6 10.9 9.1 22.9 9.1 35l0 35.9c0 12.6-3.3 25.3-9.9 36.6-12.9 22-36.5 35.5-62.1 35.5L72 522c-25.5 0-49.1-13.5-62.1-35.5-6.6-11.3-10-23.9-9.9-36.6l0-35.9c0-12.1 3-24.1 9.1-35l180-324zm31.5 17.5l-180 324c-6.2 11.2-5.9 25 .4 35.7 6.5 11 18.3 17.7 31 17.7l360 0c12.8 0 24.6-6.8 31-17.7s6.6-24.6 .4-35.7l-180-324C277.1 61.1 265.1 54 252 54s-25.1 7.1-31.5 18.5z"],
    "lock": [360, 540, [128274], "f023", "M198 288c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 90c0 9.9 8.1 18 18 18s18-8.1 18-18l0-90zM54 126C54 56.4 110.4 0 180 0S306 56.4 306 126l0 56.3c31.1 8 54 36.2 54 69.7l0 198c0 39.8-32.2 72-72 72L72 522c-39.8 0-72-32.2-72-72L0 252c0-33.5 22.9-61.7 54-69.7L54 126zm216 0c0-49.7-40.3-90-90-90S90 76.3 90 126l0 54 72 0 0-54c0-9.9 8.1-18 18-18s18 8.1 18 18l0 54 72 0 0-54zM36 252l0 162c0 19.9 16.1 36 36 36l216 0c19.9 0 36-16.1 36-36l0-162c0-19.9-16.1-36-36-36L72 216c-19.9 0-36 16.1-36 36z"],
    "anchor": [504, 540, [9875], "f13d", "M216 126a36 36 0 1 1 72 0 36 36 0 1 1 -72 0zM0 396c0 29.4 17.9 55.9 45.3 66.9l180 72c17.2 6.9 36.3 6.9 53.5 0l180-72C486.1 451.9 504 425.4 504 396l0-72c0-39.8-32.2-72-72-72-35.2 0-64.6 25.3-70.8 58.8l-37.2 14.9 0-60.2c32.6-22.7 54-60.6 54-103.4l0-36C378 56.4 321.6 0 252 0S126 56.4 126 126c0 12 0 24 0 36 0 42.8 21.4 80.7 54 103.4l0 60.2-37.2-14.9c-6.2-33.4-35.5-58.8-70.8-58.8-39.8 0-72 32.2-72 72l0 72zM252 36c49.7 0 90 40.3 90 90 0 33.3-18.1 62.4-45 78-5.6 3.2-9 9.2-9 15.6l0 132.7c0 6 3 11.6 7.9 14.9s11.2 4 16.8 1.8l72-28.8c6.8-2.7 11.2-9.2 11.3-16.5 .2-19.7 16.2-35.6 36-35.6 19.9 0 36 16.1 36 36l0 36c0 14.7-9 28-22.6 33.4l-180 72c-8.6 3.4-18.2 3.4-26.7 0l-180-72C45 388 36 374.7 36 360l0-36c0-19.9 16.1-36 36-36 19.8 0 35.8 15.9 36 35.6 .1 7.3 4.5 13.8 11.3 16.5l72 28.8c5.5 2.2 11.8 1.5 16.8-1.8s7.9-8.9 7.9-14.9l0-132.7c0-6.4-3.4-12.4-9-15.6-27.6-16-44.9-46.1-45-78 0-49.7 40.3-90 90-90z"],
    "scissors": [504, 540, [9984, 9986, 9988, "cut"], "f0c4", "M126 180a36 36 0 1 0 0-72 36 36 0 1 0 0 72zM90 360a36 36 0 1 1 72 0 36 36 0 1 1 -72 0zM126 18c69.3 0 125.6 56 126 125.2L364.8 37.5c29-27.2 74.6-25.7 101.8 3.3 13.1 13.9 19.5 31.7 19.5 49.4l0 35.8c0 19.2-7.6 38.4-22.8 52.5l-97.6 91.5 97.6 91.5C478.4 375.6 486 394.8 486 414l0 36c0 17.7-6.4 35.3-19.5 49.2-27.2 29-72.8 30.5-101.8 3.3L252 396.8C251.6 466 195.3 522 126 522 56.4 522 0 465.6 0 396l0-36C0 324.7 14.5 292.9 37.8 270 14.5 247.1 0 215.3 0 180l0-36C0 74.4 56.4 18 126 18zm0 36c-49.7 0-90 40.3-90 90s40.3 90 90 90c13.6 0 26.6-3 38.2-8.5l40.7-38.2c7.1-12.9 11.1-27.6 11.1-43.3 0-49.7-40.3-90-90-90zM320.2 276.7L267.5 326 389.4 440.3c14.5 13.6 37.3 12.9 50.9-1.6s12.9-37.3-1.6-50.9L320.2 276.7zM36 360c0 49.7 40.3 90 90 90s90-40.3 90-90c0-7.1-.8-13.9-2.3-20.5-1.5-6.3 .5-12.8 5.2-17.2l219.7-206c14.5-13.6 15.2-36.4 1.6-50.9s-36.4-15.2-50.9-1.6l-219.7 206c-4.7 4.4-11.4 6-17.5 4.1-8.2-2.5-17-3.8-26.1-3.8-49.7 0-90 40.3-90 90z"],
    "bug": [504, 540, [], "f188", "M270 252c0-9.9-8.1-18-18-18s-18 8.1-18 18l0 108c0 9.9 8.1 18 18 18s18-8.1 18-18l0-108zM252 0c-50.1 0-92.2 34.1-104.4 80.3l-11.5-9.6C105.5 45.2 60.1 49.4 34.7 79.9 23.5 93.4 18 109.7 18 126l0 36c0 11.8 2.9 23.6 8.6 34.1-16.2 13.2-26.6 33.3-26.6 55.9l0 36c0 22.5 10.4 42.7 26.6 55.9-5.7 10.6-8.6 22.4-8.6 34.2L18 414c0 16.3 5.5 32.6 16.7 46.1 25.5 30.5 70.9 34.7 101.4 9.2l11.5-9.6C159.8 505.9 201.9 540 252 540s92.2-34.1 104.4-80.3l11.5 9.6c30.5 25.5 75.9 21.3 101.4-9.2 11.2-13.5 16.7-29.8 16.7-46.1l0-35.7c.1-11.9-2.8-23.8-8.6-34.5 16.2-13.2 26.6-33.3 26.6-55.9l0-36c0-22.5-10.4-42.7-26.6-55.9 5.7-10.6 8.6-22.3 8.6-34.1l0-36c0-16.3-5.5-32.6-16.7-46.1-25.5-30.5-70.9-34.7-101.4-9.2l-11.5 9.6C344.2 34.1 302.1 0 252 0zm0 36c39.8 0 72 32.2 72 72l0 18c0 19.9-16.1 36-36 36l-72 0c-19.9 0-36-16.1-36-36l0-18c0-39.8 32.2-72 72-72zM113 98.3l31 25.8c0 39.9 31.3 73.9 72 73.9l72 0c40.7 0 72-33.9 72-73.9l31-25.8c15.3-12.7 38-10.7 50.7 4.6s10.7 38-4.6 50.7l-36.6 30.5c-5.8 4.9-8 12.8-5.4 20S404.4 216 412 216l20 0c19.9 0 36 16.1 36 36s-16.1 36-36 36l-20 0c-7.6 0-14.3 4.7-16.9 11.9s-.4 15.1 5.4 20L437 350.3c15.3 12.7 17.3 35.4 4.6 50.7s-35.4 17.3-50.7 4.6l-37.4-31.2c-5.4-4.5-12.8-5.4-19.2-2.5S324 381.3 324 388.3l0 7.7c0 39.8-32.2 72-72 72s-72-32.2-72-72l0-7.7c0-7-4-13.3-10.4-16.3s-13.8-2-19.2 2.5L113 405.7c-15.3 12.7-38 10.7-50.7-4.6s-10.7-38 4.6-50.7l36.6-30.5c5.8-4.9 8-12.8 5.4-20S99.6 288 92 288l-20 0c-19.9 0-36-16.1-36-36s16.1-36 36-36l20 0c7.6 0 14.3-4.7 16.9-11.9s.4-15.1-5.4-20L67 153.7c-15.3-12.7-17.3-35.4-4.6-50.7S97.8 85.6 113 98.3z"],
    "arrow-right-from-bracket": [504, 540, ["sign-out"], "f08b", "M234 108c0-39.8-32.2-72-72-72l-36 0C56.4 36 0 92.4 0 162L0 378c0 69.6 56.4 126 126 126l36 0c39.8 0 72-32.2 72-72l0-36c0-13.1-3.5-25.4-9.6-36l63.6 0c0 29.1 17.5 55.4 44.4 66.5 8.7 3.6 17.9 5.4 27 5.5 18.9 .1 37.6-7.2 51.5-21.1l72-72C497 324.9 504 306.4 504 288l0-36c0-18.4-7-36.9-21.1-50.9l-72-72c-13.9-13.9-32.4-21.2-51.3-21.1-9.1 .1-18.4 1.9-27.1 5.5-26.9 11.1-44.4 37.4-44.4 66.5l-63.6 0c6.1-10.6 9.6-22.9 9.6-36l0-36zM126 432c-49.7 0-90-40.3-90-90l0-180c0-49.7 40.3-90 90-90l36 0c19.9 0 36 16.1 36 36s-16.1 36-36 36l-36 0c-4.8 0-9.4 1.9-12.7 5.3s-5.3 8-5.3 12.7l0 180c0 9.9 8.1 18 18 18l36 0c19.9 0 36 16.1 36 36s-16.1 36-36 36l-36 0zM324 324l0-18c0-9.8-8.2-18-18-18l-126 0c-19.7 0-35.9-16.5-36-36.1 .1-19.8 16.2-35.9 36-35.9l126 0c9.9 0 18-8.1 18-18l0-18c0-14.6 8.8-27.7 22.2-33.3 13.3-5.5 29.1-2.4 39.2 7.8l72 72c14.1 14.1 14.1 36.9 0 50.9l-72 72c-10.2 10.2-26 13.3-39.2 7.8-13.5-5.6-22.2-18.7-22.2-33.3z"],
    "arrow-right-arrow-left": [576, 540, [8644, "exchange"], "f0ec", "M576 198.1c0-18.4-7-36.9-21.1-51l-90-90c-20.6-20.6-51.6-26.8-78.5-15.6S342 78.9 342 108l0 18-72 0c-26.2 0-49.1 14-61.7 34.9-5.5-4.7-11.8-8.5-18.8-11.4-26.9-11.1-57.9-5-78.5 15.6l-90 90C7 269.1 0 287.5 0 305.9L0 342c0 18.4 7 36.9 21.1 50.9l90 90c20.6 20.6 51.6 26.8 78.5 15.6S234 461.1 234 432l0-18 72 0c26.2 0 49.1-14 61.7-34.9 5.5 4.7 11.8 8.5 18.8 11.4 26.9 11.1 57.9 5 78.5-15.6l90-90C569 270.9 576 252.4 576 234l0-35.9zM439.5 82.5l90 90c14.1 14.1 14 36.9 0 50.9l-90 90c-10.3 10.3-25.8 13.4-39.2 7.8S378 302.6 378 288l0-36c0-9.8-8.2-18-18-18-30.1 0-60.3 0-90.4 0-19.7-.2-35.6-16.3-35.6-36 0-19.9 16.1-36 36-36l90 0c9.9 0 18-8.1 18-18l0-36c0-14.6 8.8-27.7 22.2-33.3s28.9-2.5 39.2 7.8zM306.4 270c19.7 .2 35.6 16.2 35.6 36 0 19.9-16.1 36-36 36l-90 0c-9.8 0-18 8.2-18 18l0 36c0 14.6-8.8 27.7-22.2 33.3s-28.9 2.5-39.2-7.8l-90-90c-14.1-14.1-14-36.9 0-50.9l90-90c10.3-10.3 25.8-13.4 39.2-7.8S198 201.4 198 216l0 36c0 9.9 8.1 18 18 18z"],
    "arrow-up-from-line": [360, 540, [8613, "arrow-from-bottom"], "f342", "M230.9 39.1l90 90c13.8 13.8 21.1 32.2 21.1 51l0 35.9c0 9.3-1.8 18.6-5.5 27.6-11.1 26.9-37.4 44.4-66.5 44.4l-18 0 0 54 36 0c39.8 0 72 32.2 72 72l0 36c0 39.8-32.2 72-72 72L72 522c-39.8 0-72-32.2-72-72l0-36c0-39.8 32.2-72 72-72l36 0 0-54-18 0c-29.1 0-55.4-17.5-66.5-44.4-3.7-8.9-5.5-18.3-5.5-27.6l0-36c0-18.7 7.3-37.1 21.1-50.9l90-90c28.1-28.1 73.7-28.1 101.8 0zM36 414c0 19.9 16.1 36 36 36l216 0c19.9 0 36-16.1 36-36s-16.1-36-36-36L72 378c-19.9 0-36 16.1-36 36zM303.3 193.8c5.6-13.5 2.5-28.9-7.8-39.2l-90-90c-14.1-14.1-36.9-14.1-50.9 0l-90 90c-10.3 10.3-13.4 25.8-7.8 39.2S75.4 216 90 216l36 0c4.8 0 9.4 1.9 12.7 5.3s5.3 8 5.3 12.7l0 72c0 19.9 16.1 36 36 36s36-16.1 36-36l0-72c0-9.9 8.1-18 18-18l36 0c14.6 0 27.7-8.8 33.3-22.2z"],
    "font": [468, 540, [], "f031", "M250.3 190.4c-6.4-13.5-26.2-13.5-32.5 0l-25.5 53.9c-5.6 11.7 3.3 25.7 16.3 25.7l51 0c13 0 21.8-14 16.3-25.7l-25.5-53.9zM234 0c-27.8 0-53.2 16-65.1 41.2l-162 342C2 393.6-.2 404.7 0 415.5l0 35.6c.6 26.3 15.7 51.9 41.2 63.9 35.9 17 78.9 1.7 95.9-34.2l31.7-66.8 130.6 0 31.7 66.8c17 35.9 60 51.3 95.9 34.2 26-12.3 41.2-38.2 41.2-65.1l0-34.5c.2-10.8-2-21.9-6.9-32.3l-162-342C287.2 16 261.8 0 234 0zM428.6 398.6c2.4 5.1 3.5 10.6 3.5 16.2-.3 13.2-7.8 25.7-20.6 31.8-18 8.5-39.4 .8-47.9-17.1L327 352.3c-3-6.3-9.3-10.3-16.3-10.3l-153.3 0c-7 0-13.3 4-16.3 10.3l-36.5 77.1c-8.5 18-30 25.6-47.9 17.1-12.7-6-20.3-18.6-20.6-31.8 0-5.6 1.1-11.1 3.5-16.2l162-342c12.7-26.9 52.3-26.9 65.1 0l162 342z"],
    "language": [504, 540, [], "f1ab", "M0 126C0 86.2 32.2 54 72 54l360 0c39.8 0 72 32.2 72 72l0 288c0 39.8-32.2 72-72 72L72 486c-39.8 0-72-32.2-72-72L0 126zM36 378c0 19.9 16.1 36 36 36l360 0c19.9 0 36-16.1 36-36l0-252c0-19.9-16.1-36-36-36L72 90c-19.9 0-36 16.1-36 36l0 252zM342 171c7.1 0 13.6 4.2 16.4 10.7l72 162c4 9.1-.1 19.7-9.1 23.8s-19.7-.1-23.8-9.1l-19.2-43.3-72.6 0-19.2 43.3c-4 9.1-14.7 13.2-23.8 9.1s-13.2-14.7-9.1-23.8l12.8-28.7-14.3 0c-28.6 0-52.4-5.9-72-15.3-19.7 9.4-43.4 15.3-72 15.3-9.9 0-18-8.1-18-18s8.1-18 18-18c13.1 0 24.9-1.5 35.4-4.2-13.8-12.8-24.1-27.2-31.8-41.1-4.8-8.7-1.7-19.6 7-24.5s19.6-1.7 24.5 7c8.2 14.8 19.9 30.1 36.9 42 27.6-19.2 41.9-48.6 48.8-69.2L108 189c-9.9 0-18-8.1-18-18s8.1-18 18-18l54 0 0-18c0-9.9 8.1-18 18-18s18 8.1 18 18l0 18 54 0c5.2 0 10.2 2.3 13.6 6.2s5 9.2 4.2 14.3c-1.1 7.6-3.1 15.1-5.4 22.5-4 12.9-10.8 30.2-22 47.7-6.9 10.7-15.4 21.3-25.8 31.1 10.5 2.7 22.3 4.2 35.4 4.2l30.3 0 43.2-97.3c2.9-6.5 9.3-10.7 16.4-10.7zm0 62.3l-20.3 45.7 40.6 0-20.3-45.7z"],
    "person-biking": [504, 540, [128692, "biking"], "f84a", "M288 79.3c-12.9-4.8-26.8-7.3-40.9-7.3-22.1 0-43.7 6.2-62.4 17.9l-52.1 32.6c-25.8 16.1-41.8 44.1-42.5 74.5l0 38.4c0 6.1 .6 12.1 1.8 17.9-52 7.8-91.8 52.7-91.8 106.8l0 36c0 59.6 48.4 108 108 108 36.2 0 68.2-17.8 87.8-45 13.2 16.5 33.5 27 56.2 27s43-10.6 56.2-27c19.6 27.3 51.6 45 87.8 45 59.6 0 108-48.4 108-108l0-36c0-33.9-15.6-64.2-40.1-84 2.7-7.5 4.1-15.6 4.1-24l0-36c0-23.7-11.5-44.8-29.2-57.9 7.1-12 11.2-26.1 11.2-41.1l0-36c0-44.7-36.3-81-81-81-44.2 0-80.1 35.4-81 79.3zM369 126a45 45 0 1 1 0-90 45 45 0 1 1 0 90zm99 234a72 72 0 1 1 -144 0 72 72 0 1 1 144 0zM432 216c0 19.9-16.1 36-36 36l-72 0c-11.3 0-22-5.3-28.8-14.4L259.5 190c-5.6-7.5-16-9.4-23.9-4.5l-8 5c-9.7 6-11.2 19.9-3.2 28l53.1 53.1c6.8 6.8 10.5 15.9 10.5 25.5l0 81c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-58.6c0-4.8-1.9-9.4-5.3-12.7L142 237.9c-10.2-10.2-16-24.1-16-38.6 0-18.8 9.7-36.3 25.7-46.3l52.1-32.6c13-8.1 28-12.4 43.3-12.4 25.7 0 50 12.1 65.4 32.7l24.1 32.1c3.4 4.5 8.7 7.2 14.4 7.2l45 0c19.9 0 36 16.1 36 36zM36 360a72 72 0 1 1 144 0 72 72 0 1 1 -144 0z"],
    "globe": [504, 540, [127760], "f0ac", "M252 0C112.8 0 0 112.8 0 252l0 36C0 427.2 112.8 540 252 540S504 427.2 504 288l0-36C504 112.8 391.2 0 252 0zM36.7 234c7.6-92.4 73.5-168.4 160.8-191.1-41.2 55.3-67.3 122-71 191.1l-89.7 0zm0 36l89.7 0c3.8 69.1 29.8 135.8 71 191.1-87.3-22.7-153.2-98.6-160.8-191.1zM250.4 468c-50.9-52.5-83.4-125.1-87.8-198l178.9 0c-4.5 72.9-36.9 145.5-87.8 198-1.1 0-2.2 0-3.3 0zM377.5 270l89.7 0c-7.6 92.4-73.5 168.4-160.8 191.1 41.2-55.3 67.3-122 71-191.1zm0-36c-3.8-69.1-29.8-135.8-71-191.1 87.3 22.7 153.2 98.6 160.8 191.1l-89.7 0zM253.6 36c50.9 52.5 83.4 125.1 87.8 198l-178.9 0c4.5-72.9 36.9-145.5 87.8-198 1.1 0 2.2 0 3.3 0z"],
    "arrow-left": [504, 540, [8592], "f060", "M284.9 39.1C256.8 11 211.2 11 183.1 39.1l-162 162C7 215.1 0 233.6 0 252l0 36c0 18.4 7 36.9 21.1 50.9l162 162c28.1 28.1 73.7 28.1 101.8 0 14-14 21.1-32.5 21.1-50.9l0-36.1c0-21.2-9.5-39.3-24.2-53.9L432 360c39.8 0 72-32.2 72-72l0-36c0-39.8-32.2-72-72-72l-126 0 0-90.1c0-18.4-7-36.8-21.1-50.9zM270 414c0 9.2-3.5 18.4-10.5 25.4-14.1 14.1-36.9 14.1-50.9 0l-162-162c-14.1-14.1-14.1-36.8 0-50.9l162-162c14.1-14.1 36.9-14.1 50.9 0s14.1 36.9 0 50.9l-69.8 69.8c-11.1 11.1-3 30.7 12.7 30.7L432 216c19.9 0 36 16.1 36 36s-16.1 36-36 36l-229.6 0c-15.7 0-23.8 19.6-12.7 30.7l69.8 69.8c7 7 10.5 16.3 10.5 25.5z"],
    "paw": [468, 540, [], "f1b0", "M180 18c-39.8 0-72 32.2-72 72l0 9.6C97.4 93.5 85.1 90 72 90 32.2 90 0 122.2 0 162l0 72c0 34.5 24.2 63.3 56.6 70.3-13 28.4-20.6 59.8-20.6 91.7l0 36c0 22.5 10.5 43.7 28.4 57.3 17.9 13.6 41.1 18.1 62.8 12.1 35-9.5 71.4-15.4 106.8-15.4s71.9 6 106.8 15.4c21.6 6 44.9 1.5 62.7-12.1 17.9-13.6 28.4-34.8 28.4-57.3l0-36c0-31.8-7.5-63.2-20.6-91.7 32.3-7.1 56.6-35.9 56.6-70.3l0-72c0-39.8-32.2-72-72-72-13.1 0-25.4 3.5-36 9.6l0-9.6c0-39.8-32.2-72-72-72-21.5 0-40.8 9.4-54 24.4-13.2-14.9-32.5-24.4-54-24.4zM396 396c0 11.3-5.3 21.9-14.2 28.7-8.9 6.8-20.7 9-31.5 6-37.3-10.1-77-16.7-116.3-16.7s-79 6.6-116.3 16.7c-10.8 3-22.6 .8-31.5-6S72 407.3 72 396c0-44 17.6-88 45.3-121.2 27.7-33.2 68.6-58.8 116.7-58.8s89 25.6 116.7 58.8C378.4 308 396 352 396 396zM216 90l0 54c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-54c0-19.9 16.1-36 36-36s36 16.1 36 36zm36 54l0-54c0-19.9 16.1-36 36-36s36 16.1 36 36l0 54c0 19.9-16.1 36-36 36s-36-16.1-36-36zM72 234c-19.9 0-36-16.1-36-36l0-36c0-19.9 16.1-36 36-36s36 16.1 36 36l0 36c0 19.9-16.1 36-36 36zm360-72l0 36c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-36c0-19.9 16.1-36 36-36s36 16.1 36 36z"],
    "bed": [540, 540, [128716], "f236", "M0 126C0 86.2 32.2 54 72 54s72 32.2 72 72l0 9.6c10.6-6.1 22.9-9.6 36-9.6 21.5 0 40.8 9.4 54 24.4 13.2-14.9 32.5-24.4 54-24.4l180 0c39.8 0 72 32.2 72 72l0 216c0 39.8-32.2 72-72 72s-72-32.2-72-72l-252 0c0 39.8-32.2 72-72 72S0 453.8 0 414L0 126zM108 252l0-126c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 252c0 19.9 16.1 36 36 36s36-16.1 36-36l0-18c0-9.9 8.1-18 18-18l288 0c9.9 0 18 8.1 18 18l0 18c0 19.9 16.1 36 36 36s36-16.1 36-36l0-108-378 0c-9.9 0-18-8.1-18-18zm108-54a36 36 0 1 0 -72 0 36 36 0 1 0 72 0zm36 36l252 0 0-36c0-19.9-16.1-36-36-36l-180 0c-19.9 0-36 16.1-36 36l0 36z"],
    "landmark": [432, 540, [127963], "f66f", "M183.8 7.6c20.3-10.1 44.1-10.1 64.4 0l144 72c24.6 12.3 39.6 37.3 39.8 63.9 0 .2 0 .4 0 .5l0 36c0 5.5-.6 11-1.9 16.5-4.7 19.9-17.3 36.1-34.1 45.8l0 91.3c21.5 12.5 36 35.7 36 62.4l0 36c0 39.8-32.2 72-72 72L72 504c-39.8 0-72-32.2-72-72l0-36c0-26.6 14.5-49.9 36-62.4l0-91.3c-16.7-9.7-29.4-26-34.1-45.8-1-4.1-1.6-8.3-1.8-12.4L0 180 0 144c0-.3 0-.6 0-.8 .3-26.5 15.2-51.3 39.8-63.6l144-72zM72 360c-19.9 0-36 16.1-36 36s16.1 36 36 36l288 0c19.9 0 36-16.1 36-36s-16.1-36-36-36L72 360zm0-36l72 0 0-108-72 0 0 108zm108 0l72 0 0-108-72 0 0 108zm108 0l72 0 0-108-72 0 0 108zM232.1 39.8c-10.1-5.1-22.1-5.1-32.2 0l-144 72C41 119.3 33.1 136 37 152.3S55.3 180 72 180l288 0c16.7 0 31.2-11.5 35.1-27.7s-4-33-19-40.5l-144-72z"],
    "music": [504, 540, [127925], "f001", "M0 369c0-29.3 15.9-54.5 38.8-71.7 18.8-14.1 42.8-23.4 69.2-26.3l0-145c0-35.2 25.4-65.2 60.2-71l216-36c20.9-3.5 42.2 2.4 58.4 16.1S468 68.8 468 90l0 279c0 29.3-15.9 54.5-38.8 71.7-22.9 17.2-53.8 27.3-87.2 27.3-34.2 0-69.7-10.8-95.4-34.1-6.5 16.9-18.5 31.6-33.4 42.8-22.9 17.2-53.8 27.3-87.2 27.3S61.8 493.9 38.8 476.7 0 434.3 0 405l0-36zM390.1 54.5l-216 36C156.7 93.4 144 108.4 144 126l0 162c0 9.9-8.1 18-18 18-26.3 0-49.4 8-65.6 20.1S36 353.6 36 369 44.3 399.8 60.4 411.9 99.7 432 126 432 175.4 424 191.6 411.9 216 384.4 216 369l0-197.3c0-8.8 6.4-16.3 15-17.8l108-18c10.8-1.8 21 6.8 21 17.8l0 98.3c0 9.9-8.1 18-18 18-26.3 0-49.4 8-65.6 20.1s-24.4 27.4-24.4 42.9 8.3 30.8 24.4 42.9 39.3 20.1 65.6 20.1 49.4-8 65.6-20.1 24.4-27.4 24.4-42.9l0-243c0-10.6-4.7-20.6-12.7-27.5s-18.7-9.8-29.2-8zM324 235l0-24-72 12 0 40.5c19.2-15.3 44.3-25.4 72-28.5z"],
    "files": [396, 540, [], "e178", "M396 130.4c0-19.1-7.6-37.4-21.1-50.9L316.5 21.1C303 7.6 284.7 0 265.6 0L180 0c-39.8 0-72 32.2-72 72l0 36-36 0c-39.8 0-72 32.2-72 72L0 468c0 39.8 32.2 72 72 72l144 0c39.8 0 72-32.2 72-72l0-36 36 0c39.8 0 72-32.2 72-72l0-229.6zM144 72c0-19.9 16.1-36 36-36l54 0 0 54c0 39.8 32.2 72 72 72l54 0 0 162c0 19.9-16.1 36-36 36l-144 0c-19.9 0-36-16.1-36-36l0-252zM252 396l0 36c0 19.9-16.1 36-36 36L72 468c-19.9 0-36-16.1-36-36l0-252c0-19.9 16.1-36 36-36l36 0 0 180c0 39.8 32.2 72 72 72l72 0zM270 90l0-53.7c7.9 1 15.4 4.6 21.1 10.3l58.4 58.4c5.7 5.7 9.3 13.2 10.3 21.1L306 126c-19.9 0-36-16.1-36-36z"],
    "plus": [468, 540, [10133, 61543, "add"], "2b", "M0 252c0-39.8 32.2-72 72-72l90 0 0-90c0-39.8 32.2-72 72-72s72 32.2 72 72l0 90 90 0c39.8 0 72 32.2 72 72l0 36c0 39.8-32.2 72-72 72l-90 0 0 90c0 39.8-32.2 72-72 72s-72-32.2-72-72l0-90-90 0c-39.8 0-72-32.2-72-72l0-36zM198 90l0 108c0 9.9-8.1 18-18 18L72 216c-19.9 0-36 16.1-36 36s16.1 36 36 36l108 0c9.9 0 18 8.1 18 18l0 108c0 19.9 16.1 36 36 36s36-16.1 36-36l0-108c0-9.9 8.1-18 18-18l108 0c19.9 0 36-16.1 36-36s-16.1-36-36-36l-108 0c-9.9 0-18-8.1-18-18l0-108c0-19.9-16.1-36-36-36s-36 16.1-36 36z"],
    "copy": [468, 540, [], "f0c5", "M126 90c0-39.8 32.2-72 72-72l198 0c39.8 0 72 32.2 72 72l0 234c0 39.8-32.2 72-72 72l-36 0 0 54c0 39.8-32.2 72-72 72L90 522c-39.8 0-72-32.2-72-72l0-234c0-39.8 32.2-72 72-72l36 0 0-54zm0 90l-36 0c-19.9 0-36 16.1-36 36l0 198c0 19.9 16.1 36 36 36l198 0c19.9 0 36-16.1 36-36l0-54-126 0c-39.8 0-72-32.2-72-72l0-108zM432 90c0-19.9-16.1-36-36-36L198 54c-19.9 0-36 16.1-36 36l0 198c0 19.9 16.1 36 36 36l198 0c19.9 0 36-16.1 36-36l0-198z"],
    "box": [432, 540, [128230], "f466", "M117 36C89.7 36 64.8 51.4 52.6 75.8l-45 90c-5 10-7.6 21-7.6 32.2L0 432c0 39.8 32.2 72 72 72l288 0c39.8 0 72-32.2 72-72l0-234c0-11.2-2.6-22.2-7.6-32.2l-45-90C367.2 51.4 342.3 36 315 36L117 36zM84.8 91.9C90.9 79.7 103.4 72 117 72l81 0 0 108-157.2 0 44-88.1zM36 216l360 0 0 180c0 19.9-16.1 36-36 36L72 432c-19.9 0-36-16.1-36-36l0-180zm355.2-36l-157.2 0 0-108 81 0c13.6 0 26.1 7.7 32.2 19.9l44 88.1z"],
    "arrow-rotate-right": [504, 540, [8635, "arrow-right-rotate", "arrow-rotate-forward", "redo"], "f01e", "M36 252c0-119.3 96.7-216 216-216 50 0 98.1 18.5 135.1 51.7 20.3-16.2 48-20.3 72.4-10.2 26.9 11.1 44.4 37.4 44.4 66.5l0 126c0 38.3-29.9 69.6-67.6 71.9l0 36.1c0 15.8-5.2 31.7-15.8 45-39.5 49.2-100.3 81-168.6 81-119.3 0-216-96.7-216-216l0-36zm36 0c0 99.4 80.6 180 180 180 56.9 0 107.6-26.4 140.5-67.5 12.4-15.5 9.9-38.2-5.6-50.6-15.2-12.2-38.3-9.8-50.6 5.6-19.9 24.8-50.2 40.5-84.3 40.5-59.6 0-108-48.4-108-108s48.4-108 108-108c25 0 49 9.9 66.7 27.6l.4 .4c4.9 4.9 9.5 9.5 9.5 17 0 7.7-5.1 12.7-10.2 17.7-.6 .6-1.3 1.2-1.9 1.9-10.3 10.3-13.4 25.8-7.8 39.2S327.4 270 342 270l90 0c19.9 0 36-16.1 36-36l0-90c0-14.6-8.8-27.7-22.2-33.3s-28.9-2.5-39.2 7.8l-6.8 6.8c-3.4 3.4-8 5.3-12.7 5.3s-9.4-1.9-12.7-5.3l-4.6-4.6C338.4 89.5 296.1 72 252 72 152.6 72 72 152.6 72 252zm214.1 63.4c-4.3-5.3-7.9-11.3-10.7-17.9-3.7-8.9-5.5-18.3-5.5-27.6l0-36c0-4.9 .5-9.9 1.5-14.7-6.2-2.2-12.8-3.4-19.5-3.4-33.5 0-61.7 22.9-69.7 54 8 31.1 36.2 54 69.7 54 12.4 0 24-3.1 34.1-8.6z"],
    "signal-bars-slash": [504, 540, ["signal-alt-slash"], "f694", "M21.1 21.1C49.2-7 94.8-7 122.9 21.1L261.3 159.5c12.3-9.7 27.8-15.5 44.7-15.5 13.1 0 25.4 3.5 36 9.6l0-9.6c0-39.8 32.2-72 72-72s72 32.2 72 72l0 240.4C498 398 504 415 504 432l0 36c0 18.4-7 36.9-21.1 50.9-28.1 28.1-73.7 28.1-101.8 0l-30.4-30.4c-12.3 9.7-27.8 15.5-44.7 15.5-21.5 0-40.8-9.4-54-24.4-13.2 14.9-32.5 24.4-54 24.4s-40.8-9.4-54-24.4c-13.2 14.9-32.5 24.4-54 24.4-39.8 0-72-32.2-72-72l0-72c0-39.8 32.2-72 72-72 13.1 0 25.4 3.5 36 9.6 0-10.4 0-20.6 3.1-30.7l-108-108C7 144.9 0 126.4 0 108L0 69.8c0-18 8.5-36.1 21.1-48.7zM46.5 46.5c-14.1 14.1-14.1 36.9 0 50.9l360 360c14.1 14.1 36.9 14.1 50.9 0s14.1-36.9 0-50.9l-360-360c-14.1-14.1-36.9-14.1-50.9 0zM450 348.2L450 144c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 132.2 72 72zm-108-108l0-24.2c0-19.9-16.1-36-36-36-6.9 0-13.4 1.9-18.9 5.3L342 240.2zM162 299.8L162 432c0 19.9 16.1 36 36 36s36-16.1 36-36l0-60.2-72-72zM270 432c0 19.9 16.1 36 36 36 6.9 0 13.4-1.9 18.9-5.3L270 407.8 270 432zM126 360c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 72c0 19.9 16.1 36 36 36s36-16.1 36-36l0-72z"],
    "arrow-down-wide-short": [540, 540, ["sort-amount-asc", "sort-amount-down"], "f160", "M432 396c0 39.8-32.2 72-72 72l-36 0c-30.9 0-57.2-19.4-67.4-46.7l-61.6 61.6c-28.1 28.1-73.7 28.1-101.8 0l-72-72C7.3 397.1 0 378.7 0 360l0-35.5c-.1-9.5 1.7-19 5.5-28.1 11.1-26.9 37.4-44.4 66.5-44.4l0-144c0-39.8 32.2-72 72-72s72 32.2 72 72l0 144c12.9 0 25.3 3.5 36 9.6l0-9.6c0-13.1 3.5-25.5 9.6-36-6.1-10.6-9.6-22.9-9.6-36l0-36.2c.1-39.7 32.3-71.8 72-71.8l144 0c39.8 0 72 32.2 72 72l0 36c0 33.6-23 61.8-54 69.7 .4 12.7 0 25.5 0 38.3 0 33.6-23 61.8-54 69.7 0 .8 0 37.5 0 38.3zM46.5 349.5l72 72c14.1 14.1 36.9 14.1 50.9 0l72-72c10.3-10.3 13.4-25.8 7.8-39.2S230.6 288 216 288l-18 0c-9.8 0-18-8.2-18-18l0-162c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 162c0 9.9-8.1 18-18 18l-18 0c-14.6 0-27.7 8.8-33.3 22.2-5.5 13.2-2.3 29.1 7.8 39.2zM468 108l-144 0c-19.9 0-36 16.1-36 36s16.1 36 36 36l144 0c19.8 0 35.9-16.3 36-36.1-.1-19.8-16.2-35.9-36-35.9zM414 216L324 216c-19.9 0-36 16.1-36 36 0 19.9 16.1 36 36 36l90 0c19.8 0 35.9-16.3 36-36.1-.1-19.8-16.1-35.8-36-35.9zM360 324l-36 0c-19.8 0-35.9 16.1-36 35.9 .1 19.8 16.2 36.1 36 36.1l36 0c19.8 0 35.9-16.3 36-36.1-.1-19.8-16.2-35.9-36-35.9z"],
    "compress": [432, 540, [], "f066", "M9.6 270C3.5 259.4 0 247.1 0 234l0-36c0-39.8 32.2-72 72-72l18 0 0-18c0-39.8 32.2-72 72-72 21.5 0 40.8 9.4 54 24.4 13.2-14.9 32.5-24.4 54-24.4 39.8 0 72 32.2 72 72l0 18 18 0c39.8 0 72 32.2 72 72l0 36c0 13.1-3.5 25.4-9.6 36 6.1 10.6 9.6 22.9 9.6 36l0 36c0 39.8-32.2 72-72 72l-18 0 0 18c0 39.8-32.2 72-72 72-21.5 0-40.8-9.4-54-24.4-13.2 14.9-32.5 24.4-54 24.4-39.8 0-72-32.2-72-72l0-18-18 0c-39.8 0-72-32.2-72-72l0-36c0-13.1 3.5-25.4 9.6-36zM198 198l0-90c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 36c0 9.8-8.2 18-18 18l-36 0c-19.9 0-36 16.1-36 36s16.1 36 36 36l90 0c19.6 0 36-16.4 36-36zM36 306c0 19.9 16.1 36 36 36l36 0c9.8 0 18 8.2 18 18l0 36c0 19.9 16.1 36 36 36s36-16.1 36-36l0-90c0-19.6-16.4-36-36-36l-90 0c-19.8 0-36 16.3-36 36zm360 0c0-19.7-16.2-36-36-36l-90 0c-19.6 0-36 16.4-36 36l0 90c0 19.9 16.1 36 36 36s36-16.1 36-36l0-36c0-9.8 8.2-18 18-18l36 0c19.9 0 36-16.1 36-36zm0-108c0-19.9-16.1-36-36-36l-36 0c-9.8 0-18-8.2-18-18l0-36c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 90c0 19.6 16.4 36 36 36l90 0c19.9 0 36-16.1 36-36z"],
    "eye-slash": [504, 540, [], "f070", "M21.1 21.1C49.2-7 94.8-7 122.9 21.1l74.5 74.5c15.9-3.7 32.2-5.6 48.8-5.6l11.5 0c63.1 0 123 27.6 164 75.4l64.9 75.7c23.1 27 23.1 66.8 0 93.7l-23.1 26.9 19.3 19.3C497 395.1 504 413.6 504 432l0 36c0 18.4-7 36.9-21.1 50.9-28.1 28.1-73.7 28.1-101.8 0L334.2 472c-24.2 9.1-50 14-76.4 14l-11.5 0c-63.1 0-123-27.6-164-75.4L17.3 334.9c-23.1-27-23.1-66.8 0-93.7L57 194.8 21.1 158.9C7 144.9 0 126.4 0 108L0 69.8c0-18 8.5-36.1 21.1-48.7zM46.5 46.5c-14.1 14.1-14.1 36.9 0 50.9l360 360c14.1 14.1 36.9 14.1 50.9 0s14.1-36.9 0-50.9l-360-360c-14.1-14.1-36.9-14.1-50.9 0zM438.1 336.2l21.3-24.8c11.6-13.5 11.6-33.4 0-46.9l-64.9-75.7C360.2 149 310.3 126 257.8 126l-11.5 0c-5.9 0-11.7 .3-17.5 .9L438.1 336.2zM44.7 264.6c-11.6 13.5-11.6 33.4 0 46.9l64.9 75.7C143.8 427 193.7 450 246.2 450l11.5 0c16.4 0 32.5-2.2 47.9-6.5L82.6 220.4 44.7 264.6z"],
    "mug-hot": [504, 540, [9749], "f7b6", "M327.9 12.1c20.9 14 32.2 37 32.1 60.4 0 2.8 .1 6.1 .2 9.8 .2 7.8 .5 16.9 0 24.8-.8 12.9-3.4 27.5-12.3 40.9-3.9 5.8-5.9 12.6-5.9 19.5l0 12.5 45 0c64.6 0 117 52.4 117 117l0 36c0 64.6-52.4 117-117 117l-3.1 0c-20.2 42.6-63.6 72-113.9 72l-108 0C92.4 522 36 465.6 36 396l0-144c0-37 27.9-67.5 63.9-71.5-6.3-10.7-9.9-23.2-9.9-36.5l0-36c0-39.8 32.2-72 72-72 20.3 0 38.7 8.4 51.8 22 4-9 8.8-17.6 14.3-25.9 22.1-33.1 66.8-42 99.8-20zM72 252l0 108c0 49.7 40.3 90 90 90l108 0c49.7 0 90-40.3 90-90l0-144-252 0c-19.9 0-36 16.1-36 36zm198-72c19.9 0 36-16.1 36-36l0-12.6c0-14.1 4.2-27.8 12-39.5 11-16.5 6.6-38.9-10-49.9S269.1 35.5 258 52c-15.7 23.5-24 51.2-24 79.4l0 12.6c0 19.9 16.1 36 36 36zm-108 0c19.9 0 36-16.1 36-36l0-36c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 36c0 19.9 16.1 36 36 36zM396 360c0 6-.4 11.9-1.2 17.6 41.1-3.9 73.2-38.5 73.2-80.6 0-41.7-31.5-76-72-80.5L396 360z"],
    "bolt": [396, 540, [9889, "zap"], "f0e7", "M246.4 6.7c-30.1-14-65.9-5.6-86.6 20.3L15.8 207C5.4 220 0 236 0 252l0 36c0 10.6 2.3 21.3 7.1 31.2 12 24.9 37.2 40.8 64.9 40.8l49 0-11.6 57.9c-.9 4.7-1.4 9.4-1.4 14.1l0 36.1c0 27.5 15.9 53.2 41.6 65.2 30.1 14 65.9 5.6 86.6-20.3l144-180C390.6 320 396 304 396 288l0-36c0-10.6-2.3-21.3-7.1-31.2-12-24.9-37.2-40.8-64.9-40.8l-49 0 11.6-57.9c.9-4.7 1.4-9.4 1.4-14.1l0-36c0-27.6-15.9-53.3-41.6-65.3zM231.2 39.4c15 7 23.4 23.4 20.1 39.7L228.2 194.5c-1.1 5.3 .3 10.8 3.7 14.9s8.5 6.6 13.9 6.6l78.1 0c13.8 0 26.5 7.9 32.4 20.4s4.3 27.3-4.3 38.1l-144 180c-10.4 13-28.3 17.2-43.3 10.1s-23.4-23.4-20.1-39.7l23.1-115.4c1.1-5.3-.3-10.8-3.7-14.9s-8.5-6.6-13.9-6.6L72 288c-13.8 0-26.5-7.9-32.4-20.4s-4.3-27.3 4.3-38.1l144-180c10.4-13 28.3-17.2 43.3-10.1z"],
    "arrow-rotate-left": [504, 540, [8634, "arrow-left-rotate", "arrow-rotate-back", "arrow-rotate-backward", "undo"], "f0e2", "M468 234C468 114.7 371.3 18 252 18 202 18 153.9 36.5 116.9 69.7 96.6 53.5 68.8 49.4 44.4 59.5 17.5 70.6 0 96.9 0 126L0 252c0 38.3 29.9 69.6 67.6 71.9l0 36.1c0 15.8 5.2 31.7 15.8 45 39.5 49.2 100.3 81 168.6 81 119.3 0 216-96.7 216-216l0-36zm-36 0c0 99.4-80.6 180-180 180-56.9 0-107.6-26.4-140.5-67.5-12.4-15.5-9.9-38.2 5.6-50.6 15.2-12.2 38.3-9.8 50.6 5.6 19.9 24.8 50.2 40.5 84.3 40.5 59.6 0 108-48.4 108-108S311.6 126 252 126c-25 0-49 9.9-66.7 27.6l-.4 .4c-4.9 4.9-9.5 9.5-9.5 17 0 7.7 5.1 12.7 10.2 17.7 .6 .6 1.3 1.2 1.9 1.9 10.3 10.3 13.4 25.8 7.8 39.2S176.6 252 162 252l-90 0c-19.9 0-36-16.1-36-36l0-90c0-14.6 8.8-27.7 22.2-33.3s28.9-2.5 39.2 7.8l6.8 6.8c3.4 3.4 8 5.3 12.7 5.3s9.4-1.9 12.7-5.3l4.6-4.6C165.6 71.5 207.9 54 252 54 351.4 54 432 134.6 432 234zM217.9 297.4c4.3-5.3 7.9-11.3 10.7-17.9 3.7-8.9 5.5-18.3 5.5-27.6l0-36c0-4.9-.5-9.9-1.5-14.7 6.2-2.2 12.8-3.4 19.5-3.4 33.5 0 61.7 22.9 69.7 54-8 31.1-36.2 54-69.7 54-12.4 0-24-3.1-34.1-8.6z"],
    "wifi": [576, 540, ["wifi-3", "wifi-strong"], "f1eb", "M552 118.9c15.9 14.3 24 34.1 24 53.9l0 35.7c0 17.1-6.1 34.3-18.4 48-14.2 15.9-33.9 23.9-53.6 24l0 8.8c-.1 17-6.1 34.1-18.4 47.8-14.2 15.9-33.9 23.9-53.6 24l0 7.9c.1 17.3-5.9 34.7-18.4 48.6-14.2 15.9-33.9 23.9-53.6 24l0 8.5c0 39.8-32.2 72-72 72s-72-32.2-72-72l0-8.5c-19.7 0-39.4-8.1-53.6-24-12.4-13.9-18.5-31.3-18.4-48.6l0-7.9c-19.7 0-39.4-8.1-53.6-24-12.2-13.6-18.3-30.8-18.4-47.8l0-8.8c-19.7 0-39.4-8.1-53.6-24-12.3-13.7-18.4-30.9-18.4-48l0-35.7c-.1-19.9 8-39.6 24-53.9 150.1-134.5 378-134.5 528.1 0zM324 414a36 36 0 1 0 -72 0 36 36 0 1 0 72 0zm12-53.7c14.8 13.3 37.6 12 50.8-2.8s12-37.6-2.8-50.8c-54.6-48.9-137.5-48.9-192 0-14.8 13.3-16.1 36-2.8 50.8s36 16.1 50.8 2.8c27.2-24.4 68.7-24.4 96 0zM456 226.2c-95.5-85.6-240.5-85.6-336 0-7.9 7.1-11.9 16.8-12 26.6 0 8.5 3.1 17.4 9.2 24.2 13.3 14.8 36 16.1 50.8 2.8 68.2-61.1 171.8-61.1 240 0 14.8 13.3 37.6 12 50.8-2.8 6.1-6.8 9.1-15.7 9.2-24.2 0-9.8-4.1-19.6-12-26.6zm24-26.9c14.8 13.3 37.6 12 50.8-2.8 6.1-6.8 9.2-15.6 9.2-24.1 0-9.9-4.1-19.7-12-26.8-136.4-122.2-343.6-122.2-480 0-7.9 7.1-12 16.9-12 26.8 0 8.5 3.1 17.2 9.2 24.1 13.3 14.8 36 16.1 50.8 2.8 109.1-97.7 274.9-97.7 384 0z"],
    "volume": [576, 540, [128265, "volume-medium"], "f6a8", "M249.8 18c-14.9 0-29.2 5.9-39.7 16.5l-86.3 86.3c-3.4 3.4-8 5.3-12.7 5.3L72 126c-39.8 0-72 32.2-72 72L0 342c0 39.8 32.2 72 72 72l39.1 0c4.8 0 9.4 1.9 12.7 5.3l86.3 86.3c10.5 10.5 24.8 16.5 39.7 16.5 31 0 56.2-25.2 56.2-56.2l0-391.6c0-31-25.2-56.2-56.2-56.2zM270 74.2l0 355.6c0 11.1-9 20.2-20.2 20.2-5.4 0-10.5-2.1-14.3-5.9l-86.3-86.3c-10.1-10.1-23.9-15.8-38.2-15.8L72 342c-19.9 0-36-16.1-36-36l0-108c0-19.9 16.1-36 36-36l39.1 0c14.3 0 28.1-5.7 38.2-15.8l86.3-86.3c3.8-3.8 8.9-5.9 14.3-5.9 11.1 0 20.2 9 20.2 20.2zm79.5 .6C367.2 39.2 410.4 24.7 446 42.4 522.9 80.6 576 160 576 252l0 36c0 92-53.1 171.4-130 209.6-35.6 17.7-78.8 3.2-96.5-32.4-5.3-10.7-7.7-22.1-7.5-33.3l0-33.2c-.6-27 14.2-53.2 40-66 24.6-12.2 42.7-35.2 48.2-62.7-5.6-27.4-23.7-50.5-48.2-62.7-24.9-12.4-39.4-37.3-40-63.2l0-35.8c-.2-11.3 2.2-22.7 7.5-33.5zM398 364.9c-17.5 8.7-24.8 30.9-16.2 48.3 8.8 17.8 30.5 25.1 48.3 16.2 65.1-32.4 110-99.6 110-177.4S495.1 107 430 74.6c-17.8-8.8-39.4-1.6-48.3 16.2s-1.6 39.4 16.2 48.3c41.6 20.7 70 63.5 70 112.9s-28.4 92.3-70 112.9z"],
    "tag": [468, 540, [127991], "f02b", "M234 180a72 72 0 1 1 -144 0 72 72 0 1 1 144 0zm-40.8 18c-6.2-10.8-17.9-18-31.2-18s-25 7.2-31.2 18c6.2 10.8 17.9 18 31.2 18s25-7.2 31.2-18zM0 288c0 19.1 7.6 37.4 21.1 50.9l162 162c28.1 28.1 73.7 28.1 101.8 0l162-162C461 324.9 468 306.4 468 288l0-36c0-18.4-7-36.9-21.1-50.9l-162-162C271.4 25.6 253.1 18 234 18L72 18C32.2 18 0 50.2 0 90L0 288zM72 54l162 0c9.5 0 18.7 3.8 25.5 10.5l162 162c14.1 14.1 14.1 36.9 0 50.9l-162 162c-14.1 14.1-36.9 14.1-50.9 0l-162-162C39.8 270.7 36 261.5 36 252L36 90c0-19.9 16.1-36 36-36z"],
    "compact-disc": [504, 540, [128191, 128192, 128440], "f51f", "M0 252C0 112.8 112.8 0 252 0S504 112.8 504 252l0 36c0 139.2-112.8 252-252 252S0 427.2 0 288l0-36zm36 0c0 119.3 96.7 216 216 216 13.1 0 25.9-1.2 38.3-3.4L257.4 341.8c-51 3-95.4-38.7-95.4-89.8 0-10 1.6-19.5 4.6-28.5L56.5 159.9C43.4 187.9 36 219.1 36 252zm148.6-59.7c7.6-8.6 16.8-15.7 27.2-20.9L178.9 48.7C136.3 64 100 92.3 74.6 128.8l110.1 63.5zm61.9-30.2c51-3 95.4 38.7 95.4 89.8 0 10-1.6 19.5-4.6 28.5l110.1 63.5c13.2-27.9 20.5-59.1 20.5-92.1 0-119.3-96.7-216-216-216-13.1 0-25.9 1.2-38.3 3.4l32.9 122.8zm72.8 149.5c-7.6 8.6-16.8 15.7-27.2 20.9l32.9 122.8c42.6-15.3 78.9-43.6 104.3-80.1L319.4 311.7zM201 269.7c7.3 21.1 27.4 36.3 51 36.3 20.1 0 37.4-10.8 46.8-27 1.7-2.9 3.1-6 4.2-9.3-1.6-2.8-2.6-5.9-4.2-8.7-9.4-16.2-26.8-27-46.8-27-20.1 0-37.4 10.8-46.8 27-1.6 2.8-2.7 5.9-4.2 8.7z"],
    "phone-slash": [504, 540, [], "f3dd", "M178.6 463.4L123 518.9C94.9 547 49.3 547 21.2 518.9 7.1 504.9 .1 486.4 .1 468l0-36c0-18.4 7-36.9 21.1-50.9l41.9-41.9c-28.7-51.4-45-110.5-45-173.5 0-25.4 10.5-49.1 32.1-63.5l54-36c28.6-19 66.6-15.3 90.8 9l45 45c7.5 7.5 13 16.3 16.5 25.6L381.2 21.1c28.1-28.1 73.7-28.1 101.8 0 12.9 12.9 19.9 29.6 21 46.5 1.6 13.1 .1 27.2 .1 40.4 0 18.4-7 36.9-21.1 50.9L362.6 279.3c20.5-1.8 41.7 5.1 57.4 20.8l45 45c24.3 24.3 28 62.3 9 90.8l-36 54c-14.4 21.6-38.1 32.1-63.5 32.1-72.4 0-139.7-21.6-195.9-58.6zm26.1-26.1c49.2 30.9 107.5 48.7 169.9 48.7 13.4 0 25.8-4.4 33.6-16l36-54c9.5-14.3 7.6-33.3-4.5-45.4l-45-45c-14.1-14.1-36.9-14.1-50.9 0l-59.1 59.1c-5.5 5.5-13.8 6.8-20.8 3.4-2.2-1.1-4.4-2.2-6.5-3.4l-52.7 52.7zm-158-30.8c-14.1 14.1-14.1 36.9 0 50.9s36.9 14.1 50.9 0l360-360c14.1-14.1 14.1-36.9 0-50.9s-36.9-14.1-50.9 0l-360 360zm167.9-261l-45-45c-12.1-12.1-31.1-14-45.4-4.5l-54 36c-11.6 7.7-16 20.2-16 33.6 0 53 12.9 102.9 35.6 147L224.5 177.8c2.2-11.3-1.1-23.5-9.9-32.3z"],
    "arrow-up-right-from-square": [432, 540, ["external-link"], "f08e", "M432 216c0 26.8-14.8 51.1-38.1 63.5 1.4 5.6 2.1 11.4 2.1 17.5 0 45 0 90 0 135 0 39.8-32.2 72-72 72L72 504c-39.2 0-72-32.8-72-72 0-96 0-192 0-288 0-39.8 32.2-72 72-72l99 0c18.1 0 34.7 6.7 47.3 17.8 .8-3.1 1.9-6.3 3.1-9.3 11.1-26.9 37.4-44.4 66.5-44.4l72 0c39.2 0 72 32.8 72 72l0 108zM360 72l-72 0c-14.6 0-27.7 8.8-33.3 22.2-5.3 12.8-2.8 27.5 6.4 37.7 6.4 7.1 6 18-.7 24.7L154.6 262.5c-14.1 14.1-14.1 36.9 0 50.9s36.9 14.1 50.9 0L311.3 207.6c6.7-6.7 17.6-7.1 24.7-.7 10.3 9.2 24.9 11.7 37.7 6.4 13.4-5.6 22.2-18.6 22.2-33.2l0-72.1c0-19.6-16.4-36-36-36zM36 396c.1 19.6 16.4 36 36 36l252 0c19.9 0 36-16.1 36-36l0-99c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 45c0 9.9-8.1 18-18 18l-144 0c-9.8 0-18-8.2-18-18l0-144c0-9.9 8.1-18 18-18l45 0c19.9 0 36-16.1 36-36s-16.1-36-36-36l-99 0c-19.9 0-36 16.1-36 36l0 252z"],
    "rectangle-tall": [324, 540, [], "e791", "M0 54C0 14.2 32.2-18 72-18l180 0c39.8 0 72 32.2 72 72l0 432c0 39.8-32.2 72-72 72L72 558c-39.8 0-72-32.2-72-72L0 54zm36 0l0 396c0 19.9 16.1 36 36 36l180 0c19.9 0 36-16.1 36-36l0-396c0-19.9-16.1-36-36-36L72 18C52.1 18 36 34.1 36 54z"],
    "compass": [504, 540, [129517], "f14e", "M252 279a27 27 0 1 0 0-54 27 27 0 1 0 0 54zm42.2-164.5c27.3-12.4 59.5-6.6 80.7 14.6s27.1 53.4 14.6 80.7l-45 99c-7.2 15.8-19.9 28.5-35.8 35.8l-99 45c-27.3 12.4-59.5 6.6-80.7-14.6s-27.1-53.4-14.6-80.7l45-99c7.2-15.8 19.9-28.5 35.8-35.8l99-45zm55.2 40.1c-10.6-10.6-26.7-13.5-40.4-7.3l-99 45c-7.9 3.6-14.3 10-17.9 17.9l-45 99c-6.2 13.7-3.3 29.7 7.3 40.4s26.7 13.5 40.4 7.3l99-45c7.9-3.6 14.3-10 17.9-17.9l45-99c6.2-13.7 3.3-29.7-7.3-40.4zM0 252C0 112.8 112.8 0 252 0S504 112.8 504 252l0 36c0 139.2-112.8 252-252 252S0 427.2 0 288l0-36zm36 0a216 216 0 1 0 432 0 216 216 0 1 0 -432 0z"],
    "square": [432, 540, [9632, 9723, 9724, 61590], "f0c8", "M72 36C32.2 36 0 68.2 0 108L0 432c0 39.8 32.2 72 72 72l288 0c39.8 0 72-32.2 72-72l0-324c0-39.8-32.2-72-72-72L72 36zm324 72l0 288c0 19.9-16.1 36-36 36L72 432c-19.9 0-36-16.1-36-36l0-288c0-19.9 16.1-36 36-36l288 0c19.9 0 36 16.1 36 36z"],
    "face-grin": [504, 540, [128512, "grin"], "f580", "M162 180c0-9.9 8.1-18 18-18s18 8.1 18 18 8.1 18 18 18 18-8.1 18-18c0-29.8-24.2-54-54-54s-54 24.2-54 54c0 9.9 8.1 18 18 18s18-8.1 18-18zm162-18c-9.9 0-18 8.1-18 18s-8.1 18-18 18-18-8.1-18-18c0-29.8 24.2-54 54-54s54 24.2 54 54c0 9.9-8.1 18-18 18s-18-8.1-18-18-8.1-18-18-18zM154.1 240.9c-11.4-2.6-23.1 .3-31.6 7.2-8.8 7.1-14.4 18.9-11.7 32.2 13.2 66 71.4 115.7 141.2 115.7s128-49.7 141.2-115.7c2.7-13.3-3-25.1-11.7-32.2-8.5-6.9-20.2-9.8-31.6-7.2-21.6 5-56.7 11.1-97.9 11.1s-76.3-6.1-97.9-11.1zM252 360c-51.3 0-94.3-35.8-105.3-83.9 23.5 5.3 61.1 11.9 105.3 11.9s81.8-6.5 105.3-11.9c-11 48-54 83.9-105.3 83.9zM252 0C112.8 0 0 112.8 0 252l0 36C0 427.2 112.8 540 252 540S504 427.2 504 288l0-36C504 112.8 391.2 0 252 0zm0 468a216 216 0 1 1 0-432 216 216 0 1 1 0 432z"],
    "angle-up": [432, 540, [8963], "f106", "M165.1 111.1c28.1-28.1 73.7-28.1 101.8 0l144 144C425 269.1 432 287.6 432 306l0 36c0 18.4-7 36.9-21.1 50.9-28.1 28.1-73.7 28.1-101.8 0l-93.1-93.1-93.1 93.1C94.8 421 49.2 421 21.1 392.9 7 378.9 0 360.4 0 342l0-36c0-18.4 7-36.9 21.1-50.9l144-144zm76.4 25.5c-14.1-14.1-36.9-14.1-50.9 0l-144 144c-14.1 14.1-14.1 36.9 0 50.9s36.9 14.1 50.9 0L203.3 225.6c6.9-6.9 18.5-6.9 25.5 0L334.5 331.5c14.1 14.1 36.9 14.1 50.9 0s14.1-36.9 0-50.9l-144-144z"],
    "face-smile": [504, 540, [128578, "smile"], "f118", "M126 234c9.9 0 18 8.1 18 18 0 59.6 48.4 108 108 108s108-48.4 108-108c0-9.9 8.1-18 18-18s18 8.1 18 18c0 79.5-64.5 144-144 144S108 331.5 108 252c0-9.9 8.1-18 18-18zm36-63a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zm153 27a27 27 0 1 0 0-54 27 27 0 1 0 0 54zm189 54l0 36c0 139.2-112.8 252-252 252S0 427.2 0 288l0-36C0 112.8 112.8 0 252 0S504 112.8 504 252zM252 36a216 216 0 1 0 0 432 216 216 0 1 0 0-432z"],
    "umbrella": [504, 540, [], "f0e9", "M0 216C0 146 28.6 91.2 75.4 54.4 121.7 18 184.4 0 252 0S382.3 18 428.6 54.4C475.4 91.2 504 146 504 216l0 36c0 29.8-24.2 54-54 54l-126 0 0 108c0 69.6-56.4 126-126 126S72 483.6 72 414l0-36c0-39.8 32.2-72 72-72l-90 0c-29.8 0-54-24.2-54-54l0-36zM97.7 82.7c-37.9 29.9-61.7 74.1-61.7 133.3 0 9.9 8.1 18 18 18l91 0c1.6-22 5.4-62.1 14-102.7 6.5-30.7 15.1-62.2 31.3-89.3-36 7.3-67.6 21.1-92.6 40.7zM468 216c0-59.2-23.7-103.4-61.7-133.3-25-19.7-56.6-33.5-92.6-40.7 16.2 27.1 24.8 58.7 31.3 89.3 8.6 40.6 12.4 80.7 14 102.7l91 0c9.9 0 18-8.1 18-18zM181.1 234l141.7 0c-1.6-21.6-5.3-58.6-13.1-95.3-6.1-28.6-14.3-55.8-25.3-75.4-11.2-20.1-22.3-27.3-32.5-27.3s-21.3 7.2-32.5 27.3c-10.9 19.6-19.2 46.8-25.3 75.4-7.8 36.6-11.5 73.7-13.1 95.3zM216 377.9c0 9.9-8.1 18-18 18s-18-8-18-18c0-19.9-16.1-36-36-36-19.9 0-36 16.1-36 36 0 49.7 40.3 90 90 90s90-40.3 90-90l0-108-72 0 0 107.9z"],
    "briefcase": [504, 540, [128188], "f0b1", "M126 90l0-18c0-39.8 32.2-72 72-72L306 0c39.8 0 72 32.2 72 72l0 18 54 0c39.8 0 72 32.2 72 72l0 252c0 39.8-32.2 72-72 72L72 486c-39.8 0-72-32.2-72-72L0 162c0-39.8 32.2-72 72-72l54 0zm36-18l0 18 180 0 0-18c0-19.9-16.1-36-36-36L198 36c-19.9 0-36 16.1-36 36zM468 244.9c-10.5 4.6-23.9 9.9-39.9 15.2-23.6 7.8-53 15.7-87.3 21-5.1 24.5-26.8 42.9-52.9 42.9l-72 0c-26 0-47.7-18.4-52.9-42.9-34.2-5.4-63.6-13.2-87.3-21-16-5.3-29.4-10.6-39.9-15.2L36 378c0 19.9 16.1 36 36 36l360 0c19.9 0 36-16.1 36-36l0-133.1zm0-39.7l0-43.2c0-19.9-16.1-36-36-36L72 126c-19.9 0-36 16.1-36 36l0 43.2c9.7 4.8 27.2 12.8 51.2 20.7 21.8 7.2 49 14.5 80.7 19.5 8.9-17.5 27.1-29.4 48.1-29.4l72 0c21 0 39.2 12 48.1 29.4 31.7-5 58.9-12.3 80.7-19.5 24-8 41.5-15.9 51.2-20.7zM216 252c-9.9 0-18 8.1-18 18s8.1 18 18 18l72 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-72 0z"],
    "pause": [432, 540, [9208], "f04c", "M72 36C32.2 36 0 68.2 0 108L0 432c0 39.8 32.2 72 72 72l54 0c39.8 0 72-32.2 72-72l0-324c0-39.8-32.2-72-72-72L72 36zM36 396l0-288c0-19.9 16.1-36 36-36l54 0c19.9 0 36 16.1 36 36l0 288c0 19.9-16.1 36-36 36l-54 0c-19.9 0-36-16.1-36-36zM306 36c-39.8 0-72 32.2-72 72l0 324c0 39.8 32.2 72 72 72l54 0c39.8 0 72-32.2 72-72l0-324c0-39.8-32.2-72-72-72l-54 0zm90 72l0 288c0 19.9-16.1 36-36 36l-54 0c-19.9 0-36-16.1-36-36l0-288c0-19.9 16.1-36 36-36l54 0c19.9 0 36 16.1 36 36z"],
    "desktop": [432, 540, [128421, 61704, "desktop-alt"], "f390", "M90 144c0-9.9 8.1-18 18-18l216 0c9.9 0 18 8.1 18 18l0 126c0 9.9-8.1 18-18 18l-216 0c-9.9 0-18-8.1-18-18l0-126zm36 54l0 54 180 0 0-54-180 0zM0 108L0 342c0 39.8 32.2 72 72 72l0 36c0 39.8 32.2 72 72 72l144 0c39.8 0 72-32.2 72-72l0-36c39.8 0 72-32.2 72-72l0-234c0-39.8-32.2-72-72-72L72 36C32.2 36 0 68.2 0 108zM72 72l288 0c19.9 0 36 16.1 36 36l0 198c0 19.9-16.1 36-36 36l-90 0c-9.9 0-18 8.1-18 18s8.1 18 18 18l18 0c19.9 0 36 16.1 36 36s-16.1 36-36 36l-144 0c-19.9 0-36-16.1-36-36s16.1-36 36-36l18 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-90 0c-19.9 0-36-16.1-36-36l0-198c0-19.9 16.1-36 36-36z"],
    "arrow-down": [468, 540, [8595], "f063", "M468 270l0 36c0 18.4-7 36.9-21.1 50.9l-162 162c-28.1 28.1-73.7 28.1-101.8 0l-162-162C7 342.9 0 324.4 0 306l0-36c0-18.4 7-36.9 21.1-50.9 28.1-28.1 73.7-28.1 101.8 0L162 258.2 162 72c0-39.8 32.2-72 72-72s72 32.2 72 72l0 186.2 39.1-39.1c28.1-28.1 73.7-28.1 101.8 0 14.1 14.1 21.1 32.5 21.1 50.9zM234 36c-19.9 0-36 16.1-36 36l0 229.6c0 15.7-19.6 23.8-30.7 12.7L97.5 244.5c-14.1-14.1-36.9-14.1-50.9 0s-14.1 36.8 0 50.9l162 162c14.1 14.1 36.9 14.1 50.9 0l162-162c14.1-14.1 14.1-36.8 0-50.9-14.1-14.1-36.9-14.1-50.9 0l-69.8 69.8c-11.1 11.1-30.7 3-30.7-12.7L270 72c0-19.9-16.1-36-36-36z"],
    "location-dot": [360, 540, ["map-marker-alt"], "f3c5", "M180 126a72 72 0 1 0 0 144 72 72 0 1 0 0-144zm0 72c13.3 0 25 7.2 31.2 18-6.2 10.8-17.9 18-31.2 18s-25-7.2-31.2-18c6.2-10.8 17.9-18 31.2-18zM0 198C0 98.6 80.6 18 180 18S360 98.6 360 198l0 36c0 63.7-26 126-55.3 176.4-29.4 50.6-63.3 90.8-81.1 110.6-11.4 12.6-27.4 19-43.6 19s-32.2-6.4-43.6-19C118.5 501.2 84.7 460.9 55.3 410.4 26 360 0 297.7 0 234l0-36zm36 0c0 54.5 22.5 110.3 50.4 158.2 27.7 47.7 59.8 85.8 76.7 104.6 4 4.5 10 7.1 16.9 7.1s12.8-2.6 16.9-7.1c16.9-18.8 49-57 76.7-104.6 27.9-47.9 50.4-103.8 50.4-158.2 0-79.5-64.5-144-144-144S36 118.5 36 198z"],
    "bars": [504, 540, ["navicon"], "f0c9", "M72 54C32.2 54 0 86.2 0 126l0 36C0 179 5.9 194.7 15.8 207 5.9 219.3 0 235 0 252l0 36C0 305 5.9 320.7 15.8 333 5.9 345.3 0 361 0 378l0 36c0 39.8 32.2 72 72 72l360 0c39.8 0 72-32.2 72-72l0-36c0-17-5.9-32.7-15.8-45 9.9-12.3 15.8-28 15.8-45l0-36c0-17-5.9-32.7-15.8-45 9.9-12.3 15.8-28 15.8-45l0-36c0-39.8-32.2-72-72-72L72 54zm396 72c0 19.9-16.1 36-36 36L72 162c-19.9 0-36-16.1-36-36S52.1 90 72 90l360 0c19.9 0 36 16.1 36 36zm0 126c0 19.9-16.1 36-36 36L72 288c-19.9 0-36-16.1-36-36s16.1-36 36-36l360 0c19.9 0 36 16.1 36 36zm0 126c0 19.9-16.1 36-36 36L72 414c-19.9 0-36-16.1-36-36s16.1-36 36-36l360 0c19.9 0 36 16.1 36 36z"],
    "battery-empty": [576, 540, ["battery-0"], "f244", "M162 162c-9.9 0-18 8.1-18 18l0 144c0 9.9 8.1 18 18 18l234 0c9.9 0 18-8.1 18-18l0-144c0-9.9-8.1-18-18-18l-234 0zm18 144l0-72 198 0 0 72-198 0zM108 54c-39.8 0-72 32.2-72 72l0 288c0 39.8 32.2 72 72 72l342 0c39.8 0 72-32.2 72-72l0-20.3c31.1-8 54-36.2 54-69.7l0-108c0-33.5-22.9-61.7-54-69.7l0-20.3c0-39.8-32.2-72-72-72L108 54zM540 288c0 19.9-16.1 36-36 36-9.9 0-18 8.1-18 18l0 36c0 19.9-16.1 36-36 36l-342 0c-19.9 0-36-16.1-36-36l0-252c0-19.9 16.1-36 36-36l342 0c19.9 0 36 16.1 36 36l0 36c0 9.9 8.1 18 18 18 19.9 0 36 16.1 36 36l0 72z"],
    "stopwatch": [468, 540, [9201], "f2f2", "M108 72c0-39.8 32.2-72 72-72L288 0c39.8 0 72 32.2 72 72l0 36c0 11.8-2.8 22.9-7.8 32.7l3.9-2.6c33.1-22.1 77.8-13.1 99.8 20 8.4 12.6 12.3 26.8 12.1 40.8l0 36c-.3 22.1-13.4 53.3-36.2 61.1 .2 3.3 .2 6.7 .2 10l0 36c0 109.4-88.6 198-198 198S36 451.4 36 342l0-36c0-66.2 32.5-124.8 82.4-160.8-6.6-10.9-10.4-23.6-10.4-37.2l0-36zm36 0c0 19.9 16.1 36 36 36l108 0c19.9 0 36-16.1 36-36s-16.1-36-36-36L180 36c-19.9 0-36 16.1-36 36zM396 306a162 162 0 1 0 -324 0 162 162 0 1 0 324 0zm30-128c-11-16.5-33.4-21-49.9-10 16.7 17.2 30.4 37.5 40 59.9 16.2-10.9 20.7-33.8 9.9-49.9zM252 234l0 72c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-72c0-9.9 8.1-18 18-18s18 8.1 18 18z"],
    "train": [432, 540, [128646], "f238", "M153 342a27 27 0 1 0 0-54 27 27 0 1 0 0 54zm99-27a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zM108 18C68.2 18 36 50.2 36 90l0 252c0 6.7 .9 13.2 2.7 19.4L18.5 383.8C6.1 397.6 0 414.8 0 432l0 36c0 19.7 8 39.3 23.8 53.5 29.6 26.6 75.1 24.2 101.7-5.4l59.5-66.2 61.9 0 59.5 66.2c26.6 29.6 72.1 32 101.7 5.4 15.8-14.2 23.8-33.9 23.8-53.5l0-35.6c.1-17.3-6-34.7-18.5-48.6l-20.2-22.4c1.7-6.2 2.7-12.7 2.7-19.4l0-252c0-39.8-32.2-72-72-72L108 18zM374 393.8l12.7 14.1c13.2 14.7 12 37.6-2.7 50.8-14.8 13.3-37.5 12.1-50.8-2.7L295.4 414 324 414c19.4 0 37.1-7.7 50-20.2zM136.6 414L98.8 456.1c-13.3 14.8-36.1 16-50.8 2.7s-16-36.1-2.7-50.8L58 393.8c13 12.5 30.6 20.2 50 20.2l28.6 0zM72 90c0-19.9 16.1-36 36-36l90 0 0 162-126 0 0-126zM234 216l0-162 90 0c19.9 0 36 16.1 36 36l0 126-126 0zm126 36l0 90c0 19.9-16.1 36-36 36l-216 0c-19.9 0-36-16.1-36-36l0-90 288 0z"],
    "gamepad": [504, 540, [], "f11b", "M65 165.2l-28 168.2c-1.2 7.2-.9 14.4-.9 21.6 0 32.6 26.4 59 59 59 20.7 0 39.9-10.9 50.6-28.6l31.6-52.6c3.3-5.4 9.1-8.7 15.4-8.7l118.9 0c6.3 0 12.2 3.3 15.4 8.7l31.6 52.6c10.7 17.8 29.9 28.6 50.6 28.6 32.6 0 59-26.4 59-59 0-7.2 .3-14.5-.9-21.6L439 165.2C431.8 121.8 394.3 90 350.3 90L153.7 90c-44 0-81.5 31.8-88.8 75.2zM502.6 327.4c.9 5.7 1.4 11.4 1.4 17.2l0 46.4c0 52.5-42.5 95-95 95-33.4 0-64.3-17.5-81.4-46.1l-26.3-43.9-98.5 0-26.3 43.9C159.3 468.5 128.4 486 95 486 42.5 486 0 443.5 0 391l0-46.3c0-5.8 .5-11.6 1.4-17.3l28-168.2C39.6 98.5 92.2 54 153.7 54l196.5 0c61.6 0 114.2 44.5 124.3 105.3l28 168.2zM342 234a27 27 0 1 1 0 54 27 27 0 1 1 0-54zm-81-27a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zm135-27a27 27 0 1 1 0 54 27 27 0 1 1 0-54zm-81-27a27 27 0 1 1 54 0 27 27 0 1 1 -54 0zm-153 9l0 18 18 0c9.9 0 18 8.1 18 18s-8.1 18-18 18l-18 0 0 18c0 9.9-8.1 18-18 18s-18-8.1-18-18l0-18-18 0c-9.9 0-18-8.1-18-18s8.1-18 18-18l18 0 0-18c0-9.9 8.1-18 18-18s18 8.1 18 18z"],
    "ship": [504, 540, [128674], "f21a", "M108 90l0 69.8-17.5 4.4c-20.2 5-37.2 18.6-46.6 37.1-5.2 10.2-7.8 21.3-7.9 32.5L36 270c0 9.1 1.7 18.1 5.1 26.7l18.5 46.1C25.7 351.4-.4 378.2 0 414.7L0 450c0 45.6 44.6 81.1 89.5 69.9 0 0 38.6-9.6 63.3-15.8 32.8 8.1 65.4 18 99.5 18 33.8 0 66-9.8 98.5-18l63.8 15.8C459.4 531.1 504 495.7 504 450l0-35.3c.4-36.5-25.7-63.4-59.6-71.8l18.5-46.1c3.4-8.6 5.2-17.7 5.1-26.7l0-35.4c.1-11.5-2.6-22.9-7.9-33.3-9.5-18.5-26.5-32-46.6-37.1L396 159.8 396 90c0-39.8-32.2-72-72-72L180 18c-39.8 0-72 32.2-72 72zm72-36l144 0c19.9 0 36 16.1 36 36l0 60.8-90.5-22.6c-11.5-2.9-23.5-2.9-34.9 0L144 150.8 144 90c0-19.9 16.1-36 36-36zM429.4 247.4l-33.4 83.4c-14.9-3.7-29.6-6.8-45.1-6.8-11.9 0-23.7 1.5-35.2 4.3l-45.8 11.5 0-174.4 134.7 33.7c10.1 2.5 18.6 9.3 23.3 18.5 4.7 9.2 5.2 20.2 1.4 29.8zM234 165.4l0 174.4-45.8-11.5c-11.5-2.9-23.3-4.3-35.2-4.3-15.4 0-30.2 3.1-45.1 6.8L74.6 247.4c-3.9-9.7-3.4-20.5 1.4-29.8s13.2-16 23.3-18.5L234 165.4zM126.6 363.3c17.3-4.3 35.6-4.3 52.9 0l46.1 11.5c17.3 4.3 35.6 4.3 52.9 0l46.1-11.5c17.3-4.3 35.6-4.3 52.9 0l63.3 15.8c19.3 4.8 31 24.4 26.2 43.7s-24.4 31-43.7 26.2L360 433.1c-5.9-1.5-12.1-1.5-18 0-29.5 7.4-59.1 16.9-89.7 16.9-30.9 0-60.6-9.5-90.3-16.9-5.9-1.5-12.1-1.5-18 0L80.8 448.9c-19.3 4.8-38.8-6.9-43.7-26.2s6.9-38.8 26.2-43.7l63.3-15.8z"],
    "arrows-rotate": [504, 540, [128472, "refresh", "sync"], "f021", "M252 36c-68.3 0-129.1 31.7-168.6 81-10.7 13.3-15.9 29.3-15.8 45.2l0 36C29.9 200.4 0 231.7 0 270L0 396c0 29.1 17.5 55.4 44.4 66.5 24.4 10.1 52.1 6 72.4-10.2 37 33.2 85.1 51.7 135.1 51.7 68.3 0 129.1-31.7 168.6-81 10.7-13.3 15.8-29.2 15.8-45l0-36.1c37.7-2.3 67.6-33.6 67.6-71.9l0-126c0-29.1-17.5-55.4-44.4-66.5-24.4-10.1-52.1-6-72.4 10.2-37-33.2-85.1-51.7-135.1-51.7zM72 234l90 0c14.6 0 27.7 8.8 33.3 22.2s2.5 28.9-7.8 39.2c-.6 .6-1.3 1.2-1.9 1.9-5.1 5-10.2 10-10.2 17.7 0 7.5 4.7 12.1 9.5 17 17.7 17.7 42.1 28 67.1 28 34.1 0 64.5-15.7 84.3-40.5 7.2-9 16.9-13.5 27.7-13.5 8.1 0 16.2 2.5 22.9 7.9 15.5 12.4 18 35.1 5.6 50.6-32.9 41.1-83.7 67.5-140.5 67.5-44.1 0-86.4-17.5-117.6-48.7l-4.6-4.6c-7-7-18.4-7-25.5 0l-6.8 6.8c-10.3 10.3-25.8 13.4-39.2 7.8S36 374.6 36 360l0-90c0-19.9 16.1-36 36-36zm145.9-9.4c10.2-5.5 21.8-8.6 34.1-8.6 6.7 0 13.3 1.2 19.5 3.4-1 4.8-1.5 9.7-1.5 14.7l0 36c0 9.3 1.8 18.6 5.5 27.5 2.7 6.6 6.3 12.6 10.7 17.9-10.2 5.5-21.8 8.6-34.1 8.6-6.7 0-13.3-1.2-19.5-3.4 1-4.8 1.5-9.7 1.5-14.7l0-36c0-9.3-1.8-18.6-5.5-27.5-2.7-6.6-6.3-12.6-10.7-17.9zm90.9 23.2c-5.6-13.5-2.5-28.9 7.8-39.2l6.8-6.8c7-7 7-18.4 0-25.5l-4.6-4.6c-17.7-17.7-41.7-27.6-66.7-27.6-34.1 0-64.5 15.7-84.3 40.5-7 8.8-17.3 13.4-27.8 13.5-7.8-.1-16.2-2.6-22.8-7.9-15.5-12.4-18-35.1-5.6-50.6 32.9-41.1 83.7-67.5 140.5-67.5 44.3 0 86.7 17.8 118 49.1 4.9 4.9 9.5 9.5 17 9.5 7.7 0 12.7-5.1 17.7-10.2 .6-.6 1.2-1.3 1.9-1.9 10.3-10.3 25.8-13.4 39.2-7.8S468 129.4 468 144l0 90c0 19.9-16.1 36-36 36l-90 0c-14.6 0-27.7-8.8-33.3-22.2z"],
    "book-open": [504, 540, [128214, 128366], "f518", "M110 44.5c23.4-12.5 51.8-11.2 73.9 3.6L252 93.5 320.1 48.1c22.1-14.7 50.5-16.1 73.9-3.6 18 9.6 30.8 26.3 35.7 45.5 40.1 0 74.3 31 74.3 72l0 252c0 39.8-32.2 72-72 72L72 486c-39.8 0-72-32.2-72-72L0 162c0-41 34.2-72 74.3-72 5-19.2 17.8-35.9 35.7-45.5zM468 378l0-216c0-19.9-16.1-36-36-36l0 180c0 24.1-12 46.6-32.1 59.9L327.8 414 432 414c19.9 0 36-16.1 36-36zM340 78L270 124.8 270 409.2 380 336c10-6.7 16-17.9 16-30l0-198c0-13.3-7.3-25.5-19-31.7s-25.9-5.6-37 1.8zM108 108l0 198c0 12 6 23.3 16 30L234 409.2 234 124.8 164 78c-11-7.4-25.3-8.1-37-1.8S108 94.7 108 108zM72 126c-19.9 0-36 16.1-36 36l0 216c0 19.9 16.1 36 36 36l104.2 0-72.1-48.1C84 352.6 72 330.1 72 306l0-180z"],
    "box-archive": [504, 540, ["archive"], "f187", "M198 234c-9.9 0-18 8.1-18 18s8.1 18 18 18l108 0c9.9 0 18-8.1 18-18s-8.1-18-18-18l-108 0zM0 108C0 68.2 32.2 36 72 36l360 0c39.8 0 72 32.2 72 72 0 26.7-14.5 49.9-36 62.4L468 432c0 39.8-32.2 72-72 72l-288 0c-39.8 0-72-32.2-72-72l0-261.6C14.5 157.9 0 134.7 0 108zm468 0c0-19.9-16.1-36-36-36L72 72c-19.9 0-36 16.1-36 36s16.1 36 36 36l360 0c19.9 0 36-16.1 36-36zM72 396c0 19.9 16.1 36 36 36l288 0c19.9 0 36-16.1 36-36l0-216-360 0 0 216z"],
    "cake-candles": [432, 540, [127874, "birthday-cake", "cake"], "f1fd", "M68.5 43.8C54.3 57.5 36.1 79.9 36 107.8L36 144c0 13.1 3.5 25.4 9.6 36-6.1 10.6-9.6 22.9-9.6 36l0 9.6C14.5 238.1 0 261.3 0 288L0 432c0 39.8 32.2 72 72 72l288 0c39.8 0 72-32.2 72-72l0-144c0-26.7-14.5-49.9-36-62.4l0-9.6c0-13.1-3.5-25.4-9.6-36 6.1-10.6 9.6-22.9 9.6-36l0-36c0-28-18.2-50.5-32.5-64.2-7.6-7.2-15-13-20.6-17-3.2-2.2-6.4-4.4-9.8-6.4-5.6-3.3-12.5-3.3-18.1 0-3.3 2-6.6 4.2-9.8 6.4-5.6 3.9-13.1 9.7-20.6 17-4.7 4.5-9.8 9.9-14.5 16.2-4.8-6.3-9.9-11.7-14.5-16.2-7.6-7.2-15-13-20.6-17-3.2-2.2-6.4-4.4-9.8-6.4-5.6-3.3-12.5-3.3-18.1 0-3.3 2-6.6 4.2-9.8 6.4-5.6 3.9-13.1 9.7-20.6 17-4.7 4.5-9.8 9.9-14.5 16.2-4.8-6.3-9.9-11.7-14.5-16.2-7.6-7.2-15-13-20.6-17-3.2-2.2-6.4-4.4-9.8-6.4-5.6-3.3-12.5-3.3-18.1 0-3.4 2-6.6 4.2-9.8 6.4-5.6 3.9-13.1 9.7-20.6 17zM396 309l-58.5 10.6c-14.9 2.7-30.2 2.7-45.1 0L245 311c-19.2-3.5-38.8-3.5-58 0l-47.5 8.6c-14.9 2.7-30.2 2.7-45.1 0L36 309 36 288c0-15.6 10-29 24-34 7.2-2.5 12-9.3 12-17L72 216c0-19.7 16.2-36 36-36 19.9 0 36 16.1 36 36l0 18c0 9.9 8.1 18 18 18s18-8.1 18-18l0-18c0-19.9 16.1-36 36-36s36 16.1 36 36l0 18c0 9.9 8.1 18 18 18s18-8.1 18-18l0-18c0-19.9 16.1-36 36-36 19.7 0 36 16.3 36 36l0 21.1c0 7.6 4.8 14.4 12 17 14 5 24 18.3 24 34l0 21zM36 345.6L88 355c19.2 3.5 38.8 3.5 58 0l47.5-8.6c14.9-2.7 30.2-2.7 45.1 0L286 355c19.2 3.5 38.8 3.5 58 0l52-9.5 0 50.2c-.1 19.8-16.2 36.2-36 36.2L72 432c-19.9 0-36-16.1-36-36l0-50.4zM324 144c-19.9 0-36-16.1-36-36 0-12.5 8.8-26 21.5-38.2 5.1-4.9 10.3-9 14.5-12.1 4.2 3.1 9.4 7.2 14.5 12.1 12.6 12.1 21.4 25.7 21.5 38.2-.1 19.8-16.2 36-36 36zM230.5 69.8c12.7 12.2 21.5 25.6 21.5 38.2 0 19.9-16.1 36-36 36s-36-16.1-36-36c0-12.5 8.8-26 21.5-38.2 5.1-4.9 10.3-9 14.5-12.1 4.2 3.1 9.4 7.2 14.5 12.1zM144 108c0 19.9-16.1 36-36 36s-36-16.1-36-36c0-12.5 8.8-26 21.5-38.2 5.1-4.9 10.3-9 14.5-12.1 4.2 3.1 9.4 7.2 14.5 12.1 12.7 12.2 21.5 25.6 21.5 38.2z"],
    "signal-bars-good": [468, 540, ["signal-alt-3"], "f693", "M360 432c0 39.8-32.2 72-72 72-21.5 0-40.8-9.4-54-24.4-13.2 14.9-32.5 24.4-54 24.4s-40.8-9.4-54-24.4c-13.2 14.9-32.5 24.4-54 24.4-39.8 0-72-32.2-72-72L0 324c0-39.8 32.2-72 72-72 13.1 0 25.4 3.5 36 9.6l0-9.6c0-39.8 32.2-72 72-72 13.1 0 25.4 3.5 36 9.6l0-9.6c0-39.8 32.2-72 72-72s72 32.2 72 72l0 252zM36 396c0 19.9 16.1 36 36 36s36-16.1 36-36l0-72c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 72zM144 252l0 144c0 19.9 16.1 36 36 36s36-16.1 36-36l0-144c0-19.9-16.1-36-36-36s-36 16.1-36 36zM252 396c0 19.9 16.1 36 36 36s36-16.1 36-36l0-216c0-19.9-16.1-36-36-36s-36 16.1-36 36l0 216z"],
    "circle-info": [504, 540, ["info-circle"], "f05a", "M162 216c0-9.9 8.1-18 18-18l36 0c29.8 0 54 24.2 54 54l0 90 54 0c9.9 0 18 8.1 18 18s-8.1 18-18 18l-144 0c-9.9 0-18-8.1-18-18s8.1-18 18-18l54 0 0-90c0-9.9-8.1-18-18-18l-36 0c-9.9 0-18-8.1-18-18zm90-54a27 27 0 1 0 0-54 27 27 0 1 0 0 54zM0 252C0 112.8 112.8 0 252 0S504 112.8 504 252l0 36c0 139.2-112.8 252-252 252S0 427.2 0 288l0-36zm36 0a216 216 0 1 0 432 0 216 216 0 1 0 -432 0z"],
    "layer-group": [504, 540, [], "f5fd", "M0 162c0-27.3 15.4-52.2 39.8-64.4l180-90c20.3-10.1 44.1-10.1 64.4 0l180 90C488.6 109.8 504 134.7 504 162l0 36c0 27.3-15.4 52.2-39.8 64.4l-15.2 7.6 15.2 7.6c24.4 12.2 39.8 37.1 39.8 64.4 0 12 0 24 0 36 0 27.3-15.4 52.2-39.8 64.4l-180 90c-20.3 10.1-44.1 10.1-64.4 0l-180-90C15.4 430.2 0 405.3 0 378l0-36c0-27.3 15.4-52.2 39.8-64.4L55 270 39.8 262.4C15.4 250.2 0 225.3 0 198l0-36zM268.1 39.8c-10.1-5.1-22.1-5.1-32.2 0l-180 90C43.7 135.9 36 148.4 36 162s7.7 26.1 19.9 32.2l180 90c10.1 5.1 22.1 5.1 32.2 0l180-90c12.2-6.1 19.9-18.6 19.9-32.2s-7.7-26.1-19.9-32.2l-180-90zM372.7 272.1l-88.5 44.3c-20.3 10.1-44.1 10.1-64.4 0l-88.5-44.3-75.4 37.7C43.7 315.9 36 328.4 36 342s7.7 26.1 19.9 32.2l180 90c10.1 5.1 22.1 5.1 32.2 0l180-90c12.1-6 19.9-18.7 19.9-32.2 0-13.8-7.7-26.1-19.9-32.2l-75.4-37.7z"],
    "shield": [432, 540, [128737, "shield-blank"], "f132", "M39.8 97.6C15.4 109.8 0 134.7 0 162l0 36c0 216.8 140.4 298.4 176.9 315.4 14 6.5 27.6 8.6 39.1 8.6s25.1-2 39.1-8.6C291.6 496.4 432 414.8 432 198l0-36c0-27.3-15.4-52.2-39.8-64.4l-144-72c-20.3-10.1-44.1-10.1-64.4 0l-144 72zM234 58.8l142.1 71c12.2 6.1 19.9 18.6 19.9 32.2 0 105.3-50.2 247.9-162 285.1l0-388.4zM198 447.1C86.2 409.9 36 267.3 36 162 36 148.4 43.7 135.9 55.9 129.8l142.1-71 0 388.4z"],
    "cart-shopping": [540, 540, [128722, "shopping-cart"], "f07a", "M0 126C0 86.2 32.2 54 72 54l378 0c21.6 0 42 9.7 55.7 26.4 10.7 13.1 16.4 29.3 16.3 45.9l0 35.7c0 4.7-.5 9.4-1.4 14.1l-36 180c-2.9 14.4-9.9 27-19.7 36.8 2 6.7 3.1 13.7 3.1 21.1l0 36c0 39.8-32.2 72-72 72s-72-32.2-72-72l0-36-54 0 0 36c0 39.8-32.2 72-72 72s-72-32.2-72-72l0-36c0-7.3 1.1-14.4 3.1-21.1-9.8-9.8-16.9-22.4-19.7-36.8L85 234 72 234c-39.8 0-72-32.2-72-72l0-36zm36 0c0 19.9 16.1 36 36 36l27.7 0c8.6 0 16 6.1 17.7 14.5l27.3 136.6c3.4 16.8 18.1 28.9 35.3 28.9l234 0c17.2 0 31.9-12.1 35.3-28.9l36-180C489.6 111.5 472.2 90 450 90L72 90c-19.9 0-36 16.1-36 36zM198 378a36 36 0 1 0 0 72 36 36 0 1 0 0-72zm198 0a36 36 0 1 0 0 72 36 36 0 1 0 0-72z"]
  };

  bunker(function () {
    defineIcons('faslr', icons);
  });

}());
