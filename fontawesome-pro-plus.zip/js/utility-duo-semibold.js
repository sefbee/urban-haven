/*!
 * Font Awesome Pro 7.3.0 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license (Commercial License)
 * Copyright 2026 Fonticons, Inc.
 */
(function () {
  'use strict';

  var _WINDOW = {};
  var _DOCUMENT = {};
  try {
    if (typeof window !== 'undefined') _WINDOW = window;
    if (typeof document !== 'undefined') _DOCUMENT = document;
  } catch (e) {} // eslint-disable-line no-empty

  var _ref = _WINDOW.navigator || {},
    _ref$userAgent = _ref.userAgent,
    userAgent = _ref$userAgent === void 0 ? '' : _ref$userAgent;
  var WINDOW = _WINDOW;
  var DOCUMENT = _DOCUMENT;
  var IS_BROWSER = !!WINDOW.document;
  var IS_DOM = !!DOCUMENT.documentElement && !!DOCUMENT.head && typeof DOCUMENT.addEventListener === 'function' && typeof DOCUMENT.createElement === 'function';
  var IS_IE = ~userAgent.indexOf('MSIE') || ~userAgent.indexOf('Trident/');

  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _arrayWithoutHoles(r) {
    if (Array.isArray(r)) return _arrayLikeToArray(r);
  }
  function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[r] = t, e;
  }
  function _iterableToArray(r) {
    if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
  }
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function (r) {
        return Object.getOwnPropertyDescriptor(e, r).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
        _defineProperty(e, r, t[r]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
        Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
      });
    }
    return e;
  }
  function _toConsumableArray(r) {
    return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }

  var _cl;
  var rl = {
      classic: {
        fa: "solid",
        fas: "solid",
        "fa-solid": "solid",
        far: "regular",
        "fa-regular": "regular",
        fal: "light",
        "fa-light": "light",
        fat: "thin",
        "fa-thin": "thin",
        fab: "brands",
        "fa-brands": "brands"
      },
      duotone: {
        fa: "solid",
        fad: "solid",
        "fa-solid": "solid",
        "fa-duotone": "solid",
        fadr: "regular",
        "fa-regular": "regular",
        fadl: "light",
        "fa-light": "light",
        fadt: "thin",
        "fa-thin": "thin"
      },
      sharp: {
        fa: "solid",
        fass: "solid",
        "fa-solid": "solid",
        fasr: "regular",
        "fa-regular": "regular",
        fasl: "light",
        "fa-light": "light",
        fast: "thin",
        "fa-thin": "thin"
      },
      "sharp-duotone": {
        fa: "solid",
        fasds: "solid",
        "fa-solid": "solid",
        fasdr: "regular",
        "fa-regular": "regular",
        fasdl: "light",
        "fa-light": "light",
        fasdt: "thin",
        "fa-thin": "thin"
      },
      slab: {
        "fa-regular": "regular",
        faslr: "regular"
      },
      "slab-press": {
        "fa-regular": "regular",
        faslpr: "regular"
      },
      "slab-duo": {
        "fa-regular": "regular",
        fasldr: "regular"
      },
      "slab-press-duo": {
        "fa-regular": "regular",
        faslpdr: "regular"
      },
      thumbprint: {
        "fa-light": "light",
        fatl: "light"
      },
      vellum: {
        "fa-solid": "solid",
        favs: "solid"
      },
      pixel: {
        "fa-regular": "regular",
        fapr: "regular"
      },
      mosaic: {
        "fa-solid": "solid",
        fams: "solid"
      },
      whiteboard: {
        "fa-semibold": "semibold",
        fawsb: "semibold"
      },
      notdog: {
        "fa-solid": "solid",
        fans: "solid"
      },
      "notdog-duo": {
        "fa-solid": "solid",
        fands: "solid"
      },
      etch: {
        "fa-solid": "solid",
        faes: "solid"
      },
      graphite: {
        "fa-thin": "thin",
        fagt: "thin"
      },
      jelly: {
        "fa-regular": "regular",
        fajr: "regular"
      },
      "jelly-fill": {
        "fa-regular": "regular",
        fajfr: "regular"
      },
      "jelly-duo": {
        "fa-regular": "regular",
        fajdr: "regular"
      },
      chisel: {
        "fa-regular": "regular",
        facr: "regular"
      },
      utility: {
        "fa-semibold": "semibold",
        fausb: "semibold"
      },
      "utility-duo": {
        "fa-semibold": "semibold",
        faudsb: "semibold"
      },
      "utility-fill": {
        "fa-semibold": "semibold",
        faufsb: "semibold"
      }
    };
  var u = "classic",
    l = "duotone",
    h = "sharp",
    t = "sharp-duotone",
    g = "chisel",
    n = "etch",
    m = "graphite",
    p = "jelly",
    s = "jelly-duo",
    y = "jelly-fill",
    w = "mosaic",
    x = "notdog",
    e = "notdog-duo",
    b = "pixel",
    c = "slab",
    o = "slab-duo",
    I = "slab-press",
    a = "slab-press-duo",
    r = "thumbprint",
    v = "utility",
    i = "utility-duo",
    F = "utility-fill",
    d = "vellum",
    S = "whiteboard",
    A = "Classic",
    P = "Duotone",
    j = "Sharp",
    B = "Sharp Duotone",
    N = "Chisel",
    D = "Etch",
    k = "Graphite",
    T = "Jelly",
    C = "Jelly Duo",
    W = "Jelly Fill",
    R = "Mosaic",
    K = "Notdog",
    L = "Notdog Duo",
    U = "Pixel",
    J = "Slab",
    _ = "Slab Duo",
    M = "Slab Press",
    E = "Slab Press Duo",
    G = "Thumbprint",
    V = "Utility",
    z = "Utility Duo",
    O = "Utility Fill",
    Y = "Vellum",
    q = "Whiteboard",
    cl = (_cl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, u, A), l, P), h, j), t, B), g, N), n, D), m, k), p, T), s, C), y, W), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, w, R), x, K), e, L), b, U), c, J), o, _), I, M), a, E), r, G), v, V), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, i, z), F, O), d, Y), S, q));
  var Al = {
      classic: {
        900: "fas",
        400: "far",
        normal: "far",
        300: "fal",
        100: "fat"
      },
      duotone: {
        900: "fad",
        400: "fadr",
        300: "fadl",
        100: "fadt"
      },
      sharp: {
        900: "fass",
        400: "fasr",
        300: "fasl",
        100: "fast"
      },
      "sharp-duotone": {
        900: "fasds",
        400: "fasdr",
        300: "fasdl",
        100: "fasdt"
      },
      slab: {
        400: "faslr"
      },
      "slab-press": {
        400: "faslpr"
      },
      "slab-duo": {
        400: "fasldr"
      },
      "slab-press-duo": {
        400: "faslpdr"
      },
      vellum: {
        900: "favs"
      },
      mosaic: {
        900: "fams"
      },
      pixel: {
        400: "fapr"
      },
      whiteboard: {
        600: "fawsb"
      },
      thumbprint: {
        300: "fatl"
      },
      notdog: {
        900: "fans"
      },
      "notdog-duo": {
        900: "fands"
      },
      etch: {
        900: "faes"
      },
      graphite: {
        100: "fagt"
      },
      chisel: {
        400: "facr"
      },
      jelly: {
        400: "fajr"
      },
      "jelly-fill": {
        400: "fajfr"
      },
      "jelly-duo": {
        400: "fajdr"
      },
      utility: {
        600: "fausb"
      },
      "utility-duo": {
        600: "faudsb"
      },
      "utility-fill": {
        600: "faufsb"
      }
    };
  var $l = {
      chisel: {
        regular: "facr"
      },
      classic: {
        brands: "fab",
        light: "fal",
        regular: "far",
        solid: "fas",
        thin: "fat"
      },
      duotone: {
        light: "fadl",
        regular: "fadr",
        solid: "fad",
        thin: "fadt"
      },
      etch: {
        solid: "faes"
      },
      graphite: {
        thin: "fagt"
      },
      jelly: {
        regular: "fajr"
      },
      "jelly-duo": {
        regular: "fajdr"
      },
      "jelly-fill": {
        regular: "fajfr"
      },
      mosaic: {
        solid: "fams"
      },
      notdog: {
        solid: "fans"
      },
      "notdog-duo": {
        solid: "fands"
      },
      pixel: {
        regular: "fapr"
      },
      sharp: {
        light: "fasl",
        regular: "fasr",
        solid: "fass",
        thin: "fast"
      },
      "sharp-duotone": {
        light: "fasdl",
        regular: "fasdr",
        solid: "fasds",
        thin: "fasdt"
      },
      slab: {
        regular: "faslr"
      },
      "slab-duo": {
        regular: "fasldr"
      },
      "slab-press": {
        regular: "faslpr"
      },
      "slab-press-duo": {
        regular: "faslpdr"
      },
      thumbprint: {
        light: "fatl"
      },
      utility: {
        semibold: "fausb"
      },
      "utility-duo": {
        semibold: "faudsb"
      },
      "utility-fill": {
        semibold: "faufsb"
      },
      vellum: {
        solid: "favs"
      },
      whiteboard: {
        semibold: "fawsb"
      }
    };
  var rt = {
      kit: {
        fak: "kit",
        "fa-kit": "kit"
      },
      "kit-duotone": {
        fakd: "kit-duotone",
        "fa-kit-duotone": "kit-duotone"
      }
    },
    it = ["kit"];
  var H = "kit",
    f = "kit-duotone",
    Q = "Kit",
    X = "Kit Duotone",
    ht = _defineProperty(_defineProperty({}, H, Q), f, X);
  var mt = {
    kit: {
      "fa-kit": "fak"
    },
    "kit-duotone": {
      "fa-kit-duotone": "fakd"
    }
  };
  var It = {
      kit: {
        fak: "fa-kit"
      },
      "kit-duotone": {
        fakd: "fa-kit-duotone"
      }
    };
  var St = {
      kit: {
        kit: "fak"
      },
      "kit-duotone": {
        "kit-duotone": "fakd"
      }
    };

  var _jl;
  var l$1 = {
      GROUP: "duotone-group",
      SWAP_OPACITY: "swap-opacity",
      PRIMARY: "primary",
      SECONDARY: "secondary"
    };
  var g$1 = "classic",
    a$1 = "duotone",
    m$1 = "sharp",
    t$1 = "sharp-duotone",
    p$1 = "chisel",
    y$1 = "etch",
    b$1 = "graphite",
    w$1 = "jelly",
    e$1 = "jelly-duo",
    x$1 = "jelly-fill",
    c$1 = "mosaic",
    I$1 = "notdog",
    o$1 = "notdog-duo",
    v$1 = "pixel",
    F$1 = "slab",
    r$1 = "slab-duo",
    S$1 = "slab-press",
    i$1 = "slab-press-duo",
    d$1 = "thumbprint",
    A$1 = "utility",
    f$1 = "utility-duo",
    P$1 = "utility-fill",
    u$1 = "vellum",
    j$1 = "whiteboard",
    B$1 = "Classic",
    N$1 = "Duotone",
    D$1 = "Sharp",
    k$1 = "Sharp Duotone",
    C$1 = "Chisel",
    T$1 = "Etch",
    L$1 = "Graphite",
    W$1 = "Jelly",
    R$1 = "Jelly Duo",
    K$1 = "Jelly Fill",
    U$1 = "Mosaic",
    J$1 = "Notdog",
    _$1 = "Notdog Duo",
    M$1 = "Pixel",
    E$1 = "Slab",
    G$1 = "Slab Duo",
    O$1 = "Slab Press",
    V$1 = "Slab Press Duo",
    z$1 = "Thumbprint",
    Y$1 = "Utility",
    $$1 = "Utility Duo",
    q$1 = "Utility Fill",
    H$1 = "Vellum",
    Q$1 = "Whiteboard",
    jl$1 = (_jl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, g$1, B$1), a$1, N$1), m$1, D$1), t$1, k$1), p$1, C$1), y$1, T$1), b$1, L$1), w$1, W$1), e$1, R$1), x$1, K$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, c$1, U$1), I$1, J$1), o$1, _$1), v$1, M$1), F$1, E$1), r$1, G$1), S$1, O$1), i$1, V$1), d$1, z$1), A$1, Y$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, f$1, $$1), P$1, q$1), u$1, H$1), j$1, Q$1));
  var X$1 = "kit",
    h$1 = "kit-duotone",
    Z$1 = "Kit",
    ll$1 = "Kit Duotone",
    ws = _defineProperty(_defineProperty({}, X$1, Z$1), h$1, ll$1);
  var ra = {
      classic: {
        "fa-brands": "fab",
        "fa-duotone": "fad",
        "fa-light": "fal",
        "fa-regular": "far",
        "fa-solid": "fas",
        "fa-thin": "fat"
      },
      duotone: {
        "fa-regular": "fadr",
        "fa-light": "fadl",
        "fa-thin": "fadt"
      },
      sharp: {
        "fa-solid": "fass",
        "fa-regular": "fasr",
        "fa-light": "fasl",
        "fa-thin": "fast"
      },
      "sharp-duotone": {
        "fa-solid": "fasds",
        "fa-regular": "fasdr",
        "fa-light": "fasdl",
        "fa-thin": "fasdt"
      },
      slab: {
        "fa-regular": "faslr"
      },
      "slab-press": {
        "fa-regular": "faslpr"
      },
      "slab-duo": {
        "fa-regular": "fasldr"
      },
      "slab-press-duo": {
        "fa-regular": "faslpdr"
      },
      pixel: {
        "fa-regular": "fapr"
      },
      mosaic: {
        "fa-solid": "fams"
      },
      vellum: {
        "fa-solid": "favs"
      },
      whiteboard: {
        "fa-semibold": "fawsb"
      },
      thumbprint: {
        "fa-light": "fatl"
      },
      notdog: {
        "fa-solid": "fans"
      },
      "notdog-duo": {
        "fa-solid": "fands"
      },
      etch: {
        "fa-solid": "faes"
      },
      graphite: {
        "fa-thin": "fagt"
      },
      jelly: {
        "fa-regular": "fajr"
      },
      "jelly-fill": {
        "fa-regular": "fajfr"
      },
      "jelly-duo": {
        "fa-regular": "fajdr"
      },
      chisel: {
        "fa-regular": "facr"
      },
      utility: {
        "fa-semibold": "fausb"
      },
      "utility-duo": {
        "fa-semibold": "faudsb"
      },
      "utility-fill": {
        "fa-semibold": "faufsb"
      }
    },
    al$1 = {
      classic: ["fas", "far", "fal", "fat", "fad"],
      duotone: ["fadr", "fadl", "fadt"],
      sharp: ["fass", "fasr", "fasl", "fast"],
      "sharp-duotone": ["fasds", "fasdr", "fasdl", "fasdt"],
      slab: ["faslr"],
      "slab-press": ["faslpr"],
      "slab-duo": ["fasldr"],
      "slab-press-duo": ["faslpdr"],
      pixel: ["fapr"],
      mosaic: ["fams"],
      vellum: ["favs"],
      whiteboard: ["fawsb"],
      thumbprint: ["fatl"],
      notdog: ["fans"],
      "notdog-duo": ["fands"],
      etch: ["faes"],
      graphite: ["fagt"],
      jelly: ["fajr"],
      "jelly-fill": ["fajfr"],
      "jelly-duo": ["fajdr"],
      chisel: ["facr"],
      utility: ["fausb"],
      "utility-duo": ["faudsb"],
      "utility-fill": ["faufsb"]
    },
    da = {
      classic: {
        fab: "fa-brands",
        fad: "fa-duotone",
        fal: "fa-light",
        far: "fa-regular",
        fas: "fa-solid",
        fat: "fa-thin"
      },
      duotone: {
        fadr: "fa-regular",
        fadl: "fa-light",
        fadt: "fa-thin"
      },
      sharp: {
        fass: "fa-solid",
        fasr: "fa-regular",
        fasl: "fa-light",
        fast: "fa-thin"
      },
      "sharp-duotone": {
        fasds: "fa-solid",
        fasdr: "fa-regular",
        fasdl: "fa-light",
        fasdt: "fa-thin"
      },
      slab: {
        faslr: "fa-regular"
      },
      "slab-press": {
        faslpr: "fa-regular"
      },
      "slab-duo": {
        fasldr: "fa-regular"
      },
      "slab-press-duo": {
        faslpdr: "fa-regular"
      },
      pixel: {
        fapr: "fa-regular"
      },
      mosaic: {
        fams: "fa-solid"
      },
      vellum: {
        favs: "fa-solid"
      },
      whiteboard: {
        fawsb: "fa-semibold"
      },
      thumbprint: {
        fatl: "fa-light"
      },
      notdog: {
        fans: "fa-solid"
      },
      "notdog-duo": {
        fands: "fa-solid"
      },
      etch: {
        faes: "fa-solid"
      },
      graphite: {
        fagt: "fa-thin"
      },
      jelly: {
        fajr: "fa-regular"
      },
      "jelly-fill": {
        fajfr: "fa-regular"
      },
      "jelly-duo": {
        fajdr: "fa-regular"
      },
      chisel: {
        facr: "fa-regular"
      },
      utility: {
        fausb: "fa-semibold"
      },
      "utility-duo": {
        faudsb: "fa-semibold"
      },
      "utility-fill": {
        faufsb: "fa-semibold"
      }
    },
    el$1 = ["solid", "regular", "light", "thin", "duotone", "brands", "semibold"],
    sl$1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    ol$1 = sl$1.concat([11, 12, 13, 14, 15, 16, 17, 18, 19, 20]),
    rl$1 = ["aw", "fw", "pull-left", "pull-right"],
    ga = [].concat(_toConsumableArray(Object.keys(al$1)), el$1, rl$1, ["2xs", "xs", "sm", "lg", "xl", "2xl", "beat", "beat-fade", "border", "bounce", "buzz", "canvas-square", "canvas-roomy", "fade", "flip-360", "flip-both", "flip-horizontal", "flip-vertical", "flip", "float", "inverse", "jello", "layers", "layers-bottom-left", "layers-bottom-right", "layers-counter", "layers-text", "layers-top-left", "layers-top-right", "li", "pull-end", "pull-start", "pulse", "rotate-180", "rotate-270", "rotate-90", "rotate-by", "shake", "spin-pulse", "spin-reverse", "spin", "spin-snap", "spin-snap-4", "spin-snap-8", "stack-1x", "stack-2x", "stack", "swing", "ul", "wag", "width-auto", "width-fixed", l$1.GROUP, l$1.SWAP_OPACITY, l$1.PRIMARY, l$1.SECONDARY]).concat(sl$1.map(function (s) {
      return "".concat(s, "x");
    })).concat(ol$1.map(function (s) {
      return "w-".concat(s);
    }));

  var NAMESPACE_IDENTIFIER = '___FONT_AWESOME___';
  var PRODUCTION = function () {
    try {
      return "production" === 'production';
    } catch (e$$1) {
      return false;
    }
  }();
  function familyProxy(obj) {
    // Defaults to the classic family if family is not available
    return new Proxy(obj, {
      get: function get(target, prop) {
        return prop in target ? target[prop] : target[u];
      }
    });
  }
  var _PREFIX_TO_STYLE = _objectSpread2({}, rl);

  // We changed FACSSClassesToStyleId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _PREFIX_TO_STYLE below, so we are manually adding
  // {'fa-duotone': 'duotone'}
  _PREFIX_TO_STYLE[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    'fa-duotone': 'duotone'
  }), rl[u]), rt['kit']), rt['kit-duotone']);
  var PREFIX_TO_STYLE = familyProxy(_PREFIX_TO_STYLE);
  var _STYLE_TO_PREFIX = _objectSpread2({}, $l);

  // We changed FAStyleIdToShortPrefixId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _STYLE_TO_PREFIX below, so we are manually adding {duotone: 'fad'}
  _STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    duotone: 'fad'
  }), _STYLE_TO_PREFIX[u]), St['kit']), St['kit-duotone']);
  var STYLE_TO_PREFIX = familyProxy(_STYLE_TO_PREFIX);
  var _PREFIX_TO_LONG_STYLE = _objectSpread2({}, da);
  _PREFIX_TO_LONG_STYLE[u] = _objectSpread2(_objectSpread2({}, _PREFIX_TO_LONG_STYLE[u]), It['kit']);
  var PREFIX_TO_LONG_STYLE = familyProxy(_PREFIX_TO_LONG_STYLE);
  var _LONG_STYLE_TO_PREFIX = _objectSpread2({}, ra);
  _LONG_STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2({}, _LONG_STYLE_TO_PREFIX[u]), mt['kit']);
  var LONG_STYLE_TO_PREFIX = familyProxy(_LONG_STYLE_TO_PREFIX);
  var _FONT_WEIGHT_TO_PREFIX = _objectSpread2({}, Al);
  var FONT_WEIGHT_TO_PREFIX = familyProxy(_FONT_WEIGHT_TO_PREFIX);
  var RESERVED_CLASSES = [].concat(_toConsumableArray(it), _toConsumableArray(ga));

  function bunker(fn) {
    try {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      fn.apply(void 0, args);
    } catch (e) {
      if (!PRODUCTION) {
        throw e;
      }
    }
  }

  var w$2 = WINDOW || {};
  if (!w$2[NAMESPACE_IDENTIFIER]) w$2[NAMESPACE_IDENTIFIER] = {};
  if (!w$2[NAMESPACE_IDENTIFIER].styles) w$2[NAMESPACE_IDENTIFIER].styles = {};
  if (!w$2[NAMESPACE_IDENTIFIER].hooks) w$2[NAMESPACE_IDENTIFIER].hooks = {};
  if (!w$2[NAMESPACE_IDENTIFIER].shims) w$2[NAMESPACE_IDENTIFIER].shims = [];
  var namespace = w$2[NAMESPACE_IDENTIFIER];

  function normalizeIcons(icons) {
    return Object.keys(icons).reduce(function (acc, iconName) {
      var icon = icons[iconName];
      var expanded = !!icon.icon;
      if (expanded) {
        acc[icon.iconName] = icon.icon;
      } else {
        acc[iconName] = icon;
      }
      return acc;
    }, {});
  }
  function defineIcons(prefix, icons) {
    var params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var _params$skipHooks = params.skipHooks,
      skipHooks = _params$skipHooks === void 0 ? false : _params$skipHooks;
    var normalized = normalizeIcons(icons);
    if (typeof namespace.hooks.addPack === 'function' && !skipHooks) {
      namespace.hooks.addPack(prefix, normalizeIcons(icons));
    } else {
      namespace.styles[prefix] = _objectSpread2(_objectSpread2({}, namespace.styles[prefix] || {}), normalized);
    }

    /**
     * Font Awesome 4 used the prefix of `fa` for all icons. With the introduction
     * of new styles we needed to differentiate between them. Prefix `fa` is now an alias
     * for `fas` so we'll ease the upgrade process for our users by automatically defining
     * this as well.
     */
    if (prefix === 'fas') {
      defineIcons('fa', icons);
    }
  }

  var icons = {
    "dollar-sign": [384, 512, [128178, 61781, "dollar", "usd"], "24", ["", "M160 480l0 48 64 0 0-48 39.7 0c66.5 0 120.3-53.9 120.3-120.3 0-56.9-39.9-106-95.5-117.7l-64.5-13.6 0-132.4 128 0 0-64-128 0 0-48-64 0 0 48-23.7 0C69.9 32 16 85.9 16 152.3 16 209.2 55.9 258.4 111.5 270.1l48.5 10.2 0 135.7-128 0 0 64 128 0zm64-64l0-122.2 51.3 10.8c26.1 5.5 44.7 28.5 44.7 55.1 0 31.1-25.2 56.3-56.3 56.3L224 416zM160 214.9l-35.3-7.4C98.7 202 80 179 80 152.3 80 121.2 105.2 96 136.3 96l23.7 0 0 118.9z"]],
    "calendar-check": [448, 512, [], "f274", ["M64 96l0 320 320 0 0-320-320 0zm40.4 176L144 232.4c11.8 11.8 27.8 27.8 48 48l92.2-92.2 19.8-19.8 39.6 39.6-19.8 19.8-112 112c-10.9 10.9-28.7 10.9-39.6 0-36.7-36.7-59.3-59.3-67.8-67.8z", "M160 32l128 0 0-64 64 0 0 64 32 0c35.3 0 64 28.7 64 64l0 320-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-320 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 416 0 96C0 60.7 28.7 32 64 32l32 0 0-64 64 0 0 64zM64 416l320 0 0-320-320 0 0 320zM343.6 208l-19.8 19.8-112 112c-10.9 10.9-28.7 10.9-39.6 0-36.7-36.7-59.3-59.3-67.8-67.8L144 232.4c11.8 11.8 27.8 27.8 48 48l92.2-92.2 19.8-19.8 39.6 39.6z"]],
    "question": [320, 512, [10067, 10068, 61736], "3f", ["", "M64 160c0-53 43-96 96-96s96 43 96 96c0 48.9-36.6 89.4-84 95.3-22.3 2.8-44 21.4-44 48.7l0 48 64 0 0-35.2C265 302 320 237.4 320 160 320 71.6 248.4 0 160 0S0 71.6 0 160l64 0zm96 328c22.1 0 40-17.9 40-40s-17.9-40-40-40-40 17.9-40 40 17.9 40 40 40z"]],
    "minus": [448, 512, [8211, 8722, 10134, "subtract"], "f068", ["", "M445.6 288l-443.1 0 0-64 443.1 0 0 64z"]],
    "microphone-slash": [640, 512, [], "f131", ["M289 89c2-8.9 7.7-16.5 15.5-20.9 .8-.4 1.6-.8 2.4-1.2 0 0 0 0 .1 0 .2-.1 .3-.2 .5-.2 3.9-1.7 8.2-2.7 12.8-2.7 4.4 0 8.6 .9 12.5 2.5 1.9 .8 3.7 1.8 5.4 3 8.5 5.8 14.1 15.5 14.1 26.5 0 18.7 0 37.5 0 56.2L289 89z", "M621.5 512L576.2 557.2 19 0 64.3-45.3 621.5 512zM160.4 231.9c4 82 69.8 147.8 151.8 151.8l40 40 0 88.2-64 0 0-66.3C179.7 430.2 96.3 336.8 96.3 224l0-32 24.2 0 39.9 39.9zM544.2 224c0 35.1-8.1 68.3-22.4 97.8l-49.1-49.1c4.9-15.4 7.6-31.7 7.6-48.7l0-32 64 0 0 32zM320.3 0c53 0 96 43 96 96l0 120.2-64-64 0-56.2c0-17.7-14.3-32-32-32-15.3 0-28 10.7-31.2 25L241.3 41.3C258.7 16.4 287.5 0 320.3 0z"]],
    "cloud-slash": [640, 512, [], "e137", ["M96.3 320c0 53 43 96 96 96l152.2 0-185.9-185.9c-36.4 13.6-62.4 48.7-62.4 89.9zM298.2 98.2L541.7 341.7c1.6-7 2.6-14.2 2.6-21.7 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5c-5.9-56.3-53.5-100.2-111.4-100.2-7.6 0-14.9 .8-22.1 2.2z", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM158.6 230.1c-36.4 13.6-62.4 48.7-62.4 89.9 0 53 43 96 96 96l152.2 0 64 64-216.2 0c-88.4 0-160-71.6-160-160 0-58.6 31.5-109.8 78.6-137.7l47.8 47.8zM320.3 32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 25.7-6.1 49.9-16.8 71.4l-49.7-49.7c1.6-7 2.6-14.2 2.6-21.7 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5c-5.9-56.3-53.5-100.2-111.4-100.2-7.6 0-14.9 .8-22.1 2.2L247.6 47.6c22.1-10 46.7-15.6 72.6-15.6z"]],
    "car": [512, 512, [128664, "automobile"], "f1b9", ["M64 320l0 64 384 0 0-64c0-22.8-11.9-42.7-29.8-54.1l-.5 .2-.2-.6c-9.7-6-21.2-9.5-33.4-9.5l-256 0c-12.3 0-23.7 3.5-33.5 9.5l-.2 .6-.5-.2C75.9 277.3 64 297.2 64 320zm96 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm256 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z", "M314.8 32c55.1 0 104 35.3 121.4 87.5l35.9 107.7C496.7 250.5 512 283.5 512 320l0 192-64 0 0-64-384 0 0 64-64 0 0-192c0-36.5 15.3-69.5 39.8-92.8L75.8 119.5C93.2 67.3 142.1 32 197.2 32l117.6 0zM128 256c-12.3 0-23.7 3.5-33.5 9.5l-.2 .6-.5-.2C75.9 277.3 64 297.2 64 320l0 64 384 0 0-64c0-22.8-11.9-42.7-29.8-54.1l-.5 .2-.2-.6c-9.7-6-21.2-9.5-33.4-9.5l-256 0zm0 96a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm256 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64zM197.2 96c-27.5 0-52 17.6-60.7 43.8l-17.6 52.6c3-.2 6-.3 9.1-.3l256 0c3 0 6.1 .1 9.1 .3l-17.5-52.6C366.8 113.6 342.4 96 314.8 96L197.2 96z"]],
    "filter": [512, 512, [], "f0b0", ["M64 96l0 17.9c0 19.4 8.9 37.8 24 50l124 99.2 12 9.6 0 123.6 64 32 0-155.6 12-9.6 124-99.2c15.2-12.1 24-30.5 24-50L448 96 64 96z", "M448 32c35.3 0 64 28.7 64 64l0 17.9c0 38.9-17.7 75.6-48 99.9l-112 89.6 0 228.4-192-96 0-132.4-112-89.6C17.7 189.5 0 152.8 0 113.9L0 96C0 60.7 28.7 32 64 32l384 0zM64 113.9c0 19.4 8.9 37.8 24 50l124 99.2 12 9.6 0 123.6 64 32 0-155.6 12-9.6 124-99.2c15.2-12.1 24-30.5 24-50l0-17.9-384 0 0 17.9z"]],
    "envelope": [512, 512, [128386, 9993, 61443], "f0e0", ["M64 193.3l0 222.7 384 0 0-222.7-175.7 125.5-16.3 11.6-16.3-11.6-175.7-125.5z", "M64 96l0 28.4 192 137.1 192-137.1 0-28.4-384 0zm0 97.3l0 222.7 384 0 0-222.7-175.7 125.5-16.3 11.6-16.3-11.6-175.7-125.5zM0 96C0 60.7 28.7 32 64 32l384 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96z"]],
    "cloud-arrow-up": [576, 512, [62338, "cloud-upload", "cloud-upload-alt"], "f0ee", ["M64 320c0 53 43 96 96 96l32 0 0 64 68 0 0-192.4c-36.9 36.9-59.5 59.5-68 68l-39.6-39.6 19.8-19.8 96-96c10.9-10.9 28.7-10.9 39.6 0l96 96 19.8 19.8-39.6 39.6c-8.5-8.5-31.1-31.1-68-68l0 192.4 68 0 0-64 32 0c53 0 96-43 96-96 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5C393.5 139.9 345.9 96 288 96 230.1 96 182.5 139.9 176.6 196.2l-2.6 25.5-25.4 3C100.9 230.3 64 270.9 64 320z", "M288 32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 88.4-71.6 160-160 160l-32 0 0-64 32 0c53 0 96-43 96-96 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5C393.5 139.9 345.9 96 288 96 230.1 96 182.5 139.9 176.6 196.2l-2.6 25.5-25.4 3c-47.6 5.6-84.5 46.2-84.5 95.3 0 53 43 96 96 96l32 0 0 64-32 0C71.6 480 0 408.4 0 320 0 246.5 49.6 184.6 117.1 165.8 136 89 205.3 32 288 32zM268.2 200.2c10.9-10.9 28.7-10.9 39.6 0l96 96 19.8 19.8-39.6 39.6c-8.5-8.5-31.1-31.1-68-68l0 192.4-56 0 0-192.4c-36.9 36.9-59.5 59.5-68 68l-39.6-39.6 19.8-19.8 96-96z"]],
    "at": [512, 512, [61946], "40", ["M64 256c0 106 86 192 192 192l32 0 0 62c99.4-12.4 181.1-81.8 211.4-174.4-16.5 28.9-47.7 48.4-83.4 48.4-29.3 0-55.6-13.2-73.2-33.9-22.8 21-53.3 33.9-86.8 33.9-70.7 0-128-57.3-128-128s57.3-128 128-128 128 57.3 128 128l0 32c0 17.7 14.3 32 32 32s32-14.3 32-32l0-32c0-106-86-192-192-192S64 150 64 256z", "M256 64C150 64 64 150 64 256s86 192 192 192l32 0 0 64-32 0C114.6 512 0 397.4 0 256S114.6 0 256 0 512 114.6 512 256l0 32c0 53-43 96-96 96-29.3 0-55.6-13.2-73.2-33.9-22.8 21-53.3 33.9-86.8 33.9-70.7 0-128-57.3-128-128s57.3-128 128-128 128 57.3 128 128l0 32c0 17.7 14.3 32 32 32s32-14.3 32-32l0-32c0-106-86-192-192-192zm64 192a64 64 0 1 0 -128 0 64 64 0 1 0 128 0z"]],
    "truck": [640, 512, [128666, 9951], "f0d1", ["M64 96l0 288 10.8 0c18-37.8 56.5-64 101.2-64s83.2 26.2 101.2 64l85.6 0c5.4-11.3 12.6-21.5 21.2-30.3L384 96 64 96z", "M384 32c35.3 0 64 28.7 64 64l0 32 32 0c88.4 0 160 71.6 160 160l0 160-65.2 0c-7.8 54.3-54.4 96-110.8 96s-103.1-41.7-110.8-96l-66.3 0c-7.8 54.3-54.4 96-110.8 96S72.9 502.3 65.2 448L64 448c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l320 0zM176 384a48 48 0 1 0 0 96 48 48 0 1 0 0-96zm288 0a48 48 0 1 0 0 96 48 48 0 1 0 0-96zM64 384l10.8 0c18-37.8 56.5-64 101.2-64s83.2 26.2 101.2 64l85.6 0c5.4-11.3 12.6-21.5 21.2-30.3L384 96 64 96 64 384zm384-62.9c5.2-.7 10.6-1.1 16-1.1 44.7 0 83.2 26.2 101.2 64l10.8 0 0-96c0-53-43-96-96-96l-32 0 0 129.1z"]],
    "user-check": [640, 512, [], "f4fc", ["M64 480l0 32 320 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96zm96-352a64 64 0 1 0 128 0 64 64 0 1 0 -128 0z", "M288 320c88.4 0 160 71.6 160 160l0 32-64 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96l0 32-64 0 0-32c0-88.4 71.6-160 160-160l128 0zM631.6 176l-19.8 19.8-112 112c-10.9 10.9-28.7 10.9-39.6 0-36.7-36.7-59.3-59.3-67.8-67.8L432 200.4c11.8 11.8 27.8 27.8 48 48l92.2-92.2 19.8-19.8 39.6 39.6zM224 256a128 128 0 1 1 0-256 128 128 0 1 1 0 256zm0-192a64 64 0 1 0 0 128 64 64 0 1 0 0-128z"]],
    "frame": [512, 512, [], "e495", ["M160 160l0 192 192 0 0-192-192 0z", "M160 96l192 0 0-96 64 0 0 96 96 0 0 64-96 0 0 192 96 0 0 64-96 0 0 96-64 0 0-96-192 0 0 96-64 0 0-96-96 0 0-64 96 0 0-192-96 0 0-64 96 0 0-96 64 0 0 96zm0 256l192 0 0-192-192 0 0 192z"]],
    "bell": [512, 512, [128276, 61602], "f0f3", ["M116.1 352l280.4 0c-14.7-29.5-29.5-59-44.2-88.4 0-34.5 0-69 0-103.6 0-46.4-32.9-85.1-76.7-94-6.2-1.3-12.7-2-19.3-2-13.3 0-25.9 2.7-37.4 7.5-5.7 2.4-11.2 5.4-16.3 8.9-25.5 17.3-42.3 46.5-42.3 79.6 0 34.5 0 69 0 103.6-14.7 29.5-29.5 59-44.2 88.4z", "M320.3 512l-128 0 0-64 128 0 0 64zM256.3 0c88.4 0 160 71.6 160 160l0 88.4 83.8 167.6-487.6 0 83.8-167.6 0-88.4c0-88.4 71.6-160 160-160zm0 64c-53 0-96 43-96 96l0 103.6-44.2 88.4 280.4 0-44.2-88.4 0-103.6c0-53-43-96-96-96z"]],
    "mobile": [384, 512, [128241, "mobile-android", "mobile-phone"], "f3ce", ["M64 64l0 384 256 0 0-384-256 0zm64 292l128 0 0 56-128 0 0-56z", "M320 0c35.3 0 64 28.7 64 64l0 384c0 35.3-28.7 64-64 64l-256 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 448 0 64 .3 57.5C3.4 27.3 27.3 3.4 57.5 .3L64 0 320 0zM256 412l-128 0 0-56 128 0 0 56zM320 64l-256 0 0 384 256 0 0-384z"]],
    "trophy": [576, 512, [127942], "f091", ["M192 64l0 160c0 53 43 96 96 96s96-43 96-96l0-160-192 0z", "M128 64c0-35.3 28.7-64 64-64L384 0c35.3 0 64 28.7 64 64l0 4 124 0 0 140c0 59.6-48.4 108-108 108l-45.1 0c-23.1 32.8-58.2 56.5-98.9 64.8l0 67.2 80 0 0 64-224 0 0-64 80 0 0-67.2c-40.7-8.3-75.8-32-98.9-64.8L112 316C52.4 316 4 267.6 4 208l0-140 124 0 0-4zM443.9 260l20.1 0c28.7 0 52-23.3 52-52l0-84-68 0 0 100c0 12.4-1.4 24.4-4.1 36zM128 224l0-100-68 0 0 84c0 28.7 23.3 52 52 52l20.1 0c-2.7-11.6-4.1-23.6-4.1-36zm256 0l0-160-192 0 0 160c0 53 43 96 96 96s96-43 96-96z"]],
    "text": [448, 512, [], "f893", ["", "M224.7 32c-.5 0-1 0-1.4 0L64 32C28.7 32 0 60.7 0 96l0 64 64 0 0-64 128 0 0 320-64 0 0 64 192 0 0-64-64 0 0-320 128 0 0 64 64 0 0-64c0-35.3-28.7-64-64-64L224.7 32z"]],
    "pen-slash": [640, 512, [], "e213", ["M128.3 365.3l82.8-82.7-22.6-22.6 0 0 128 128 0 0-22.6-22.6-82.7 82.8-82.8 0 0-82.8zM346.7 146.7l65.6-65.6c11-11 25.9-17.1 41.4-17.1 32.3 0 58.5 26.2 58.5 58.5 0 15.5-6.2 30.4-17.1 41.4l-65.6 65.6c-27.6-27.6-55.2-55.2-82.7-82.7z", "M621.5 512L576.3 557.2 19 0 64.3-45.3 621.5 512zM211 282.5l-82.8 82.7 0 82.8 82.8 0 82.7-82.8 45.2 45.3-101.5 101.5-173.2 0 0-173.3 101.5-101.5 45.3 45.3zM453.8 0c67.7 0 122.5 54.8 122.5 122.5 0 32.5-12.9 63.7-35.9 86.6l-65.6 65.6-45.3-45.2 65.6-65.6c11-11 17.1-25.9 17.1-41.4 0-32.3-26.2-58.5-58.5-58.5-15.5 0-30.4 6.2-41.4 17.1l-65.6 65.6-45.2-45.3 65.6-65.6c23-23 54.1-35.9 86.6-35.9z"]],
    "camera-slash": [640, 512, [], "e0d9", ["M128.3 199.7c0 72.1 0 144.2 0 216.2 72.1 0 144.2 0 216.2 0-72.1-72.1-144.2-144.2-216.3-216.3zM296 96c72.1 72.1 144.2 144.2 216.2 216.2 0-50.8 0-101.5 0-152.2-19.5 0-39 0-58.5 0-21.3-21.3-42.7-42.7-64-64-31.2 0-62.5 0-93.7 0z", "M621.5 512L576.3 557.2 19 0 64.3-45.3 621.5 512zM128.3 199.7l0 216.3 216.3 0 64 64-280.3 0c-35.3 0-64-28.7-64-64l0-256c0-7.3 1.3-14.2 3.5-20.8l60.5 60.5zM480.3 96l32 0c35.3 0 64 28.7 64 64l0 216.3-64-64 0-152.3-58.5 0-64-64-93.8 0-64-64 184.3 0 64 64z"]],
    "gift": [512, 512, [127873], "f06b", ["M96 192l0 96 132 0 0-96-132 0zm0 160l0 96 132 0 0-96-132 0zM284 192l0 96 132 0 0-96-132 0zm0 160l0 96 132 0 0-96-132 0z", "M154.2 60L152 60c-19.9 0-36 16.1-36 36 0 13.9 7.9 26 19.5 32l80.5 0-28.9-49.2C180.2 67.2 167.7 60 154.2 60zm222.3 68c11.6-6 19.5-18.1 19.5-32 0-19.9-16.1-36-36-36l-2.2 0c-13.5 0-26 7.2-32.9 18.8L296 128 376.5 128zM512 192l-32 0 0 256c0 35.3-28.7 64-64 64L96 512c-35.3 0-64-28.7-64-64l0-256-32 0 0-64 65.7 0C62 118 60 107.3 60 96 60 45.2 101.2 4 152 4l2.2 0c33.4 0 64.2 17.7 81.2 46.4L256 85.6 276.7 50.4C293.6 21.7 324.5 4 357.8 4L360 4c50.8 0 92 41.2 92 92 0 11.3-2 22-5.7 32l65.7 0 0 64zm-228 0l0 256 132 0 0-256-132 0zm-56 0l-132 0 0 256 132 0 0-256z"]],
    "block-quote": [512, 512, [], "e0b5", ["", "M64 64l0-32-64 0 0 448 64 0 0-416zm384 64l32 0 0-64-320 0 0 64 288 0zm0 320l32 0 0-64-320 0 0 64 288 0zm64-160l0-64-352 0 0 64 352 0z"]],
    "gauge-low": [512, 512, ["tachometer-alt-slow"], "f627", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm32 0c0-16.7 12.7-30.4 29-31.9l26.7 53.3c-5.9 6.5-14.3 10.5-23.7 10.5-17.7 0-32-14.3-32-32zm39-83.5L185 147.5 255.3 288c.2 0 .5 0 .7 0 35.3 0 64 28.7 64 64s-28.7 64-64 64-64-28.7-64-64c0-14.7 5-28.1 13.2-38.9L135 172.5zM288 128a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm96 32a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm32 96a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm-.7 224c.2 0 .5 0 .7 0 35.3 0 64 28.7 64 64s-28.7 64-64 64-64-28.7-64-64c0-14.7 5-28.1 13.2-38.9L135 172.5 185 147.5 255.3 288zM151.7 277.5c-5.9 6.5-14.3 10.5-23.7 10.5-17.7 0-32-14.3-32-32 0-16.7 12.7-30.4 29-31.9l26.7 53.3zM384 288a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm-32-96a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm-96-32a32 32 0 1 1 0-64 32 32 0 1 1 0 64z"]],
    "gauge": [512, 512, ["dashboard", "gauge-med", "tachometer-alt-average"], "f624", ["M64 256c0 1.6 0 3.2 .1 4.8 .1 5 .4 9.9 .9 14.8 3.6 35.5 16.9 68.1 37.2 95.2 2.3 3.1 4.7 6.2 7.2 9.1 27.8 32.8 66.4 56.2 110.3 64.6 2.3 .4 4.7 .9 7.1 1.2l0 0c9.5 1.5 19.3 2.2 29.2 2.2s19.7-.8 29.2-2.2c61-9.3 112.5-47.3 140.4-99.8 .2-.4 .4-.7 .6-1.1 3.9-7.4 7.2-15 10.1-22.9 1.1-2.9 2.1-5.8 3-8.8 2.5-8 4.5-16.2 5.9-24.6 1.4-8.2 2.4-17.5 2.7-27.7 .1-2.7 .1-6.8-.1-12.2-.1-2.5-.2-4.9-.4-7.3 0-.1 0-.1 0-.2 0-.2 0-.4-.1-.7 0-.1 0-.4-.1-.8 0-.2 0-.5-.1-.9 0-.1 0-.4-.1-.8 0-.3-.1-.7-.1-1-.1-.5-.1-1-.1-1.4 0-.2 0-.5-.1-.8 0-.1 0-.2 0-.2-5.6-50-30.4-94.2-66.8-125-3-2.5-6-4.9-9.1-7.2-27.1-20.3-59.7-33.6-95.2-37.2-4.9-.5-9.8-.8-14.8-.9-1.6 0-3.2-.1-4.8-.1-106 0-192 86-192 192zm96 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm32-96a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm0 191.4c0-4.2 .5-8.4 1.3-12.4 0-.1 0-.2 .1-.3 .4-1.8 .8-3.6 1.4-5.4 .1-.2 .1-.4 .2-.6 1.2-3.9 2.8-7.7 4.8-11.2 .1-.3 .3-.5 .4-.8 .8-1.3 1.6-2.7 2.4-3.9 .4-.6 .7-1.1 1.1-1.6 .2-.3 .4-.6 .6-.8 4.1-5.6 9-10.5 14.6-14.5 .2-.2 .5-.3 .7-.5 2.6-1.8 5.3-3.4 8.1-4.8 .1-.1 .2-.1 .3-.2l0-166.5 56 0 0 166.5c21.2 10.3 35.8 32 36 57.1 0 .1 0 .3 0 .4 0 35.3-28.7 64-64 64s-64-28.7-64-64c0-.2 0-.4 0-.6zM384 160a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm32 96a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm28 230.5c21.3 10.4 36 32.2 36 57.5 0 35.3-28.7 64-64 64s-64-28.7-64-64c0-25.3 14.7-47.1 36-57.5l0-166.5 56 0 0 166.5zM128 288a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm256 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64zM160 192a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm192 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64z"]],
    "signal": [576, 512, [128246, "signal-5", "signal-perfect"], "f012", ["M79.1 448L196 346.1 196 448c-39 0-78 0-116.9 0zM252 297.3l104-90.6 0 241.2c-34.7 0-69.3 0-104 0l0-150.7zM412 158L512 70.9 512 448c-33.3 0-66.7 0-100 0l0-290z", "M517.8 0C549.9 0 576 26.1 576 58.2L576 448c0 35.3-28.7 64-64 64L55 512c-30.4 0-55-24.6-55-55 0-15.9 6.9-31 18.9-41.5L479.6 14.3C490.2 5.1 503.7 0 517.8 0zM79.1 448L196 448 196 346.1 79.1 448zM412 158l0 290 100 0 0-377.1-100 87.1zM252 297.3l0 150.7 104 0 0-241.2-104 90.6z"]],
    "share-nodes": [512, 512, ["share-alt"], "f1e0", ["M56 256a40 40 0 1 0 80 0 40 40 0 1 0 -80 0zM376 96a40 40 0 1 0 80 0 40 40 0 1 0 -80 0zm0 320a40 40 0 1 0 80 0 40 40 0 1 0 -80 0z", "M456 96a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm56 0c0 53-43 96-96 96-25.9 0-49.4-10.2-66.6-26.9l-158.1 79c.5 3.9 .7 7.8 .7 11.9s-.2 8-.7 11.9l158.1 79c17.3-16.7 40.8-26.9 66.6-26.9 53 0 96 43 96 96s-43 96-96 96-96-43-96-96c0-4 .2-8 .7-11.9l-158.1-79C145.4 341.8 121.9 352 96 352 43 352 0 309 0 256s43-96 96-96c25.9 0 49.4 10.2 66.6 26.9l158.1-79c-.5-3.9-.7-7.8-.7-11.9 0-53 43-96 96-96s96 43 96 96zM136 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zM416 456a40 40 0 1 0 0-80 40 40 0 1 0 0 80z"]],
    "hard-drive": [512, 512, [128436, "hdd"], "f0a0", ["M64 288l0 160 384 0 0-160-384 0zm112 80a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm96 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z", "M403.5 .2c27 2.3 49.9 21.5 56.6 48.2l50 199.9c1.3 5.1 1.9 10.3 1.9 15.5L512 448c0 35.3-28.7 64-64 64L64 512c-4.3 0-8.5-.5-12.6-1.3-.7-.1-1.4-.3-2.1-.5-1.3-.3-2.6-.6-3.9-1-.7-.2-1.5-.5-2.2-.8-1.2-.4-2.4-.8-3.6-1.3-.7-.3-1.4-.6-2.1-.9-1.1-.5-2.3-1-3.3-1.6-.8-.4-1.7-.9-2.5-1.4-.9-.5-1.7-1-2.6-1.6-.8-.5-1.5-1-2.2-1.5-1-.7-1.9-1.4-2.8-2.1-.6-.5-1.3-1.1-1.9-1.6-.9-.8-1.8-1.6-2.6-2.4-.6-.5-1.1-1.1-1.7-1.7-.8-.9-1.6-1.8-2.4-2.7-.6-.6-1.1-1.3-1.7-2-.7-.9-1.3-1.7-1.9-2.6-.5-.7-1.1-1.5-1.6-2.2-.6-.9-1.1-1.8-1.7-2.7-.5-.8-1-1.6-1.4-2.5-.5-.9-.9-1.8-1.3-2.7s-.9-1.8-1.3-2.8c-.3-.8-.7-1.7-1-2.6-.4-1-.7-2-1.1-3.1-1.2-3.9-2-7.9-2.4-12L0 448 0 263.9c0-5.2 .6-10.5 1.9-15.5l50-199.9C59 20 84.6 0 114 0L398 0 403.5 .2zM64 448l384 0 0-160-384 0 0 160zm80-48a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm96 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64zM74 224L438 224 398 64 114 64 74 224z"]],
    "ellipsis": [512, 512, ["ellipsis-h"], "f141", ["", "M256 192a64 64 0 1 1 0 128 64 64 0 1 1 0-128zM64 192a64 64 0 1 1 0 128 64 64 0 1 1 0-128zm384 0a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"]],
    "percent": [448, 512, [62101, 62785, "percentage"], "25", ["M64 128a32 32 0 1 0 64 0 32 32 0 1 0 -64 0zM320 384a32 32 0 1 0 64 0 32 32 0 1 0 -64 0z", "M352 480a96 96 0 1 1 0-192 96 96 0 1 1 0 192zM438.6 86.6l-384 384-45.2-45.2 384-384 45.2 45.2zM352 352a32 32 0 1 0 0 64 32 32 0 1 0 0-64zM96 224a96 96 0 1 1 0-192 96 96 0 1 1 0 192zM96 96a32 32 0 1 0 0 64 32 32 0 1 0 0-64z"]],
    "display": [512, 512, [], "e163", ["M64 64l0 256 384 0 0-256-384 0z", "M448 0c35.3 0 64 28.7 64 64l0 256-.3 6.5C508.4 358.8 481.1 384 448 384l-160 0 0 64 96 0 0 64-256 0 0-64 96 0 0-64-160 0C30.9 384 3.6 358.8 .3 326.5L0 320 0 64C0 28.7 28.7 0 64 0L448 0zM64 320l384 0 0-256-384 0 0 256z"]],
    "magnifying-glass": [576, 512, [128269, "search"], "f002", ["M96.3 224a160 160 0 1 0 320 0 160 160 0 1 0 -320 0z", "M256.3 0c123.7 0 224 100.3 224 224 0 50.3-16.6 96.7-44.6 134.1L557.5 480 512.3 525.3 390.4 403.4c-37.4 28-83.8 44.6-134.1 44.6-123.7 0-224-100.3-224-224S132.5 0 256.3 0zm0 64a160 160 0 1 0 0 320 160 160 0 1 0 0-320z"]],
    "cloud-moon": [640, 512, [], "f6c3", ["M64 400c0 44.2 35.8 80 80 80l224 0c44.2 0 80-35.8 80-80 0-41.2-31.2-75.2-71.3-79.5l-22.2-2.4-5.4-21.6C338.6 254.8 300.9 224 256 224s-82.6 30.8-93.1 72.5l-5.4 21.6-22.2 2.4C95.2 324.8 64 358.8 64 400z", "M607.3 256l.7-1.1c12.5-19.7 21.7-41.7 27-65.2-8.8 1.5-17.8 2.3-27 2.3-13.3 0-26.2-1.6-38.6-4.7-69.7-17.3-121.4-80.3-121.4-155.3 0-10.5 1-20.8 3-30.8 4.3-22.1 13.2-42.6 25.6-60.5-14.3-3.1-29.2-4.8-44.5-4.8-9.2 0-18.3 .6-27.3 1.8-86.6 11.3-156.4 75.9-175.5 159.8 15.2-1.8 38.6-3 65.8 1.8 14-42.9 47.6-77 90.3-91.6-.9 8-1.3 16.1-1.3 24.3 0 98.4 63.4 181.9 151.6 212-4.9 5-10.1 9.7-15.6 14 14.6 15.6 26.8 33.4 36.1 53 20.2-15.1 37.6-33.7 51.3-55zM256 160C188.6 160 130.9 201.7 107.4 260.7 45.6 276.9 0 333.1 0 400 0 479.5 64.5 544 144 544l224 0c79.5 0 144-64.5 144-144 0-66.9-45.6-123.1-107.4-139.3-23.6-59-81.2-100.7-148.6-100.7zM162.9 296.5C173.4 254.8 211.1 224 256 224s82.6 30.8 93.1 72.5l5.4 21.6 22.2 2.4c40.1 4.3 71.3 38.3 71.3 79.5 0 44.2-35.8 80-80 80l-224 0c-44.2 0-80-35.8-80-80 0-41.2 31.2-75.2 71.3-79.5l22.2-2.4 5.4-21.6z"]],
    "floppy-disk": [512, 512, [128190, 128426, "save"], "f0c7", ["M64 64l0 384 384 0 0-261.5-100-100 0 41.5c0 33.1-26.9 60-60 60l-128 0c-33.1 0-60-26.9-60-60l0-64-36 0zM352 320a96 96 0 1 1 -192 0 96 96 0 1 1 192 0z", "M512 448c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64 .3 57.5C3.4 27.3 27.3 3.4 57.5 .3L64 0 325.5 0 331.8 .3c14.7 1.5 28.4 7.9 38.9 18.4L493.3 141.2c10.5 10.5 17 24.3 18.4 38.9l.3 6.3 0 261.5zM348 86.5l0 41.5c0 33.1-26.9 60-60 60l-128 0c-33.1 0-60-26.9-60-60l0-64-36 0 0 384 384 0 0-261.5-100-100zM156 64l0 64c0 2.2 1.8 4 4 4l128 0c2.2 0 4-1.8 4-4l0-64-136 0zm4 256a96 96 0 1 1 192 0 96 96 0 1 1 -192 0zm136 0a40 40 0 1 0 -80 0 40 40 0 1 0 80 0z"]],
    "palette": [512, 512, [127912], "f53f", ["M64 256c0 95.1 69.2 174 160 189.3l0-29.3c0-53 43-96 96-96l117 0c7.1-20 11-41.5 11-64 0-106-86-192-192-192S64 150 64 256zm140-32a44 44 0 1 1 -88 0 44 44 0 1 1 88 0zm96-64a44 44 0 1 1 -88 0 44 44 0 1 1 88 0zm96 64a44 44 0 1 1 -88 0 44 44 0 1 1 88 0z", "M256 0c141.4 0 256 114.6 256 256 0 39.2-8.9 76.4-24.7 109.7L478.6 384 320 384c-17.7 0-32 14.3-32 32l0 96-32 0C114.6 512 0 397.4 0 256S114.6 0 256 0zm0 64c-106 0-192 86-192 192 0 95.1 69.2 174 160 189.3l0-29.3c0-53 43-96 96-96l117 0c7.1-20 11-41.5 11-64 0-106-86-192-192-192zM160 268a44 44 0 1 1 0-88 44 44 0 1 1 0 88zm192 0a44 44 0 1 1 0-88 44 44 0 1 1 0 88zm-96-64a44 44 0 1 1 0-88 44 44 0 1 1 0 88z"]],
    "unlock": [512, 512, [128275], "f09c", ["M64 256l0 192 256 0 0-192-256 0z", "M320 128c0-35.3 28.7-64 64-64s64 28.7 64 64l0 128 64 0 0-128C512 57.3 454.7 0 384 0S256 57.3 256 128l0 64-192 0c-35.3 0-64 28.7-64 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-192c0-35.3-28.7-64-64-64l0-64zM64 256l256 0 0 192-256 0 0-192z"]],
    "key": [512, 512, [128273], "f084", ["M256.5 160c0-32 15.7-60.4 39.8-77.9 .1-.1 .2-.1 .3-.2 .9-.7 1.6-1.2 2.1-1.5 0 0 .1 0 .1-.1 5.1-3.5 10.6-6.4 16.3-8.9 11.5-4.9 24.1-7.5 37.4-7.5 6.6 0 13.1 .7 19.3 2 43.7 9 76.6 47.7 76.7 94s-32.9 85.1-76.7 94c-6.2 1.3-12.7 1.9-19.4 2-13.3 0-25.9-2.7-37.4-7.5-5.7-2.4-11.2-5.4-16.3-8.9 0 0-.1 0-.1-.1-.5-.3-1.2-.8-2.1-1.5-.1-.1-.2-.1-.3-.2-24.1-17.4-39.8-45.8-39.8-77.9z", "M352.5 0c88.4 0 160 71.6 160 160s-71.6 160-160 160c-32.6 0-63-9.8-88.2-26.5l-74.5 74.5 41.4 41.4-45.2 45.2-41.4-41.4-34.8 34.7 41.4 41.4-45.2 45.2-86.6-86.6 199.8-199.8c-16.7-25.3-26.5-55.6-26.5-88.2 0-88.4 71.6-160 160-160zm0 64a96 96 0 1 0 0 192 96 96 0 1 0 0-192z"]],
    "skull": [512, 512, [128128], "f54c", ["M64 256l0 53.5c34.6 34.6 55.9 55.9 64 64l0 74.5 52 0 0-64 56 0 0 64 40 0 0-64 56 0 0 64 52 0 0-74.5 64-64 0-53.5c0-106-86-192-192-192S64 150 64 256zm152-16a40 40 0 1 1 -80 0 40 40 0 1 1 80 0zm160 0a40 40 0 1 1 -80 0 40 40 0 1 1 80 0z", "M384 373.5l0 74.5-52 0 0-64-56 0 0 64-40 0 0-64-56 0 0 64-52 0 0-74.5c-8.1-8.1-29.4-29.4-64-64L64 256C64 150 150 64 256 64s192 86 192 192l0 53.5-64 64zM0 256l0 53.5c0 17 6.7 33.3 18.7 45.3L64 400 64 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-48 45.3-45.3c12-12 18.7-28.3 18.7-45.3l0-53.5C512 114.6 397.4 0 256 0S0 114.6 0 256zm216-16a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm120 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80z"]],
    "gamepad-modern": [576, 512, [127918, 63676, "gamepad-alt"], "e5a2", ["M64 224l0 128c0 35.3 28.7 64 64 64l32 0c20.8-27.7 36.8-49.1 48-64l160 0c11.2 14.9 27.2 36.3 48 64l32 0c35.3 0 64-28.7 64-64l0-128c0-70.7-57.3-128-128-128L192 96C121.3 96 64 153.3 64 224zm48-28l52 0 0-52 56 0 0 52 52 0 0 56-52 0 0 52-56 0 0-52-52 0 0-56zm296-20a40 40 0 1 1 -80 0 40 40 0 1 1 80 0zm64 96a40 40 0 1 1 -80 0 40 40 0 1 1 80 0z", "M336 416l48 64 64 0c70.7 0 128-57.3 128-128l0-128c0-106-86-192-192-192L192 32C86 32 0 118 0 224L0 352c0 70.7 57.3 128 128 128l64 0 48-64 96 0zm-176 0l-32 0c-35.3 0-64-28.7-64-64l0-128c0-70.7 57.3-128 128-128l192 0c70.7 0 128 57.3 128 128l0 128c0 35.3-28.7 64-64 64l-32 0c-20.8-27.7-36.8-49.1-48-64l-160 0c-11.2 14.9-27.2 36.3-48 64zM408 176a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm24 136a40 40 0 1 0 0-80 40 40 0 1 0 0 80zM164 196l-52 0 0 56 52 0 0 52 56 0 0-52 52 0 0-56-52 0 0-52-56 0 0 52z"]],
    "tree": [512, 512, [127794], "f1bb", ["M96.1 384l128 0c0-101.3 0-154.7 0-160 21.3 0 42.7 0 64 0l0 160 128 0c-45.2-60.3-70-93.3-74.3-99l32.5-32.5-118.2-165.5c-39.4 55.2-78.8 110.3-118.2 165.5 7.4 7.4 18.2 18.2 32.5 32.5-4.3 5.7-29 38.7-74.3 99z", "M137.9 252.5c7.4 7.4 18.2 18.2 32.5 32.5-4.3 5.7-29 38.7-74.3 99l128 0 0-160 64 0 0 160 128 0c-45.2-60.3-70-93.3-74.3-99l32.5-32.5-118.2-165.5-118.2 165.5zM224.1 448l-176 0c-33 0-51.8-37.6-32-64l69.7-93-7.6-7.6c-13.8-13.8-15.6-35.6-4.3-51.5L223.5 22.5c16-22.3 49.1-22.3 65.1 0L438.2 231.9c11.4 15.9 9.6 37.7-4.3 51.5l-7.6 7.6 69.7 93c19.8 26.4 1 64-32 64l-176 0 0 64-64 0 0-64z"]],
    "phone-arrow-up-right": [512, 512, ["phone-arrow-up", "phone-outgoing"], "e224", ["M66.3 216.2c13.8 72.6 54.8 135.6 112 178 11.4 8.5 23.5 16.2 36.1 22.9 25.3 13.5 52.8 23.4 81.8 28.9 41.7 7.9 84.9-5.3 114.7-35.2L437.8 384c-17.8-17.8-35.7-35.7-53.5-53.5l-33.4 33.4c-17.1 17.1-42 23.7-65.3 17.3-17.6-4.8-34.4-11.7-49.9-20.4-1-.6-2-1.2-3.1-1.8 0 0-.1 0-.1 0-4.1-2.4-8.1-4.9-12-7.6l0 0c-1-.6-1.9-1.3-2.9-2-.4-.3-.7-.5-.8-.6-41.3-29.1-72.1-72-85.8-122.2-6.3-23.3 .3-48.2 17.3-65.2L181.8 128c-17.8-17.8-35.7-35.7-53.5-53.5l-26.9 26.9c-29.9 29.9-43.1 73-35.2 114.8z", "M83.1 29.2c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-33.4 33.4c-.8 .8-1.1 2-.8 3.2 13.7 50.1 51.2 89.9 99.8 106.7l9.9 3c.6 .2 1.1 .1 1.7 0l1.5-.8 33.4-33.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9-8.7 8.2c-41.4 36.6-96.8 53.5-151.6 46.5l-11.7-1.8C142.3 481.9 30.4 370 3.4 228.1-7.7 169.6 8.9 109.1 48.1 64.8l8.2-8.7 26.9-26.9zm18.4 72.2c-29.9 29.9-43.1 73-35.2 114.7 22.1 116.1 113.8 207.8 229.9 229.9 41.7 7.9 84.9-5.3 114.7-35.2l26.9-26.9-53.5-53.5-33.4 33.4c-17.1 17.1-42 23.7-65.2 17.3-75.3-20.5-134.1-79.3-154.6-154.6-6.3-23.3 .3-48.2 17.3-65.2l33.4-33.4-53.5-53.5-26.9 26.9zM480.7 4c7.4 0 14.6 2.9 19.8 8.2s8.2 12.4 8.2 19.8l0 156-56 0 0-88.4-112.2 112.2-19.8 19.8-39.6-39.6 19.8-19.8 112.2-112.2-88.4 0 0-56 156 0z"]],
    "pen-line": [576, 512, [], "e212", ["M64 365.3l0 82.7 82.8 0 284.1-284.1c11-11 17.1-25.9 17.1-41.4 0-32.3-26.2-58.5-58.5-58.5-15.5 0-30.4 6.2-41.4 17.1L64 365.3z", "M389.5 0c67.7 0 122.5 54.8 122.5 122.5 0 32.5-12.9 63.7-35.9 86.6L173.2 512 0 512 0 338.7 302.9 35.9C325.8 12.9 357 0 389.5 0zM576 512l-288 0 0-64 288 0 0 64zM389.5 64c-15.5 0-30.4 6.2-41.4 17.1L64 365.3 64 448 146.8 448 430.9 163.9c11-11 17.1-25.9 17.1-41.4 0-32.3-26.2-58.5-58.5-58.5z"]],
    "paintbrush": [576, 512, [128396, "paint-brush"], "f1fc", ["M281.2 244c20.9 12.4 38.4 29.8 50.8 50.7l169.5-169.5 2.4-2.6c5.2-6.4 8.1-14.4 8.1-22.8 0-19.8-16.1-35.9-35.9-35.9-9.5 0-18.6 3.8-25.4 10.5L281.2 244z", "M476.1 0c55.2 0 99.9 44.7 99.9 99.9 0 24.8-9.3 48.7-25.8 67l-3.4 3.6-194.8 194.8c0 .9 .1 1.8 .1 2.7 0 79.5-64.5 144-144 144l-208 0 0-64 64 0 0-80c0-79.5 64.5-144 144-144 .9 0 1.8 0 2.7 .1l194.8-194.8 3.6-3.4C427.4 9.2 451.3 0 476.1 0zM208 288c-44.2 0-80 35.8-80 80l0 80 80 0c44.2 0 80-35.8 80-80s-35.8-80-80-80zM476.1 64c-9.5 0-18.6 3.8-25.4 10.5L281.2 244c20.9 12.4 38.4 29.8 50.8 50.7l169.5-169.5 2.4-2.6c5.2-6.4 8.1-14.4 8.1-22.8 0-19.8-16.1-35.9-35.9-35.9z"]],
    "flower": [512, 512, [127804, 10047], "f7ff", ["M64 140.7c0 36.5 25.8 68 61.6 75.2l8.3 1.6c12.5-39.7 43.9-71.1 83.6-83.6l-1.6-8.3C208.7 89.8 177.2 64 140.7 64 98.3 64 64 98.3 64 140.7zm0 230.7c0 42.3 34.3 76.7 76.7 76.7 36.5 0 68-25.8 75.2-61.6l1.6-8.2c-39.7-12.5-71.1-43.9-83.6-83.6l-8.3 1.7C89.8 303.3 64 334.8 64 371.3zM294.5 133.9c39.7 12.5 71.1 43.9 83.6 83.6l8.2-1.6c35.8-7.2 61.6-38.6 61.6-75.2 0-42.3-34.3-76.7-76.7-76.7-36.5 0-68 25.8-75.2 61.6l-1.7 8.3zm0 244.2l1.7 8.2c7.2 35.8 38.6 61.6 75.2 61.6 42.3 0 76.7-34.3 76.7-76.7 0-36.5-25.8-68-61.6-75.2l-8.2-1.7c-12.5 39.7-43.9 71.1-83.6 83.6z", "M15.4 204.7c10.5 20.5 25.8 38.1 44.7 51.3-18.9 13.2-34.2 30.9-44.7 51.3-9.9 19.3-15.4 41.1-15.4 64 0 77.7 63 140.7 140.7 140.7 47.1 0 89.6-23.4 115.3-60.1 25.7 36.7 68.2 60.1 115.3 60.1 77.7 0 140.7-63 140.7-140.7 0-22.9-5.5-44.7-15.4-64-10.5-20.5-25.8-38.1-44.7-51.3 18.9-13.2 34.2-30.9 44.7-51.3 9.9-19.3 15.4-41.1 15.4-64 0-77.7-63-140.7-140.7-140.7-47.1 0-89.6 23.4-115.3 60.1-25.7-36.7-68.2-60.1-115.3-60.1-77.7 0-140.7 63-140.7 140.7 0 22.9 5.5 44.7 15.4 64zm279.1-70.8l1.7-8.3c7.2-35.8 38.6-61.6 75.2-61.6 42.3 0 76.7 34.3 76.7 76.7 0 36.5-25.8 68-61.6 75.2l-8.2 1.6c-12.5-39.7-43.9-71.1-83.6-83.6zm-77 0c-39.7 12.5-71.1 43.9-83.6 83.6l-8.3-1.6c-35.8-7.2-61.6-38.6-61.6-75.2 0-42.3 34.3-76.7 76.7-76.7 36.5 0 68 25.8 75.2 61.6l1.6 8.3zM133.9 294.5c12.5 39.7 43.9 71.1 83.6 83.6l-1.6 8.2c-7.2 35.8-38.6 61.6-75.2 61.6-42.3 0-76.7-34.3-76.7-76.7 0-36.5 25.8-68 61.6-75.2l8.3-1.7zm160.6 83.6c39.7-12.5 71.1-43.9 83.6-83.6l8.2 1.7c35.8 7.2 61.6 38.6 61.6 75.2 0 42.3-34.3 76.7-76.7 76.7-36.5 0-68-25.8-75.2-61.6l-1.7-8.2zM192 256a64 64 0 1 1 128 0 64 64 0 1 1 -128 0z"]],
    "battery-slash": [640, 512, [], "f377", ["M64 135.8L64 384 312.2 384 64 135.8zM327.8 128L480 280.2 480 128 327.8 128z", "M621.3 512L576 557.3 18.8 0 64-45.2 621.3 512zM64 135.8l0 248.2 248.2 0 64 64-312.2 0c-35.3 0-64-28.7-64-64L0 128c0-15.7 5.6-30.1 15-41.2l49 49zM640 352l-64 0 0-192 64 0 0 192zM480 64c35.3 0 64 28.7 64 64l0 216.2-64-64 0-152.2-152.2 0-64-64 216.2 0z"]],
    "font-case": [640, 512, [], "f866", ["M96 176l0 80 160 0 0-80c0-44.2-35.8-80-80-80s-80 35.8-80 80zM448 352l0 32c0 17.7 14.3 32 32 32l64 0c17.7 0 32-14.3 32-32l0-64-96 0c-17.7 0-32 14.3-32 32z", "M96 176l0 80 160 0 0-80c0-44.2-35.8-80-80-80s-80 35.8-80 80zm0 144l0 96 32 0 0 64-128 0 0-64 32 0 0-240C32 96.5 96.5 32 176 32S320 96.5 320 176l0 240 32 0 0 64-128 0 0-64 32 0 0-96-160 0zM416 128l128 0c53 0 96 43 96 96l0 256-64 0 0-5.5c-10 3.5-20.8 5.5-32 5.5l-64 0c-53 0-96-43-96-96l0-32c0-53 43-96 96-96l96 0 0-32c0-17.7-14.3-32-32-32l-128 0 0-64zM576 384l0-64-96 0c-17.7 0-32 14.3-32 32l0 32c0 17.7 14.3 32 32 32l64 0c17.7 0 32-14.3 32-32z"]],
    "camera": [512, 512, [62258, "camera-alt"], "f030", ["M64 160l0 256 384 0 0-256-58.5 0c-8.1-8.1-29.4-29.4-64-64l-139 0c-34.6 34.6-55.9 55.9-64 64L64 160zM368 272a112 112 0 1 1 -224 0 112 112 0 1 1 224 0z", "M352 32l64 64 32 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 160c0-35.3 28.7-64 64-64l32 0 64-64 192 0zM141.3 141.3l-18.7 18.7-58.5 0 0 256 384 0 0-256-58.5 0c-8.1-8.1-29.4-29.4-64-64l-139 0-45.3 45.3zM312 272a56 56 0 1 0 -112 0 56 56 0 1 0 112 0zm-168 0a112 112 0 1 1 224 0 112 112 0 1 1 -224 0z"]],
    "eye": [576, 512, [128065], "f06e", ["M67.6 256c42.8 84 120.9 160 220.5 160s177.7-76 220.5-160C465.9 172 387.8 96 288.2 96S110.4 172 67.6 256zm312.2 0a91.8 91.8 0 1 1 -183.7 0 91.8 91.8 0 1 1 183.7 0z", "M288.2 32c135.2 0 241.5 105.6 290.7 224-49.1 118.4-155.4 224-290.7 224S46.6 374.4-2.5 256C46.6 137.6 152.9 32 288.2 32zm0 64c-99.7 0-177.7 76-220.5 160 42.8 84 120.9 160 220.5 160s177.7-76 220.5-160C465.9 172 387.8 96 288.2 96zm-.3 252a92 92 0 1 1 .3-184 92 92 0 1 1 -.3 184zm.3-128a36 36 0 1 0 -.3 72 36 36 0 1 0 .3-72z"]],
    "trash": [448, 512, [], "f1f8", ["M96 160l256 0 0 288-256 0 0-288z", "M96 64c0-35.3 28.7-64 64-64L288 0c35.3 0 64 28.7 64 64l0 32 96 0 0 64-32 0 0 288c0 35.3-28.7 64-64 64L96 512c-35.3 0-64-28.7-64-64l0-288-32 0 0-64 96 0 0-32zm64 32l128 0 0-32-128 0 0 32zm192 64l-256 0 0 288 256 0 0-288z"]],
    "clipboard-check": [448, 512, [], "f46c", ["M64 96l0 352 320 0 0-352-64 0 0 64-192 0 0-64-64 0zm40.4 208L144 264.4c11.8 11.8 27.8 27.8 48 48l92.2-92.2 19.8-19.8 39.6 39.6-19.8 19.8-112 112c-10.9 10.9-28.7 10.9-39.6 0-36.7-36.7-59.3-59.3-67.8-67.8z", "M224-32c41.8 0 77.4 26.7 90.5 64L384 32c35.3 0 64 28.7 64 64l0 352c0 33.1-25.2 60.4-57.5 63.7l-6.5 .3-320 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 448 0 96C0 60.7 28.7 32 64 32l69.5 0C146.6-5.3 182.2-32 224-32zM64 448l320 0 0-352-64 0 0 64-192 0 0-64-64 0 0 352zM343.6 240l-19.8 19.8-112 112c-10.9 10.9-28.7 10.9-39.6 0-36.7-36.7-59.3-59.3-67.8-67.8L144 264.4c11.8 11.8 27.8 27.8 48 48l92.2-92.2 19.8-19.8 39.6 39.6zM224 24c-22.1 0-40 17.9-40 40l0 40 80 0 0-40c0-22.1-17.9-40-40-40z"]],
    "equals": [448, 512, [62764], "3d", ["", "M448 384l-448 0 0-64 448 0 0 64zm0-192l-448 0 0-64 448 0 0 64z"]],
    "expand": [512, 512, [], "f065", ["", "M32 0C14.3 0 0 14.3 0 32l0 128 64 0 0-96 96 0 0-64-128 0zM64 384l0-32-64 0 0 128c0 17.7 14.3 32 32 32l128 0 0-64-96 0 0-64zM384 0l-32 0 0 64 96 0 0 96 64 0 0-128c0-17.7-14.3-32-32-32L384 0zM512 384l0-32-64 0 0 96-96 0 0 64 128 0c17.7 0 32-14.3 32-32l0-96z"]],
    "signal-weak": [576, 512, ["signal-1"], "f68c", ["", "M517.8 0C549.9 0 576 26.1 576 58.2L576 448c0 35.3-28.7 64-64 64L55 512c-30.4 0-55-24.6-55-55 0-15.9 6.9-31 18.9-41.5L479.6 14.3C490.2 5.1 503.7 0 517.8 0zM79.1 448L512 448 512 70.9 79.1 448z"]],
    "water": [640, 512, [], "f773", ["M64 0L192 0c0 35.3-28.7 64-64 64S64 35.3 64 0zm0 192l128 0c0 35.3-28.7 64-64 64s-64-28.7-64-64zm0 192l128 0c0 35.3-28.7 64-64 64s-64-28.7-64-64zM256 0L384 0c0 35.3-28.7 64-64 64S256 35.3 256 0zm0 192l128 0c0 35.3-28.7 64-64 64s-64-28.7-64-64zm0 192l128 0c0 35.3-28.7 64-64 64s-64-28.7-64-64zM448 0L576 0c0 35.3-28.7 64-64 64S448 35.3 448 0zm0 192l128 0c0 35.3-28.7 64-64 64s-64-28.7-64-64zm0 192l128 0c0 35.3-28.7 64-64 64s-64-28.7-64-64z", "M128 64C92.7 64 64 35.3 64 0L0 0c0 70.7 57.3 128 128 128 38.2 0 72.5-16.8 96-43.3 23.5 26.6 57.8 43.3 96 43.3s72.5-16.8 96-43.3c23.5 26.6 57.8 43.3 96 43.3 70.7 0 128-57.3 128-128L576 0c0 35.3-28.7 64-64 64S448 35.3 448 0L384 0c0 35.3-28.7 64-64 64S256 35.3 256 0L192 0c0 35.3-28.7 64-64 64zM64 192L0 192c0 70.7 57.3 128 128 128 38.2 0 72.5-16.8 96-43.3 23.5 26.6 57.8 43.3 96 43.3s72.5-16.8 96-43.3c23.5 26.6 57.8 43.3 96 43.3 70.7 0 128-57.3 128-128l-64 0c0 35.3-28.7 64-64 64s-64-28.7-64-64l-64 0c0 35.3-28.7 64-64 64s-64-28.7-64-64l-64 0c0 35.3-28.7 64-64 64s-64-28.7-64-64zm0 192L0 384c0 70.7 57.3 128 128 128 38.2 0 72.5-16.8 96-43.3 23.5 26.6 57.8 43.3 96 43.3s72.5-16.8 96-43.3c23.5 26.6 57.8 43.3 96 43.3 70.7 0 128-57.3 128-128l-64 0c0 35.3-28.7 64-64 64s-64-28.7-64-64l-64 0c0 35.3-28.7 64-64 64s-64-28.7-64-64l-64 0c0 35.3-28.7 64-64 64s-64-28.7-64-64z"]],
    "signal-good": [576, 512, ["signal-3"], "f68e", ["M79.1 448L196 346.1 196 448c-39 0-78 0-116.9 0zM252 297.3l104-90.6 0 241.2c-34.7 0-69.3 0-104 0l0-150.7z", "M517.8 0C549.9 0 576 26.1 576 58.2L576 448c0 35.3-28.7 64-64 64L55 512c-30.4 0-55-24.6-55-55 0-15.9 6.9-31 18.9-41.5L479.6 14.3C490.2 5.1 503.7 0 517.8 0zM79.1 448L196 448 196 346.1 79.1 448zM412 158l0 290 100 0 0-377.1-100 87.1zM252 297.3l0 150.7 104 0 0-241.2-104 90.6z"]],
    "stop": [384, 512, [9209], "f04d", ["M64 128l256 0 0 256-256 0 0-256z", "M320 128l0 256-256 0 0-256 256 0zM64 64C28.7 64 0 92.7 0 128L0 384c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L64 64z"]],
    "signal-slash": [640, 512, [], "f695", ["M111.3 448L253 324.5 376.5 448 111.3 448zM398.1 198.1c48.7-42.4 97.4-84.8 146.1-127.2l0 273.3-146.1-146.1z", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM253 324.5l-141.7 123.5 265.2 0 64 64-353.3 0c-30.4 0-55-24.6-55-55 0-15.9 6.9-31 18.9-41.5L207.7 279.2 253 324.5zM550 0c32.1 0 58.2 26.1 58.2 58.2l0 350-64-64 0-273.3-146.1 127.2-45.3-45.3 159-138.5C522.4 5.1 536 0 550 0z"]],
    "command": [512, 512, [], "e142", ["M64 112c0 26.5 21.5 48 48 48l48 0 0-48c0-26.5-21.5-48-48-48S64 85.5 64 112zm0 288c0 26.5 21.5 48 48 48s48-21.5 48-48l0-48-48 0c-26.5 0-48 21.5-48 48zM352 112l0 48 48 0c26.5 0 48-21.5 48-48s-21.5-48-48-48-48 21.5-48 48zm0 240l0 48c0 26.5 21.5 48 48 48s48-21.5 48-48-21.5-48-48-48l-48 0z", "M64 112c0 26.5 21.5 48 48 48l48 0 0-48c0-26.5-21.5-48-48-48S64 85.5 64 112zm160 0l0 48 64 0 0-48C288 50.1 338.1 0 400 0s112 50.1 112 112-50.1 112-112 112l-48 0 0 64 48 0c61.9 0 112 50.1 112 112s-50.1 112-112 112-112-50.1-112-112l0-48-64 0 0 48c0 61.9-50.1 112-112 112S0 461.9 0 400 50.1 288 112 288l48 0 0-64-48 0C50.1 224 0 173.9 0 112S50.1 0 112 0 224 50.1 224 112zm32 176l32 0 0-64-64 0 0 64 32 0zM112 352c-26.5 0-48 21.5-48 48s21.5 48 48 48 48-21.5 48-48l0-48-48 0zM448 112c0-26.5-21.5-48-48-48s-48 21.5-48 48l0 48 48 0c26.5 0 48-21.5 48-48zM400 352l-48 0 0 48c0 26.5 21.5 48 48 48s48-21.5 48-48-21.5-48-48-48z"]],
    "tv-retro": [512, 512, [128250], "f401", ["M64 160c64 0 128 0 192 0l32 0 0 256-224 0 0-256z", "M182.6 9.4L160-13.3 114.7 32c12 12 33.3 33.3 64 64L64 96C28.7 96 0 124.7 0 160L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L333.3 96c30.7-30.7 52-52 64-64L352-13.3c-6.6 6.6-38.6 38.6-96 96L182.6 9.4zM64 160l384 0 0 256-384 0 0-256zm344 80a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zM368 376a40 40 0 1 0 0-80 40 40 0 1 0 0 80z"]],
    "angle-left": [320, 512, [8249], "f104", ["", "M269.7 64l-192 192 192 192-45.3 45.2-214.6-214.6c-12.5-12.5-12.5-32.8 0-45.3L224.5 18.7 269.7 64z"]],
    "arrow-right-to-line": [512, 512, [8677, "arrow-to-right"], "f340", ["", "M512 480l-64 0 0-448 64 0 0 448zM342.6 233.4l2.2 2.4c10.2 12.6 9.5 31.1-2.2 42.8l-150.6 150.6-45.2-45.3 96-96-242.8 0 0-64 242.8 0-96-96 45.2-45.2 150.6 150.6z"]],
    "radio": [512, 512, [128251], "f8d7", ["M64 192.5l384 0 0 255.5-384 0 0-255.5zm32 128c0 6.6 .7 13.1 2 19.3 .2 .8 .3 1.6 .5 2.3 0 0 0 .1 0 .1 0 .1 0 .2 .1 .2 0 .1 .1 .3 .1 .4 0 .1 0 .1 .1 .2 0 .1 .1 .2 .1 .3 0 .1 0 .1 0 .2 0 .2 .1 .3 .1 .5 0 .1 0 .1 0 .1 0 .1 .1 .3 .1 .4 0 0 0 0 0 .1 3.4 13.1 9.5 25 17.6 35.3 .1 .1 .1 .2 .2 .3 .4 .5 .8 1 1.2 1.5 .1 .1 .1 .2 .2 .2 .2 .2 .4 .5 .6 .7 .1 .1 .1 .1 .2 .2 1.2 1.4 2.4 2.7 3.6 4 .1 .1 .1 .1 .2 .2 .2 .2 .4 .4 .6 .6 .1 .1 .1 .1 .2 .2 .1 .1 .2 .2 .3 .3 17.4 17.4 41.4 28.1 67.9 28.1s50.5-10.7 67.9-28.1c.1-.1 .2-.2 .3-.3 .1-.1 .1-.1 .2-.2 .2-.2 .4-.4 .6-.6 .1-.1 .1-.1 .2-.2 1.2-1.3 2.5-2.6 3.6-4 .1-.1 .1-.1 .2-.2 .2-.2 .4-.5 .6-.7 .1-.1 .1-.1 .2-.2 .4-.5 .8-1 1.2-1.5 .1-.1 .1-.2 .2-.3 8.1-10.3 14.2-22.3 17.6-35.3 0 0 0 0 0-.1 0-.1 .1-.3 .1-.4 0 0 0-.1 0-.1 0-.2 .1-.3 .1-.5 0-.1 0-.1 0-.2 0-.1 .1-.2 .1-.3s.1-.3 .1-.6c0-.1 0-.2 .1-.2 0 0 0-.1 0-.1 .2-.8 .3-1.5 .5-2.3 1.3-6.3 2-12.7 2-19.4s-.7-13.1-2-19.3c0 0 0 0 0 0-.2-.8-.3-1.5-.5-2.3-.1-.4-.2-.8-.3-1.1 0 0 0 0 0 0-.2-.8-.4-1.4-.4-1.8 0-.2-.1-.3-.1-.5 0 0 0 0 0 0-.1-.4-.2-.7-.3-1.1-.2-.8-.4-1.5-.7-2.3 0 0 0 0 0 0-.9-3-2-5.9-3.2-8.8-9.7-23-28.1-41.4-51.1-51.1-11.5-4.9-24.1-7.5-37.4-7.5s-25.9 2.7-37.4 7.5c-23 9.7-41.4 28.1-51.1 51.1-1.2 2.9-2.3 5.8-3.2 8.8 0 0 0 0 0 0-.2 .7-.5 1.5-.7 2.3-.1 .4-.2 .7-.3 1.1 0 0 0 0 0 0-.1 .3-.2 .7-.3 1.1-.1 .4-.2 .8-.3 1.1 0 0 0 0 0 0-.1 .3-.2 .7-.3 1.1-.2 .8-.3 1.5-.5 2.3 0 0 0 0 0 0-1.3 6.2-2 12.7-2 19.3zm232-48a40 40 0 1 0 80 0 40 40 0 1 0 -80 0zm0 96a40 40 0 1 0 80 0 40 40 0 1 0 -80 0z", "M426.1 62.8L456.5 52.7 436.2-8 405.9 2.1 43.8 122.8C17.6 131.5 0 156 0 183.5L0 448.5c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64l-218.8 0 196.9-65.6zM64 192.5l384 0 0 256-384 0 0-256zm344 80a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm-40 136a40 40 0 1 0 0-80 40 40 0 1 0 0 80zm-176-128a40 40 0 1 1 0 80 40 40 0 1 1 0-80zm0 136a96 96 0 1 0 0-192 96 96 0 1 0 0 192z"]],
    "pencil-line": [576, 512, [], "e74f", ["M64 365.2l210.8-210.8 82.7 82.8-210.8 210.8-82.8 0 0-82.8z", "M389.5 0c67.7 0 122.5 54.8 122.5 122.5 0 32.5-12.9 63.7-35.9 86.6L173.2 512 0 512 0 338.7 302.9 35.9C325.8 12.9 357 0 389.5 0zM576 512l-288 0 0-64 288 0 0 64zM64 365.2l0 82.8 82.8 0 210.8-210.8-82.7-82.8-210.8 210.8zM389.5 64c-15.5 0-30.4 6.2-41.4 17.1l-33.7 33.7 82.7 82.8 33.7-33.7c11-11 17.1-25.9 17.1-41.4 0-32.3-26.2-58.5-58.5-58.5z"]],
    "pen-to-square": [512, 512, ["edit"], "f044", ["M192.4 237.3l0 50.7 50.7 0 198.6-198.6c14-14 14-36.7 0-50.7s-36.7-14-50.7 0L192.4 237.3z", "M391 38.6l-198.6 198.6 0 50.7 50.7 0 198.6-198.6c14-14 14-36.7 0-50.7s-36.7-14-50.7 0zM487-6.6c39 39 39 102.2 0 141.3l-208 208-9.4 9.4-141.3 0 0-141.3 9.4-9.4 208-208c39-39 102.2-39 141.3 0zM64.4 32l152.2 0-64 64-88.2 0 0 320 320 0 0-88.2 64-64 0 152.2c0 35.3-28.7 64-64 64l-320 0c-35.3 0-64-28.7-64-64L.4 96c0-35.3 28.7-64 64-64z"]],
    "circle-half-stroke": [512, 512, [9680, "adjust"], "f042", ["M64 256c0 71.3 38.9 133.6 96.7 166.7 19.3 11 40.6 18.8 63.3 22.6l0-378.6C133.2 81.9 64 160.9 64 256z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM224 66.7C133.2 81.9 64 160.9 64 256s69.2 174 160 189.3l0-378.6zm64 378.6C378.8 430 448 351.1 448 256S378.8 81.9 288 66.7l0 378.6z"]],
    "clock": [512, 512, [128339, "clock-four"], "f017", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zM228 116l56 0 0 112 96 0 0 56-124 0c-15.5 0-28-12.5-28-28l0-140z", "M448 256a192 192 0 1 0 -384 0 192 192 0 1 0 384 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zM284 144l0 84 96 0 0 56-124 0c-15.5 0-28-12.5-28-28l0-140 56 0 0 28z"]],
    "book": [448, 512, [128212], "f02d", ["M64 96l0 229.5c.4-.1 .8-.3 1.2-.4 9.7-3.3 20-5 30.8-5l160 0 0-256-160 0C78.3 64 64 78.3 64 96z", "M0 416L0 96C0 43 43 0 96 0l224 0 0 384-224 0c-17.7 0-32 14.3-32 32s14.3 32 32 32l288 0 0-384 64 0 0 448-352 0c-53 0-96-43-96-96zm128-96l128 0 0-256-160 0C78.3 64 64 78.3 64 96l0 229.5c.4-.1 .8-.3 1.2-.4 9.7-3.3 20-5 30.8-5l32 0z"]],
    "magnifying-glass-minus": [576, 512, ["search-minus"], "f010", ["M96.3 224a160 160 0 1 0 320 0 160 160 0 1 0 -320 0zm64-28l192 0 0 56-192 0 0-56z", "M256.3 0c123.7 0 224 100.3 224 224 0 50.3-16.6 96.7-44.6 134.1L557.5 480 512.3 525.3 390.4 403.4c-37.4 28-83.8 44.6-134.1 44.6-123.7 0-224-100.3-224-224S132.5 0 256.3 0zm0 64a160 160 0 1 0 0 320 160 160 0 1 0 0-320zm96 188l-192 0 0-56 192 0 0 56z"]],
    "paper-plane": [512, 512, [61913], "f1d8", ["M69 434.9L137.6 284 353 284 69 434.9z", "M137.6 284L353 284 69 434.9 137.6 284zM353 228L137.6 228 69 77.1 353 228zm144.9 4.5L64 2 0-32 0 80 80 256 0 432 0 544 64 510 497.9 279.5c8.7-4.6 14.1-13.7 14.1-23.5s-5.4-18.9-14.1-23.5z"]],
    "heart": [576, 512, [128153, 128154, 128155, 128156, 128420, 129293, 129294, 129505, 9829, 10084, 61578], "f004", ["M111.1 123.1c-36.1 36.1-36.1 94.6 0 130.8L288.4 431.2 465.8 253.8c36.1-36.1 36.1-94.6 0-130.8-36.1-36.1-94.7-36.1-130.7 0l-46.6 46.6-46.6-46.6c-36.1-36.1-94.7-36.1-130.7 0z", "M289.8 77.8c61.1-61.1 160.2-61.1 221.3 0 61.1 61.1 61.1 160.2 0 221.2L288.4 521.7 65.8 299.1C4.7 238 4.7 138.9 65.8 77.8s160.2-61.1 221.3 0l1.4 1.4 1.4-1.4zm176 45.2c-36.1-36.1-94.7-36.1-130.7 0l-46.6 46.6-46.6-46.6c-36.1-36.1-94.7-36.1-130.7 0s-36.1 94.6 0 130.8L288.4 431.2 465.8 253.8c36.1-36.1 36.1-94.6 0-130.8z"]],
    "battery-half": [640, 512, ["battery-3"], "f242", ["M64 128l0 256 416 0 0-256-416 0zm36 36l216 0 0 184-216 0 0-184z", "M480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l416 0zM64 384l416 0 0-256-416 0 0 256zm576-32l-64 0 0-192 64 0 0 192zm-324-4l-216 0 0-184 216 0 0 184zM156 292l104 0 0-72-104 0 0 72z"]],
    "font-awesome": [512, 512, [62501, 62694, "font-awesome-flag", "font-awesome-logo-full"], "f2b4", ["M96 128l0 224 317.2 0-37.2-86.8c-6.9-16.1-6.9-34.3 0-50.4L413.2 128 96 128z", "M64 0c26.5 0 48 21.5 48 48 0 5.6-1 11-2.8 16l312.2 0c32.3 0 58.6 26.2 58.6 58.6 0 5.9-.9 11.8-2.7 17.5l-2 5.6-40.5 94.4 40.5 94.4 2 5.6c1.8 5.7 2.7 11.6 2.7 17.5 0 32.3-26.2 58.6-58.6 58.6l-325.4 0 0 96-64 0 0-428.3C22.2 74.9 16 62.2 16 48 16 21.5 37.5 0 64 0zM96 352l317.2 0-37.2-86.8c-6.9-16.1-6.9-34.3 0-50.4L413.2 128 96 128 96 352z"]],
    "forward": [576, 512, [9193], "f04e", ["M96 139.2l0 233.5c42.8-38.9 85.6-77.8 128.4-116.8-42.8-38.9-85.6-77.8-128.4-116.8zm256 0l0 233.5c42.8-38.9 85.6-77.8 128.4-116.8-42.8-38.9-85.6-77.8-128.4-116.8z", "M64 64l-32 0 0 384 76.4 0 9.2-8.3 170.5-155 0 163.3 76.4 0 9.2-8.3 176-160C556.2 273.6 560 265 560 256s-3.8-17.6-10.5-23.7l-176-160-9.2-8.3-76.4 0 0 163.3-170.5-155-9.2-8.3-44.4 0zM224.4 256L96 372.8 96 139.2 224.4 256zm256 0L352 372.8 352 139.2 480.4 256z"]],
    "triangle": [576, 512, [9650], "f2ec", ["M91.8 416L288 121.7 484.2 416 91.8 416z", "M288 32c10.7 0 20.7 5.3 26.6 14.2l256 384c6.5 9.8 7.2 22.4 1.6 32.8S555.8 480 544 480L32 480c-11.8 0-22.7-6.5-28.2-16.9s-4.9-23 1.6-32.8l256-384 2.4-3.2c6-7 14.9-11.1 24.2-11.1zM91.8 416L484.2 416 288 121.7 91.8 416z"]],
    "lightbulb-slash": [640, 512, [], "f673", ["M273 73c55.4 55.4 110.8 110.8 166.2 166.2 5.8-14.6 9-30.5 9-47.2 0-48-26.5-89.9-65.6-111.8-.4-.2-.9-.5-1.3-.7 0 0-.1 0-.1-.1-3.6-2-7.4-3.8-11.2-5.4 0 0 0 0 0 0-.9-.4-1.9-.8-2.8-1.2 0 0 0 0-.1 0-1-.4-1.9-.7-2.9-1.1 0 0 0 0 0 0-2-.7-3.9-1.4-5.9-2-12-3.7-24.8-5.8-38.1-5.8-16.7 0-32.6 3.2-47.2 9z", "M621.5 512L576.3 557.2 19 0 64.3-45.3 621.5 512zM384.3 455.7l0 56.2-128 0 0-64 120.3 0 7.8 7.8zM344.5 416l-56.3 0c-33.2 0-60.4-25.2-63.7-57.5-55.3-31.9-93.3-90.6-96.1-158.5l216 216zM320.3 0c106 0 192 86 192 192 0 34.6-9.2 67-25.3 95l-47.8-47.8c5.8-14.6 9-30.5 9-47.2 0-70.7-57.3-128-128-128-16.7 0-32.6 3.2-47.2 9L225.2 25.2C253.2 9.2 285.7 0 320.3 0z"]],
    "landmark-dome": [512, 512, ["landmark-alt"], "f752", ["M65.6 192l380.8 0C434.5 101.7 357.3 32 263.7 32l-15.5 0C154.7 32 77.5 101.7 65.6 192z", "M248.3-32C111.2-32 0 79.2 0 216.3 0 235.6 13.8 251.6 32 255.2l0 128.8 64 0 0-128 64 0 0 128 64 0 0-128 64 0 0 128 64 0 0-128 64 0 0 128 64 0 0-128.7c18.2-3.6 32-19.7 32-39 0-137.1-111.2-248.3-248.3-248.3l-15.5 0zm0 64l15.5 0c93.5 0 170.8 69.7 182.7 160L65.6 192C77.5 101.7 154.7 32 248.3 32zM32 448l-32 0 0 64 512 0 0-64-480 0z"]],
    "moon-star": [512, 512, [], "e7c9", ["M64 256c0 106 86 192 192 192 44.9 0 86.3-15.4 119-41.3-123.7-32.3-215-144.8-215-278.7 0-13.5 .9-26.8 2.7-39.9-58.9 32.8-98.7 95.7-98.7 167.9z", "M375 406.7c-32.7 25.9-74.1 41.3-119 41.3-106 0-192-86-192-192 0-72.2 39.8-135.1 98.7-167.9-1.8 13-2.7 26.4-2.7 39.9 0 133.8 91.3 246.4 215 278.7zm48.1-56c-112-12.4-199.1-107.3-199.1-222.6 0-44.1 12.6-83.2 32-115.4 2.6-4.2 5.2-8.4 8.1-12.4-2.7-.1-5.4-.1-8.1-.1-24.5 0-48.3 3.5-70.7 9.9-107 30.7-185.3 129.3-185.3 246.1 0 141.4 114.6 256 256 256 80.9 0 153-37.5 199.9-96.1 16.5-20.6 29.9-43.8 39.4-68.9-15.3 3.3-31.1 5-47.4 5-8.4 0-16.7-.5-24.9-1.4zM388 32l0 68-68 0 0 56 68 0 0 68 56 0 0-68 68 0 0-56-68 0 0-68-56 0z"]],
    "strikethrough": [448, 512, [], "f0cc", ["", "M96 352c0 35.3 28.7 64 64 64l136.1 0c30.9 0 55.9-25 55.9-55.9 0-2.7-.2-5.4-.6-8.1l64.3 0c.2 2.7 .3 5.4 .3 8.1 0 66.2-53.7 119.9-119.9 119.9L160 480C89.3 480 32 422.7 32 352l64 0zm295.9-64L0 288 0 224 56.1 224C40.9 203.8 32 178.7 32 151.9 32 85.7 85.7 32 151.9 32L288 32c70.7 0 128 57.3 128 128l-64 0c0-35.3-28.7-64-64-64L151.9 96c-30.9 0-55.9 25-55.9 55.9 0 26.7 18.8 49.6 45 54.8l86.2 17.2 220.8 0 0 64-56.1 0z"]],
    "shield-check": [448, 512, [], "f2f7", ["M64 119l160-53.3 160 53.3 0 146.3c0 60.6-34.2 116-88.4 143.1l-71.6 35.8-71.6-35.8C98.2 381.3 64 325.9 64 265.3L64 119zm40.4 153c8.5 8.5 31.1 31.1 67.8 67.8 10.9 10.9 28.7 10.9 39.6 0l112-112 19.8-19.8-39.6-39.6-19.8 19.8-92.2 92.2c-20.2-20.2-36.2-36.2-48-48L104.4 272z", "M234.1 1.6L404.2 58.3C430.4 67 448 91.5 448 119l0 146.3c0 84.8-47.9 162.4-123.8 200.3L224 515.8 123.8 465.7C47.9 427.7 0 350.2 0 265.3L0 119C0 91.5 17.6 67 43.8 58.3L213.9 1.6 224-1.7 234.1 1.6zM64 119l0 146.3c0 60.6 34.2 116 88.4 143.1l71.6 35.8 71.6-35.8c54.2-27.1 88.4-82.5 88.4-143.1L384 119 224 65.7 64 119zm279.6 89l-19.8 19.8-112 112c-10.9 10.9-28.7 10.9-39.6 0-36.7-36.7-59.3-59.3-67.8-67.8L144 232.4c11.8 11.8 27.8 27.8 48 48l92.2-92.2 19.8-19.8 39.6 39.6z"]],
    "arrow-down-to-bracket": [448, 512, [], "e094", ["", "M64 320l0 96c0 17.7 14.3 32 32 32l256 0c17.7 0 32-14.3 32-32l0-96 64 0 0 96c0 53-43 96-96 96L96 512c-53 0-96-43-96-96l0-96 64 0zm192-77.3l96-96 45.3 45.3-150.6 150.6-2.4 2.2c-12.6 10.2-31.1 9.5-42.8-2.2L50.8 192 96 146.7 192 242.7 192 0 256 0 256 242.7z"]],
    "star-half": [576, 512, [61731], "f089", ["M147.7 242.3c20.1-3.2 40.2-6.5 60.3-9.7 14.1-2.3 27-8.7 37.3-18.1 1-.9 2-1.9 3-2.9 4.9-5 9-10.8 12.3-17.1l27.9-54.3 0 232.5 0 0 0 0c-6.7 0-13.4 .9-19.9 2.8-.6 .2-1.1 .3-1.7 .5-2.4 .7-4.7 1.6-7 2.6l-3.9 1.8-54.5 27.5 9.3-60.3c3.5-22.6-3.9-45.6-20.1-61.8l-43-43.3z", "M288.4 140l-27.9 54.3c-10.5 20.3-29.9 34.5-52.5 38.2l-60.3 9.8 43 43.3c16.1 16.2 23.6 39.2 20.1 61.8l-9.3 60.3 54.5-27.5 3.9-1.8c9.1-3.9 18.9-5.9 28.6-5.9l0 64c-1.2 0-2.5 .3-3.6 .8L119.1 521 147.5 337.6c.4-2.5-.4-5.1-2.2-6.9L14.5 199 197.7 169.3c1.9-.3 3.6-1.3 4.8-2.7l1.1-1.5 84.8-165.1 0 140z"]],
    "arrow-down-to-line": [448, 512, ["arrow-to-bottom"], "f33d", ["", "M448 512l-448 0 0-64 448 0 0 64zM256 242.8l96-96 45.3 45.2-150.6 150.6-2.4 2.2c-12.6 10.2-31.1 9.5-42.8-2.2L50.8 192 96 146.8 192 242.8 192 0 256 0 256 242.8z"]],
    "fire": [448, 512, [128293], "f06d", ["M64 288c0 44.9 18.5 85.5 48.3 114.5-.3-4.5-.5-10.6 .2-17.8l0 0c.3-3.4 .8-6.8 1.4-10.1 .1-.5 .2-.9 .2-1.2l0 0c.2-.9 .3-1.5 .4-1.9 0-.2 .1-.4 .1-.5l0-.1c.2-.9 .4-1.5 .5-1.9 0-.2 .1-.4 .1-.5 0 0 0 0 0-.1 .1-.4 .2-.8 .3-1.2l0 0c.2-.8 .4-1.6 .7-2.4 .3-.9 .5-1.7 .7-2.4 .3-.8 .5-1.6 .8-2.4l0-.1c.5-1.6 1.1-3.2 1.8-4.8 5-12.6 12.3-24.3 21.7-34.4 30.6-32.8 58.2-62.3 82.7-88.6 24.5 26.3 52.1 55.8 82.7 88.6 9.4 10.1 16.8 21.8 21.7 34.4 .6 1.6 1.2 3.2 1.8 4.8l0 .1c.3 .8 .5 1.6 .8 2.4 .5 1.5 1 3.3 1.4 4.9l0 0c.1 .4 .2 .8 .3 1.2 0 0 0 0 0 .1 .1 .3 .2 .7 .3 1.2 .1 .4 .2 .8 .3 1.2l0 .1c.1 .3 .2 .7 .3 1.2 .1 .4 .2 .8 .3 1.2l0 0c.1 .3 .2 .8 .2 1.2 .3 1.7 .6 3.4 .8 5 .1 .8 .2 1.7 .3 2.5s.2 1.7 .3 2.5l0 0c.7 7.3 .5 13.3 .2 17.8 3.7-3.6 7.3-7.4 10.6-11.4 0 0 0 0 0-.1 .4-.5 .8-.9 1.2-1.4 9.5-11.6 17.4-24.5 23.4-38.4 8.3-19.4 13-40.7 13-63.2 0-48.8-17.3-95.9-48.5-133-5.4 5.4-26.5 26.5-63.4 63.4-26.5-29.1-63.8-70.2-112.1-123.3-12.6 13.8-25.2 27.7-37.7 41.5-37.4 41.1-58.3 95.5-58.3 151.3z", "M203.2 47.6c16.1 17.7 39.8 43.8 71 78.1 8.9-8.9 24-24 45.3-45.3l16.4-16.4 32.8 32.8 0 0c4.1 4.2 8.2 8.4 12 12.8 43.2 49.2 67.2 112.5 67.2 178.3 0 123.7-100.3 224-224 224S0 411.7 0 288C0 216.4 26.7 146.6 74.9 93.6 102.6 63.2 130.9 32 160 0l43.2 47.6zM319.5 171l-47.5 47.5C245.6 189.3 208.2 148.2 160 95.1l-37.7 41.5c-37.4 41.1-58.3 95.5-58.3 151.3 0 44.9 18.5 85.5 48.3 114.5-.2-2.5-.3-5-.3-7.5 0-27.6 10.5-54.2 29.3-74.4 30.6-32.8 58.2-62.3 82.7-88.6 24.5 26.3 52.1 55.8 82.7 88.6 18.8 20.2 29.3 46.8 29.3 74.4 0 2.5-.1 5-.3 7.5 29.8-29.1 48.3-69.6 48.3-114.5 0-48.8-17.3-95.9-48.5-133L319.5 171zM224 448c2.3 0 4.7-.1 7-.2 27.4-2.1 49-24.9 49-52.9 0-13.4-5.1-26.4-14.3-36.2l-41.7-44.7-41.7 44.7c-9.2 9.8-14.3 22.7-14.3 36.2 0 27.9 21.6 50.8 49 52.9 2.3 .1 4.7 .2 7 .2z"]],
    "magnifying-glass-plus": [576, 512, ["search-plus"], "f00e", ["M96.3 224a160 160 0 1 0 320 0 160 160 0 1 0 -320 0zm64-28l68 0 0-68 56 0 0 68 68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56z", "M256.3 0c123.7 0 224 100.3 224 224 0 50.3-16.6 96.7-44.6 134.1L557.5 480 512.3 525.3 390.4 403.4c-37.4 28-83.8 44.6-134.1 44.6-123.7 0-224-100.3-224-224S132.5 0 256.3 0zm0 64a160 160 0 1 0 0 320 160 160 0 1 0 0-320zm28 132l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"]],
    "rectangle-vertical": [448, 512, ["rectangle-portrait"], "f2fb", ["M64 64l0 384 320 0 0-384-320 0z", "M384 0c35.3 0 64 28.7 64 64l0 384c0 33.1-25.2 60.4-57.5 63.7l-6.5 .3-320 0-6.5-.3C25.2 508.4 0 481.1 0 448L0 64C0 28.7 28.7 0 64 0L384 0zM64 448l320 0 0-384-320 0 0 384z"]],
    "burger": [512, 512, ["hamburger"], "f805", ["M64 192l384 0c0-33.3-12.7-63.6-33.5-86.3-4.1 12.9-16.2 22.3-30.5 22.3-17.7 0-32-14.3-32-32 0-9.8 4.4-18.6 11.4-24.5-13.5-4.9-28.1-7.5-43.4-7.5l-32 0c0 17.7-14.3 32-32 32s-32-14.3-32-32l-32 0c-15.2 0-29.8 2.7-43.4 7.5 7 5.9 11.4 14.7 11.4 24.5 0 17.7-14.3 32-32 32-14.3 0-26.4-9.4-30.5-22.3-20.8 22.8-33.5 53.1-33.5 86.3zm0 192c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64L64 384z", "M320 0C426 0 512 86 512 192l-64 0c0-70.7-57.3-128-128-128L192 64C121.3 64 64 121.3 64 192L0 192C0 86 86 0 192 0L320 0zm64 512l-256 0C57.3 512 0 454.7 0 384l64 0c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l64 0c0 70.7-57.3 128-128 128zM512 256l0 64-512 0 0-64 512 0z"]],
    "print": [512, 512, [128424, 128438, 9113], "f02f", ["M64 192l384 0 0 224-32 0 0-128-320 0 0 128-32 0 0-224z", "M416 512l-320 0 0-224 320 0 0 224zM160 448l192 0 0-96-192 0 0 96zM416 128l32 0c35.3 0 64 28.7 64 64l0 160c0 35.3-28.7 64-64 64l0-224-384 0 0 224C30.9 416 3.6 390.8 .3 358.5L0 352 0 192c0-35.3 28.7-64 64-64l32 0 0-128 320 0 0 128zm-256 0l192 0 0-64-192 0 0 64z"]],
    "users": [640, 512, [], "f0c0", ["M64 480l0 32 320 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96zm96-352a64 64 0 1 0 128 0 64 64 0 1 0 -128 0z", "M288 320c88.4 0 160 71.6 160 160l0 32-64 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96l0 32-64 0 0-32c0-88.4 71.6-160 160-160l128 0zm192 0c88.4 0 160 71.6 160 160l0 32-64 0 0-32c0-45.5-31.6-83.5-74.1-93.4-8.4-24.9-21.7-47.5-38.8-66.6l16.9 0zM224 256a128 128 0 1 1 0-256 128 128 0 1 1 0 256zM416 0c70.7 0 128 57.3 128 128S486.7 256 416 256c-15 0-29.3-2.6-42.7-7.3 13.8-17 24.7-36.5 32-57.6 3.5 .6 7 1 10.7 1 35.3 0 64-28.7 64-64s-28.7-64-64-64c-3.6 0-7.2 .4-10.7 .9-7.3-21.1-18.2-40.6-32-57.6 13.4-4.7 27.7-7.3 42.7-7.3zM224 64a64 64 0 1 0 0 128 64 64 0 1 0 0-128z"]],
    "alarm-clock": [640, 512, [9200], "f34e", ["M128.3 256a191.7 191.7 0 1 0 383.5 0 191.7 191.7 0 1 0 -383.5 0zm164-140l56 0 0 112 96 0 0 56-124 0c-15.5 0-28-12.5-28-28l0-140z", "M319.7 512a256 256 0 1 1 .5-512 256 256 0 1 1 -.5 512zm.5-448a192 192 0 1 0 -.5 384 192 192 0 1 0 .5-384zm28 164l96 0 0 56-124 0c-15.5 0-28-12.5-28-28l0-140 56 0 0 112zM173.5 0L64.3 109.2 19 64 128.3-45.2 173.5 0zm448 64L576.3 109.2 467 0 512.3-45.2 621.5 64z"]],
    "database": [448, 512, [], "f1c0", ["M64 97.9l0 72C100 185 157.1 196 224 196s124-11 160-26.1l0-72C357.3 83.9 301.9 64 224 64S90.7 83.9 64 97.9zm0 131.6l0 68.3C100 313 157.1 324 224 324s124-11 160-26.1l0-68.3C340.1 243.9 283.7 252 224 252s-116.1-8.1-160-22.5zm0 128l0 56.6c26.7 14 82.1 33.9 160 33.9s133.3-19.9 160-33.9l0-56.6C340.1 371.9 283.7 380 224 380s-116.1-8.1-160-22.5z", "M224 0c91.7 0 159.1 24.1 194 43.5 20.7 11.5 30 33 30 52.5l0 320c0 19.5-9.2 41-30 52.5-34.9 19.4-102.3 43.5-194 43.5-86 0-150.6-21.2-187.1-39.8L30 468.5C9.2 457 0 435.5 0 416L0 96C0 76.5 9.2 55 30 43.5l6.9-3.7C73.4 21.2 138 0 224 0zM384 357.5C340.1 371.9 283.7 380 224 380s-116.1-8.1-160-22.5l0 56.6c26.7 14 82.1 33.9 160 33.9s133.3-19.9 160-33.9l0-56.6zm0-128C340.1 243.9 283.7 252 224 252s-116.1-8.1-160-22.5l0 68.3C100 313 157.1 324 224 324s124-11 160-26.1l0-68.3zM224 64C146.1 64 90.7 83.9 64 97.9l0 72C100 185 157.1 196 224 196s124-11 160-26.1l0-72C357.3 83.9 301.9 64 224 64z"]],
    "newspaper": [576, 512, [128240], "f1ea", ["M186.4 416L480 416c17.7 0 32-14.3 32-32l0-288-320 0 0 288c0 11.2-2 22-5.6 32zM256 164l192 0 0 56-192 0 0-56zm0 128l192 0 0 56-192 0 0-56z", "M576 32l0 352c0 53-43 96-96 96L96 480c-53 0-96-43-96-96l0-288 64 0 0 288c0 17.7 14.3 32 32 32s32-14.3 32-32l0-352 448 0zM192 96l0 288c0 11.2-2 22-5.6 32L480 416c17.7 0 32-14.3 32-32l0-288-320 0zM448 348l-192 0 0-56 192 0 0 56zm0-128l-192 0 0-56 192 0 0 56z"]],
    "location-arrow": [512, 512, [], "f124", ["M78.8 224L423.4 88.6 288 433.2 288 224 78.8 224z", "M468.3 2.2c11.8-4.6 25.3-1.8 34.3 7.2s11.8 22.5 7.2 34.3l-184 468.3-101.8 0 0-224-224 0 0-101.8 468.3-184zM78.8 224L288 224 288 433.2 423.4 88.6 78.8 224z"]],
    "rectangle-code": [640, 512, [], "e322", ["M160 288c0 42.7 0 85.3 0 128 128 0 256 0 384 0 0-106.7 0-213.3 0-320-53.3 0-106.7 0-160 0 0 64 0 128 0 192-74.7 0-149.3 0-224 0z", "M544 32c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64l-384 0c-33.1 0-60.4-25.2-63.7-57.5l-.3-6.5 0-128 64 0 0 128 384 0 0-320-160 0 0-64 160 0zM135.6 64c-9.1 9.1-30.4 30.5-64 64 33.5 33.5 54.8 54.9 64 64l-39.6 39.6-19.8-19.8-64-64c-10.9-10.9-10.9-28.7 0-39.6l64-64 19.8-19.8 39.6 39.6zM243.8 44.2l64 64c10.9 10.9 10.9 28.7 0 39.6l-64 64-19.8 19.8-39.6-39.6c9.1-9.1 30.4-30.5 64-64-33.5-33.5-54.8-54.9-64-64L224 24.4 243.8 44.2z"]],
    "arrow-right-to-bracket": [512, 512, ["sign-in"], "f090", ["", "M416 32c53 0 96 43 96 96l0 256c0 53-43 96-96 96l-96 0 0-64 96 0c17.7 0 32-14.3 32-32l0-256c0-17.7-14.3-32-32-32l-96 0 0-64 96 0zM342.6 233.4l2.2 2.4c10.3 12.6 9.5 31.1-2.2 42.8l-150.6 150.6-45.2-45.2 96-96-242.8 0 0-64 242.8 0-96-96 45.2-45.3 150.6 150.6z"]],
    "folder-check": [512, 512, [], "e64e", ["M64 96l0 320 384 0 0-256-186.5 0-64-64-133.5 0zm72.4 208L176 264.4c11.8 11.8 27.8 27.8 48 48l92.2-92.2 19.8-19.8 39.6 39.6-19.8 19.8-112 112c-10.9 10.9-28.7 10.9-39.6 0-36.7-36.7-59.3-59.3-67.8-67.8z", "M288 96l160 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l160 0 64 64zM64 416l384 0 0-256-186.5 0-64-64-133.5 0 0 320zM375.6 240l-19.8 19.8-112 112c-10.9 10.9-28.7 10.9-39.6 0-36.7-36.7-59.3-59.3-67.8-67.8L176 264.4c11.8 11.8 27.8 27.8 48 48l92.2-92.2 19.8-19.8 39.6 39.6z"]],
    "video-slash": [640, 512, [], "f4e2", ["M96.3 167.8L344.5 416c-82.7 0-165.5 0-248.2 0l0-248.2zM296 96c29.4 0 58.8 0 88.2 0 0 29.4 0 58.8 0 88.2L296 96z", "M621.5 512L576.3 557.2 19 0 64.3-45.3 621.5 512zM96.3 167.7l0 248.3 248.3 0 60.5 60.5c-4.5 1.6-9.3 2.7-14.2 3.2l-6.5 .3-288 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1l-.3-6.5 0-312.3 64 64zM384.3 32c35.3 0 64 28.7 64 64l0 45.7 160-45.7 0 312.3-64-64 0-163.4-96 27.4 0 40-64-64 0-88.2-88.3 0-64-64 152.3 0z"]],
    "comment": [512, 512, [128489, 61669], "f075", ["M64 256c0 31.9 11.3 62.3 32.2 88.3L112.7 365c-1.8 15.9-4.1 36.8-7 62.6l68.8-17.2 15-3.7 15.1 3.5c16.4 3.8 33.6 5.9 51.4 5.9 114.3 0 192-79.4 192-160S370.3 96 256 96 64 175.4 64 256z", "M256 32c141.4 0 256 100.3 256 224S397.4 480 256 480c-22.8 0-44.9-2.7-65.9-7.6L32 512 46.2 384.3C17.1 347.9 0 303.7 0 256 0 132.3 114.6 32 256 32zm0 64c-114.3 0-192 79.4-192 160 0 31.9 11.3 62.3 32.2 88.3L112.7 365c-1.8 15.9-4.1 36.8-7 62.6l68.8-17.2 15-3.7 15.1 3.5c16.4 3.8 33.6 5.9 51.4 5.9 114.3 0 192-79.4 192-160S370.3 96 256 96z"]],
    "file-check": [384, 512, [], "f316", ["M64 64l0 384 256 0 0-293.5-90.5-90.5-165.5 0zM80.4 312L120 272.4c13.1 13.1 26.5 26.4 40 40l76.2-76.2 19.8-19.8 39.6 39.6-19.8 19.8-96 96c-10.9 10.9-28.7 10.9-39.6 0-30-30-50-50-59.8-59.8z", "M384 128l0 320-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-256 0c-35.3 0-64-28.7-64-64L0 64C0 28.7 28.7 0 64 0L256 0 384 128zM64 448l256 0 0-293.5-90.5-90.5-165.5 0 0 384zM295.6 256l-19.8 19.8-96 96c-10.9 10.9-28.7 10.9-39.6 0-30-30-50-50-59.8-59.8L120 272.4c13.1 13.1 26.5 26.4 40 40l76.2-76.2 19.8-19.8 39.6 39.6z"]],
    "video": [576, 512, ["video-camera"], "f03d", ["M64 96l0 320 288 0 0-320-288 0z", "M64 96l0 320 288 0 0-320-288 0zM416 370.3l0 45.7c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l288 0c35.3 0 64 28.7 64 64l0 45.7c69.3-19.8 122.7-35 160-45.7l0 320c-37.3-10.7-90.7-25.9-160-45.7zm0-66.6l96 27.4 0-150.3-96 27.4 0 95.4z"]],
    "calendar-plus": [448, 512, [], "f271", ["M64 96l0 320 320 0 0-320-320 0zm64 132l68 0 0-68 56 0 0 68 68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56z", "M160 32l128 0 0-64 64 0 0 64 32 0c35.3 0 64 28.7 64 64l0 320-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-320 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 416 0 96C0 60.7 28.7 32 64 32l32 0 0-64 64 0 0 64zM64 416l320 0 0-320-320 0 0 320zM252 228l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"]],
    "wheelchair-move": [448, 512, ["wheelchair-alt"], "e2ce", ["M64 384c0-49.5 37.5-90.2 85.6-95.4 .4 50 40.5 95.4 96.1 95.4l10.3 0c0 53-43 96-96 96s-96-43-96-96z", "M171 224.4l-9.7 17.9c-8.2 15.1-11.8 30.9-11.7 46.3-48.1 5.2-85.6 45.9-85.6 95.4 0 53 43 96 96 96s96-43 96-96l64 0c0 88.4-71.6 160-160 160S0 472.4 0 384 71.6 224 160 224c3.7 0 7.3 .2 11 .4zM255.7 96c42.4 0 69.4 45.3 49.2 82.7L245.7 288 384 288c16.1 0 29.7 12 31.8 28l20 159.8-63.5 7.9c-1.2-9.8-6.7-53.7-16.5-131.7l-110 0c-48.5 0-79.4-51.8-56.3-94.5l52.8-97.5-62.9 0c-6.3 0-12.5 1.9-17.8 5.4l-58.5 39-35.5-53.2 58.5-39C141.9 101.6 160.4 96 179.4 96l76.3 0zM336 96a48 48 0 1 1 0-96 48 48 0 1 1 0 96z"]],
    "bold": [384, 512, [], "f032", ["M128 96l96 0c35.3 0 64 28.7 64 64s-28.6 64-64 64l-96 0 0-128zm0 192l128 0c35.3 0 64 28.7 64 64s-28.7 64-64 64l-128 0 0-128z", "M288 160c0-35.3-28.7-64-64-64l-96 0 0 128 96 0c35.3 0 64-28.7 64-64zM64 288l0-192-64 0 0-64 224 0c70.7 0 128 57.3 128 128 0 31.3-11.3 60.1-30 82.3 37.1 22.4 62 63.1 62 109.7 0 70.7-57.3 128-128 128l-256 0 0-64 64 0 0-128zm64 128l128 0c35.3 0 64-28.7 64-64s-28.7-64-64-64l-128 0 0 128z"]],
    "clipboard": [448, 512, [128203], "f328", ["M64 96l0 352 320 0 0-352-64 0 0 64-192 0 0-64-64 0z", "M264 64c0-22.1-17.9-40-40-40s-40 17.9-40 40l0 40 80 0 0-40zM133.5 32C146.6-5.3 182.2-32 224-32s77.4 26.7 90.5 64L384 32c35.3 0 64 28.7 64 64l0 352c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l69.5 0zM320 96l0 64-192 0 0-64-64 0 0 352 320 0 0-352-64 0z"]],
    "laptop": [576, 512, [128187], "f109", ["M128 96l320 0 0 256-320 0 0-256z", "M576 424c0 30.9-25.1 56-56 56L56 480c-30.9 0-56-25.1-56-56l0-8 576 0 0 8zM448 32c35.3 0 64 28.7 64 64l0 256-64 0 0-256-320 0 0 256-64 0 0-256c0-35.3 28.7-64 64-64l320 0z"]],
    "user-xmark": [640, 512, ["user-times"], "f235", ["M64 480l0 32 320 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96zm96-352a64 64 0 1 0 128 0 64 64 0 1 0 -128 0z", "M288 320c88.4 0 160 71.6 160 160l0 32-64 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96l0 32-64 0 0-32c0-88.4 71.6-160 160-160l128 0zM639.7 167.9l-56.1 56.1 56.1 56.1-39.6 39.6-56.1-56.1-56.1 56.1-39.6-39.6 56.1-56.1-56.1-56.1 39.6-39.6 56.1 56.1 56.1-56.1 39.6 39.6zM224 256a128 128 0 1 1 0-256 128 128 0 1 1 0 256zm0-192a64 64 0 1 0 0 128 64 64 0 1 0 0-128z"]],
    "joystick": [512, 512, [128377], "f8c5", ["M64 352l0 96 384 0 0-96-384 0z", "M192 64a48 48 0 1 0 0 96 48 48 0 1 0 0-96zm112 48c0 50.7-33.7 93.6-80 107.4l0 68.6 96 0 0-32 64 0 0 32 64 0 6.5 .3c32.3 3.3 57.5 30.5 57.5 63.7l0 96-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-384 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 448 0 352c0-33.1 25.2-60.4 57.5-63.7l6.5-.3 96 0 0-68.6C113.7 205.6 80 162.7 80 112 80 50.1 130.1 0 192 0S304 50.1 304 112zM448 448l0-96-384 0 0 96 384 0z"]],
    "battery-three-quarters": [640, 512, ["battery-4"], "f241", ["M64 128l0 256 416 0 0-256-416 0zm36 36l280 0 0 184-280 0 0-184z", "M480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l416 0zM64 384l416 0 0-256-416 0 0 256zm576-32l-64 0 0-192 64 0 0 192zm-260-4l-280 0 0-184 280 0 0 184zM156 292l168 0 0-72-168 0 0 72z"]],
    "thumbs-down": [512, 512, [128078, 61576], "f165", ["M192 96l159 0c26.2 0 49.7 15.9 59.4 40.2l37.6 93.9 0 57.8c0 17.7-14.3 32-32 32l-160 0 0 122.9-64-115.2 0-231.7z", "M240 512l-18.8 0-9.1-16.5-79.8-143.7c-1.4 .1-2.8 .1-4.2 .1l-64 0c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l287 0c52.3 0 99.4 31.9 118.8 80.5l39.9 99.7 2.3 5.7 0 70.2c0 53-43 96-96 96l-96 0 0 64c0 35.3-28.7 64-64 64l-16 0zM128 96l-64 0 0 192 64 0 0-192zm64 0l0 231.7 64 115.2 0-122.9 160 0c17.7 0 32-14.3 32-32l0-57.8-37.6-93.9C400.7 111.9 377.2 96 351 96L192 96z"]],
    "utensils": [512, 512, [127860, 61685, "cutlery"], "f2e7", ["M64 128c0 35.3 28.7 64 64 64s64-28.7 64-64c-16 0-48 0-96 0-10.7 0-21.3 0-32 0zm320 64l0 96 64 0 0-206.9c-38.3 22.1-64 63.5-64 110.9z", "M64 0l0 128c0 35.3 28.7 64 64 64s64-28.7 64-64l0-128 64 0 0 128c0 59.6-40.8 109.8-96 124l0 260-64 0 0-260C40.8 237.8 0 187.6 0 128L0 0 64 0zm96 0l0 128-64 0 0-128 64 0zM448 10.9C468 3.8 489.6 0 512 0l0 512-64 0 0-160-64 0c-35.3 0-64-28.7-64-64l0-96c0-83.6 53.4-154.7 128-181.1zM448 240l0-158.9c-38.3 22.1-64 63.5-64 110.9l0 96 64 0 0-48z"]],
    "envelope-open": [512, 512, [62135], "f2b6", ["M64 225.3l0 222.7 384 0 0-222.7-175.7 125.5-16.3 11.6-16.3-11.6C181.1 308.9 122.6 267.1 64 225.3z", "M448 225.3l-175.7 125.5-16.3 11.6-16.3-11.6-175.7-125.5 0 222.7 384 0 0-222.7zm-5.2-65.1L256 43.5 69.2 160.2 256 293.6 442.8 160.2zm-412.7-51L256-32 481.9 109.2c18.7 11.7 30.1 32.2 30.1 54.3L512 448c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 163.5c0-22.1 11.4-42.6 30.1-54.3z"]],
    "voicemail": [640, 512, [], "f897", ["M64 240a80 80 0 1 0 160 0 80 80 0 1 0 -160 0zm352 0a80 80 0 1 0 160 0 80 80 0 1 0 -160 0z", "M144 160a80 80 0 1 1 0 160 80 80 0 1 1 0-160zM263.8 320c15.3-22.9 24.2-50.4 24.2-80 0-79.5-64.5-144-144-144S0 160.5 0 240 64.5 384 144 384l352 0c79.5 0 144-64.5 144-144S575.5 96 496 96 352 160.5 352 240c0 29.6 8.9 57.1 24.2 80l-112.5 0zM496 160a80 80 0 1 1 0 160 80 80 0 1 1 0-160z"]],
    "microphone": [448, 512, [], "f130", ["M192 96l0 128c0 17.7 14.3 32 32 32s32-14.3 32-32l0-128c0-17.7-14.3-32-32-32s-32 14.3-32 32z", "M256 224l0-128c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 128c0 17.7 14.3 32 32 32s32-14.3 32-32zM224 0c53 0 96 43 96 96l0 128c0 53-43 96-96 96s-96-43-96-96l0-128c0-53 43-96 96-96zM64 192l0 32c0 88.4 71.6 160 160 160s160-71.6 160-160l0-32 64 0 0 32c0 112.8-83.4 206.2-192 221.7l0 66.3-64 0 0-66.3C83.4 430.2 0 336.8 0 224l0-32 64 0z"]],
    "crown": [512, 512, [128081], "f521", ["M83.6 164.7l34.5 241.5 64.3-10.7c48.8-8.1 98.5-8.1 147.3 0l64.3 10.7 34.5-241.5c-14 9.3-35.8 23.8-65.2 43.5-19-16.2-54.7-46.9-107.2-91.9-52.5 45-88.2 75.6-107.2 91.9-29.5-19.6-51.2-34.1-65.2-43.5z", "M363.2 208.1c-19-16.2-54.7-46.9-107.2-91.9-52.5 45-88.2 75.6-107.2 91.9-29.5-19.6-51.2-34.1-65.2-43.5l34.5 241.5 64.3-10.7c48.8-8.1 98.5-8.1 147.3 0l64.3 10.7 34.5-241.5c-14 9.4-35.8 23.9-65.2 43.5zM440.5 79.6L512 32c-3 21.1-21.3 148.9-54.7 383.2-5.1 35.6-38.4 60-73.9 54.1l-64.3-10.7c-41.8-7-84.5-7-126.3 0l-64.3 10.7C93.2 475.1 59.8 450.7 54.7 415.2 21.3 180.9 3 53.2 0 32 47.5 63.6 95.5 95.6 144 128l112-96 112 96 72.5-48.4z"]],
    "arrow-up-wide-short": [640, 512, ["sort-amount-up"], "f161", ["", "M182.9 41.4C170.4 28.9 150.1 28.9 137.6 41.4 61.4 117.6 21.9 157.1 19 160l45.3 45.3c12-12 33.3-33.3 64-64l0 338.7 64 0 0-338.7c30.7 30.7 52 52 64 64L301.5 160c-2.9-2.9-42.4-42.4-118.6-118.6zM576.3 128l32 0 0-64-288 0 0 64 256 0zm-96 320l0-64-160 0 0 64 160 0zm32-160l32 0 0-64-224 0 0 64 192 0z"]],
    "sun": [576, 512, [9728], "f185", ["M90.5 256c25.8 25.8 43.7 43.7 53.5 53.5l0 90.5c48.9 0 79.1 0 90.5 0 9.8 9.8 27.7 27.7 53.5 53.5 25.8-25.8 43.7-43.7 53.5-53.5 11.4 0 41.6 0 90.5 0l0-90.5c9.8-9.8 27.7-27.7 53.5-53.5-25.8-25.8-43.7-43.7-53.5-53.5l0-90.5c-48.9 0-79.1 0-90.5 0-9.8-9.8-27.7-27.7-53.5-53.5-25.8 25.8-43.7 43.7-53.5 53.5-11.4 0-41.6 0-90.5 0l0 90.5c-9.8 9.8-27.7 27.7-53.5 53.5zm93.5-1.4c0-.2 0-.4 0-.6 0 0 0 0 0 0 0-.2 0-.4 0-.6 0 0 0 0 0-.1 0-.2 0-.4 0-.6 0 0 0 0 0 0 0-.2 0-.4 0-.6 0 0 0 0 0-.1 0-.2 0-.4 0-.6 0 0 0 0 0-.1 0-.2 0-.4 0-.6 0 0 0-.1 0-.1 0-.2 0-.4 0-.6 0 0 0 0 0-.1 0-.2 0-.4 0-.6 0 0 0-.1 0-.1 0-.2 0-.4 0-.5 0 0 0-.1 0-.1 0-.2 0-.4 0-.5 0-.1 0-.1 0-.2 0-.2 0-.3 0-.5 0 0 0-.1 0-.1 0-.2 0-.3 0-.5 0-.1 0-.1 0-.2 0-.2 0-.3 0-.5 0 0 0-.1 0-.1 0-.4 .1-.6 .1-.7 0-.2 0-.3 0-.5 0 0 0-.1 0-.2 0-.3 .1-.6 .1-.7 0-.3 .1-.5 .1-.6 .1-.7 .1-.8 .1-1.1 0-.1 0-.3 .1-.6 0-.1 0-.2 0-.3 0-.1 0-.3 .1-.4 0-.1 0-.1 0-.2 0-.1 0-.2 .1-.4s0-.3 .1-.4c0-.1 0-.2 .1-.3 0-.1 0-.2 0-.2 0-.1 0-.2 .1-.3s0-.2 .1-.4c0-.1 0-.2 .1-.3 0-.1 0-.2 0-.3s0-.2 .1-.3c0-.1 .1-.3 .1-.4 0-.1 0-.2 0-.3 0-.1 0-.2 .1-.3 0-.1 0-.2 0-.3 0-.1 .1-.3 .1-.4 0-.1 0-.1 0-.2 0-.1 0-.2 .1-.3 0-.1 0-.1 0-.2 0-.2 .1-.4 .1-.6 0-.1 0-.1 0-.2 0-.1 .1-.3 .1-.4 0 0 0-.1 0-.1 0-.2 .1-.4 .1-.6 0 0 0 0 0-.1 10.3-46.6 51.9-81.4 101.5-81.4 49.9 0 91.6 35.2 101.7 82.1 0 0 0 0 0 .1 0 .2 .1 .3 .1 .5 0 0 0 .1 0 .1 0 .2 .1 .4 .1 .6 0 .1 0 .1 0 .2 0 .1 .1 .3 .1 .4 0 .1 0 .1 0 .2 0 .2 .1 .3 .1 .5 0 .1 0 .2 0 .2 0 .1 0 .2 .1 .3 0 .1 0 .2 0 .2 0 .2 .1 .3 .1 .5 0 .1 0 .2 0 .3s0 .2 .1 .3 0 .2 0 .3c0 .1 0 .2 .1 .4 0 .1 0 .2 .1 .3 0 .1 0 .2 0 .3 0 .1 0 .2 .1 .3 0 .1 0 .3 .1 .4 0 .1 0 .2 .1 .4 0 .1 0 .2 0 .2 0 .1 0 .2 .1 .4 0 .1 0 .2 0 .3 0 .1 0 .3 .1 .4 0 .1 0 .3 .1 .6 0 .2 .1 .4 .1 .7 0 .1 0 .3 .1 .6 0 .1 0 .3 .1 .7 0 .1 0 .1 0 .2 0 .3 .1 .6 .1 .7 0 .2 0 .3 0 .5 0 0 0 .1 0 .1 0 .2 0 .3 0 .5 0 .1 0 .1 0 .2 0 .2 0 .3 0 .5 0 0 0 .1 0 .1 0 .2 0 .3 0 .5 0 .1 0 .1 0 .2 0 .2 0 .4 0 .5 0 0 0 .1 0 .1 0 .2 0 .4 0 .5 0 0 0 .1 0 .1 0 .2 0 .4 0 .6 0 0 0 .1 0 .1 0 .2 0 .4 0 .6 0 0 0 .1 0 .1 0 .2 0 .4 0 .6 0 0 0 0 0 .1 0 .2 0 .4 0 .6 0 0 0 0 0 .1 0 .2 0 .4 0 .6 0 0 0 0 0 0 0 .2 0 .4 0 .6 0 0 0 0 0 .1 0 .2 0 .4 0 .6 0 0 0 0 0 0 0 .2 0 .4 0 .6 0 0 0 0 0 0 0 .4 0 .9 0 1.3 0 57.4-46.6 104-104 104-43.1 0-80-26.2-95.8-63.5-5.3-12.4-8.2-26.1-8.2-40.5 0-.4 0-.9 0-1.3 0 0 0 0 0 0z", "M333.3 13.3L368 48 496 48 496 176c21.4 21.4 48.1 48.1 80 80-31.9 31.9-58.6 58.6-80 80l0 128-128 0c-21.4 21.4-48.1 48.1-80 80-31.9-31.9-58.6-58.6-80-80l-128 0 0-128c-21.4-21.4-48.1-48.1-80-80 31.9-31.9 58.6-58.6 80-80l0-128 128 0c21.4-21.4 48.1-48.1 80-80l45.3 45.3zM368 112l-26.5 0c-9.8-9.8-27.7-27.7-53.5-53.5-25.8 25.8-43.7 43.7-53.5 53.5l-90.5 0 0 90.5c-9.8 9.8-27.7 27.7-53.5 53.5 25.8 25.8 43.7 43.7 53.5 53.5l0 90.5 90.5 0c9.8 9.8 27.7 27.7 53.5 53.5 25.8-25.8 43.7-43.7 53.5-53.5l90.5 0 0-90.5c9.8-9.8 27.7-27.7 53.5-53.5-25.8-25.8-43.7-43.7-53.5-53.5l0-90.5-64 0zM336 256a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm-152 0a104 104 0 1 1 208 0 104 104 0 1 1 -208 0z"]],
    "image": [512, 512, [], "f03e", ["M64 96l384 0 0 216.4-108.2-108.2c-10.9-10.9-28.7-10.9-39.6 0L88.4 416 64 416 64 96zm40 112a40 40 0 1 0 80 0 40 40 0 1 0 -80 0z", "M448 96l0 216.4-108.2-108.2c-10.9-10.9-28.7-10.9-39.6 0L88.4 416 64 416 64 96 448 96zm0 295.6l0 24.4-280.4 0 152.4-152.4 128 128zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32zM184 208a40 40 0 1 0 -80 0 40 40 0 1 0 80 0z"]],
    "notdef": [448, 512, [], "e1fe", ["M64 118.5L181.9 256 64 393.5 64 118.5zM101.5 448L224 305.1 346.5 448 101.5 448zm0-384L346.4 64 224 206.8 101.6 64zM266.1 256L384 118.4 384 393.5 266.1 256z", "M384 0c35.3 0 64 28.7 64 64l0 384c0 33.1-25.2 60.4-57.5 63.7l-6.5 .3-320 0-6.5-.3C25.2 508.4 0 481.1 0 448L0 64C0 28.7 28.7 0 64 0L384 0zM101.5 448L346.5 448 224 305.1 101.5 448zM266.1 256L384 393.5 384 118.4 266.1 256zM64 393.5L181.9 256 64 118.5 64 393.5zM224 206.8L346.4 64 101.6 64 224 206.8z"]],
    "pencil": [512, 512, [9999, 61504, "pencil-alt"], "f303", ["M64 365.3l210.8-210.8 82.7 82.8-210.8 210.8-82.8 0 0-82.7z", "M389.5 0c67.7 0 122.5 54.8 122.5 122.5 0 32.5-12.9 63.7-35.9 86.6L173.2 512 0 512 0 338.7 302.9 35.9C325.8 12.9 357 0 389.5 0zM64 365.3l0 82.7 82.8 0 210.8-210.8-82.7-82.8-210.8 210.8zM389.5 64c-15.5 0-30.4 6.2-41.4 17.1l-33.7 33.7 82.7 82.8 33.7-33.7c11-11 17.1-25.9 17.1-41.4 0-32.3-26.2-58.5-58.5-58.5z"]],
    "plane-up": [576, 512, [], "e22d", ["M64 288.5c59.5-42.5 119.1-85 178.6-127.6l13.4-9.6 0 0c0-39.8 0-79.5 0-119.3 0-4.4 .9-8.6 2.5-12.4 4.9-11.5 16.2-19.5 29.5-19.5 12.2 0 22.7 6.8 28.1 16.7 .2 .5 .5 .9 .7 1.4l0 0c.2 .5 .4 .9 .6 1.4l0 0c.8 1.9 1.4 3.9 1.9 6 .2 1 .4 2.1 .5 3.2 .1 .5 .1 1.1 .1 1.6 0 .3 0 .5 0 .8s0 .5 0 .8l0 0 0 119.3 13.4 9.6 178.6 127.6 0 47C396.6 286 332.6 258.6 320 253.2l0 176.1 64 64 0 17-96-32-96 32 0-17 64-64 0-176.1c-12.6 5.4-76.6 32.8-192 82.3l0-47z", "M0 288.5c0-20.7 10-40.1 26.8-52.1L192 118.4 192 32c0-53 43-96 96-96 53 0 96 42.9 96 96l0 86.4 165.2 118 6 4.8c13.2 12 20.8 29.2 20.8 47.2l0 144.1c-12.6-5.4-76.6-32.9-192-82.3l0 52.5 64 64 0 45.3c0 35.3-28.7 64-64 64l-5.2 0-4.9-1.7-85.9-28.6-85.9 28.6-4.9 1.7-5.2 0c-35.3 0-64-28.7-64-64l0-45.3 64-64 0-52.5C76.6 399.7 12.6 427.1 0 432.5L0 288.5zm211.4-16.2l44.6-19.1 0 176.1-64 64 0 17 96-32 96 32 0-17-64-64 0-176.1c12.6 5.4 76.6 32.8 192 82.3l0-47-178.6-127.6-13.4-9.6 0-119.3c0-17.7-14.3-32-32-32-17.7 0-32 14.3-32 32l0 119.3-13.4 9.6-178.6 127.6 0 47 147.4-63.2z"]],
    "circle-arrow-left": [512, 512, ["arrow-circle-left"], "f0a8", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm76.2-19.8l112-112 39.6 39.6-64.2 64.2 156.4 0 0 56-156.4 0 64.2 64.2-39.6 39.6-112-112c-10.9-10.9-10.9-28.7 0-39.6z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm35.8 99.8l-64.2 64.2 156.4 0 0 56-156.4 0 64.2 64.2-39.6 39.6-112-112c-10.9-10.9-10.9-28.7 0-39.6l112-112 39.6 39.6z"]],
    "lightbulb": [384, 512, [128161], "f0eb", ["M96 240c0 15.3 2.4 30 6.8 43.8 9.3 9 19.9 16.6 31.5 22.5 .4 .2 .8 .4 1.1 .6 0 0 .1 0 .1 .1 1.7 .9 3.5 1.7 5.3 2.4l19.2 8.4 0 34.3 64 0 0-34.3 19.2-8.4c45.3-19.8 76.8-64.9 76.8-117.3 0-.5 0-1.1 0-1.6 0-.3 0-.5 0-.8 0 0 0 0 0-.1 0-.2 0-.5 0-.7 0 0 0-.1 0-.1 0-.2 0-.4 0-.6 0-.1 0-.4 0-.8 0-.1 0-.4 0-.7 0-.4 0-.6 0-.8-1.5-32.3-15.1-61.4-36.2-83.1-13.8-4.4-28.4-6.7-43.7-6.7-79.5 0-144 64.5-144 144z", "M256 512l-128 0 0-64 128 0 0 64zM192 0c106 0 192 86 192 192 0 71.3-38.8 133.4-96.3 166.5-3.2 32.3-30.5 57.5-63.7 57.5l-64 0C126.8 416 99.6 390.8 96.3 358.5 38.8 325.3 0 263.2 0 192 0 86 86 0 192 0zm0 64c-70.7 0-128 57.3-128 128 0 52.4 31.5 97.6 76.8 117.3l19.2 8.4 0 34.3 64 0 0-34.3 19.2-8.4c45.3-19.8 76.8-64.9 76.8-117.3 0-70.7-57.3-128-128-128z"]],
    "circle-arrow-right": [512, 512, ["arrow-circle-right"], "f0a9", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm64-28l156.4 0-64.2-64.2 39.6-39.6 112 112c10.9 10.9 10.9 28.7 0 39.6l-112 112-39.6-39.6 64.2-64.2-156.4 0 0-56z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zM371.8 236.2c10.9 10.9 10.9 28.7 0 39.6l-112 112-39.6-39.6 64.2-64.2-156.4 0 0-56 156.4 0-64.2-64.2 39.6-39.6 112 112z"]],
    "bed-empty": [640, 512, [128719], "f8f9", ["M256 192l0 160 320 0 0-128c0-17.7-14.3-32-32-32l-288 0z", "M64 32l0 96 480 0c53 0 96 43 96 96l0 256-64 0 0-64-512 0 0 64-64 0 0-448 64 0zM192 192l-128 0 0 160 128 0 0-160zm64 160l320 0 0-128c0-17.7-14.3-32-32-32l-288 0 0 160z"]],
    "code": [576, 512, [], "f121", ["", "M356.7 4.9l-4.5 31.7-64 448-4.5 31.7-63.4-9.1 4.5-31.7 64-448 4.5-31.7 63.4 9.1zM189.7 144l-112 112 112 112-45.2 45.2-134.6-134.6c-12.5-12.5-12.5-32.8 0-45.3L144.5 98.8 189.7 144zm377.4 89.4c12.5 12.5 12.5 32.8 0 45.3l-134.6 134.6-45.3-45.2 112-112-112-112 45.3-45.3 134.6 134.6z"]],
    "sparkles": [576, 512, [10024], "f890", ["M167.5 256l51.7 25.8c3.8 1.9 7.4 4 10.9 6.4 .2 .2 .5 .3 .7 .5l0 0c.5 .4 1 .7 1.6 1.1l0 0c2.1 1.5 4.1 3.1 6.1 4.8 9.8 8.3 17.8 18.6 23.6 30.2 8.6 17.2 17.2 34.4 25.8 51.7 8.6-17.2 17.2-34.4 25.8-51.7 9.3-18.6 24.4-33.7 42.9-42.9 17.2-8.6 34.4-17.2 51.6-25.8-17.2-8.6-34.4-17.2-51.6-25.8-11.6-5.8-21.9-13.9-30.2-23.6-1.7-2-3.2-4-4.8-6.1l0 0c-.4-.5-.7-1-1.1-1.6-2.6-3.7-4.9-7.6-6.9-11.7-8.6-17.2-17.2-34.4-25.8-51.7l-25.8 51.7c-9.3 18.6-24.4 33.6-42.9 42.9L167.5 256z", "M508 420l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68zM316.6 49.7l54.5 108.9c3.1 6.2 8.1 11.2 14.3 14.3 81.2 40.6 136.6 68.3 166.2 83.1-29.6 14.8-85 42.5-166.2 83.1-6.2 3.1-11.2 8.1-14.3 14.3-40.6 81.2-68.3 136.6-83.1 166.2-14.8-29.6-42.5-85-83.1-166.2-3.1-6.2-8.1-11.2-14.3-14.3-81.2-40.6-136.6-68.3-166.2-83.1 29.6-14.8 85-42.5 166.2-83.1 6.2-3.1 11.2-8.1 14.3-14.3 40.6-81.2 68.3-136.6 83.1-166.2l28.6 57.2zM262.2 187.2c-9.3 18.6-24.4 33.6-42.9 42.9l-51.7 25.8 51.7 25.8c18.6 9.3 33.6 24.4 42.9 42.9l25.8 51.7 25.8-51.7c9.3-18.6 24.4-33.6 42.9-42.9l51.7-25.8-51.7-25.8c-18.6-9.3-33.6-24.4-42.9-42.9l-25.8-51.7-25.8 51.7zM124 36l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"]],
    "angle-right": [320, 512, [8250], "f105", ["", "M51.2 448l192-192-192-192 45.2-45.2 214.6 214.6c12.5 12.5 12.5 32.8 0 45.3L96.5 493.3 51.2 448z"]],
    "face-meh": [512, 512, [128528, "meh"], "f11a", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm144-48a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM164 324l184 0 0 56-184 0 0-56zM368 208a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z", "M448 256a192 192 0 1 0 -384 0 192 192 0 1 0 384 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm176-80a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM192 324l156 0 0 56-184 0 0-56 28 0z"]],
    "map": [576, 512, [128506, 62072], "f279", ["M64 149.6l0 267.1c33.3-13.3 66.7-26.7 100-40l0-267.1c-33.3 13.3-66.7 26.7-100 40zm348 1.6l0 278.9c33.3-16.7 66.7-33.3 100-50l0-269c-33.3 13.3-66.7 26.7-100 40z", "M576 380.2c0 24.2-13.7 46.4-35.4 57.3l-142.3 71.2-13.1 6.5-13.5-5.6-179.9-75C75.8 480.9 11.9 506.5 0 511.2L0 149.6C0 123.5 15.9 100 40.2 90.2l139.9-56 10.9-4.3 11.1 3.7 180.8 60.3C500 47.1 564.3 21.4 576 16.7l0 363.5zM220 377l136 56.7 0-281.3-136-45.3 0 270zM412 151.2l0 278.9 100-50 0-269-100 40zM64 149.6l0 267.1 100-40 0-267.1-100 40z"]],
    "user-plus": [640, 512, [], "f234", ["M64 480l0 32 320 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96zm96-352a64 64 0 1 0 128 0 64 64 0 1 0 -128 0z", "M288 320c88.4 0 160 71.6 160 160l0 32-64 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96l0 32-64 0 0-32c0-88.4 71.6-160 160-160l128 0zM572 196l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68zM224 256a128 128 0 1 1 0-256 128 128 0 1 1 0 256zm0-192a64 64 0 1 0 0 128 64 64 0 1 0 0-128z"]],
    "thumbtack": [384, 512, [128204, 128392, "thumb-tack"], "f08d", ["M64 285.1l0 34.9 96 0 0-96 64 0 0 96 96 0 0-34.9c0-12.6-3.7-25-10.7-35.5l-53.3-79.9 0-105.7-128 0 0 105.7-53.2 79.9c-7 10.5-10.7 22.9-10.8 35.5z", "M352 64l-32 0 0 86.3 42.5 63.7c14 21 21.5 45.7 21.5 71l0 98.9-160 0 0 128-64 0 0-128-160 0 0-98.9c0-25.3 7.5-50 21.5-71l42.5-63.7 0-86.3-32 0 0-64 320 0 0 64zM128 169.7L74.8 249.6c-7 10.5-10.7 22.9-10.8 35.5l0 34.9 96 0 0-96 64 0 0 96 96 0 0-34.9c0-12.6-3.7-25-10.7-35.5l-53.3-79.9 0-105.7-128 0 0 105.7z"]],
    "money-bill-wave": [576, 512, [], "f53a", ["M64 192l0 192c35.3 0 63.9 28.5 64 63.7 .9 0 1.8 .1 2.7 .1l0 0c35.4-1.2 73.8-9.2 117.4-20 8-2 16.2-4.1 24.7-6.3 25.9-6.7 53.9-13.9 83.4-19.6s60.5-9.8 92.2-10.3c-.3-2.5-.5-5.1-.5-7.7 0-35.3 28.7-64 64-64l0-192c-35.3 0-63.9-28.5-64-63.7-.9 0-1.8-.1-2.7-.1l0 0c-4.4 .2-8.9 .4-13.4 .8l0 0c-4.5 .4-9 .8-13.6 1.3 0 0-.1 0-.1 0-9.2 1.1-18.7 2.5-28.4 4.3l-.1 0c-9.7 1.7-19.7 3.8-30 6.1l0 0c-10.2 2.3-20.8 4.8-31.6 7.5-.1 0-.1 0-.2 0-8 2-16.2 4.1-24.7 6.3-51.8 13.3-112.2 28.9-175.6 29.8 .3 2.5 .5 5.1 .5 7.7 0 35.3-28.7 64-64 64zm320 64a96 96 0 1 1 -192 0 96 96 0 1 1 192 0z", "M248.2 427.8c8-2 16.2-4.1 24.7-6.3l0 0c68.8-17.8 153-39.5 239.1-25.4l0-324.6c-54.2-15.3-111.9-5.4-184.2 12.7-8 2-16.2 4.1-24.7 6.3-68.8 17.8-153 39.5-239.1 25.4l0 324.6c54.2 15.3 111.9 5.4 184.2-12.7zM288 28.3c96-24.5 192-48.9 288 0l0 403.3c0 23.9-25.6 39.7-48.7 33.4-79.8-21.8-159.6-1.5-239.3 18.9-96 24.5-192 48.9-288 0L0 80.5C0 56.6 25.6 40.8 48.7 47.1 128.4 68.9 208.2 48.6 288 28.3zM328 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm-136 0a96 96 0 1 1 192 0 96 96 0 1 1 -192 0z"]],
    "phone-hangup": [576, 512, [], "e225", ["M64 283.7c0-44.6 23.2-86 61.2-109.2l12.6-7.7c92.2-56.3 208.2-56.3 300.4 0l12.6 7.7c38 23.3 61.2 64.6 61.3 109.2l0 0 0 36.3c-26.7 0-53.3 0-80 0l0-48c0-22.5-11.8-43.3-31.1-54.9-.6-.4-1.2-.7-1.8-1.1-8.6-5.1-17.4-9.6-26.4-13.5-63.1-26.9-136-22.4-195.9 13.5-.6 .4-1.2 .7-1.8 1.1-19.3 11.6-31.1 32.4-31.1 54.9l0 48c-26.7 0-53.3 0-80 0l0-36.3z", "M104.4 112.2c112.7-68.9 254.4-68.9 367.1 0l12.6 7.7c57.1 34.9 91.9 97 91.9 163.8l0 36.3-.3 6.5C572.4 358.8 545.1 384 512 384l-80 0c-35.3 0-64-28.7-64-64l0-48-1.8-1.1c-48.1-28.9-108.3-28.9-156.4 0l-1.8 1.1 0 48-.3 6.5C204.4 358.8 177.1 384 144 384l-80 0c-35.3 0-64-28.7-64-64l0-36.3c0-66.9 34.8-129 91.9-163.8l12.6-7.7zm333.8 54.6c-92.2-56.3-208.2-56.3-300.4 0l-12.6 7.7C87.2 197.7 64 239.1 64 283.7l0 36.3 80 0 0-48c0-22.5 11.8-43.3 31.1-54.9l1.8-1.1c68.4-41 153.9-41 222.3 0l1.8 1.1C420.2 228.7 432 249.5 432 272l0 48 80 0 0-36.3c0-44.6-23.2-86-61.3-109.2l-12.6-7.7z"]],
    "circle-plus": [512, 512, ["plus-circle"], "f055", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm96-28l68 0 0-68 56 0 0 68 68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm28 164l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"]],
    "folder": [512, 512, [128193, 128447, 61716, "folder-blank"], "f07b", ["M64 96l0 320 384 0 0-256-186.5 0-64-64-133.5 0z", "M288 96l160 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l160 0 64 64zM64 416l384 0 0-256-186.5 0-64-64-133.5 0 0 320z"]],
    "arrow-up-from-bracket": [448, 512, [], "e09a", ["", "M64 416c0 17.7 14.3 32 32 32l256 0c17.7 0 32-14.3 32-32l0-96 64 0 0 96c0 53-43 96-96 96L96 512c-53 0-96-43-96-96l0-96 64 0 0 96zM203.8 7.2c12.6-10.3 31.1-9.5 42.8 2.2l150.6 150.6-45.3 45.3-96-96 0 242.7-64 0 0-242.7-96 96-45.2-45.3 150.6-150.6 2.4-2.2z"]],
    "cloud": [576, 512, [9729], "f0c2", ["M64 320c0 53 43 96 96 96l256 0c53 0 96-43 96-96 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5c-5.9-56.3-53.5-100.2-111.4-100.2-45.5 0-84.6 27.2-102.1 66.1 30.4 4.9 57.9 18.4 80 37.9-14.1 16-28.2 32-42.3 48-16.9-15-39.1-24-63.5-24-4 0-8 .3-11.9 .8-47.4 5.8-84.1 46.3-84.1 95.2z", "M288 32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 88.4-71.6 160-160 160l-256 0c-88.4 0-160-71.6-160-160 0-2.6 .1-5.1 .2-7.6 0-.7 .1-1.5 .2-2.2 .1-1.8 .2-3.6 .4-5.3 .1-1.4 .3-2.8 .5-4.2 .1-1.2 .3-2.4 .4-3.5 .1-.8 .2-1.6 .3-2.3 .7-4.2 1.5-8.3 2.5-12.3 .7-2.8 1.4-5.5 2.2-8.2 .1-.4 .2-.7 .3-1.1 .4-1.1 .8-2.3 1.1-3.4 .4-1.2 .8-2.5 1.2-3.7 .4-1.1 .9-2.3 1.3-3.4 .5-1.2 1-2.5 1.5-3.7 .4-.9 .7-1.7 1.1-2.6 .6-1.4 1.3-2.8 1.9-4.2 .3-.7 .7-1.5 1-2.2 1-2 2-4.1 3.1-6.1 .6-1.2 1.3-2.3 2-3.5 .5-.9 1-1.9 1.6-2.8 .8-1.3 1.6-2.5 2.4-3.8 .5-.8 1-1.5 1.5-2.3 .7-1.1 1.4-2.1 2.2-3.2 .7-1 1.4-2 2.1-3 .4-.6 .9-1.2 1.3-1.8 1-1.3 2-2.6 3.1-3.9 .6-.7 1.1-1.4 1.7-2.1 1.4-1.7 2.9-3.4 4.4-5.1 .5-.6 1-1.1 1.6-1.7 1.2-1.2 2.3-2.5 3.5-3.7 .5-.5 1-1 1.5-1.5 1.1-1 2.1-2.1 3.2-3.1 .9-.8 1.8-1.7 2.7-2.5 .9-.8 1.8-1.6 2.7-2.3 .8-.7 1.7-1.4 2.5-2.1 .9-.7 1.8-1.4 2.7-2.1 6-4.6 12.3-8.9 18.9-12.7 .3-.2 .6-.3 .9-.5 3.5-2 5.6-3 6.1-3.3 4.8-2.5 9.8-4.7 14.9-6.6 .8-.3 1.5-.6 2.3-.9 .7-.2 1.3-.5 2-.7 1.3-.5 2.6-.9 4-1.3l1.6-.5c1.3-.4 2.6-.8 4-1.1 .2-.1 .5-.2 .7-.2 18.9-76.9 88.2-133.8 170.9-133.8zm0 64c-45.5 0-84.6 27.2-102.1 66.1 30.4 4.9 57.9 18.4 80 37.9-14.1 16-28.2 32-42.3 48-16.9-15-39.1-24-63.5-24-4 0-8 .3-11.9 .8-47.4 5.8-84.1 46.3-84.1 95.2 0 53 43 96 96 96l256 0c53 0 96-43 96-96 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5C393.5 139.9 345.9 96 288 96z"]],
    "circle": [512, 512, [128308, 128309, 128992, 128993, 128994, 128995, 128996, 9679, 9898, 9899, 11044, 61708, 61915], "f111", ["M64 256c0 79.5 48.4 147.8 117.3 176.9 23 9.7 48.2 15.1 74.7 15.1 13.3 0 26.2-1.3 38.7-3.9 87.5-17.9 153.3-95.3 153.3-188.1 0-6.6-.3-13.2-1-19.6-.2-1.6-.3-3.2-.6-4.8l0 0c-.1-.8-.2-1.6-.3-2.3l0 0c-.1-.8-.2-1.6-.3-2.4l0 0c-.5-3.2-1-6.3-1.7-9.5-15.3-75-74.4-134.1-149.4-149.4-12.5-2.6-25.4-3.9-38.7-3.9-106 0-192 86-192 192z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384z"]],
    "circle-exclamation": [512, 512, ["exclamation-circle"], "f06a", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm232 96a40 40 0 1 1 -80 0 40 40 0 1 1 80 0zM228 128l56 0 0 144-56 0 0-144z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm0 328a40 40 0 1 1 0-80 40 40 0 1 1 0 80zm28-120l-56 0 0-144 56 0 0 144z"]],
    "backward": [576, 512, [9194], "f04a", ["M111.6 256c42.8 38.9 85.6 77.8 128.4 116.8 0-77.9 0-155.7 0-233.5-42.8 38.9-85.6 77.8-128.4 116.8zm256 0c42.8 38.9 85.6 77.8 128.4 116.8l0-233.5c-42.8 38.9-85.6 77.8-128.4 116.8z", "M528 64l32 0 0 384-76.4 0-9.2-8.3-170.5-155 0 163.3-76.4 0-9.2-8.3-176-160C35.8 273.6 32 265 32 256s3.8-17.6 10.5-23.7l176-160 9.2-8.3 76.4 0 0 163.3 170.5-155 9.2-8.3 44.4 0zM367.6 256L496 372.8 496 139.2 367.6 256zm-256 0L240 372.8 240 139.2 111.6 256z"]],
    "link": [640, 512, [128279, "chain"], "f0c1", ["M0 304l0 1.8c0-74.5 55.9-135.9 128-144.7l0 64.9c-36.6 8.1-64 40.8-64 79.8L64 320c0 53 43 96 96 96l128 0c53 0 96-43 96-96l0-14.2c0-39.1-27.4-71.7-64-79.8l0-64.9c72.1 8.8 128 70.2 128 144.7l0-1.8c0-79.5-64.5-144-144-144l-42.5 0c-3.5 10-5.5 20.8-5.5 32l0 14.2c0 39.1 27.4 71.7 64 79.8l0 64.9c-72.1-8.8-128-70.2-128-144.7l0-14.2c0-2.7 .1-5.5 .2-8.2s.3-5.4 .6-8.1c.5-5.3 1.3-10.6 2.4-15.8L144 160C64.5 160 0 224.5 0 304z", "M640 206.2c0 74.5-55.9 135.9-128 144.7l0-64.9c36.6-8.1 64-40.8 64-79.8l0-14.2c0-53-43-96-96-96L352 96c-53 0-96 43-96 96l0 14.2c0 39.1 27.4 71.7 64 79.8l0 64.9c-72.1-8.8-128-70.2-128-144.7l0-14.2c0-88.4 71.6-160 160-160l128 0c88.4 0 160 71.6 160 160l0 14.2zM0 305.8c0-74.5 55.9-135.9 128-144.7l0 64.9c-36.6 8.1-64 40.8-64 79.8L64 320c0 53 43 96 96 96l128 0c53 0 96-43 96-96l0-14.2c0-39.1-27.4-71.7-64-79.8l0-64.9c72.1 8.8 128 70.2 128 144.7l0 14.2c0 88.4-71.6 160-160 160l-128 0C71.6 480 0 408.4 0 320l0-14.2z"]],
    "backward-step": [384, 512, ["step-backward"], "f048", ["M191.6 256L320 372.8 320 139.2c-42.8 38.9-85.6 77.8-128.4 116.8z", "M352 448l32 0 0-384-76.4 0-9.2 8.3-176 160C115.8 238.4 112 247 112 256s3.8 17.6 10.5 23.7l176 160 9.2 8.3 44.4 0zM191.6 256L320 139.2 320 372.8 191.6 256zM0 448l64 0 0-384-64 0 0 384z"]],
    "circle-user": [512, 512, [62142, "user-circle"], "f2bd", ["M64 256c0 52.7 21.3 100.5 55.7 135.2 39.5-24.9 86.2-39.2 136.3-39.2 50.1 0 96.8 14.4 136.2 39.2 34.5-34.7 55.8-82.5 55.8-135.2 0-106-86-192-192-192S64 150 64 256zm288-32a96 96 0 1 1 -192 0 96 96 0 1 1 192 0z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-104c-30.9 0-60.1 7-86.2 19.5 25.9 13.1 55.2 20.5 86.2 20.5 31 0 60.3-7.4 86.2-20.5-26.1-12.5-55.3-19.5-86.2-19.5zm0-344c-106 0-192 86-192 192 0 52.7 21.3 100.5 55.7 135.2 39.5-24.9 86.2-39.2 136.3-39.2 50.1 0 96.8 14.4 136.2 39.2 34.5-34.7 55.8-82.5 55.8-135.2 0-106-86-192-192-192zm0 256a96 96 0 1 1 0-192 96 96 0 1 1 0 192zm0-136a40 40 0 1 0 0 80 40 40 0 1 0 0-80z"]],
    "hand": [448, 512, [129306, 9995, "hand-paper"], "f256", ["M64 224l32 0 0 96 64 0 0-208c0-8.8 7.2-16 16-16s16 7.2 16 16l0 176 64 0 0-208c0-8.8 7.2-16 16-16s16 7.2 16 16l0 208 64 0 0-144c0-8.8 7.2-16 16-16s16 7.2 16 16l0 208c0 53-43 96-96 96l-96 0c-70.7 0-128-57.3-128-128l0-96z", "M272 64c-8.8 0-16 7.2-16 16l0 208-64 0 0-176c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 208-64 0 0-208c0-44.2 35.8-80 80-80 10 0 19.6 1.8 28.4 5.2 14.2-22.4 39.2-37.2 67.6-37.2 39.4 0 72.1 28.4 78.8 65.9 5.6-1.2 11.3-1.9 17.2-1.9 44.2 0 80 35.8 80 80l0 208c0 88.4-71.6 160-160 160l-96 0C86 512 0 426 0 320l0-96 64 0 0 96c0 70.7 57.3 128 128 128l96 0c53 0 96-43 96-96l0-208c0-8.8-7.2-16-16-16s-16 7.2-16 16l0 144-64 0 0-208c0-8.8-7.2-16-16-16z"]],
    "thumbs-up": [512, 512, [128077, 61575], "f164", ["M192 184.3l0 231.7 159 0c26.2 0 49.7-15.9 59.4-40.2l33-82.5c3-7.6 4.6-15.6 4.6-23.8l0-45.5c0-17.7-14.3-32-32-32l-160 0 0-122.9-64 115.2z", "M240 0l-18.8 0-9.1 16.5-79.8 143.7c-1.4-.1-2.8-.1-4.2-.1l-64 0c-35.3 0-64 28.7-64 64L0 416c0 35.3 28.7 64 64 64l287 0c52.3 0 99.4-31.9 118.8-80.5l33-82.5c6-15.1 9.2-31.3 9.2-47.5l0-45.5c0-53-43-96-96-96l-96 0 0-64c0-35.3-28.7-64-64-64L240 0zM128 416l-64 0 0-192 64 0 0 192zm64 0l0-231.7 64-115.2 0 122.9 160 0c17.7 0 32 14.3 32 32l0 45.5c0 8.1-1.6 16.2-4.6 23.8l-33 82.5C400.7 400.1 377.2 416 351 416l-159 0z"]],
    "building": [448, 512, [127970, 61687], "f1ad", ["M64 64l320 0 0 384-320 0 0-384zm64 96l0 64 64 0 0-64-64 0zm0 128l0 64 64 0 0-64-64 0zM256 160l0 64 64 0 0-64-64 0zm0 128l0 64 64 0 0-64-64 0z", "M384 64l0 384-320 0 0-384 320 0zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-384c0-35.3-28.7-64-64-64L64 0zm64 160l0 64 64 0 0-64-64 0zm192 0l-64 0 0 64 64 0 0-64zM256 288l0 64 64 0 0-64-64 0zm-64 0l-64 0 0 64 64 0 0-64z"]],
    "circle-arrow-down": [512, 512, ["arrow-circle-down"], "f0ab", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm60.2 3.8l39.6-39.6 64.2 64.2 0-156.4 56 0 0 156.4 64.2-64.2 39.6 39.6-112 112c-10.9 10.9-28.7 10.9-39.6 0l-112-112z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm28 220.4l64.2-64.2 39.6 39.6-112 112c-10.9 10.9-28.7 10.9-39.6 0l-112-112 39.6-39.6 64.2 64.2 0-156.4 56 0 0 156.4z"]],
    "gear": [512, 512, [9881, "cog"], "f013", ["M74.5 186.9c22.3 21.5 35.6 34.4 40.1 38.8-.5 5.2-1 10.3-1.6 15.5-.5 4.8-.7 9.8-.7 14.9 0 5.1 .3 10 .7 14.8 .5 5.1 1 10.3 1.6 15.4-4.5 4.3-17.8 17.3-40.1 38.8 10.3 17.9 20.7 35.8 31 53.7 29.7-8.5 47.6-13.7 53.7-15.4 4.2 3.1 8.4 6.1 12.7 9.2 6 4.3 12.3 8.2 18.9 11.6 2.3 1.1 4.5 2.2 6.8 3.2 4.7 2.1 9.4 4.2 14.2 6.3 1.5 6 6 24.1 13.6 54.2 0 0 0 0 0 0l62 0c7.5-30.1 12-48.1 13.5-54.2 4.7-2.1 9.5-4.3 14.2-6.4 9.1-4.1 17.7-9 25.7-14.8 4.2-3.1 8.4-6.1 12.6-9.2 5 1.4 10 2.9 15 4.3 12.9 3.7 25.8 7.4 38.7 11.1 0 0 0 0 0 0 10.3-17.9 20.7-35.8 31-53.7-22.3-21.5-35.7-34.5-40.1-38.8 .5-5.2 1-10.3 1.6-15.5 .5-4.9 .8-9.9 .8-14.9 0-5-.3-10-.8-14.9-.5-5.2-1-10.3-1.6-15.5 4.5-4.4 17.9-17.3 40.1-38.8-10.3-17.9-20.7-35.8-31-53.7l0 0c-12.9 3.7-25.9 7.4-38.8 11.1-5 1.4-10 2.8-15 4.2-4.2-3-8.4-6.1-12.6-9.1-8-5.8-16.6-10.7-25.7-14.8-4.7-2.1-9.5-4.2-14.2-6.4-1.3-5-2.5-10.1-3.8-15.1-3.3-13-6.5-26-9.7-39.1l-62 0c0 0 0 0 0 0-7.5 30.1-12.1 48.1-13.6 54.2-4.7 2.1-9.4 4.2-14.2 6.3-9.1 4.1-17.7 9.1-25.7 14.8-4.2 3-8.4 6.1-12.6 9.1-5-1.4-10-2.8-15-4.2-12.9-3.7-25.8-7.4-38.7-11.1l0 0-31 53.7zM160.3 256c0-46.4 32.9-85.1 76.7-94 6.2-1.3 12.7-2 19.4-2 13.3 0 25.9 2.7 37.4 7.5 5.7 2.4 11.2 5.4 16.3 8.9 25.5 17.3 42.3 46.5 42.3 79.6s-16.8 62.4-42.3 79.6c-5.1 3.5-10.6 6.4-16.3 8.9-11.5 4.9-24.1 7.5-37.4 7.5-6.6 0-13.1-.7-19.3-2-43.7-9-76.6-47.7-76.7-94z", "M292.8 .2c27 2.3 49.9 21.6 56.6 48.3l0 0 6.2 24.8c3.1 1.7 6.2 3.5 9.2 5.3l24.7-7c28.2-8.1 58.3 4.1 73 29.5l0 0 31 53.7 2.5 4.8c11.5 24.5 6.3 54-13.5 73.2l0 0-18.4 17.8c0 1.8 .2 3.6 .2 5.3 0 1.8-.1 3.5-.2 5.3l18.4 17.8c21.1 20.4 25.6 52.6 10.9 78l-31 53.7c-14.7 25.5-44.9 37.6-73.1 29.5l0 0-24.7-7.1c-3 1.9-6.1 3.6-9.2 5.3l-6.2 24.9 0 0c-6.7 26.7-29.6 46-56.6 48.3l-5.5 .2-62 0c-29.4 0-55-20-62.1-48.5l-6.3-24.9c-3.1-1.7-6.2-3.5-9.2-5.3l-24.5 7.1 0 0c-28.2 8.1-58.3-4.1-73-29.5l0 0-31-53.7C4.4 331.7 8.9 299.5 30 279.1l18.4-17.8c0-1.8-.1-3.5-.1-5.3 0-1.8 .1-3.6 .1-5.3L30 232.9c-21.1-20.4-25.6-52.6-10.9-78l31-53.7 0 0c14.7-25.4 44.8-37.6 73-29.5l0 0 24.6 7c3-1.8 6.1-3.6 9.2-5.3l6.3-24.8C170.3 20 195.9 0 225.3 0l62 0 5.5 .2zM225.3 64c-7.5 30.1-12.1 48.1-13.6 54.2l-14.2 6.3c-9.1 4.1-17.7 9.1-25.7 14.8l-12.6 9.1-15-4.2-38.8-11.1 0 0-31 53.7c22.3 21.5 35.6 34.4 40.1 38.8L113 241.1c-.5 4.8-.7 9.8-.7 14.9 0 5.1 .3 10 .7 14.8l1.6 15.4c-4.5 4.3-17.8 17.3-40.1 38.8l31 53.7c29.7-8.5 47.6-13.7 53.7-15.4l12.7 9.2c6 4.3 12.3 8.2 18.9 11.6l6.8 3.2 14.2 6.3c1.5 6 6 24.1 13.6 54.2l0 0 62 0 9.8-39.1 3.8-15.1 14.2-6.4c9.1-4.1 17.7-9 25.7-14.8l12.6-9.2 15 4.3 38.7 11.1 0 0 31-53.7c-22.3-21.5-35.7-34.5-40.1-38.8l1.6-15.5c.5-4.9 .8-9.9 .8-14.9 0-5-.3-10-.8-14.9l-1.6-15.5c4.5-4.4 17.9-17.3 40.1-38.8l-31-53.7 0 0-38.8 11.1-15 4.2-12.6-9.1c-8-5.8-16.6-10.7-25.7-14.8l-14.2-6.4c-1.5-6.1-6-24.1-13.5-54.2l-62 0 0 0zm30.5 288a96 96 0 1 1 .6-192 96 96 0 1 1 -.6 192zm.6-136a40 40 0 1 0 -.6 80 40 40 0 1 0 .6-80z"]],
    "circle-question": [512, 512, [62108, "question-circle"], "f059", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm100-48c0-50.8 41.2-92 92-92s92 41.2 92 92-41.2 92-92 92l-32 0 0-56 32 0c19.9 0 36-16.1 36-36s-16.1-36-36-36-36 16.1-36 36l-56 0zM296 368a40 40 0 1 1 -80 0 40 40 0 1 1 80 0z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm0 344a40 40 0 1 1 0-80 40 40 0 1 1 0 80zm0-292c50.8 0 92 41.2 92 92s-41.2 92-92 92l-32 0 0-56 32 0c19.9 0 36-16.1 36-36s-16.1-36-36-36-36 16.1-36 36l-56 0c0-50.8 41.2-92 92-92z"]],
    "arrow-rotate-right-10": [512, 512, [], "e837", ["", "M256 64c74 0 138.3 41.9 170.4 103.3 7.6 14.5 22.8 24.7 40.4 24.7 25 0 45.2-20.2 45.2-45.2l0-114.8-64 0 0 54.7C401.1 33.6 332.5 0 256 0 114.6 0 0 114.6 0 256S114.6 512 256 512c102.2 0 190.3-59.9 231.3-146.3l-57.8-27.5C398.7 403.2 332.5 448 256 448 150 448 64 362 64 256S150 64 256 64zM132 168l0 176 56 0 0-176-56 0zm148-4c-28.7 0-52 23.3-52 52l0 80c0 28.7 23.3 52 52 52l48 0c28.7 0 52-23.3 52-52l0-80c0-28.7-23.3-52-52-52l-48 0zm44 128l-40 0 0-72 40 0 0 72z"]],
    "file": [384, 512, [128196, 128459, 61462], "f15b", ["M64 64l0 384 256 0 0-293.5-90.5-90.5-165.5 0z", "M384 128l0 320-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-256 0c-35.3 0-64-28.7-64-64L0 64C0 28.7 28.7 0 64 0L256 0 384 128zM64 448l256 0 0-293.5-90.5-90.5-165.5 0 0 384z"]],
    "volume-slash": [640, 512, [128263], "f2e2", ["M96.3 192l0 128 74.7 0 8.5 6.4 108.8 81.6 0-48.2-167.8-167.8-24.2 0z", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zm-501-320l-24.2 0 0 128 74.7 0 8.5 6.4 108.8 81.6 0-48.2 64 64 0 56.2-53.3 0c-13.8 0-27.3-4.5-38.4-12.8L149.6 384 96.3 384c-33.1 0-60.4-25.2-63.7-57.5l-.3-6.5 0-128c0-23.9 13.1-44.7 32.5-55.7L120.5 192zM416.3 34.3c108.5 15.5 192 108.8 192 221.7 0 43.5-12.4 84-33.9 118.4l-41-41c12-23.2 18.9-49.5 18.9-77.4 0-81.8-58.5-150-136-164.9l0-56.8zm0 97.7c55.2 14.2 96 64.3 96 124 0 16.7-3.3 32.5-9.1 47.1l-46.9-46.9c0-.1 0-.1 0-.2 0-28.3-16.3-52.7-40-64.4l0-59.5zm-64 20.2l-100.7-100.7 9-6.7C271.6 36.5 285.1 32 298.9 32l53.3 0 0 120.2z"]],
    "arrow-up": [512, 512, [8593], "f062", ["", "M448.3 301.3l-160-160 0 338.8-64 0 0-338.8-160 160-45.3-45.3 214.6-214.6c12.5-12.5 32.8-12.5 45.3 0L493.5 256 448.3 301.3z"]],
    "rectangle": [512, 512, [9644, "rectangle-landscape"], "f2fa", ["M64 96l0 320 384 0 0-320-384 0z", "M448 32c35.3 0 64 28.7 64 64l0 320-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-384 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 416 0 96C0 60.7 28.7 32 64 32l384 0zM64 416l384 0 0-320-384 0 0 320z"]],
    "shirt": [640, 512, [128085, "t-shirt", "tshirt"], "f553", ["M74.7 117.9c3.4 33.8 6.8 67.5 10.1 101.3 52.7-8.1 88.6-13.6 107.5-16.5 0 12.4 0 24.9 0 37.3 0 69.3 0 138.7 0 208l256 0 0-245.3c18.9 2.9 54.8 8.4 107.5 16.5 3.4-33.8 6.8-67.5 10.1-101.3-48.3-16.8-96.6-33.6-144.8-50.4-.8-.3-1.6-.5-2.4-.8 0 0 0 0-.1 0-.7-.2-1.5-.5-2.4-.7 0 0 0 0 0 0 0 .2 0 .4 0 .5 0 0 0 .1 0 .1 0 .2 0 .3 0 .5 0 0 0 .1 0 .1 0 .3 0 .5 0 .7 0 .3 0 .5 0 .6 0 .1 0 .3 0 .7 0 0 0 .1 0 .1-2.8 50.5-44.7 90.5-95.8 90.5-5.9 0-11.7-.5-17.3-1.6 0 0-.1 0-.1 0-.3-.1-.8-.1-1.6-.3 0 0-.1 0-.1 0-6.2-1.2-12.1-3.1-17.8-5.5-11.4-4.7-21.6-11.6-30.3-20.1l0 0c-1.1-1.1-2.1-2.1-3.2-3.3l0 0c-.2-.3-.5-.5-.7-.8-15-16.6-24.3-38.4-24.8-62.4-1.6 .4-3.2 .9-4.8 1.5-48.3 16.8-96.5 33.6-144.8 50.4z", "M280.4 64l80 0c0 22.1-17.9 40-40 40s-40-17.9-40-40zm136 2.1c1.6 .4 3.2 .9 4.8 1.5L566 117.9 555.9 219.2c-52.7-8.1-88.6-13.6-107.5-16.5l0 245.3-256 0 0-245.3c-18.9 2.9-54.8 8.4-107.5 16.5L74.7 117.9 219.6 67.6c1.6-.6 3.2-1 4.8-1.5 1.1 52.1 43.7 93.9 96 93.9s94.9-41.9 96-93.9zM240.6 0C226.3 0 212 2.4 198.5 7.1L29.8 65.8 6 74.1 8.5 99.2c12.8 127.7 19.2 192.3 19.4 193.6 16.6-2.6 50.1-7.7 100.5-15.5l0 170.7c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-170.7c50.4 7.8 83.9 12.9 100.5 15.5 .1-1.3 6.6-65.9 19.4-193.6l2.5-25.1-23.8-8.3-168.7-58.7C428.7 2.4 414.5 0 400.1 0L240.6 0z"]],
    "suitcase": [512, 512, [129523], "f0f2", ["M64 160l0 288 68 0 0-288-68 0zm124 0l0 288 136 0 0-288-136 0zm192 0l0 288 68 0 0-288-68 0z", "M192 60l128 0c2.2 0 4 1.8 4 4l0 32-136 0 0-32c0-2.2 1.8-4 4-4zm-60 4l0 32-68 0C28.7 96 0 124.7 0 160L0 448c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-288c0-35.3-28.7-64-64-64l-68 0 0-32c0-33.1-26.9-60-60-60L192 4c-33.1 0-60 26.9-60 60zm0 96l0 288-68 0 0-288 68 0zm56 0l136 0 0 288-136 0 0-288zm192 0l68 0 0 288-68 0 0-288z"]],
    "comment-slash": [640, 512, [], "f4b3", ["M128.3 256c0-16 3.1-32 8.9-47.3L343.3 414.8c-7.5 .7-15.2 1.2-23.1 1.2-17.8 0-35-2.1-51.4-5.9l-15.1-3.5-15 3.7-68.8 17.2c2.9-25.8 5.2-46.6 7-62.6l-16.6-20.7c-20.8-26-32.2-56.4-32.2-88.3zM297.2 97.1c7.5-.7 15.2-1.1 23.1-1.1 114.3 0 192 79.4 192 160 0 16-3.1 32-8.9 47.3L297.2 97.1z", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM137.2 208.7c-5.8 15.3-8.9 31.3-8.9 47.3 0 31.9 11.3 62.3 32.2 88.3L177 365c-1.8 15.9-4.1 36.8-7 62.6l68.8-17.2 15-3.7 15.1 3.5c16.4 3.8 33.6 5.9 51.4 5.9 7.9 0 15.6-.4 23.1-1.2l54.6 54.6c-24.5 6.8-50.6 10.6-77.7 10.6-22.8 0-44.9-2.7-65.9-7.6L96.3 512 110.4 384.3c-29.1-36.3-46.2-80.6-46.2-128.3 0-34.3 8.8-66.7 24.5-95.8l48.4 48.4zM320.3 32c141.4 0 256 100.3 256 224 0 34.3-8.8 66.7-24.5 95.7l-48.4-48.4c5.8-15.3 8.9-31.3 8.9-47.3 0-80.6-77.7-160-192-160-7.9 0-15.6 .4-23.1 1.1L242.5 42.5C267 35.7 293.2 32 320.3 32z"]],
    "play": [384, 512, [9654], "f04b", ["M64 102.5L64 409.5 294.3 256 64 102.5z", "M0 32l54.3 0c12.6 0 25 3.7 35.5 10.7L369.8 229.4c8.9 5.9 14.2 15.9 14.2 26.6s-5.3 20.7-14.2 26.6L89.8 469.3c-10.5 7-22.9 10.7-35.5 10.7L0 480 0 32zm64 70.5L64 409.5 294.3 256 64 102.5z"]],
    "paperclip": [448, 512, [128206], "f0c6", ["M64 160l0 128c0 88.4 71.6 160 160 160s160-71.6 160-160l0-128-64 0 0 128c0 53-43 96-96 96s-96-43-96-96l0-128 64 0 0 128c0 17.7 14.3 32 32 32s32-14.3 32-32l0-128c0-53-43-96-96-96s-96 43-96 96z", "M0 160C0 71.6 71.6 0 160 0S320 71.6 320 160l0 128c0 53-43 96-96 96s-96-43-96-96l0-128 64 0 0 128c0 17.7 14.3 32 32 32s32-14.3 32-32l0-128c0-53-43-96-96-96s-96 43-96 96l0 128c0 88.4 71.6 160 160 160s160-71.6 160-160l0-128 64 0 0 128c0 123.7-100.3 224-224 224S0 411.7 0 288L0 160z"]],
    "wrench": [512, 512, [128295], "f0ad", ["M80 240c0-61.8 31.8-116.1 80-147.5L160 208c0 10.1 4.8 19.6 12.8 25.6L256 296 339.2 233.6c8.1-6 12.8-15.5 12.8-25.6l0-115.5c48.2 31.4 80 85.8 80 147.5 0 67.8-38.4 126.8-94.8 156.2l-17.2 9 0 106.8c-42.7 0-85.3 0-128 0l0-106.8-17.2-9C118.4 366.8 80 307.9 80 240z", "M301.2 16.2c8.3-6 19-7.7 28.7-4.6 96.4 31.1 166.2 121.6 166.2 228.4 0 85.5-44.8 160.5-112 203l0 69-64 0 0-106.8 17.2-9c56.4-29.4 94.8-88.3 94.8-156.2 0-61.8-31.8-116.1-80-147.5L352 208c0 10.1-4.8 19.6-12.8 25.6L256 296 172.8 233.6c-8.1-6-12.8-15.5-12.8-25.6l0-115.5c-48.2 31.4-80 85.8-80 147.5 0 67.8 38.4 126.8 94.8 156.2l17.2 9 0 106.8-64 0 0-69c-67.2-42.5-112-117.5-112-203 0-106.8 69.8-197.3 166.2-228.4 9.7-3.1 20.4-1.5 28.7 4.6S224 31.8 224 42l0 150 32 24 32-24 0-150c0-10.2 4.9-19.9 13.2-25.9z"]],
    "life-ring": [512, 512, [], "f1cd", ["M141.5 101.9c19.2 19.2 38.4 38.4 57.6 57.6 16.7-9.8 36.1-15.5 56.9-15.5s40.2 5.7 56.8 15.5c19.2-19.2 38.4-38.4 57.6-57.6-32-23.8-71.6-37.9-114.5-37.9-42.9 0-82.5 14.1-114.5 37.9zm0 308.2c32 23.8 71.6 37.9 114.5 37.9s82.5-14.1 114.5-37.9c-19.2-19.2-38.4-38.4-57.6-57.6-16.7 9.8-36.1 15.5-56.8 15.5-20.8 0-40.2-5.7-56.9-15.5-19.2 19.2-38.4 38.4-57.6 57.6z", "M256 0c60.6 0 116.2 21.1 160.1 56.3L432 40.4 471.6 80 455.7 95.9C490.9 139.8 512 195.4 512 256s-21.1 116.2-56.3 160.1l15.9 15.9-39.6 39.6-15.9-15.9C372.2 490.9 316.6 512 256 512S139.8 490.9 95.9 455.7L80 471.6 40.4 432 56.3 416.1C21.1 372.2 0 316.6 0 256S21.1 139.8 56.3 95.9L40.4 80 80 40.4 95.9 56.3C139.8 21.1 195.4 0 256 0zM141.5 410.1c32 23.8 71.6 37.9 114.5 37.9s82.5-14.1 114.5-37.9l-57.6-57.6c-16.7 9.8-36.1 15.5-56.8 15.5-20.8 0-40.2-5.7-56.9-15.5l-57.6 57.6zm211-211c9.9 16.7 15.5 36.1 15.5 56.9 0 20.8-5.7 40.2-15.5 56.8l57.6 57.6c23.8-32 37.9-71.6 37.9-114.5s-14.1-82.5-37.9-114.5l-57.6 57.6zM101.9 141.5C78.1 173.5 64 213.1 64 256s14.1 82.5 37.9 114.5l57.6-57.6c-9.8-16.7-15.5-36.1-15.5-56.8 0-20.8 5.7-40.2 15.5-56.9l-57.6-57.6zM256 208a48 48 0 1 0 0 96 48 48 0 1 0 0-96zm0-144c-42.9 0-82.5 14.1-114.5 37.9l57.6 57.6c16.7-9.8 36.1-15.5 56.9-15.5 20.8 0 40.2 5.7 56.8 15.5l57.6-57.6C338.5 78.1 298.9 64 256 64z"]],
    "calendar": [448, 512, [128197, 128198], "f133", ["M64 220l0 196 320 0 0-196-320 0z", "M160 32l128 0 0-64 64 0 0 64 32 0c35.3 0 64 28.7 64 64l0 320-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-320 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 416 0 96C0 60.7 28.7 32 64 32l32 0 0-64 64 0 0 64zM64 220l0 196 320 0 0-196-320 0zm0-56l320 0 0-68-320 0 0 68z"]],
    "italic": [448, 512, [], "f033", ["", "M321 32l127 0 0 64-108.2 0-160 320c58.2 0 94.3 0 108.2 0l0 64c-5.4 0-58.6 0-159.5 0-.4 0-.8 0-1.1 0-74.2 0-116.6 0-127.4 0l0-64c14 0 50 0 108.2 0l160-320-108.2 0 0-64 159.1 0c.6 0 1.3 0 1.9 0z"]],
    "check": [512, 512, [10003, 10004], "f00c", ["", "M493.5 128l-22.6 22.6-256 256c-12.5 12.5-32.8 12.5-45.3 0L41.6 278.6 19 256 64.3 210.7c1.3 1.3 44 44 128 128l233.4-233.4 22.6-22.6 45.3 45.3z"]],
    "wifi-slash": [640, 512, [], "f6ac", ["M33.2 192.9l0 0c13.8-15.6 28.9-30 45.1-43.2l45.6 45.6c-16.5 12.8-31.7 27.2-45.3 42.9 18.9 18.9 37.8 37.8 56.7 56.7 13.3-16.1 28.7-30.4 45.7-42.5l46.2 46.2c-17.8 11.1-33.5 25.4-46.3 41.9 17.5 17.5 35.1 35.1 52.6 52.6 13.5-16.5 31.7-29.1 52.5-35.8l78.4 78.4-44.1 44.2s0 0 0 0l44.1-44.1-286.1-286.1C62.1 162.9 47 177.4 33.2 192.9zm294.9-64.8c57.3 57.3 114.7 114.7 172 172L607.3 192.9c-58.8-66.2-140.2-111.8-232-125 91.8 13.2 173.1 58.9 231.9 125l-45.4 45.4c-57.1-65.7-140.4-108-233.8-110.2z", "M621.5 512L576.3 557.2 19 0 64.3-45.3 621.5 512zM364.3 435.8l-44.1 44.2-86.8-86.8c13.5-16.5 31.7-29.1 52.5-35.8l78.4 78.4zM227.2 298.7c-17.8 11.1-33.5 25.4-46.3 41.9L135.3 295c13.3-16.1 28.7-30.4 45.7-42.5l46.2 46.2zM123.9 195.4c-16.5 12.8-31.7 27.2-45.3 42.9L33.2 193c13.8-15.6 28.9-30 45.1-43.2l45.6 45.6zM320.3 64c114.2 0 216.7 49.9 287 129l-45.4 45.4c-57.1-65.7-140.4-108-233.8-110.2L267.6 67.6c17.2-2.4 34.8-3.6 52.7-3.6z"]],
    "rocket-launch": [576, 512, [128640], "e027", ["M112.2 192l0 2.8 25.6 25.6c33.3-55.5 55-91.6 65-108.4l-10.7 0c-44.2 0-80 35.8-80 80zM184.4 267c4.6 4.6 35.4 35.4 92.7 92.6l125.4-75.2c17.1-10.3 31.9-23.5 43.8-38.7 .1-.1 .2-.3 .3-.4 0 0 .1-.1 .1-.1 .5-.7 1-1.3 1.5-2 20.4-27.3 31.9-60.8 32-96l0-83.3-83.2 0c-56.2 0-108.3 29.5-137.2 77.7-16.2 26.9-41.2 68.7-75.2 125.4zm135.7-91c0-2.1 .1-4.1 .4-6.1 0 0 0 0 0 0 0-.4 .1-.8 .2-1.1 3.5-23.1 23.4-40.7 47.5-40.7 8.3 0 16.1 2.1 22.9 5.8 .7 .4 1.3 .7 2 1.1 13.9 8.4 23.1 23.7 23.1 41.1 0 26.5-21.5 48-48 48-26.5 0-48-21.5-48-48zm3.6 230.3l25.7 25.7 2.8 0c41.1 0 75-31 79.5-70.9 0-.1 0-.2 0-.3l0 0c0-.2 0-.3 0-.5 .3-2.7 .4-5.5 .4-8.2 0-3.6 0-7.2 0-10.7-49.3 29.6-85.5 51.3-108.4 65z", "M236.8 480.6l-54.1 54.1-45.2-45.2 54.1-54.1 45.2 45.3zm-64-64l-86.1 86.1-45.2-45.2 86.1-86.1 45.2 45.3zM544.2 147.3c0 51-17.4 99.5-48 138.4l0 66.4c0 79.5-64.5 144-144 144l-29.2 0-274.8-274.8 0-29.2c0-79.5 64.5-144 144-144l66.3 0C297.4 17.4 345.9 0 396.8 0l147.3 0 0 147.3zM323.7 406.3l25.6 25.7 2.8 0c44.2 0 80-35.8 80-80l0-10.8-108.4 65.1zM108.8 352.6l-54.1 54.1-45.2-45.2 54.1-54.1 45.2 45.3zM396.9 64c-56.2 0-108.3 29.5-137.2 77.7l-75.2 125.3 92.7 92.7 125.4-75.2c48.2-28.9 77.7-81 77.7-137.2l0-83.3-83.2 0zM368.1 224a48 48 0 1 1 0-96 48 48 0 1 1 0 96zm-176-112c-44.2 0-80 35.8-80 80l0 2.8 25.6 25.6 65.1-108.4-10.7 0z"]],
    "shield-slash": [640, 512, [], "e24b", ["M160.3 231.8l0 33.6c0 60.6 34.2 116 88.4 143.1l71.6 35.8 35-17.5c-65-65-130-130-195-195zM279.3 79.3c66.7 66.7 133.4 133.4 200.2 200.2 .4-4.7 .7-9.4 .7-14.2l0-146.3-160-53.3-40.9 13.6z", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM160.3 231.8l0 33.6c0 60.6 34.2 116 88.4 143.1l71.6 35.8 35-17.5 47.7 47.7-82.7 41.3-100.2-50.1C144.2 427.7 96.3 350.2 96.3 265.3l0-97.6 64 64zM330.4 1.7L500.5 58.3c26.1 8.7 43.7 33.2 43.8 60.7l0 146.3c0 23.5-3.7 46.5-10.7 68.2l-54-54c.4-4.7 .7-9.4 .7-14.2l0-146.3-160-53.3-40.9 13.6-50.6-50.6 81.4-27.1 10.1-3.4 10.1 3.4z"]],
    "house": [512, 512, [127968, 63498, 63500, "home", "home-alt", "home-lg-alt"], "f015", ["M64 192l0 256 96 0 0-96c0-53 43-96 96-96s96 43 96 96l0 96 96 0 0-256-192-144-192 144z", "M448 192l-192-144-192 144 0 256 96 0 0-96c0-53 43-96 96-96s96 43 96 96l0 96 96 0 0-256zM216 448l80 0 0-96c0-22.1-17.9-40-40-40s-40 17.9-40 40l0 96zm-56 64l-96 0c-35.3 0-64-28.7-64-64L0 192c0-20.1 9.5-39.1 25.6-51.2L256-32 486.4 140.8C502.5 152.9 512 171.9 512 192l0 256c0 35.3-28.7 64-64 64l-288 0z"]],
    "play-pause": [512, 512, [], "e22f", ["M64 139.2l0 233.5c42.8-38.9 85.6-77.8 128.4-116.8-42.8-38.9-85.6-77.8-128.4-116.8z", "M32 64l-32 0 0 384 76.4 0 9.2-8.3 176-160C268.2 273.6 272 265 272 256s-3.8-17.6-10.5-23.7L85.5 72.3 76.4 64 32 64zM192.4 256L64 372.8 64 139.2 192.4 256zM320 64l0 384 64 0 0-384-64 0zm128 0l0 384 64 0 0-384-64 0z"]],
    "sliders": [512, 512, ["sliders-h"], "f1de", ["", "M128 0c17.7 0 32 14.3 32 32l0 192c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-64-96 0 0-64 96 0 0-64c0-17.7 14.3-32 32-32zM288 256c17.7 0 32 14.3 32 32l0 192c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-64-256 0 0-64 256 0 0-64c0-17.7 14.3-32 32-32zm-64-96l0-64 288 0 0 64-288 0zM512 416l-128 0 0-64 128 0 0 64z"]],
    "paintbrush-slash": [640, 512, [], "e74e", ["M378.7 178.7L483 74.5c6.7-6.7 15.9-10.5 25.4-10.5 19.8 0 35.9 16.1 35.9 35.9 0 9.5-3.8 18.6-10.5 25.4l-104.3 104.2-50.8-50.8z", "M621.5 512L576.3 557.2 19 0 64.3-45.3 621.5 512zM219.3 290.8c-34 9.2-59.1 40.2-59.1 77.2l0 80 80 0c36.9 0 67.9-25.1 77.1-59.1l48.8 48.8C341.7 482 294.5 512 240.3 512l-208 0 0-64 64 0 0-80c0-54.2 30-101.4 74.2-126l48.8 48.8zM508.4 0c55.2 0 99.9 44.7 99.9 99.9 0 26.5-10.5 51.9-29.3 70.6l-104.3 104.2-45.2-45.2 104.3-104.2c6.7-6.7 10.5-15.9 10.5-25.4 0-19.8-16.1-35.9-35.9-35.9-9.5 0-18.6 3.8-25.4 10.5L378.7 178.7 333.5 133.5 437.8 29.2C456.5 10.5 481.9 0 508.4 0z"]],
    "face-frown": [512, 512, [9785, "frown"], "f119", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm60.4 100c26.2-45.4 75.4-76 131.6-76s105.4 30.6 131.7 76l-41.5 24c-18-31.1-51.6-52-90.1-52s-72.1 20.9-90.1 52l-41.5-24zM208 208a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm160 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z", "M448 256a192 192 0 1 0 -384 0 192 192 0 1 0 384 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm176-80a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM256 328c-38.5 0-72.1 20.9-90.1 52l-41.5-24c26.2-45.4 75.4-76 131.6-76s105.4 30.6 131.7 76l-41.5 24c-18-31.1-51.6-52-90.1-52z"]],
    "phone-plus": [512, 512, [], "f4d2", ["M66.3 216.2c11.1 58 39.5 110 79.7 150.2 5 5 10.2 9.9 15.6 14.5 37.7 32.5 83.8 55.5 134.6 65.2 41.7 7.9 84.9-5.3 114.7-35.2L437.8 384c-17.8-17.8-35.7-35.7-53.5-53.5l-33.4 33.4c-17.1 17.1-42 23.7-65.3 17.3-37.6-10.3-71.1-30.1-97.8-56.8-3.3-3.3-6.6-6.8-9.7-10.3-21.8-24.8-38.1-54.6-47.1-87.5-6.3-23.3 .3-48.2 17.3-65.3L181.8 128c-17.8-17.8-35.7-35.7-53.5-53.5l-26.9 26.9c-29.9 29.9-43.1 73-35.2 114.8z", "M83.1 29.2c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-33.4 33.4c-.8 .8-1.1 2-.8 3.2 13.7 50.1 51.2 89.9 99.8 106.7l9.9 3c.6 .2 1.1 .1 1.7 0l1.5-.8 33.4-33.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9-8.7 8.2c-41.4 36.6-96.8 53.5-151.6 46.5l-11.7-1.8C142.3 481.9 30.4 370 3.4 228.1-7.7 169.6 8.9 109.1 48.1 64.8l8.2-8.7 26.9-26.9zm18.4 72.2c-29.9 29.9-43.1 73-35.2 114.8 22.1 116.1 113.8 207.8 229.9 229.9 41.7 7.9 84.9-5.3 114.7-35.2l26.9-26.9-53.5-53.5-33.4 33.4c-17.1 17.1-42 23.7-65.2 17.3-75.3-20.5-134.1-79.3-154.6-154.6-6.3-23.3 .3-48.2 17.3-65.3l33.4-33.4-53.5-53.5-26.9 26.9zM428.3 84l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"]],
    "forward-step": [384, 512, ["step-forward"], "f051", ["M64 139.2l0 233.5c42.8-38.9 85.6-77.8 128.4-116.8-42.8-38.9-85.6-77.8-128.4-116.8z", "M32 64l-32 0 0 384 76.4 0 9.2-8.3 176-160C268.2 273.6 272 265 272 256s-3.8-17.6-10.5-23.7L85.5 72.3 76.4 64 32 64zM192.4 256L64 372.8 64 139.2 192.4 256zM384 64l-64 0 0 384 64 0 0-384z"]],
    "wand-magic": [576, 512, ["magic"], "f0d0", ["M93.5 400c76.5-76.5 153.1-153.1 229.6-229.6 16.9 16.9 33.8 33.8 50.7 50.7-76.5 76.5-153.1 153.1-229.6 229.6L93.5 400z", "M454.9-6.6L432.3-29.3 409.6-6.6 48.3 354.7c-25 25-25 65.5 0 90.5L99 496c25 25 65.5 25 90.5 0L550.9 134.6 573.5 112c-2.9-2.9-42.4-42.4-118.6-118.6zM362.7 130.8l69.6-69.6 50.7 50.7-69.6 69.6-50.7-50.7zm-39.6 39.6l50.7 50.7-229.6 229.6-50.7-50.7 229.6-229.6z"]],
    "sort": [384, 512, ["unsorted"], "f0dc", ["M77.3 160c76.5 0 153 0 229.5 0-38.2-38.2-76.5-76.5-114.7-114.7-38.2 38.2-76.5 76.5-114.7 114.7zm0 192c38.3 38.3 76.5 76.5 114.7 114.7 38.3-38.3 76.5-76.5 114.7-114.7L77.3 352z", "M0 320l0-32 384 0 0 77.3-169.4 169.4c-6 6-14.1 9.4-22.6 9.4s-16.6-3.4-22.6-9.4L9.4 374.6 0 365.3 0 320zM192 466.7L306.7 352 77.3 352 192 466.7zM0 192l0-45.3 9.4-9.4 160-160c6-6 14.1-9.4 22.6-9.4s16.6 3.4 22.6 9.4l160 160 9.4 9.4 0 77.3-384 0 0-32zM192 45.3L77.3 160 306.7 160 192 45.3z"]],
    "server": [512, 512, [], "f233", ["M64 64l0 160 384 0 0-160-384 0zm0 224l0 160 384 0 0-160-384 0zM400 144a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm0 224a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z", "M512 448c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64 .3 57.5C3.4 27.3 27.3 3.4 57.5 .3L64 0 448 0 454.5 .3c30.1 3.1 54.1 27 57.1 57.1l.3 6.5 0 384zM64 64l0 160 384 0 0-160-384 0zm0 224l0 160 384 0 0-160-384 0zM336 144a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm0 224a32 32 0 1 1 64 0 32 32 0 1 1 -64 0z"]],
    "user": [448, 512, [128100, 62144, 62470, "user-alt", "user-large"], "f007", ["M64 480l0 32 320 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96zm96-352a64 64 0 1 0 128 0 64 64 0 1 0 -128 0z", "M288 320c88.4 0 160 71.6 160 160l0 32-64 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96l0 32-64 0 0-32c0-88.4 71.6-160 160-160l128 0zm-64-64a128 128 0 1 1 0-256 128 128 0 1 1 0 256zm0-192a64 64 0 1 0 0 128 64 64 0 1 0 0-128z"]],
    "snowflake": [512, 512, [10052, 10054], "f2dc", ["", "M288 32l0-32-64 0 0 88.4-64-64-39.6 39.6 103.6 103.6 0 56.4-56.4 0-103.6-103.6-39.6 39.6 64 64-88.4 0 0 64 88.4 0c-33.5 33.5-54.9 54.9-64 64L64 391.6c2.5-2.5 37.1-37.1 103.6-103.6l56.4 0 0 56.4C157.5 410.9 122.9 445.5 120.4 448L160 487.6c9.1-9.1 30.5-30.5 64-64l0 88.4 64 0 0-88.4 64 64 39.6-39.6-103.6-103.6 0-56.4 56.4 0 103.6 103.6 39.6-39.6-64-64 88.4 0 0-64-88.4 0c33.5-33.5 54.9-54.9 64-64L448 120.4c-2.5 2.5-37.1 37.1-103.6 103.6l-56.4 0 0-56.4C354.5 101.1 389.1 66.5 391.6 64L352 24.4c-9.1 9.1-30.5 30.5-64 64L288 32z"]],
    "skull-crossbones": [512, 512, [128369, 9760], "f714", ["M128.5 160c0-48.6 27.1-90.9 67-112.5 3.6-2 7.4-3.8 11.2-5.4l0 0C222 35.6 238.8 32 256.5 32s34.5 3.6 49.8 10.1l0 0c3.8 1.6 7.5 3.4 11.2 5.4 0 0 .1 0 .1 .1 .4 .2 .8 .5 1.2 .7 39.2 21.9 65.6 63.8 65.6 111.8 0 7.2 0 14.3 0 21.5-34.6 34.6-55.9 55.9-64 64 0 19.4 0 33.6 0 42.5l-128 0c0-8.9 0-23.1 0-42.5-8.1-8.1-29.4-29.4-64-64 0-7.2 0-14.3 0-21.5zm48-16c0 8.5 3.3 16.3 8.8 22 .2 .2 .3 .3 .5 .5 0 0 .1 .1 .1 .1 5.8 5.8 13.8 9.4 22.6 9.4s16.8-3.6 22.6-9.4c.3-.3 .5-.5 .8-.8 0 0 0-.1 .1-.1 5.3-5.7 8.5-13.3 8.5-21.7s-3.2-16-8.5-21.7c0 0 0-.1-.1-.1-.3-.3-.5-.6-.8-.8-5.8-5.8-13.8-9.4-22.6-9.4s-16.8 3.6-22.6 9.4c0 0-.1 .1-.1 .1-.2 .2-.3 .3-.5 .5-5.5 5.7-8.8 13.5-8.8 22zm96 0c0 13.3 8.1 24.6 19.5 29.5 3.8 1.6 8 2.5 12.5 2.5s8.6-.9 12.5-2.5c1-.4 1.9-.9 2.8-1.3 10-5.4 16.7-16 16.7-28.1s-6.8-22.7-16.7-28.1c-.9-.5-1.8-.9-2.8-1.3-3.8-1.6-8-2.5-12.5-2.5s-8.6 .9-12.5 2.5c-11.5 4.9-19.5 16.2-19.5 29.5z", "M339.2 226.7l45.3-45.3 0-21.5c0-70.7-57.3-128-128-128s-128 57.3-128 128l0 21.5c34.6 34.6 55.9 55.9 64 64l0 42.5 128 0 0-42.5 18.7-18.7zM64.5 185.5l0-25.5c0-106 86-192 192-192s192 86 192 192l0 25.5c0 14.4-5.7 28.2-15.9 38.4l-48.1 48.1 0 16c0 35.3-28.7 64-64 64l-128 0c-35.3 0-64-28.7-64-64l0-16-48.1-48.1c-10.2-10.2-15.9-24-15.9-38.4zm-20.2 158l30.4 10.1 181.9 60.6 181.9-60.6 30.4-10.1 20.2 60.7c-8.5 2.8-52.2 17.4-131.3 43.8 79 26.3 122.8 40.9 131.3 43.8l-20.2 60.7-30.4-10.1-181.9-60.6-181.9 60.6-30.4 10.1-20.2-60.7c8.5-2.8 52.2-17.4 131.3-43.8-79.1-26.4-122.8-40.9-131.3-43.8l20.2-60.7zM176.5 144a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm128-32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"]],
    "ticket": [512, 512, [127903], "f145", ["M64 96c0 19.5 0 39 0 58.5 33.7 21.3 56 58.8 56 101.5S97.7 336.3 64 357.5c0 19.5 0 39 0 58.5l384 0 0-58.5c-33.7-21.3-56-58.8-56-101.5s22.3-80.3 56-101.5L448 96 64 96zm224 64a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm0 96a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm-.1 96a32 32 0 1 1 -63.9 0 32 32 0 1 1 63.9 0z", "M64 96l384 0 0 58.5c-33.7 21.3-56 58.8-56 101.5s22.3 80.3 56 101.5l0 58.5-384 0 0-58.5c33.7-21.3 56-58.8 56-101.5S97.7 175.7 64 154.5L64 96zM456 256c0-30.9 25.1-56 56-56l0-104c0-35.3-28.7-64-64-64L64 32C28.7 32 0 60.7 0 96L0 200c30.9 0 56 25.1 56 56S30.9 312 0 312L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-104c-30.9 0-56-25.1-56-56zM256 288a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm-32 64a32 32 0 1 0 64 0 32 32 0 1 0 -64 0zm32-160a32 32 0 1 0 0-64 32 32 0 1 0 0 64z"]],
    "wheelchair": [448, 512, [], "f193", ["M64 384c0-41.8 26.7-77.4 64-90.5l0 2.5c0 48.6 39.4 88 88 88l40 0c0 53-43 96-96 96s-96-43-96-96z", "M160 16a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zM128 227.2l0 66.3c-37.3 13.2-64 48.7-64 90.5 0 53 43 96 96 96s96-43 96-96l64 0c0 88.4-71.6 160-160 160S0 472.4 0 384c0-77.4 55-142 128-156.8zm143 .8l-47-58.8 0 118.8 160 0c16.1 0 29.8 12 31.8 28 12.7 101.4 19.3 154.6 20 159.8l-63.5 7.9c-1.2-9.8-6.7-53.7-16.5-131.7L224 352c-35.3 0-64-28.7-64-64l0-136c0-30.9 25.1-56 56-56l4.5 0c17 0 33.1 7.7 43.7 21l47.2 59 56.6 0 0 64-72 0c-9.7 0-18.9-4.4-25-12z"]],
    "volume-off": [384, 512, [], "f026", ["M64 192l0 128 74.7 0 8.5 6.4 108.8 81.6 0-304-108.8 81.6-8.5 6.4-74.7 0z", "M320 480l-53.3 0c-13.8 0-27.3-4.5-38.4-12.8L117.3 384 64 384C30.9 384 3.6 358.8 .3 326.5L0 320 0 192c0-35.3 28.7-64 64-64l53.3 0 110.9-83.2C239.4 36.5 252.8 32 266.7 32l53.3 0 0 448zM147.2 185.6l-8.5 6.4-74.7 0 0 128 74.7 0 8.5 6.4 108.8 81.6 0-304-108.8 81.6z"]],
    "bookmark": [384, 512, [128278, 61591], "f02e", ["M64 64l0 336.6c74.4-43.4 117.1-68.3 128-74.7 10.9 6.4 53.6 31.2 128 74.7L320 64 64 64z", "M192 325.9c10.9 6.4 53.6 31.3 128 74.7L320 64 64 64 64 400.6c74.4-43.4 117.1-68.3 128-74.7zM64 474.7L0 512 0 64C0 28.7 28.7 0 64 0L320 0c35.3 0 64 28.7 64 64l0 448c-32-18.7-96-56-192-112L64 474.7z"]],
    "list-ol": [512, 512, ["list-1-2", "list-numeric"], "f0cb", ["", "M36 92l-36 0 0-56 92 0 0 128 36 0 0 56-128 0 0-56 36 0 0-72zm476 36l-320 0 0-64 320 0 0 64zm0 320l-320 0 0-64 320 0 0 64zM480 288l-288 0 0-64 320 0 0 64-32 0zM0 348l0-56 72.3 0c28.5 0 51.7 23.1 51.7 51.7 0 11.7-4 23.1-11.3 32.3l-35.2 44 50.5 0 0 56-124 0 0-53.8 6.1-7.7 53.2-66.5-63.3 0z"]],
    "bomb": [640, 512, [128163], "f1e2", ["M128 287c0 .3 0 .7 0 1 .1 2.7 .1 5.5 .2 8.2 4.3 84.5 74.2 151.8 159.8 151.8 86.4 0 156.8-68.5 159.9-154.1 0-.2 0-.5 0-1 0-.7 0-1 0-1.5 0-.2 0-.5 0-1.1 0-.1 0-.1 0-.2 0-.3 0-.6 0-.9 0 0 0-.1 0-.1 0-.3 0-.6 0-1l0 0c0-.2 0-.4 0-.7 0-.1 0-.1 0-.2 0-.4 0-.7 0-.8 0-.2 0-.5 0-.9 0 0 0-.1 0-.1-.1-5.3-.4-10.5-1-15.6-.1-.6-.1-.9-.1-1.2l0-.1c-.1-.5-.1-1-.2-1.4-.1-1-.3-2-.4-2.9-1.2-7.8-2.9-15.4-5.2-22.8l-5.7-18.7s0 0 0 0l14-13.6c.3-.3 .6-.6 1-.9l-82.7-82.8-.2 .2-1.5 1.5c-4.5 4.4-9 8.8-13.5 13.2 0 0 0 0 0 0l-18.1-5.4c-11-3.3-22.4-5.5-34.2-6.4L288 128c-66.3 0-123.1 40.3-147.4 97.7-2 4.8-3.8 9.7-5.4 14.7-.2 .5-.3 1-.4 1.2-.2 .6-.4 1.3-.4 1.5-.1 .2-.1 .5-.3 .9 0 .2-.2 .6-.3 1.2 0 .1 0 .1 0 .2-.1 .4-.2 .7-.2 .8-.1 .3-.2 .6-.2 .9 0 0 0 .1 0 .1-.1 .5-.2 .7-.2 .8-.3 1.3-.6 2.6-.9 3.8l0 0c-.1 .6-.3 1.3-.4 1.9l0 0c-.1 .3-.1 .6-.2 .9 0 0 0 .1 0 .1-.1 .3-.1 .5-.2 .8 0 .1 0 .1 0 .2-1.1 5.2-1.9 10.5-2.4 15.9-.3 2.7-.5 5.4-.6 8.1-.1 1.4-.1 2.7-.2 4.1 0 .7 0 1.4 0 2.1 0 .3 0 .7 0 1zm36-.6c0-.5 0-1.1 0-1.6 0-1.1 .1-2.1 .1-3.2 .2-4.2 .6-8.4 1.3-12.5 .3-2.1 .7-4.1 1.1-6.1 0-.1 0-.1 0-.2 0-.2 .1-.3 .1-.5 0 0 0-.1 0-.1 0-.2 .1-.5 .2-.7 0 0 0 0 0 0 .1-.5 .2-1 .3-1.5 0 0 0 0 0 0 .2-1 .5-2 .7-3 0-.1 0-.2 .1-.3 0-.1 .1-.2 .1-.3 0-.1 0-.1 0-.2 .1-.5 .2-.8 .3-1 0-.1 .1-.2 .1-.3 0-.1 0-.1 .1-.2 .1-.5 .2-.8 .3-1.1 0-.1 0-.1 .1-.2 0-.2 .1-.3 .1-.5 0 0 0-.1 0-.1 15.1-51.4 62.7-88.9 119-88.9l0 56c-30.5 0-56.3 20.1-64.9 47.8-.3 1.1-.6 2.1-.9 3.2-.1 .5-.3 1.1-.4 1.6 0 0 0 0 0 0-.1 .3-.1 .5-.2 .8 0 0 0 0 0 0-.1 .3-.1 .4-.1 .5 0 0 0 0 0 .1 0 .1 0 .1 0 .2-.5 2.2-.8 4.5-1 6.7-.1 1.1-.2 2.3-.3 3.5 0 .6-.1 1.2-.1 1.7 0 .7 0 1.1 0 1.3 0 .1 0 .3 0 .4l0 0-56 0 0 0c0-.5 0-1.1 0-1.6z", "M336.5 69.3c24.3-13.5 55.6-10 76.3 10.7l82.8 82.7 4.4 4.9c16.6 20.3 18.7 48.5 6.6 70.9 3.6 15.9 5.5 32.5 5.5 49.5 0 119.8-94.1 217.7-212.5 223.7L288 512C168.2 512 70.3 417.9 64.3 299.5L64 288C64 164.3 164.3 64 288 64l8.4 .2c13.7 .5 27.1 2.3 40.1 5.2zm30.8 56.2l-1.5 1.5-13.5 13.2-18.1-5.4c-11-3.3-22.4-5.5-34.2-6.4L288 128c-88.4 0-160 71.6-160 160l.2 8.2c4.3 84.5 74.2 151.8 159.8 151.8 88.4 0 160-71.6 160-160 0-16.3-2.4-32-6.9-46.8l-5.7-18.7 14-13.6 1-.9-82.7-82.8-.2 .2zM288 220c-37.6 0-68 30.4-68 68l-56 0c0-68.5 55.5-124 124-124l0 56zM572 4l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"]],
    "trash-slash": [640, 512, [], "e2b3", ["M192.3 263.8l0 184.2 184.2 0-184.2-184.2zM360 160l88.2 88.2 0-88.2-88.2 0z", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM192.3 263.8l0 184.2 184.2 0 64 64-248.2 0c-33.1 0-60.4-25.2-63.7-57.5l-.3-6.5 0-248.2 64 64zM390.8 .3c32.3 3.3 57.5 30.5 57.5 63.7l0 32 96 0 0 64-32 0 0 152.2-64-64 0-88.2-88.2 0-64-64 88.2 0 0-32-120.2 0-49-49c11.1-9.4 25.5-15 41.2-15l128 0 6.5 .3z"]],
    "airplay": [512, 512, [], "e089", ["M64 96l0 256 92.1 0c49.3-49.3 82.6-82.6 99.9-99.9 17.3 17.3 50.6 50.6 99.9 99.9l92.1 0 0-256-384 0z", "M64 96l384 0 0 256-92.1 0 62.1 62.1 1.9 1.9 28.1 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L64 32C28.7 32 0 60.7 0 96L0 352c0 35.3 28.7 64 64 64l28.1 0 1.9-1.9 62.1-62.1-92.1 0 0-256zM256 399.2l56.8 56.8-113.6 0 56.8-56.8zm0-79.2c-18.3 18.3-60.9 60.9-128 128l0 64 256 0 0-64-128-128z"]],
    "volume-xmark": [576, 512, ["volume-mute", "volume-times"], "f6a9", ["M64 192l0 128 74.7 0 8.5 6.4 108.8 81.6 0-304-108.8 81.6-8.5 6.4-74.7 0z", "M320 480l-53.3 0c-13.8 0-27.3-4.5-38.4-12.8L117.3 384 64 384C30.9 384 3.6 358.8 .3 326.5L0 320 0 192c0-35.3 28.7-64 64-64l53.3 0 110.9-83.2C239.4 36.5 252.8 32 266.7 32l53.3 0 0 448zM147.2 185.6l-8.5 6.4-74.7 0 0 128 74.7 0 8.5 6.4 108.8 81.6 0-304-108.8 81.6zm419.4 29l-57.4 57.4 57.4 57.4-45.2 45.2-57.4-57.4-57.4 57.4-45.2-45.2 57.4-57.4-57.4-57.4 45.2-45.2 57.4 57.4 57.4-57.4 45.2 45.2z"]],
    "gauge-high": [512, 512, [62461, "tachometer-alt", "tachometer-alt-fast"], "f625", ["M64 256c0 1.6 0 3.2 .1 4.8 .1 5 .4 9.9 .9 14.8 3.6 35.5 16.9 68.1 37.2 95.2 2.3 3.1 4.7 6.2 7.2 9.1 15.1 17.9 33.4 32.9 54.1 44.3 .8 .4 1.6 .9 2.4 1.3 7.8 4.1 15.8 7.7 24.2 10.8 3 1.1 6.1 2.1 9.2 3.1 14.2 4.4 29.1 7.2 44.5 8.2 4.1 .3 8.2 .4 12.3 .4 9.9 0 19.7-.8 29.2-2.2 61-9.3 112.5-47.3 140.4-99.8 .2-.4 .4-.7 .6-1.1 3.9-7.4 7.2-15 10.1-22.9 1.1-2.9 2.1-5.8 3-8.8 2.5-8 4.5-16.2 5.9-24.6 1.4-8.2 2.4-17.5 2.7-27.7 .1-2.7 .1-6.8-.1-12.2-.1-2.5-.2-4.9-.4-7.3 0-.1 0-.1 0-.2 0-.2 0-.4-.1-.7 0-.1 0-.4-.1-.8 0-.2 0-.5-.1-.9 0-.1 0-.4-.1-.8 0-.3-.1-.7-.1-1-.1-.5-.1-1-.1-1.4 0-.2 0-.5-.1-.8 0-.1 0-.2 0-.2-5.6-50-30.4-94.2-66.8-125-3-2.5-6-4.9-9.1-7.2-27.1-20.3-59.7-33.6-95.2-37.2-4.9-.5-9.8-.8-14.8-.9-1.6 0-3.2-.1-4.8-.1-106 0-192 86-192 192zm96 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm32-96a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm0 192c0-35.3 28.7-64 64-64 .2 0 .4 0 .7 0L327 147.5 377 172.5 306.7 313.1c2.2 2.8 4.1 5.8 5.7 8.9 4.7 8.8 7.4 18.8 7.5 29.4 0 .2 0 .4 0 .5 0 35.3-28.7 64-64 64s-64-28.7-64-64zm96-224a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm72.3 149.5L387 224.1c16.3 1.5 29 15.2 29 31.9 0 17.7-14.3 32-32 32-9.4 0-17.8-4.1-23.7-10.5z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zM377 172.5L306.7 313.1c8.3 10.8 13.3 24.2 13.3 38.9 0 35.3-28.7 64-64 64s-64-28.7-64-64 28.7-64 64-64c.2 0 .4 0 .7 0L327 147.5 377 172.5zM128 288a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm259-63.9c16.3 1.5 29 15.2 29 31.9 0 17.7-14.3 32-32 32-9.4 0-17.8-4.1-23.7-10.5L387 224.1zM160 192a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm96-32a32 32 0 1 1 0-64 32 32 0 1 1 0 64z"]],
    "cloud-sun": [640, 512, [9925], "f6c4", ["M64 400c0 44.2 35.8 80 80 80l224 0c44.2 0 80-35.8 80-80 0-41.2-31.2-75.2-71.3-79.5l-22.2-2.4-5.4-21.6C338.6 254.8 300.9 224 256 224s-82.6 30.8-93.1 72.5l-5.4 21.6-22.2 2.4C95.2 324.8 64 358.8 64 400z", "M461.3-18.7L416-64C381.4-29.4 360.1-8.1 352 0l-96 0 0 96 0 0c22.2 0 43.7 3.2 64 9.3l0-41.3 58.5 0c12.5-12.5 25-25 37.5-37.5 12.5 12.5 25 25 37.5 37.5l58.5 0 0 58.5c12.5 12.5 25 25 37.5 37.5-12.5 12.5-25 25-37.5 37.5l0 52.4c20.5 19.7 37 43.5 48.1 70.1l15.9 0 0-96c8.1-8.1 29.4-29.4 64-64-34.6-34.6-55.9-55.9-64-64l0-96-96 0-18.7-18.7zM464 160c0-26.5-21.5-48-48-48-15.9 0-30 7.7-38.7 19.6 26.9 17.3 49.8 40.3 67.1 67.1 11.9-8.7 19.7-22.8 19.7-38.7zm-208 0C188.6 160 130.9 201.7 107.4 260.7 45.6 276.9 0 333.1 0 400 0 479.5 64.5 544 144 544l224 0c79.5 0 144-64.5 144-144 0-66.9-45.6-123.1-107.4-139.3-23.6-59-81.2-100.7-148.6-100.7zM162.9 296.5C173.4 254.8 211.1 224 256 224s82.6 30.8 93.1 72.5l5.4 21.6 22.2 2.4c40.1 4.3 71.3 38.3 71.3 79.5 0 44.2-35.8 80-80 80l-224 0c-44.2 0-80-35.8-80-80 0-41.2 31.2-75.2 71.3-79.5l22.2-2.4 5.4-21.6z"]],
    "arrow-right": [448, 512, [8594], "f061", ["", "M178.8 448l160-160-338.7 0 0-64 338.7 0-160-160 45.2-45.3 214.6 214.6c12.5 12.5 12.5 32.8 0 45.3L224 493.2 178.8 448z"]],
    "file-minus": [384, 512, [], "f318", ["M64 64l0 384 256 0 0-293.5-90.5-90.5-165.5 0zM96 260l192 0 0 56-192 0 0-56z", "M384 128l0 320-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-256 0c-35.3 0-64-28.7-64-64L0 64C0 28.7 28.7 0 64 0L256 0 384 128zM64 448l256 0 0-293.5-90.5-90.5-165.5 0 0 384zM288 316l-192 0 0-56 192 0 0 56z"]],
    "shredder": [512, 512, [], "f68a", ["M64 192l384 0 0 224-32 0 0-128-320 0 0 128-32 0 0-224z", "M192 512l-64 0 0-224 64 0 0 224zm96 0l-64 0 0-224 64 0 0 224zm96 0l-64 0 0-224 64 0 0 224zm32-384l32 0c35.3 0 64 28.7 64 64l0 160c0 35.3-28.7 64-64 64l0-224-384 0 0 224C30.9 416 3.6 390.8 .3 358.5L0 352 0 192c0-35.3 28.7-64 64-64l32 0 0-128 320 0 0 128zm-256 0l192 0 0-64-192 0 0 64z"]],
    "battery-bolt": [640, 512, [], "f376", ["M189.9 275.1c18 3.7 40.7 8.4 68 14 3.8 26.9 7.2 51.1 10.2 72.7L354 236.9c-18-3.7-40.7-8.4-68-14-3.8-26.9-7.2-51.1-10.3-72.7L189.9 275.1z", "M336 176L448 199.1 232.9 512 208 336 96 312.9 311.1 0 336 176zM164.9 128l-100.9 0 0 256 102.3 0 9.1 64-111.4 0c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l144.9 0-44 64zM480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64l-144.9 0 44-64 100.9 0 0-256-102.3 0-9.1-64 111.4 0zM189.9 275.1c18 3.7 40.7 8.4 68 14 3.8 26.9 7.2 51.1 10.2 72.7L354 236.9c-18-3.7-40.7-8.4-68-14-3.8-26.9-7.2-51.1-10.3-72.7L189.9 275.1zM640 352l-64 0 0-192 64 0 0 192z"]],
    "arrow-rotate-left-10": [512, 512, [], "e836", ["", "M256 64c-74 0-138.3 41.9-170.4 103.3-7.6 14.5-22.8 24.7-40.4 24.7-25 0-45.2-20.2-45.2-45.2L0 32 64 32 64 86.7C110.9 33.6 179.5 0 256 0 397.4 0 512 114.6 512 256S397.4 512 256 512C153.8 512 65.7 452.1 24.7 365.7l57.8-27.5c30.9 64.9 97 109.7 173.5 109.7 106 0 192-86 192-192S362 64 256 64zM132 344l0-176 56 0 0 176-56 0zM280 164l48 0c28.7 0 52 23.3 52 52l0 80c0 28.7-23.3 52-52 52l-48 0c-28.7 0-52-23.3-52-52l0-80c0-28.7 23.3-52 52-52zm44 128l0-72-40 0 0 72 40 0z"]],
    "buildings": [576, 512, [], "e0cc", ["M64 64l192 0 0 384-192 0 0-384zm64 64l0 64 64 0 0-64-64 0zm0 128l0 64 64 0 0-64-64 0z", "M64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L320 64c0-35.3-28.7-64-64-64L64 0zM320 128l192 0 0 320-192 0 0-320zM256 448l-192 0 0-384 192 0 0 384zM192 128l-64 0 0 64 64 0 0-64zM128 256l0 64 64 0 0-64-64 0zm320-64l-64 0 0 64 64 0 0-64zM384 320l0 64 64 0 0-64-64 0z"]],
    "xmark": [384, 512, [128473, 10005, 10006, 10060, 215, "close", "multiply", "remove", "times"], "f00d", ["", "M365.5 128l-128 128 128 128-45.2 45.2-128-128-128 128-45.3-45.2 128-128-128-128 45.3-45.2 128 128 128-128 45.2 45.2z"]],
    "lock-open": [384, 512, [], "f3c1", ["M64 256l256 0 0 192-256 0 0-192z", "M128 128l0 64 192 0c35.3 0 64 28.7 64 64l0 192c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 256c0-35.3 28.7-64 64-64l0-64C64 57.3 121.3 0 192 0S320 57.3 320 128l-64 0c0-35.3-28.7-64-64-64s-64 28.7-64 64zM256 256l-192 0 0 192 256 0 0-192-64 0z"]],
    "droplet": [384, 512, [128167, "tint"], "f043", ["M64 320c0 70.7 57.3 128 128 128s128-57.3 128-128c0-27.7-9-54.6-25.6-76.8-34.1-45.5-68.3-91-102.4-136.5-34.1 45.5-68.3 91-102.4 136.5-16.6 22.2-25.6 49.1-25.6 76.8z", "M192 106.7L294.4 243.2c16.6 22.2 25.6 49.1 25.6 76.8 0 70.7-57.3 128-128 128S64 390.7 64 320c0-27.7 9-54.6 25.6-76.8L192 106.7zM152 53.3L38.4 204.8C13.5 238 0 278.5 0 320 0 426 86 512 192 512s192-86 192-192c0-41.5-13.5-82-38.4-115.2-88-117.3-139.2-185.6-153.6-204.8L152 53.3z"]],
    "shop": [576, 512, ["store-alt"], "f54f", ["M74.6 160l426.7 0-57.6-96-311.5 0-57.6 96zM128 380c0 22.7 0 45.3 0 68l160 0 0-68-160 0z", "M443.8 64l-311.5 0-57.6 96 426.7 0-57.6-96zM64 224l-13.9 0c-27.7 0-50.1-22.4-50.1-50.1 0-9.1 2.5-18 7.1-25.8L96 0 480 0 568.9 148.1c4.7 7.8 7.1 16.7 7.1 25.8 0 27.7-22.4 50.1-50.1 50.1l-13.9 0 0 288-64 0 0-288-96 0 0 224c0 35.3-28.7 64-64 64l-160 0c-35.3 0-64-28.7-64-64l0-224zm224 0l-160 0 0 100 160 0 0-100zM128 380l0 68 160 0 0-68-160 0z"]],
    "film": [512, 512, [127902, 62368, "film-alt", "film-simple"], "f008", ["M188 96l0 320 136 0 0-320-136 0z", "M188 96l0 320 136 0 0-320-136 0zm192 68l68 0 0-68-68 0 0 68zm0 56l0 72 68 0 0-72-68 0zm68 128l-68 0 0 68 68 0 0-68zM132 96l-68 0 0 68 68 0 0-68zm0 124l-68 0 0 72 68 0 0-72zm0 128l-68 0 0 68 68 0 0-68zM0 96C0 60.7 28.7 32 64 32l384 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96z"]],
    "comments": [640, 512, [128490, 61670], "f086", ["M64 160c0 26 9.8 51 28.5 72.5l18.4 21.2c-2.2 20.2-3.9 35.5-5.1 45.9 44.1-11 67.2-16.8 69.1-17.3l13.6 2.5c11.4 2.1 23.2 3.2 35.5 3.2 98 0 160-66.2 160-128S322 32 224 32 64 98.2 64 160z", "M107.8 281.6l3.1-27.9-18.4-21.2C73.8 211 64 186 64 160 64 98.2 126 32 224 32s160 66.2 160 128-62 128-160 128c-12.3 0-24.1-1.1-35.5-3.2l-13.6-2.5c-1.9 .5-25 6.2-69.1 17.3l2-18zM32 384c42.1-10.5 90.4-22.6 145-36.2 15.2 2.8 30.9 4.2 47 4.2 123.7 0 224-86 224-192S347.7-32 224-32 0 54 0 160c0 42.9 16.4 82.5 44.2 114.5-2.6 23.4-6.7 59.9-12.2 109.5zM497.1 241.5c49.8 23.8 78.9 68.2 78.9 110.5 0 26-9.8 51-28.5 72.5l-18.4 21.2c2.2 20.2 3.9 35.5 5.1 45.9-44.2-11-67.2-16.8-69.1-17.3l-13.6 2.5c-11.4 2.1-23.2 3.2-35.5 3.2-65.7 0-115.3-29.8-140.8-68-16.6 2.7-33.8 4-51.2 4-6.6 0-13-.2-19.5-.6 30.6 74.9 113.7 128.6 211.5 128.6 16.1 0 31.9-1.5 47-4.2 54.6 13.6 102.9 25.7 145 36.2-5.5-49.6-9.6-86.1-12.2-109.5 27.7-32 44.2-71.6 44.2-114.5 0-76.8-52.7-143.1-128.7-173.8-1.7 22-6.6 43.2-14.2 63.3z"]],
    "circle-check": [512, 512, [61533, "check-circle"], "f058", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm72.4 16L176 232.4c11.8 11.8 27.8 27.8 48 48l92.2-92.2 19.8-19.8 39.6 39.6-19.8 19.8-112 112c-10.9 10.9-28.7 10.9-39.6 0-36.7-36.7-59.3-59.3-67.8-67.8z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zM375.6 208l-19.8 19.8-112 112c-10.9 10.9-28.7 10.9-39.6 0-36.7-36.7-59.3-59.3-67.8-67.8L176 232.4c11.8 11.8 27.8 27.8 48 48l92.2-92.2 19.8-19.8 39.6 39.6z"]],
    "moon": [512, 512, [127769, 9214], "f186", ["M64 256c0 106 86 192 192 192 44.9 0 86.3-15.4 119-41.3-123.7-32.3-215-144.8-215-278.7 0-13.5 .9-26.8 2.7-39.9-58.9 32.8-98.7 95.7-98.7 167.9z", "M375 406.7c-32.7 25.9-74.1 41.3-119 41.3-106 0-192-86-192-192 0-72.2 39.8-135.1 98.7-167.9-1.8 13-2.7 26.4-2.7 39.9 0 133.8 91.3 246.4 215 278.7zm48.1-56c-112-12.4-199.1-107.3-199.1-222.6 0-44.1 12.6-83.2 32-115.4 2.6-4.2 5.2-8.4 8.1-12.4-2.7-.1-5.4-.1-8.1-.1-24.5 0-48.3 3.5-70.7 9.9-107 30.7-185.3 129.3-185.3 246.1 0 141.4 114.6 256 256 256 80.9 0 153-37.5 199.9-96.1 16.5-20.6 29.9-43.8 39.4-68.9-15.3 3.3-31.1 5-47.4 5-8.4 0-16.7-.5-24.9-1.4z"]],
    "file-plus": [384, 512, [], "f319", ["M64 64l0 384 256 0 0-293.5-90.5-90.5-165.5 0zM96 260l68 0 0-68 56 0 0 68 68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56z", "M384 128l0 320-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-256 0c-35.3 0-64-28.7-64-64L0 64C0 28.7 28.7 0 64 0L256 0 384 128zM64 448l256 0 0-293.5-90.5-90.5-165.5 0 0 384zM220 260l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"]],
    "closed-captioning": [576, 512, [], "f20a", ["", "M512 96l0 320-448 0 0-320 448 0zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32zm52 160l0 128c0 19.9 16.1 36 36 36l80 0c19.9 0 36-16.1 36-36l0-40-56 0 0 20-40 0 0-88 40 0 0 20 56 0 0-40c0-19.9-16.1-36-36-36l-80 0c-19.9 0-36 16.1-36 36zm228-36c-19.9 0-36 16.1-36 36l0 128c0 19.9 16.1 36 36 36l80 0c19.9 0 36-16.1 36-36l0-40-56 0 0 20-40 0 0-88 40 0 0 20 56 0 0-40c0-19.9-16.1-36-36-36l-80 0z"]],
    "pen": [512, 512, [128394], "f304", ["M64 365.3l0 82.7 82.8 0 284.1-284.1c11-11 17.1-25.9 17.1-41.4 0-32.3-26.2-58.5-58.5-58.5-15.5 0-30.4 6.2-41.4 17.1L64 365.3z", "M389.5 0c67.7 0 122.5 54.8 122.5 122.5 0 32.5-12.9 63.7-35.9 86.6L173.2 512 0 512 0 338.7 302.9 35.9C325.8 12.9 357 0 389.5 0zm0 64c-15.5 0-30.4 6.2-41.4 17.1L64 365.3 64 448 146.8 448 430.9 163.9c11-11 17.1-25.9 17.1-41.4 0-32.3-26.2-58.5-58.5-58.5z"]],
    "plane": [640, 512, [], "f072", ["M65.7 160l17 0 64 64 176.1 0c-5.4-12.6-32.8-76.6-82.3-192l47 0c42.5 59.5 85 119.1 127.6 178.6 3.2 4.5 6.4 8.9 9.6 13.4L544 224c4.4 0 8.6 .9 12.5 2.5 11.5 4.9 19.5 16.2 19.5 29.5 0 11.9-6.5 22.2-16.1 27.8-.2 .1-.4 .2-.6 .4l0 0c-.9 .5-1.8 .9-2.8 1.3-3.8 1.6-8 2.5-12.5 2.5l-119.3 0c-3.2 4.5-6.4 8.9-9.6 13.4-42.5 59.5-85 119.1-127.6 178.6l-47 0c49.4-115.4 76.9-179.4 82.3-192l-176.1 0-64 64-17 0 32-96-32-96z", "M287.5-32c20.7 0 40.1 10 52.1 26.8l118 165.2 86.4 0c53 0 96 43 96 96 0 53-42.9 96-96 96l-86.4 0-118 165.2-4.8 6c-12 13.2-29.2 20.8-47.2 20.8l-144.1 0c5.4-12.6 32.8-76.6 82.3-192l-52.5 0-64 64-45.2 0c-35.3 0-64-28.7-64-64l0-5.2 1.7-4.9 28.6-85.9-28.6-85.9-1.7-4.9 0-5.2c0-35.3 28.7-64 64-64l45.2 0 64 64 52.5 0C176.3 44.6 148.9-19.4 143.5-32l144.1 0zm16.2 211.4l19.1 44.6-176.1 0-64-64-17 0 32 96-32 96 17 0 64-64 176.1 0c-5.4 12.6-32.8 76.6-82.3 192l47 0 127.6-178.6 9.6-13.4 119.3 0c17.7 0 32-14.3 32-32 0-17.7-14.3-32-32-32l-119.3 0-9.6-13.4-127.6-178.6-47 0 63.2 147.4z"]],
    "images": [576, 512, [], "f302", ["M192 64l0 256 24.4 0 147.8-147.8c5.3-5.3 12.4-8.2 19.8-8.2s14.5 3 19.8 8.2L512 280.4 512 64 192 64zm120 80a40 40 0 1 1 -80 0 40 40 0 1 1 80 0z", "M192 64l0 256 24.4 0 147.8-147.8c5.3-5.3 12.4-8.2 19.8-8.2s14.5 3 19.8 8.2L512 280.4 512 64 192 64zM384 231.6l-88.4 88.4 176.8 0-88.4-88.4zM128 64c0-35.3 28.7-64 64-64L512 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64l-320 0c-35.3 0-64-28.7-64-64l0-256zm144 40a40 40 0 1 1 0 80 40 40 0 1 1 0-80zM64 160l0 288 384 0 0 64-384 0c-35.3 0-64-28.7-64-64l0-320 64 0 0 32z"]],
    "bag-shopping": [448, 512, ["shopping-bag"], "f290", ["M64 192l0 192c0 35.3 28.7 64 64 64l192 0c35.3 0 64-28.7 64-64l0-192-320 0z", "M160 96l0 32 128 0 0-32c0-17.7-14.3-32-32-32l-64 0c-17.7 0-32 14.3-32 32zM96 128l0-32c0-53 43-96 96-96l64 0c53 0 96 43 96 96l0 32 96 0 0 256c0 70.7-57.3 128-128 128l-192 0C57.3 512 0 454.7 0 384l0-256 96 0zm224 64l-256 0 0 192c0 35.3 28.7 64 64 64l192 0c35.3 0 64-28.7 64-64l0-192-64 0z"]],
    "phone-volume": [576, 512, ["volume-control-phone"], "f2a0", ["M98.4 216.2c13.8 72.6 54.8 135.6 112 178 11.4 8.5 23.5 16.2 36.1 22.9 25.3 13.5 52.8 23.4 81.8 28.9 41.7 7.9 84.9-5.3 114.7-35.2L470 384c-17.8-17.8-35.7-35.7-53.5-53.5l-33.4 33.4c-17.1 17.1-42 23.7-65.3 17.3-17.6-4.8-34.3-11.7-49.9-20.4-1-.6-2-1.2-3.1-1.7 0 0-.1 0-.1-.1-4.1-2.4-8.1-4.9-12-7.6l0 0c-1-.6-1.9-1.3-2.9-2-41.7-29.1-72.8-72.2-86.6-122.8-6.3-23.3 .3-48.2 17.3-65.2L214 128c-17.8-17.8-35.7-35.7-53.5-53.5l-26.9 26.9c-29.9 29.9-43.1 73-35.2 114.8z", "M115.2 29.2c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-33.4 33.4c-.8 .8-1.1 2-.8 3.2 13.7 50.1 51.2 89.9 99.8 106.7l9.9 3c.6 .2 1.1 .1 1.7 0l1.5-.8 33.4-33.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9-8.7 8.2c-41.4 36.6-96.8 53.5-151.6 46.5l-11.7-1.8C174.5 481.9 62.6 370 35.5 228.1 24.4 169.6 41 109.1 80.2 64.8l8.2-8.7 26.9-26.9zm18.4 72.2c-29.9 29.9-43.1 73-35.2 114.7 22.1 116.1 113.8 207.8 229.9 229.9 41.7 7.9 84.9-5.3 114.7-35.2l26.9-26.9-53.5-53.5-33.4 33.4c-17.1 17.1-42 23.7-65.2 17.3-75.3-20.5-134.1-79.3-154.6-154.6-6.3-23.3 .3-48.2 17.3-65.2l33.4-33.4-53.5-53.5-26.9 26.9zM352.5-32c123.7 0 224 100.3 224 224 0 9.4-.7 18.7-1.8 27.8l-55.6-6.9c.8-6.8 1.3-13.8 1.3-20.8 0-92.8-75.2-168-168-168-14.1 0-27.7 1.7-40.8 5L298.1-25.3c17.4-4.3 35.6-6.7 54.3-6.7zm0 96c70.7 0 128 57.3 128 128 0 5.4-.4 10.7-1 15.8l-55.6-6.9c.4-2.9 .6-5.9 .6-8.9 0-39.8-32.2-72-72-72-6 0-11.9 .8-17.5 2.2L321.4 67.8c9.9-2.5 20.4-3.8 31.1-3.8z"]],
    "phone": [512, 512, [128222, 128379], "f095", ["M66.3 216.2c16.2 85.3 70 157.4 143.4 198.4 1.5 .9 3.1 1.7 4.7 2.5l.1 0c25.3 13.5 52.8 23.4 81.8 28.9 41.7 7.9 84.9-5.3 114.7-35.2L437.8 384c-17.8-17.8-35.7-35.7-53.5-53.5l-33.4 33.4c-14.9 14.9-35.9 21.9-56.5 19.1-2.9-.4-5.9-1-8.8-1.8 0 0 0 0 0 0-18.8-5.1-36.6-12.7-53-22.2-49.3-28.7-86.2-75.9-101.6-132.4-6.4-23.3 .3-48.2 17.3-65.2 11.1-11.1 22.3-22.3 33.4-33.4-17.8-17.8-35.7-35.7-53.5-53.5-9 9-17.9 17.9-26.9 26.9-29.9 29.9-43.1 73-35.2 114.7z", "M83.1 29.3c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-33.4 33.4c-.8 .8-1.1 2-.8 3.2 13.7 50.1 51.2 89.9 99.8 106.7l9.9 3c.6 .2 1.1 .1 1.7 0l1.5-.8 33.4-33.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9-8.7 8.2c-41.4 36.6-96.8 53.5-151.6 46.5l-11.7-1.8C142.3 481.9 30.4 370 3.4 228.1-7.7 169.6 8.9 109.1 48.1 64.8l8.2-8.7 26.9-26.9zm18.4 72.2c-29.9 29.9-43.1 73-35.2 114.7 22.1 116.1 113.8 207.8 229.9 229.9 41.7 7.9 84.9-5.3 114.7-35.2l26.9-26.9-53.5-53.5-33.4 33.4c-17.1 17.1-42 23.7-65.3 17.3-75.3-20.5-134.1-79.3-154.6-154.6-6.3-23.3 .3-48.2 17.3-65.2l33.4-33.4-53.5-53.5-26.9 26.9z"]],
    "id-card": [576, 512, [62147, "drivers-license"], "f2c2", ["M64 64l448 0 0 384-121.7 0c-16.6-28.7-40.4-52.7-69-69.5S259.5 352 224 352c-66.8 0-125.6 34.1-160 85.8L64 64zm64 160a96 96 0 1 0 192 0 96 96 0 1 0 -192 0zm256-60l0 56 96 0 0-56-96 0zm0 96l0 56 96 0 0-56-96 0z", "M512 64l0 384-121.7 0c-33.2-57.4-95.2-96-166.3-96-66.8 0-125.6 34.1-160 85.8L64 64 512 64zM320.3 448l-192.7 0c24.6-24.7 58.7-40 96.3-40s71.7 15.3 96.3 40zM64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l448 0c35.3 0 64-28.7 64-64l0-384c0-35.3-28.7-64-64-64L64 0zM224 184a40 40 0 1 1 0 80 40 40 0 1 1 0-80zm0 136a96 96 0 1 0 0-192 96 96 0 1 0 0 192zM480 220l0-56-96 0 0 56 96 0zm-96 96l96 0 0-56-96 0 0 56z"]],
    "leaf": [512, 512, [], "f06c", ["M96.1 264.6c0-39.7 15.3-76.1 40.6-103.2 12.6-13.6 27.7-24.8 44.6-33 8.4-4.1 17.3-7.5 26.6-10 4.6-1.2 9.4-2.3 14.2-3.1l0 0c2.4-.4 4.8-.7 7.2-1l0 0c2.4-.3 4.9-.5 7.4-.7 0 0 0 0 0 0 58.1-4.1 116.2-8.3 174.3-12.4-4.1 58.1-8.3 116.2-12.4 174.3-5.7 79.2-71.6 140.6-151 140.6-30.2 0-58.4-8.9-82-24.1 48.4-48.4 96.8-96.8 145.2-145.2-15.1-15.1-30.2-30.2-45.3-45.3L120.3 346.6c-15-23.3-23.8-50.9-24.1-80.6 0-.4 0-.8 0-1.3 0-.1 0-.1 0-.2z", "M462.4 279.9c-6.5 90.5-68.2 164.7-150.9 190.4-20.3 6.3-41.8 9.7-64 9.7-47.9 0-92.2-15.7-128-42.1l-64.8 64.8-45.3-45.3 64.8-64.8c-26.5-35.8-42.1-80.1-42.1-128 0-113 87.3-206.8 200.1-214.9 142.1-10.2 224.8-16.1 247.9-17.7-1.7 23.2-7.6 105.8-17.7 247.9zM120.3 346.6l145.2-145.2 45.3 45.3-145.2 145.2c23.6 15.3 51.8 24.1 82 24.1 79.4 0 145.4-61.4 151-140.6L411 101.1 236.8 113.5c-79.2 5.7-140.6 71.6-140.6 151 0 30.2 8.9 58.4 24.1 82z"]],
    "heart-half": [576, 512, [], "e1ab", ["M111.1 123.1c-36.1 36.1-36.1 94.6 0 130.8 59.1 59.1 118.3 118.2 177.4 177.4 0-87.2 0-174.3 0-261.5-15.5-15.5-31.1-31.1-46.6-46.6-12.1-12.1-26.8-20.2-42.4-24.2-.3-.1-.6-.2-.9-.2 0 0-.1 0-.1 0-1.4-.4-2.9-.7-4.3-.9-2.9-.6-5.8-1-8.8-1.3-26.5-2.5-53.9 6.3-74.2 26.6z", "M65.8 77.8c61.1-61.1 160.2-61.1 221.2 0l1.4 1.4 0 90.5-46.6-46.6c-36.1-36.1-94.7-36.1-130.8 0s-36.1 94.6 0 130.8l177.4 177.4 0 90.5-222.6-222.6C4.7 238 4.7 138.9 65.8 77.8z"]],
    "universal-access": [512, 512, [], "f29a", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm72-56l240 0 0 48-56 0 0 160-48 0 0-68-32 0 0 68-48 0 0-160-56 0 0-48zm160-72a40 40 0 1 1 -80 0 40 40 0 1 1 80 0z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zM376 248l-56 0 0 160-48 0 0-68-32 0 0 68-48 0 0-160-56 0 0-48 240 0 0 48zM256 168a40 40 0 1 1 0-80 40 40 0 1 1 0 80z"]],
    "volume-low": [512, 512, [128264, "volume-down"], "f027", ["M96 192l0 128 74.7 0 8.5 6.4 108.8 81.6 0-304-108.8 81.6-8.5 6.4-74.7 0z", "M352 480l-53.3 0c-13.8 0-27.3-4.5-38.4-12.8L149.3 384 96 384c-33.1 0-60.4-25.2-63.7-57.5L32 320 32 192c0-35.3 28.7-64 64-64l53.3 0 110.9-83.2C271.4 36.5 284.8 32 298.7 32l53.3 0 0 448zM179.2 185.6l-8.5 6.4-74.7 0 0 128 74.7 0 8.5 6.4 108.8 81.6 0-304-108.8 81.6zM416 136.2c53 14.1 92 62.4 92 119.8s-39 105.7-92 119.8l0-59.8c21.4-11.4 36-34 36-60s-14.6-48.6-36-60l0-59.8z"]],
    "hourglass": [448, 512, [9203, 62032, "hourglass-empty"], "f254", ["M98.5 448l251 0c-.1-.7-.3-1.4-.4-2.1 0 0 0-.1 0-.1-.1-.6-.2-1-.2-1.1-.1-.6-.2-.9-.2-1.1-.2-.8-.3-1.5-.4-1.6-.1-.2-.1-.5-.2-.7 0 0 0-.1 0-.1-4.6-20.5-13.3-39.9-25.4-57l-197.4 0c-13.5 19.1-22.6 40.9-26.8 64zm26.8-320c8.6 12.1 18.9 23.2 30.8 32.7 22.7 18.1 45.3 36.2 68 54.4 22.7-18.1 45.3-36.2 68-54.4 11.9-9.5 22.2-20.5 30.8-32.7l-197.4 0z", "M0 64l33.8 0c7.3 57.3 36.6 110.1 82.3 146.6l56.7 45.4-56.7 45.4c-45.7 36.6-75 89.3-82.3 146.6l-33.8 0 0 64 448 0 0-64-33.8 0c-7.3-57.3-36.6-110.1-82.3-146.6l-56.7-45.4 56.7-45.4c45.7-36.6 75-89.3 82.3-146.6L448 64 448 0 0 0 0 64zm349.5 0c-6.8 37.8-27 72.3-57.5 96.7l-68 54.4-68-54.4c-30.5-24.4-50.7-58.9-57.5-96.7l251 0zM224 297l68 54.4c30.5 24.4 50.7 58.9 57.5 96.7l-251 0c6.8-37.8 27-72.3 57.5-96.7L224 297z"]],
    "fish": [640, 512, [128031], "f578", ["M112.9 339.4l124 124c0-.1 .1-.1 .1-.2 .4-.8 .7-1.3 .8-1.5 .3-.6 .6-1.2 .8-1.5 .3-.6 .6-1.2 .6-1.3 .2-.5 .4-.9 .5-1.1 .2-.4 .3-.7 .4-.9 .1-.3 .2-.5 .3-.8 .1-.2 .2-.5 .4-.9 0-.1 .1-.2 .1-.3 .1-.3 .2-.6 .4-.9 0-.1 .1-.2 .1-.2 .1-.2 .2-.5 .3-.7 0-.1 0-.1 .1-.2 .1-.3 .3-.6 .4-1 0 0 0-.1 .1-.1 2.7-7 4.7-14.2 6-21.7 2.5-14.9 5-29.8 7.4-44.7 .9-5.1 2.7-9.9 5.2-14.1 .3-.5 .6-1 .9-1.5 .3-.5 .6-.9 1-1.4 .2-.2 .3-.4 .5-.7l0 0c.3-.5 .7-.9 1.1-1.3l0 0c1.5-1.8 3.1-3.4 4.9-4.9 7-5.9 16.1-9.5 25.9-9.5l25.2 0c106 0 192-86 192-192l0-48c0-6.6-1.3-12.9-3.8-18.7 0-.1-.1-.2-.2-.4-.1-.3-.2-.4-.2-.6-.1-.2-.2-.4-.2-.5-.1-.1-.1-.3-.2-.4 0-.1-.1-.3-.2-.5 0 0 0-.1-.1-.1-.1-.2-.2-.3-.2-.5 0 0 0-.1 0-.1-2.3-4.6-5.3-8.7-8.9-12.3-8.7-8.7-20.7-14.1-33.9-14.1l-48 0c-106 0-192 86-192 192 0 8.4 0 16.8 0 25.2 0 19.6-14.1 36.2-33.4 39.5-14.9 2.5-29.8 5-44.7 7.4-11.7 1.9-22.9 5.8-33.3 11.3zM376.3 160c0-22.1 17.9-40 40-40 11 0 21 4.5 28.3 11.7 3.4 3.4 6.3 7.5 8.3 12 0 0 0 0 0 0 .1 .1 .1 .3 .2 .4 0 0 0 .1 0 .1 0 .1 0 .1 .1 .2 2 4.8 3.1 10 3.1 15.6s-1.1 10.8-3.1 15.6c0 .1 0 .1-.1 .2 0 0 0 .1 0 .1-.1 .1-.1 .3-.2 .4 0 0 0 0 0 0-2 4.5-4.8 8.6-8.3 12-7.2 7.2-17.2 11.7-28.3 11.7-22.1 0-40-17.9-40-40z", "M224.3 256c0-106 86-192 192-192l48 0c26.5 0 48 21.5 48 48l0 48c0 106-86 192-192 192L295 352c-19.6 0-36.2 14.1-39.5 33.4l-7.4 44.7c-1.9 11.7-5.8 22.9-11.3 33.3l-124-124c10.3-5.5 21.6-9.3 33.3-11.3l44.7-7.4c19.3-3.2 33.4-19.9 33.4-39.5l0-25.2zM416.3 0c-141.4 0-256 114.6-256 256l0 4.9-24.6 4.1c-35.6 5.9-68.5 22.8-94 48.4l-22.6 22.6 22.6 22.6 176 176 22.6 22.6 22.6-22.6c25.5-25.5 42.4-58.4 48.4-94l4.1-24.6 4.9 0c141.4 0 256-114.6 256-256l0-48c0-61.9-50.1-112-112-112l-48 0zm0 200a40 40 0 1 0 0-80 40 40 0 1 0 0 80z"]],
    "chart-simple": [512, 512, [], "e473", ["M64 256l96 0 0 192-96 0 0-192zm288-96l96 0 0 288-96 0 0-288z", "M288 64l-64 0 0 384 64 0 0-384zm64 96l0 288 96 0 0-288-96 0zm0-64l96 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 256c0-35.3 28.7-64 64-64l96 0 0-128c0-35.3 28.7-64 64-64l64 0c35.3 0 64 28.7 64 64l0 32zM160 256l-96 0 0 192 96 0 0-192z"]],
    "headphones": [512, 512, [127911, 62863, "headphones-alt", "headphones-simple"], "f025", ["M64 320l0 96 64 0 0-96-64 0zm320 0l0 96 64 0 0-96-64 0z", "M256 64C150 64 64 150 64 256l64 0c35.3 0 64 28.7 64 64l0 96c0 35.3-28.7 64-64 64l-64 0c-35.3 0-64-28.7-64-64L0 256C0 114.6 114.6 0 256 0l32 0 0 2C414.3 17.7 512 125.5 512 256l0 160c0 35.3-28.7 64-64 64l-64 0c-35.3 0-64-28.7-64-64l0-96c0-35.3 28.7-64 64-64l64 0c0-106-86-192-192-192zM448 320l-64 0 0 96 64 0 0-96zM64 416l64 0 0-96-64 0 0 96z"]],
    "bus": [640, 512, [128653], "f207", ["M160 256l0 128 320 0 0-128-320 0zm96 64a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm192 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z", "M416 0c70.7 0 128 57.3 128 128l0 384-64 0 0-64-320 0 0 64-64 0 0-384C96 57.3 153.3 0 224 0L416 0zM160 384l320 0 0-128-320 0 0 128zm64-32a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm192 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64zM64 288l-64 0 0-128 64 0 0 128zm576 0l-64 0 0-128 64 0 0 128zM224 64c-35.3 0-64 28.7-64 64l0 64 320 0 0-64c0-35.3-28.7-64-64-64L224 64z"]],
    "screencast": [512, 512, [], "e23e", ["M64 96l384 0 0 320-134.4 0C288.1 290.6 189.4 191.9 64 166.4L64 96z", "M448 96l-384 0 0 70.4C43.3 162.2 21.9 160 0 160L0 96C0 60.7 28.7 32 64 32l384 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64l-128 0c0-21.9-2.2-43.3-6.4-64l134.4 0 0-320zM0 224c141.4 0 256 114.6 256 256l-56 0c0-110.5-89.5-200-200-200l0-56zm0 96c88.4 0 160 71.6 160 160l-56 0c0-57.4-46.6-104-104-104l0-56zm0 96c35.3 0 64 28.7 64 64l-64 0 0-64z"]],
    "martini-glass": [512, 512, [127864, "glass-martini-alt"], "f57b", ["M130.5 128L256 271.4c41.8-47.8 83.7-95.6 125.5-143.4l-251 0z", "M2.9 50.8C8 39.3 19.4 32 32 32l448 0c12.6 0 24 7.3 29.1 18.8s3.2 24.8-5.1 34.3l-216.1 247 0 116 96 0 0 64-256 0 0-64 96 0 0-116-216.1-247C-.3 75.6-2.3 62.2 2.9 50.8zM256 271.4L409.5 96 102.5 96 256 271.4z"]],
    "link-simple": [576, 512, [], "e1cd", ["M64 224l0 64c0 53 43 96 96 96l96 0 0 64 64 0 0-64 96 0c53 0 96-43 96-96l0-64c0-53-43-96-96-96l-96 0 0-64-64 0 0 64-96 0c-53 0-96 43-96 96zm96 0l256 0 0 64-256 0 0-64z", "M160 64C71.6 64 0 135.6 0 224l0 64c0 88.4 71.6 160 160 160l96 0 0-64-96 0c-53 0-96-43-96-96l0-64c0-53 43-96 96-96l96 0 0-64-96 0zM416 448c88.4 0 160-71.6 160-160l0-64c0-88.4-71.6-160-160-160l-96 0 0 64 96 0c53 0 96 43 96 96l0 64c0 53-43 96-96 96l-96 0 0 64 96 0zM192 224l-32 0 0 64 256 0 0-64-224 0z"]],
    "rectangle-wide": [576, 512, [], "f2fc", ["M64 128l0 256 448 0 0-256-448 0z", "M518.5 64.3C550.8 67.6 576 94.9 576 128l0 256-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-448 0-6.5-.3C25.2 444.4 0 417.1 0 384L0 128C0 94.9 25.2 67.6 57.5 64.3l6.5-.3 448 0 6.5 .3zM64 384l448 0 0-256-448 0 0 256z"]],
    "cloud-arrow-down": [576, 512, [62337, "cloud-download", "cloud-download-alt"], "f0ed", ["M64 320c0-49.1 36.9-89.7 84.5-95.3l25.4-3 2.6-25.5C182.5 139.9 230.1 96 288 96 345.9 96 393.5 139.9 399.4 196.2l2.6 25.5 25.4 3c47.6 5.6 84.6 46.2 84.6 95.3 0 40.6-25.2 75.2-60.8 89.3l-70.7 70.7-184.9 0-70.8-70.7C89.2 395.2 64 360.6 64 320zm88.4 32l19.8 19.8 96 96c10.9 10.9 28.7 10.9 39.6 0l96-96 19.8-19.8-39.6-39.6c-8.5 8.4-31.2 31.1-68 68l0-188.4-56 0 0 188.4c-36.8-36.9-59.5-59.5-68-68L152.4 352z", "M288 32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 88.4-71.6 160-160 160l-35.6 0 70.7-70.7c35.6-14 60.8-48.7 60.8-89.3 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5C393.5 139.9 345.9 96 288 96 230.1 96 182.5 139.9 176.6 196.2l-2.6 25.5-25.4 3c-47.6 5.6-84.5 46.2-84.5 95.3 0 40.6 25.2 75.2 60.8 89.3l70.8 70.7-35.6 0C71.6 480 0 408.4 0 320 0 246.5 49.6 184.6 117.1 165.8 136 89 205.3 32 288 32zm28 348.4c36.9-36.9 59.5-59.5 68-68l39.6 39.6-19.8 19.8-96 96c-10.9 10.9-28.7 10.9-39.6 0l-96-96-19.8-19.8 39.6-39.6c8.5 8.5 31.2 31.1 68 68l0-188.4 56 0 0 188.4z"]],
    "angle-down": [512, 512, [8964], "f107", ["", "M448.3 146.8l-192 192-192-192-45.2 45.2 214.6 214.6c12.5 12.5 32.8 12.5 45.3 0L493.5 192 448.3 146.8z"]],
    "ghost": [448, 512, [128123], "f6e2", ["M64 224l0 224 .3 0 38-32.6c24-20.5 59.3-20.5 83.3 0l38 32.6 .7 0 38-32.6c24-20.5 59.3-20.5 83.3 0l38 32.6 .3 0 0-224c0-88.4-71.6-160-160-160S64 135.6 64 224zm136 0a40 40 0 1 1 -80 0 40 40 0 1 1 80 0zm128 0a40 40 0 1 1 -80 0 40 40 0 1 1 80 0z", "M224 0C347.7 0 448 100.3 448 224l0 288-64.3 0c-15.3 0-30.1-5.5-41.7-15.4l-38-32.6-38 32.6c-11.6 9.9-26.4 15.4-41.7 15.4l-.7 0c-15.3 0-30.1-5.5-41.7-15.4l-38-32.6-38 32.6C94.4 506.5 79.6 512 64.3 512L0 512 0 224C0 100.3 100.3 0 224 0zm0 64C135.6 64 64 135.6 64 224l0 224 .3 0 38-32.6c24-20.5 59.3-20.5 83.3 0l38 32.6 .7 0 38-32.6c24-20.5 59.3-20.5 83.3 0l38 32.6 .3 0 0-224c0-88.4-71.6-160-160-160zM160 264a40 40 0 1 1 0-80 40 40 0 1 1 0 80zm128 0a40 40 0 1 1 0-80 40 40 0 1 1 0 80z"]],
    "chart-pie": [512, 512, ["pie-chart"], "f200", ["M288 66.7C368.4 80.2 431.8 143.6 445.3 224L288 224 288 66.7z", "M512 256c0 17.7-14.3 32-32 32l-256 0 0-256 .2-3.3C225.8 12.6 239.4 0 256 0 397.4 0 512 114.6 512 256zm-66.7-32C431.8 143.6 368.4 80.2 288 66.7l0 157.3 157.3 0zM0 256C0 148.6 66.2 56.6 160 18.6l0 71.1c-57.4 33.2-96 95.2-96 166.3 0 106 86 192 192 192 71.1 0 133.1-38.6 166.3-96l71.1 0c-38 93.8-130 160-237.4 160-141.4 0-256-114.6-256-256z"]],
    "phone-arrow-right": [576, 512, [], "e5be", ["M66.3 216.2c13.8 72.6 54.8 135.6 112 178 11.4 8.5 23.5 16.2 36.1 22.9 25.3 13.5 52.8 23.4 81.8 28.9 41.7 7.9 84.9-5.3 114.7-35.2L437.8 384c-17.8-17.8-35.7-35.7-53.5-53.5l-33.4 33.4c-17.1 17.1-42 23.7-65.3 17.3-16.5-4.5-32.1-10.8-46.8-18.7-2.1-1.1-4.2-2.3-6.2-3.5l0 0c-4.1-2.4-8.1-4.9-12-7.6-43.2-29.1-75.4-73.1-89.5-124.8-6.3-23.3 .3-48.2 17.3-65.2L181.8 128c-17.8-17.8-35.7-35.7-53.5-53.5l-26.9 26.9c-29.9 29.9-43.1 73-35.2 114.8z", "M83.1 29.2c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-33.4 33.4c-.8 .8-1.1 2-.8 3.2 13.7 50.1 51.2 89.9 99.8 106.7l9.9 3c.6 .2 1.1 .1 1.7 0l1.5-.8 33.4-33.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9-8.7 8.2c-41.4 36.6-96.8 53.5-151.6 46.5l-11.7-1.8C142.3 481.9 30.4 370 3.4 228.1-7.7 169.6 8.9 109.1 48.1 64.8l8.2-8.7 26.9-26.9zm18.4 72.2c-29.9 29.9-43.1 73-35.2 114.7 22.1 116.1 113.8 207.8 229.9 229.9 41.7 7.9 84.9-5.3 114.7-35.2l26.9-26.9-53.5-53.5-33.4 33.4c-17.1 17.1-42 23.7-65.2 17.3-75.3-20.5-134.1-79.3-154.6-154.6-6.3-23.3 .3-48.2 17.3-65.2l33.4-33.4-53.5-53.5-26.9 26.9zM565.6 76.2l1.8 2c4.1 5 6.3 11.3 6.3 17.8 0 7.4-2.9 14.6-8.2 19.8l-90.5 90.5-19.8 19.8-39.6-39.6c9.4-9.4 30.2-30.2 62.5-62.5l-186.7 0 0-56 186.7 0c-32.3-32.3-53.1-53.1-62.5-62.5L455.3-34.1 565.6 76.2z"]],
    "list-music": [640, 512, [], "f8c9", ["M192 64l0 64 96 0 0-64-96 0z", "M128 64c0-35.3 28.7-64 64-64l96 0c35.3 0 64 28.7 64 64l0 64c0 35.3-28.7 64-64 64l-96 0 0 224c0 53-43 96-96 96s-96-43-96-96 43-96 96-96c11.2 0 22 1.9 32 5.5L128 64zM96 384c-17.7 0-32 14.3-32 32s14.3 32 32 32 32-14.3 32-32l0 0c0-17.7-14.3-32-32-32zm96-256l96 0 0-64-96 0 0 64zm416 0l-192 0 0-64 224 0 0 64-32 0zm32 320l-352 0 0-64 352 0 0 64zM608 288l-192 0 0-64 224 0 0 64-32 0z"]],
    "inbox": [512, 512, [], "f01c", ["M64 64l0 196 113.3 0 32 64 93.4 0c18.9-37.9 29.6-59.2 32-64l113.3 0 0-196-384 0z", "M64 64l0 196 113.3 0 32 64 93.4 0c18.9-37.9 29.6-59.2 32-64l113.3 0 0-196-384 0zm0 252l0 132 384 0 0-132-78.7 0c-18.9 37.9-29.6 59.2-32 64l-162.6 0c-2.4-4.8-13.1-26.1-32-64L64 316zM0 64C0 28.7 28.7 0 64 0L448 0c35.3 0 64 28.7 64 64l0 384c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64z"]],
    "bolt-slash": [640, 512, [], "e0b8", ["", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM364.4 435.9L256.3 544 240.8 342.8c-.3-3.9-3.4-7.1-7.4-7.4l-201.2-15.5 108.1-108.1 224 224zm35.3-266.7c.3 3.9 3.4 7.1 7.4 7.4L608.3 192 500.1 300.1 276.1 76.1 384.3-32 399.7 169.2z"]],
    "cloud-snow": [576, 512, [127784], "f742", ["M64 256c0-49 36.7-89.4 84.1-95.2 3.9-.5 7.9-.8 11.9-.8 24.4 0 46.6 9 63.5 24 14.1-16 28.2-32 42.3-48-22.1-19.5-49.6-32.9-80-37.9 17.5-39 56.6-66.1 102.1-66.1 57.9 0 105.5 43.9 111.4 100.2l2.6 25.5 25.4 3c47.6 5.6 84.6 46.2 84.6 95.3 0 41.8-26.7 77.2-64 90.4l0-26.4c0-35.3-28.7-64-64-64s-64 28.7-64 64l0 8.6c-9.4-5.5-20.3-8.6-32-8.6s-22.6 3.1-32 8.6l0-8.6c0-35.3-28.7-64-64-64s-64 28.7-64 64l0 26.4C90.7 333.2 64 297.8 64 256z", "M288 480c17.7 0 32 14.3 32 32s-14.3 32-32 32-32-14.3-32-32 14.3-32 32-32zm-96 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm192 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm-96-64a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm0-448c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 77.4-55 142-128 156.8l0-66.4c37.3-13.2 64-48.6 64-90.4 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5c-5.9-56.3-53.5-100.2-111.4-100.2-45.5 0-84.6 27.2-102.1 66.1 30.4 4.9 57.9 18.4 80 37.9-14.1 16-28.2 32-42.3 48-16.9-15-39.1-24-63.5-24-4 0-8 .3-11.9 .8-47.4 5.8-84.1 46.3-84.1 95.2 0 41.8 26.7 77.2 64 90.4l0 66.4c-73-14.8-128-79.4-128-156.8 0-2.6 .1-5.1 .2-7.6 0-.7 .1-1.5 .2-2.2 .1-1.8 .2-3.6 .4-5.3 .1-1.4 .3-2.8 .5-4.2 .1-1.2 .3-2.4 .4-3.5 .1-.8 .2-1.6 .3-2.3 .7-4.2 1.5-8.3 2.5-12.3 .7-2.8 1.4-5.5 2.2-8.2 .1-.4 .2-.7 .3-1.1 .4-1.1 .8-2.3 1.1-3.4 .4-1.2 .8-2.5 1.2-3.7 .4-1.1 .9-2.3 1.3-3.4 .5-1.2 1-2.5 1.5-3.7 .4-.9 .7-1.7 1.1-2.6 .6-1.4 1.3-2.8 1.9-4.2 .3-.7 .7-1.5 1-2.2 1-2 2-4.1 3.1-6.1 .6-1.2 1.3-2.3 2-3.5 .5-.9 1-1.9 1.6-2.8 .8-1.3 1.6-2.5 2.4-3.8 .5-.8 1-1.5 1.5-2.3 .7-1.1 1.4-2.1 2.2-3.2 .7-1 1.4-2 2.1-3 .4-.6 .9-1.2 1.3-1.8 1-1.3 2-2.6 3.1-3.9 .6-.7 1.1-1.4 1.7-2.1 1.4-1.7 2.9-3.4 4.4-5.1 .5-.6 1-1.1 1.6-1.7 1.2-1.2 2.3-2.5 3.5-3.7 .5-.5 1-1 1.5-1.5 1.1-1 2.1-2.1 3.2-3.1 .9-.8 1.8-1.7 2.7-2.5 .9-.8 1.8-1.6 2.7-2.3 .8-.7 1.7-1.4 2.5-2.1 .9-.7 1.8-1.4 2.7-2.1 6-4.6 12.3-8.9 18.9-12.7 .3-.2 .6-.3 .9-.5 3.5-2 5.6-3 6.1-3.3 4.8-2.5 9.8-4.7 14.9-6.6 .8-.3 1.5-.6 2.3-.9 .7-.2 1.3-.5 2-.7 1.3-.5 2.6-.9 4-1.3l1.6-.5c1.3-.4 2.6-.8 4-1.1 .2-.1 .5-.2 .7-.2 18.9-76.9 88.2-133.8 170.9-133.8zM192 352a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm192 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64z"]],
    "credit-card": [512, 512, [128179, 62083, "credit-card-alt"], "f09d", ["M64 96l0 64 384 0 0-64-384 0zm0 128l0 192 384 0 0-192-384 0z", "M64 96l0 64 384 0 0-64-384 0zm0 128l0 192 384 0 0-192-384 0zM0 96C0 60.7 28.7 32 64 32l384 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96z"]],
    "wand-magic-sparkles": [576, 512, ["magic-wand-sparkles"], "e2ca", ["M93.3 400c76.5-76.5 153-153 229.6-229.6L373.6 221.2 144 450.7c-16.9-16.9-33.8-33.8-50.7-50.7z", "M508 420l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68zm65.2-308l-384 384c-25 25-65.5 25-90.5 0L48 445.3c-25-25-25-65.5 0-90.5L432-29.2 573.3 112zM93.3 400L144 450.7 373.6 221.2 322.8 170.4 93.3 400zM362.5 130.8l50.8 50.8 69.6-69.6-50.7-50.8-69.6 69.6zM124 36l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"]],
    "bell-slash": [640, 512, [128277, 61943], "f1f6", ["M180 352c2.5-4.9 13.6-27.2 33.5-67 22.3 22.3 44.7 44.6 67 67L180 352zM275.2 75.2c11.8-6.3 25-10.2 39-11.1 2-.1 4-.2 6.1-.2 6.6 0 13.1 .7 19.3 2 3.1 .6 6.2 1.4 9.2 2.4 39.1 12.2 67.5 48.6 67.5 91.7 0 18.7 0 37.5 0 56.2l-141-141z", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM384.3 455.8l0 56.2-128 0 0-64 120.2 0 7.8 7.8zM213.5 285l-33.5 67 100.5 0 64 64-268 0 83.8-167.6 0-16.7 53.2 53.2zM320.3 0c88.4 0 160 71.6 160 160l0 120.2-64-64 0-56.2c0-53-43-96-96-96-16.3 0-31.6 4.1-45 11.2L228.8 28.8C254.7 10.6 286.2 0 320.3 0z"]],
    "folders": [576, 512, [], "f660", ["M192 64l0 256 320 0 0-192-154.5 0c-8.1-8.1-29.4-29.4-64-64L192 64z", "M320 0L192 0c-35.3 0-64 28.7-64 64l0 256c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-192c0-35.3-28.7-64-64-64L384 64 320 0zM192 64l101.5 0c34.6 34.6 55.9 55.9 64 64l154.5 0 0 192-320 0 0-256zM64 160l0-32-64 0 0 320c0 35.3 28.7 64 64 64l416 0 0-64-416 0 0-288z"]],
    "tv": [512, 512, [63717, "television", "tv-alt"], "f26c", ["M64 64l0 256 384 0 0-256-384 0z", "M448 512l-384 0 0-64 384 0 0 64zM448 0c35.3 0 64 28.7 64 64l0 256-.3 6.5C508.4 358.8 481.1 384 448 384L64 384C30.9 384 3.6 358.8 .3 326.5L0 320 0 64C0 28.7 28.7 0 64 0L448 0zM64 320l384 0 0-256-384 0 0 256z"]],
    "star": [576, 512, [11088, 61446], "f005", ["M147.7 242.3l43 43.3c16.1 16.2 23.6 39.2 20.1 61.8l-9.3 60.3 54.5-27.5 3.9-1.8c19.5-8.5 41.9-7.9 61.1 1.8l54.5 27.5-9.3-60.3c-3.1-19.8 2.2-39.8 14.4-55.4 1.7-2.2 3.6-4.3 5.7-6.4 14.3-14.4 28.7-28.9 43-43.3l-60.2-9.8c-22.6-3.7-42.1-17.8-52.5-38.2l-27.9-54.3-27.9 54.3c-2 3.8-4.2 7.4-6.8 10.8-.9 1.1-1.7 2.2-2.6 3.3-11 12.7-26.2 21.4-43.1 24.2l-60.3 9.7z", "M373.2 165.1c1.2 2.3 3.3 3.8 5.8 4.2L562.3 199 431.5 330.7c-1.8 1.8-2.6 4.4-2.2 6.9L457.7 521 292 437.3c-2.3-1.1-5-1.1-7.2 0L119.1 521 147.5 337.6c.4-2.5-.4-5.1-2.2-6.9L14.5 199 197.8 169.3c1.9-.3 3.6-1.3 4.8-2.7l1.1-1.5 84.8-165.1 84.8 165.1zM260.5 194.3c-10.5 20.3-29.9 34.5-52.5 38.2l-60.3 9.8 43 43.3c16.1 16.2 23.6 39.2 20.1 61.8l-9.3 60.3 54.5-27.5 3.9-1.8c19.5-8.5 41.9-7.9 61.1 1.8l54.5 27.5-9.3-60.3c-3.5-22.6 3.9-45.6 20.1-61.8l43-43.3-60.2-9.8c-22.6-3.7-42.1-17.8-52.5-38.2l-27.9-54.3-27.9 54.3z"]],
    "flag": [448, 512, [127988, 61725], "f024", ["M64 96l0 192 50.8 0c45.9 0 90 18.3 122.5 50.7 8.5 8.5 20 13.3 32 13.3l114.7 0 0-192-50.7 0c-45.9 0-90-18.3-122.5-50.8-8.5-8.5-20-13.2-32-13.2L64 96z", "M64 32l114.8 0c27.2 0 53.3 10.1 73.3 28.2l7.9 7.5c18.7 16.9 42.7 26.9 67.9 28.1l5.4 .1 50.7 0c35.3 0 64 28.7 64 64l0 192c0 35.3-28.7 64-64 64l-114.7 0-5.4-.1c-25.2-1.2-49.2-11.2-67.9-28.1l-7.9-7.5c-18.7-16.9-42.7-26.9-67.9-28.1l-5.4-.1-50.8 0 0 160-64 0 0-512 64 0 0 32zm0 256l50.8 0c45.9 0 90 18.3 122.5 50.7 8.5 8.5 20 13.3 32 13.3l114.7 0 0-192-50.7 0c-45.9 0-90-18.3-122.5-50.8-8.5-8.5-20-13.2-32-13.2L64 96 64 288z"]],
    "arrow-right-from-line": [512, 512, [8614, "arrow-from-left"], "f343", ["", "M64 480l-64 0 0-448 64 0 0 448zM502.6 233.4l2.2 2.4c10.2 12.6 9.5 31.1-2.2 42.8l-150.6 150.6-45.3-45.3 96-96-242.7 0 0-64 242.7 0-96-96 45.3-45.2 150.6 150.6z"]],
    "store": [576, 512, [], "f54e", ["M64 224l0 32c0 17.7 14.3 32 32 32s32-14.3 32-32l0-32-64 0zm10.6-64l426.7 0-57.6-96-311.5 0-57.6 96zM192 224l0 32c0 17.7 14.3 32 32 32s32-14.3 32-32l0-32-64 0zm128 0l0 32c0 17.7 14.3 32 32 32s32-14.3 32-32l0-32-64 0zm128 0l0 32c0 17.7 14.3 32 32 32s32-14.3 32-32l0-32-64 0z", "M443.8 64l57.6 96-426.7 0 57.6-96 311.5 0zM96 0L0 160 0 256c0 28.4 12.4 54 32 71.6L32 448c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-120.4c19.6-17.6 32-43.1 32-71.6l0-96-96-160-384 0zM480 352l0 96-384 0 0-96c24.6 0 47-9.2 64-24.4 17 15.2 39.4 24.4 64 24.4s47-9.2 64-24.4c17 15.2 39.4 24.4 64 24.4s47-9.2 64-24.4c17 15.2 39.4 24.4 64 24.4zM64 256l0-32 64 0 0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32zm128 0l0-32 64 0 0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32zm128 0l0-32 64 0 0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32zm128-32l64 0 0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-32z"]],
    "mug-saucer": [576, 512, ["coffee"], "f0f4", ["M128 96l0 160c0 35.3 28.7 64 64 64l128 0c35.3 0 64-28.7 64-64l0-160-256 0z", "M64 32l400 0c61.9 0 112 50.1 112 112S525.9 256 464 256l-16 0c0 70.7-57.3 128-128 128l-128 0c-70.7 0-128-57.3-128-128L64 32zM448 192l16 0c26.5 0 48-21.5 48-48s-21.5-48-48-48l-16 0 0 96zM128 96l0 160c0 35.3 28.7 64 64 64l128 0c35.3 0 64-28.7 64-64l0-160-256 0zM512 416c0 53-43 96-96 96L96 512c-53 0-96-43-96-96l64 0c0 17.7 14.3 32 32 32l320 0c17.7 0 32-14.3 32-32l64 0z"]],
    "lock": [384, 512, [128274], "f023", ["M64 256l256 0 0 192-256 0 0-192z", "M128 192l128 0 0-64c0-35.3-28.7-64-64-64s-64 28.7-64 64l0 64zm-64 0l0-64C64 57.3 121.3 0 192 0S320 57.3 320 128l0 64c35.3 0 64 28.7 64 64l0 192c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 256c0-35.3 28.7-64 64-64zm256 64l-256 0 0 192 256 0 0-192z"]],
    "folder-plus": [512, 512, [], "f65e", ["M64 96l0 320 384 0 0-256-186.5 0-64-64-133.5 0zm96 164l68 0 0-68 56 0 0 68 68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56z", "M288 96l160 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l160 0 64 64zM64 416l384 0 0-256-186.5 0-64-64-133.5 0 0 320zM284 260l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"]],
    "anchor": [512, 512, [9875], "f13d", ["M224 96a32 32 0 1 0 64 0 32 32 0 1 0 -64 0z", "M256 0c53 0 96 43 96 96 0 41.8-26.7 77.2-64 90.4l0 261.6 32 0c70.7 0 128-57.3 128-128l-64 0 0-64 128 0 0 64c0 106-86 192-192 192l-128 0C86 512 0 426 0 320l0-64 128 0 0 64-64 0c0 70.7 57.3 128 128 128l32 0 0-261.6c-37.3-13.2-64-48.6-64-90.4 0-53 43-96 96-96zm0 64a32 32 0 1 0 0 64 32 32 0 1 0 0-64z"]],
    "user-minus": [640, 512, [], "f503", ["M64 480l0 32 320 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96zm96-352a64 64 0 1 0 128 0 64 64 0 1 0 -128 0z", "M288 320c88.4 0 160 71.6 160 160l0 32-64 0 0-32c0-53-43-96-96-96l-128 0c-53 0-96 43-96 96l0 32-64 0 0-32c0-88.4 71.6-160 160-160l128 0zm-64-64a128 128 0 1 1 0-256 128 128 0 1 1 0 256zm416-4l-192 0 0-56 192 0 0 56zM224 64a64 64 0 1 0 0 128 64 64 0 1 0 0-128z"]],
    "scissors": [512, 512, [9984, 9986, 9988, "cut"], "f0c4", ["M64 112a48 48 0 1 0 96 0 48 48 0 1 0 -96 0zm0 288a48 48 0 1 0 96 0 48 48 0 1 0 -96 0z", "M112 0c61.9 0 112 50.1 112 112 0 17.5-4 34.1-11.2 48.9l68.2 53.9 163.3-127.9 25.2-19.8 39.5 50.4-25.2 19.8-271.5 212.8c7.5 15.1 11.8 32 11.8 50 0 61.9-50.1 112-112 112S0 461.9 0 400 50.1 288 112 288c20.5 0 39.7 5.5 56.2 15.2l61-47.8-59.8-47.2C152.6 218.2 133 224 112 224 50.1 224 0 173.9 0 112S50.1 0 112 0zm0 352a48 48 0 1 0 0 96 48 48 0 1 0 0-96zm371.8 22.9l25.1 19.8-39.7 50.2-25.1-19.8-111-87.6 51.7-40.8 99 78.2zM112 64a48 48 0 1 0 0 96 48 48 0 1 0 0-96z"]],
    "bug": [448, 512, [], "f188", ["M128 224l0 128c0 3.3 .2 6.6 .5 9.8 .2 1.6 .4 3.2 .6 4.8 0 0 0 .1 0 .1 .1 .5 .1 .8 .2 1 .1 .4 .1 .7 .2 .9 .1 .4 .1 .7 .1 .8 .1 .3 .1 .5 .1 .6 .1 .3 .1 .4 .1 .5 0 .2 .1 .3 .1 .5 0 0 0 .1 0 .1 2.3 11.2 6.4 21.6 12.2 31 .1 .1 .1 .2 .2 .3 3.2 5.2 6.9 10.1 11 14.6l0 0c.3 .3 .5 .6 .8 .8 0 0 0 0 0 0 .6 .7 1.3 1.3 2 2 17.4 17.4 41.4 28.1 67.9 28.1s50.5-10.7 67.9-28.1c.2-.2 .4-.4 .5-.5 .2-.2 .4-.4 .6-.6 .1-.1 .1-.1 .2-.2 1.2-1.3 2.5-2.6 3.6-4 .1-.1 .1-.1 .2-.2 .2-.2 .4-.5 .6-.7 .1-.1 .1-.2 .2-.2 .4-.5 .8-1 1.2-1.5 .1-.1 .1-.2 .2-.3 8.1-10.3 14.2-22.3 17.6-35.3 0 0 0 0 0-.1 0-.1 .1-.3 .1-.4 0 0 0-.1 0-.1 0-.2 .1-.3 .1-.5 0-.1 .1-.3 .1-.5 0-.1 .1-.3 .1-.6 0-.2 .1-.3 .1-.4 .2-.8 .3-1.5 .5-2.3 1.3-6.3 2-12.7 2-19.4l0-128-192 0zm5.6-64l180.9 0c-13.2-37.3-48.7-64-90.4-64s-77.2 26.7-90.4 64z", "M378.6 17.8L337.6 79.3c13.8 13.9 25.1 30.4 33.1 48.7l77.3 0 0 64-64 0 0 64 64 0 0 64-64 0 0 32c0 11-1.1 21.7-3.2 32l67.2 0 0 64-96 0c-29.2 38.9-75.7 64-128 64s-98.8-25.1-128-64l-96 0 0-64 67.2 0c-1.6-7.7-2.6-15.7-3-23.8l-.2-8.2 0-32-64 0 0-64 64 0 0-64-64 0 0-64 77.3 0c8-18.3 19.2-34.7 33.1-48.7l-41-61.6 53.2-35.5 41 61.5C182.3 36.2 202.6 32 224 32s41.7 4.2 60.3 11.8l41.1-61.5 53.2 35.5zM128 352c0 53 43 96 96 96s96-43 96-96l0-128-192 0 0 128zM224 96c-41.8 0-77.2 26.7-90.4 64l180.9 0c-13.2-37.3-48.7-64-90.4-64z"]],
    "arrow-right-from-bracket": [512, 512, ["sign-out"], "f08b", ["", "M192 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l96 0 0 64-96 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l96 0 0 64zM502.6 233.4l2.2 2.4c10.2 12.6 9.5 31.1-2.2 42.8l-150.6 150.6-45.2-45.3 96-96-242.8 0 0-64 242.8 0-96-96 45.2-45.2 150.6 150.6z"]],
    "arrow-right-arrow-left": [448, 512, [8644, "exchange"], "f0ec", ["", "M9.4 406.6C85.6 482.9 125.1 522.4 128 525.3L173.3 480c-12-12-33.3-33.3-64-64l338.7 0 0-64-338.7 0c30.7-30.7 52-52 64-64L128 242.7c-2.9 2.9-42.4 42.4-118.6 118.6-6 6-9.4 14.1-9.4 22.6s3.4 16.6 9.4 22.6zm429.3-256c12.5-12.5 12.5-32.8 0-45.3-76.2-76.2-115.8-115.8-118.6-118.6L274.7 32c12 12 33.3 33.3 64 64L0 96 0 160 338.7 160c-30.7 30.7-52 52-64 64L320 269.2c2.9-2.9 42.4-42.4 118.6-118.6z"]],
    "arrow-up-from-line": [448, 512, [8613, "arrow-from-bottom"], "f342", ["", "M448 512l-448 0 0-64 448 0 0 64zM203.8 7.2c12.6-10.3 31.1-9.5 42.8 2.2l150.6 150.6-45.3 45.3-96-96 0 242.7-64 0 0-242.7-96 96-45.2-45.3 150.6-150.6 2.4-2.2z"]],
    "battery-full": [640, 512, [128267, "battery", "battery-5"], "f240", ["M64 128l0 256 416 0 0-256-416 0zm36 36l344 0 0 184-344 0 0-184z", "M480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l416 0zM64 384l416 0 0-256-416 0 0 256zm576-32l-64 0 0-192 64 0 0 192zm-196-4l-344 0 0-184 344 0 0 184zM156 292l232 0 0-72-232 0 0 72z"]],
    "font": [512, 512, [], "f031", ["M128 224l0 32 256 0 0-32c0-70.7-57.3-128-128-128S128 153.3 128 224z", "M128 224l0 32 256 0 0-32c0-70.7-57.3-128-128-128S128 153.3 128 224zm0 96l0 96 64 0 0 64-192 0 0-64 64 0 0-192C64 118 150 32 256 32s192 86 192 192l0 192 64 0 0 64-192 0 0-64 64 0 0-96-256 0z"]],
    "language": [576, 512, [], "f1ab", ["M368.6 384l94.9 0-47.5-110.8-47.5 110.8z", "M192 0l0 64 160 0 0 64-41.6 0-8.4 23.1c-16.6 45.7-41.6 87.5-73.3 123.3 30.9 18.1 64.6 31.8 100 40.2l58-135.2c5-11.8 16.6-19.4 29.4-19.4s24.4 7.6 29.4 19.4l120 280 12.6 29.4-58.8 25.2c-7.9-18.4-17.3-40.4-28.3-66l-149.8 0c-11 25.6-20.4 47.6-28.3 66L254 488.8c4.4-10.3 20.8-48.5 49.1-114.6-43.6-11.7-84.9-30-122.4-54.2-20.9 16.7-43.6 31.2-67.8 43.3-24 12-45.1 22.5-63.2 31.6L21.1 337.7c18.1-9 39.2-19.6 63.2-31.6 15.3-7.6 29.8-16.4 43.5-26.3-27.4-24.4-51.9-52.3-72.6-83.4l-1.8-2.7 53.3-35.5 1.8 2.7c19.1 28.7 41.9 54.2 67.7 76.1 28.6-30.9 51.1-67.5 65.7-107.8l.5-1.2-242.3 0 0-64 128 0 0-64 64 0zM416 273.2L368.6 384 463.5 384 416 273.2z"]],
    "shield-halved": [448, 512, ["shield-alt"], "f3ed", ["M64 119.1l0 146.3c0 60.6 34.2 116 88.4 143.1l43.6 21.8 0-355.2-132 44z", "M234.1 1.7L404.2 58.3c26.1 8.7 43.7 33.2 43.8 60.7l0 146.3c0 84.8-47.9 162.4-123.8 200.3L224 515.8 123.8 465.7C47.9 427.7 0 350.2 0 265.3L0 119.1c0-27.5 17.6-52 43.8-60.7L213.9 1.7 224-1.7 234.1 1.7zM64 119.1l0 146.3c0 60.6 34.2 116 88.4 143.1l43.6 21.8 0-355.2-132 44zM252 430.2l43.6-21.8c54.2-27.1 88.4-82.5 88.4-143.1l0-146.3-132-44 0 355.2z"]],
    "person-biking": [576, 512, [128692, "biking"], "f84a", ["M56 400a56 56 0 1 0 112 0 56 56 0 1 0 -112 0zm352 0a56 56 0 1 0 112 0 56 56 0 1 0 -112 0z", "M416 48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM56 400a56 56 0 1 1 112 0 56 56 0 1 1 -112 0zm168 0a112 112 0 1 0 -224 0 112 112 0 1 0 224 0zm184 0a56 56 0 1 1 112 0 56 56 0 1 1 -112 0zm168 0a112 112 0 1 0 -224 0 112 112 0 1 0 224 0zM242.2 219l49.8-49.8 74.2 49.4c5.3 3.5 11.4 5.4 17.8 5.4l64 0 0-64-54.3 0-77-51.3c-19-12.7-44.4-10.2-60.6 6l-72.9 72.9c-21.4 21.4-17.9 57.1 7.3 73.9l65.5 43.7 0 110.9 64 0 0-128c0-10.7-5.3-20.7-14.2-26.6L242.2 219z"]],
    "phone-xmark": [512, 512, [], "e227", ["M66.3 216.2c10.9 57.1 38.6 108.3 77.8 148.2 .6 .6 1.2 1.2 1.8 1.8 0 0 .1 .1 .1 .1 5 5 10.2 9.9 15.6 14.5 37.7 32.5 83.8 55.5 134.6 65.2 41.7 7.9 84.9-5.3 114.7-35.2L437.8 384c-17.8-17.8-35.7-35.7-53.5-53.5l-33.4 33.4c-17.1 17.1-42 23.7-65.3 17.3-36.1-9.9-68.5-28.5-94.6-53.6-.2-.2-.4-.4-.7-.7-.8-.8-1.7-1.6-2.5-2.5l0 0c-3.3-3.3-6.6-6.8-9.7-10.3-21.8-24.8-38.1-54.6-47.1-87.5-6.3-23.3 .3-48.2 17.3-65.3L181.8 128c-17.8-17.8-35.7-35.7-53.5-53.5l-26.9 26.9c-29.9 29.9-43.1 73-35.2 114.8z", "M83.1 29.2c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-33.4 33.4c-.8 .8-1.1 2-.8 3.2 13.7 50.1 51.2 89.9 99.8 106.7l9.9 3c.6 .2 1.1 .1 1.7 0l1.5-.8 33.4-33.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9-8.7 8.2c-41.4 36.6-96.8 53.5-151.6 46.5l-11.7-1.8C142.3 481.9 30.4 370 3.4 228.1-7.7 169.6 8.9 109.1 48.1 64.8l8.2-8.7 26.9-26.9zm18.4 72.2c-29.9 29.9-43.1 73-35.2 114.8 22.1 116.1 113.8 207.8 229.9 229.9 41.7 7.9 84.9-5.3 114.7-35.2l26.9-26.9-53.5-53.5-33.4 33.4c-17.1 17.1-42 23.7-65.2 17.3-75.3-20.5-134.1-79.3-154.6-154.6-6.3-23.3 .3-48.2 17.3-65.3l33.4-33.4-53.5-53.5-26.9 26.9zM496 55.9l-56.1 56.1 56.1 56.1-39.6 39.6-56.1-56.1-56.1 56.1-39.6-39.6 56.1-56.1-56.1-56.1 39.6-39.6 56.1 56.1 56.1-56.1 39.6 39.6z"]],
    "globe": [512, 512, [127760], "f0ac", ["M66.1 228l62.7 0c2.8-52 13.4-99.4 29.5-137.3-48.8 28.9-83.6 78.8-92.2 137.3zm0 56c8.5 58.4 43.4 108.3 92.2 137.3-16-37.9-26.6-85.2-29.5-137.3l-62.7 0zm118.8-56l142.2 0c-3.2-51.9-15-96.5-30.7-128-9.2-18.3-17.8-29.1-24.7-35.3 0 0 0 0 0 0-2.6-.2-5.2-.4-7.8-.5l0 0c-2.6-.1-5.3-.2-7.9-.2-5.3 0-10.6 .3-15.7 .7-6.9 6.3-15.5 17.1-24.7 35.3-15.7 31.5-27.5 76-30.7 128zm0 56c3.2 51.9 15 96.5 30.7 128 9.1 18.3 17.7 29 24.7 35.3 5.2 .4 10.4 .7 15.7 .7 1.3 0 2.6 0 4-.1s2.6-.1 3.9-.1l0 0c2.6-.1 5.2-.3 7.8-.5l0 0c6.9-6.3 15.5-17 24.7-35.3 15.7-31.5 27.5-76 30.7-128l-142.3 0zM353.7 90.7c16 37.9 26.7 85.2 29.5 137.3l62.7 0c-8.5-58.5-43.4-108.4-92.2-137.3zm0 330.5c48.8-28.9 83.7-78.8 92.2-137.3l-62.7 0c-2.8 52-13.5 99.4-29.5 137.3z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM184.9 284c3.2 51.9 15 96.5 30.7 128 9.1 18.3 17.7 29 24.7 35.3 5.2 .4 10.4 .7 15.8 .7s10.5-.3 15.7-.7c6.9-6.3 15.5-17 24.7-35.3 15.7-31.5 27.5-76 30.7-128l-142.3 0zM66.1 284c8.5 58.5 43.4 108.3 92.2 137.3-16-37.9-26.6-85.2-29.5-137.3l-62.7 0zm317.2 0c-2.8 52-13.5 99.4-29.5 137.3 48.8-28.9 83.7-78.8 92.2-137.3l-62.7 0zM158.2 90.7C109.5 119.6 74.6 169.5 66.1 228l62.7 0c2.8-52 13.4-99.4 29.5-137.3zM256 64c-5.3 0-10.6 .3-15.8 .7-6.9 6.3-15.5 17.1-24.7 35.3-15.7 31.5-27.5 76-30.7 128l142.3 0c-3.2-51.9-15-96.5-30.7-128-9.2-18.3-17.8-29.1-24.7-35.3-5.2-.4-10.4-.7-15.7-.7zm97.7 26.7c16 37.9 26.7 85.2 29.5 137.3l62.7 0c-8.5-58.5-43.4-108.4-92.2-137.3z"]],
    "folder-minus": [512, 512, [], "f65d", ["M64 96l0 320 384 0 0-256-186.5 0-64-64-133.5 0zm96 164l192 0 0 56-192 0 0-56z", "M288 96l160 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l160 0 64 64zM64 416l384 0 0-256-186.5 0-64-64-133.5 0 0 320zM352 316l-192 0 0-56 192 0 0 56z"]],
    "poop": [512, 512, [], "f619", ["M64 368c0 44.2 35.8 80 80 80l224 0c44.2 0 80-35.8 80-80 0-28.2-14.5-53-36.7-67.3l-35.9-23.1c2.5-14 5.1-28 7.6-42 .7-3.7 1-7.5 1-11.5 0-23.8-13-44.6-32.5-55.7-9.4-5.3-18.7-10.6-28.1-16-1.3-10.7-2.6-21.4-3.8-32.1-2.9-24.3-19.5-44.4-41.9-52.5-9.2 30.7-27.4 57.9-52.2 78.1-5.4 4.4-10.8 8.8-16.2 13.2-6.9 .4-13.9 .7-20.8 1.1-33.7 1.8-60.4 29.8-60.4 63.9l0 .9c5.3-.6 10.6-.9 16-.9 10.7 0 21.3 0 32 0l0 64-32 0c-44.2 0-80 35.8-80 80z", "M209.3 159l16.2-13.2c24.8-20.2 43-47.4 52.2-78.1 22.4 8 39 28.2 41.9 52.5l3.8 32.1 28.1 16c19.5 11.1 32.5 31.9 32.5 55.7 0 4-.4 7.8-1 11.5l-7.6 42 35.9 23.1c22.2 14.3 36.7 39.2 36.7 67.3 0 44.2-35.8 80-80 80l-224 0c-44.2 0-80-35.8-80-80s35.8-80 80-80l32 0 0-64-32 0c-5.4 0-10.7 .3-16 .9 0-.3 0-.6 0-.9 0-34.2 26.8-62.1 60.4-63.9l20.8-1.1zM0 368c0 79.5 64.5 144 144 144l224 0c79.5 0 144-64.5 144-144 0-50.8-26.3-95.5-66-121.1 1.3-7.4 2-15.1 2-22.9 0-47.8-26.2-89.4-64.9-111.4-7.6-63.4-61.6-112.6-127.1-112.6-9.2 0-18.3 1-27 2.8L217 47c-5.3 19.4-16.5 36.6-32 49.2-67.4 3.6-121 59.5-121 127.8 0 7.8 .7 15.5 2 22.9-39.7 25.6-66 70.3-66 121.1z"]],
    "speaker": [448, 512, [], "f8df", ["M64 64l320 0 0 384-320 0 0-384zm48 240a112 112 0 1 0 224 0 112 112 0 1 0 -224 0zm72-176a40 40 0 1 0 80 0 40 40 0 1 0 -80 0z", "M384 448l-320 0 0-384 320 0 0 384zM448 64c0-35.3-28.7-64-64-64L64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-384zM224 248a56 56 0 1 1 0 112 56 56 0 1 1 0-112zm112 56a112 112 0 1 0 -224 0 112 112 0 1 0 224 0zM264 128a40 40 0 1 0 -80 0 40 40 0 1 0 80 0z"]],
    "battery-quarter": [640, 512, ["battery-2"], "f243", ["M64 128l0 256 416 0 0-256-416 0zm36 36l152 0 0 184-152 0 0-184z", "M480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l416 0zM64 384l416 0 0-256-416 0 0 256zm576-32l-64 0 0-192 64 0 0 192zm-388-4l-152 0 0-184 152 0 0 184zm-96-56l40 0 0-72-40 0 0 72z"]],
    "diamond": [576, 512, [9830], "f219", ["M90.5 256C156.3 321.8 222.2 387.7 288 453.5L485.5 256C419.7 190.2 353.8 124.3 288 58.5L90.5 256z", "M288-16c10.2 0 20.1 4.1 27.3 11.3L548.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3l-233.4 233.4-2.8 2.6c-6.9 5.6-15.5 8.7-24.5 8.7s-17.6-3.1-24.5-8.7l-2.8-2.6-233.4-233.4C20.1 276.1 16 266.2 16 256s4.1-20.1 11.3-27.3L260.7-4.7C267.9-11.9 277.8-16 288-16zM90.5 256L288 453.5 485.5 256 288 58.5 90.5 256z"]],
    "computer-classic": [512, 512, [], "f8b1", ["M64 64l0 332.6 34.2 51.4 315.5 0 34.2-51.4 0-332.6-384 0zM96 96l320 0 0 192-320 0 0-192zM288 324l128 0 0 56-128 0 0-56z", "M448 0c35.3 0 64 28.7 64 64l0 332.6-.2 4.7c-.8 11-4.4 21.6-10.6 30.8l-34.2 51.4-2.3 3.2c-11.2 14.8-28.4 24-46.9 25.1l-4 .1-315.5 0c-21.4 0-41.4-10.7-53.2-28.5L10.8 432.1C4.6 422.9 1 412.3 .2 401.3L0 396.6 0 64C0 28.7 28.7 0 64 0L448 0zM64 396.6l34.2 51.4 315.5 0 34.2-51.4 0-332.6-384 0 0 332.6zM416 380l-128 0 0-56 128 0 0 56zm0-92l-320 0 0-192 320 0 0 192zM152 232l208 0 0-80-208 0 0 80z"]],
    "grid-round": [512, 512, [], "e5da", ["M64 112a48 48 0 1 0 96 0 48 48 0 1 0 -96 0zm0 288a48 48 0 1 0 96 0 48 48 0 1 0 -96 0zM352 112a48 48 0 1 0 96 0 48 48 0 1 0 -96 0zm0 288a48 48 0 1 0 96 0 48 48 0 1 0 -96 0z", "M112 512a112 112 0 1 1 0-224 112 112 0 1 1 0 224zm288 0a112 112 0 1 1 0-224 112 112 0 1 1 0 224zM112 352a48 48 0 1 0 0 96 48 48 0 1 0 0-96zm288 0a48 48 0 1 0 0 96 48 48 0 1 0 0-96zM112 224a112 112 0 1 1 0-224 112 112 0 1 1 0 224zm288 0a112 112 0 1 1 0-224 112 112 0 1 1 0 224zM112 64a48 48 0 1 0 0 96 48 48 0 1 0 0-96zm288 0a48 48 0 1 0 0 96 48 48 0 1 0 0-96z"]],
    "arrow-left": [448, 512, [8592], "f060", ["", "M269.3 64l-160 160 338.8 0 0 64-338.8 0 160 160-45.3 45.3-214.6-214.6c-12.5-12.5-12.5-32.8 0-45.3L224 18.8 269.3 64z"]],
    "paw": [512, 512, [], "f1b0", ["M96 385.3c0 34 28.4 62.7 63.7 62.7 9.1 0 18.1-2.6 25.6-7.3 25-15.6 48.6-30.4 70.7-44.2 22.1 13.8 45.7 28.6 70.7 44.2 7.5 4.7 16.5 7.3 25.6 7.3 35.3 0 63.7-28.7 63.7-62.7 0-15.7-5.9-30.8-16.5-42.4L289.3 222.6c-8.5-9.3-20.6-14.6-33.3-14.6s-24.7 5.3-33.3 14.6L112.5 342.9C101.9 354.5 96 369.6 96 385.3z", "M128 48a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zM256 396.5c22.1 13.8 45.7 28.6 70.7 44.2 7.5 4.7 16.5 7.3 25.6 7.3 35.3 0 63.7-28.7 63.7-62.7 0-15.7-5.9-30.8-16.5-42.4L289.3 222.6c-8.5-9.3-20.6-14.6-33.3-14.6s-24.7 5.3-33.3 14.6L112.5 342.9c-10.6 11.6-16.5 26.7-16.5 42.4 0 34 28.4 62.7 63.7 62.7 9.1 0 18.1-2.6 25.6-7.3 25-15.6 48.6-30.4 70.7-44.2zM65.3 299.7L175.6 179.4C196.2 156.8 225.4 144 256 144s59.8 12.8 80.4 35.4L446.7 299.7c21.4 23.4 33.3 53.9 33.3 85.6 0 70-57.7 126.7-127.7 126.7-21 0-41.8-5.9-59.6-17l-36.8-23-36.8 23c-17.8 11.1-38.6 17-59.6 17-70 0-127.7-56.7-127.7-126.7 0-31.7 11.9-62.3 33.3-85.6zM48 128a48 48 0 1 1 0 96 48 48 0 1 1 0-96zM288 48a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm176 80a48 48 0 1 1 0 96 48 48 0 1 1 0-96z"]],
    "bed": [640, 512, [128716], "f236", ["M384 160l0 160 192 0 0-128c0-17.7-14.3-32-32-32l-160 0z", "M64 32l0 288 256 0 0-192c0-17.7 14.3-32 32-32l192 0c53 0 96 43 96 96l0 288-64 0 0-96-512 0 0 96-64 0 0-448 64 0zM384 320l192 0 0-128c0-17.7-14.3-32-32-32l-160 0 0 160zM224 192a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zM96 192a96 96 0 1 1 192 0 96 96 0 1 1 -192 0z"]],
    "heart-slash": [640, 512, [], "e78e", ["M115.8 187.3l0 0c-.3 24 8.7 48.1 27 66.5L320.2 431.2c6.6-6.6 13.1-13.2 19.7-19.7l0 0-224.1-224.1zM345 144.9l130.7 130.7 21.9-21.9c36.1-36.1 36.1-94.7 0-130.8-29.3-29.3-73.5-34.8-108.4-16.5-2.7 1.4-5.3 3-7.9 4.6-5.1 3.4-10 7.3-14.5 11.8L345 144.9z", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM115.8 187.3c-.3 24 8.7 48.2 27 66.5l177.4 177.4 19.7-19.8 45.3 45.3-65 65-222.6-222.6C52.8 254.2 40.9 189 61.8 133.3l54 54zM331.3 68.9c61.5-52 153.6-49 211.5 8.9 61.1 61.1 61.1 160.2 0 221.2l-21.9 21.9-45.3-45.3 21.9-21.9c36.1-36.1 36.1-94.7 0-130.8-36.1-36.1-94.7-36.1-130.7 0l-21.9 21.9-44.8-44.8 31.2-31.2z"]],
    "fill": [576, 512, [], "f575", ["M67.3 316l276 0-120.1 120.1c-12.5 12.5-32.8 12.5-45.2 0L76.4 334.6c-5.2-5.2-8.2-11.8-9.1-18.6z", "M518.9 367.2l38.4 51.2c9.9 13.2 15.2 29.2 15.2 45.6 0 42-34 76-76 76s-76-34-76-76c0-16.4 5.3-32.4 15.2-45.6 28.3-37.7 48.5-64.7 60.8-81.1l22.4 29.8zM455.1 249.4c6 6 9.4 14.1 9.4 22.6s-3.4 16.6-9.4 22.6L268.4 481.4c-37.5 37.5-98.3 37.5-135.8 0L31.1 379.9c-37.5-37.5-37.5-98.3 0-135.8l164.1-164.1-64-64 45.2-45.2 278.6 278.6zM480.5 452c-2.6 3.5-4 7.7-4 12 0 11 9 20 20 20s20-9 20-20c0-4.3-1.4-8.5-4-12l-16-21.3-16 21.3zM67.3 316c.9 6.8 3.9 13.4 9.1 18.6L177.9 436.1c12.5 12.5 32.8 12.5 45.2 0l120.1-120.1-276 0zm38.5-56L375.2 260 240.5 125.2 105.7 260z"]],
    "landmark": [512, 512, [127963], "f66f", ["M96.5 128L415.5 128 256 36.9 96.5 128z", "M271.9-27.8l-15.9-9.1-15.9 9.1-220 125.7C7.7 105 0 118.3 0 132.6L0 152c0 19.3 13.7 35.5 32 39.2l0 192.8 64 0 0-192 64 0 0 192 64 0 0-192 64 0 0 192 64 0 0-192 64 0 0 192 64 0 0-192.8c18.3-3.7 32-19.9 32-39.2l0-19.4c0-14.4-7.7-27.6-20.2-34.7L271.9-27.8zM256 36.9L415.5 128 96.5 128 256 36.9zM32 448l-32 0 0 64 512 0 0-64-480 0z"]],
    "music": [512, 512, [127925], "f001", ["M192 151.1l0 60.5c74.7-24.9 149.3-49.8 224-74.7l0-60.5c-74.7 24.9-149.3 49.8-224 74.7z", "M480 76.4c0-43.7-42.8-74.5-84.2-60.7l-224 74.7c-26.1 8.7-43.8 33.2-43.8 60.7l0 174.4c-10-3.5-20.8-5.5-32-5.5-53 0-96 43-96 96s43 96 96 96 96-43 96-96l0-136.9 224-74.7 0 89.1c-10-3.5-20.8-5.5-32-5.5-53 0-96 43-96 96s43 96 96 96 96-43 96-96l0-307.6zM416 384l0 0c0 17.7-14.3 32-32 32s-32-14.3-32-32 14.3-32 32-32 32 14.3 32 32zM128 416l0 0c0 17.7-14.3 32-32 32s-32-14.3-32-32 14.3-32 32-32 32 14.3 32 32zM416 136.9l-224 74.7 0-60.5 224-74.7 0 60.5z"]],
    "files": [512, 512, [], "e178", ["M192 32l0 320 224 0 0-229.5-90.5-90.5-133.5 0z", "M416 352l0-229.5-90.5-90.5-133.5 0 0 320 224 0zM192-32l160 0 128 128 0 256c0 35.3-28.7 64-64 64l-224 0c-35.3 0-64-28.7-64-64l0-320c0-35.3 28.7-64 64-64zM64 128l0 352 288 0 0 64-288 0c-35.3 0-64-28.7-64-64l0-384 64 0 0 32z"]],
    "underline": [448, 512, [], "f0cd", ["M96 32l256 0 0 192c0 70.7-57.3 128-128 128S96 294.7 96 224L96 32z", "M448 480l-448 0 0 64 448 0 0-64zM352 224c0 70.7-57.3 128-128 128S96 294.7 96 224l0-192-64 0 0 192c0 106 86 192 192 192s192-86 192-192l0-192-64 0 0 192z"]],
    "plus": [448, 512, [10133, 61543, "add"], "2b", ["", "M256 224l192 0 0 64-192 0 0 192-64 0 0-192-192 0 0-64 192 0 0-192 64 0 0 192z"]],
    "bell-ring": [576, 512, [], "e62c", ["M147.8 352l280.4 0c-14.7-29.5-29.5-59-44.2-88.4 0-34.5 0-69 0-103.6 0-43.1-28.4-79.5-67.5-91.7-3-.9-6.1-1.7-9.2-2.4-6.2-1.3-12.7-2-19.3-2-13.3 0-25.9 2.7-37.4 7.5-5.7 2.4-11.2 5.4-16.3 8.9l0 0c-1.3 .9-2.5 1.7-3.7 2.7 0 0 0 0-.1 .1-.3 .2-.6 .4-.9 .6-22.9 17.5-37.6 45.2-37.6 76.2 0 34.5 0 69 0 103.6-14.7 29.5-29.5 59-44.2 88.4z", "M352 512l-128 0 0-64 128 0 0 64zM288 0c88.4 0 160 71.6 160 160l0 88.4 83.8 167.6-487.6 0 83.8-167.6 0-88.4C128 71.6 199.6 0 288 0zm0 64c-53 0-96 43-96 96l0 103.6-44.2 88.4 280.4 0-44.2-88.4 0-103.6c0-53-43-96-96-96zM120 11.8C85.1 51.3 64 103.2 64 160l0 32-64 0 0-32C0 87 27.2 20.2 72-30.5l48 42.4zM504-30.5C548.8 20.2 576 87 576 160l0 32-64 0 0-32c0-56.8-21.1-108.7-56-148.2l48-42.4z"]],
    "copy": [512, 512, [], "f0c5", ["M192 64l0 256 256 0 0-256-256 0z", "M64 448l320 0 0 64-320 0c-35.3 0-64-28.7-64-64l0-320 64 0 0 320zM448 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64l-256 0c-35.3 0-64-28.7-64-64l0-256c0-35.3 28.7-64 64-64L448 0zM192 320l256 0 0-256-256 0 0 256z"]],
    "box": [512, 512, [128230], "f466", ["M64 188l384 0 0 260-384 0 0-260z", "M112 0l288 0 9.6 12.8 89.6 119.5c8.3 11.1 12.8 24.6 12.8 38.4L512 448c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 170.7c0-13.8 4.5-27.3 12.8-38.4L102.4 12.8 112 0zm32 64l-51 68 135 0 0-68-84 0zm140 0l0 68 135 0-51-68-84 0zM64 448l384 0 0-260-384 0 0 260z"]],
    "arrow-rotate-right": [512, 512, [8635, "arrow-right-rotate", "arrow-rotate-forward", "redo"], "f01e", ["", "M399.1 128C363.9 88.7 312.8 64 256 64 150 64 64 150 64 256s86 192 192 192c76.5 0 142.7-44.8 173.5-109.7l57.8 27.5C446.3 452.1 358.2 512 256 512 114.6 512 0 397.4 0 256S114.6 0 256 0c76.5 0 145.1 33.5 192 86.7l0-86.7 64 0 0 160c0 17.7-14.3 32-32 32l-160 0 0-64 79.1 0z"]],
    "arrow-down-wide-short": [640, 512, ["sort-amount-asc", "sort-amount-down"], "f160", ["", "M182.9 470.6c-12.5 12.5-32.8 12.5-45.3 0-76.2-76.2-115.8-115.8-118.6-118.6l45.3-45.3c12 12 33.3 33.3 64 64l0-338.7 64 0 0 338.7c30.7-30.7 52-52 64-64L301.5 352c-2.9 2.9-42.4 42.4-118.6 118.6zM576.3 128l-256 0 0-64 288 0 0 64-32 0zm-96 320l-160 0 0-64 160 0 0 64zm32-160l-192 0 0-64 224 0 0 64-32 0z"]],
    "compress": [512, 512, [], "f066", ["", "M160 32l0-32-64 0 0 96-96 0 0 64 128 0c17.7 0 32-14.3 32-32l0-96zM32 352l-32 0 0 64 96 0 0 96 64 0 0-128c0-17.7-14.3-32-32-32l-96 0zM416 32l0-32-64 0 0 128c0 17.7 14.3 32 32 32l128 0 0-64-96 0 0-64zM384 352c-17.7 0-32 14.3-32 32l0 128 64 0 0-96 96 0 0-64-128 0z"]],
    "circle-dollar": [512, 512, ["dollar-circle", "usd-circle"], "f2e8", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm84-52c0-39.7 32.2-72 72-72l8 0 0-36 56 0 0 36 52 0 0 56-116 0c-8.8 0-16 7.2-16 16 0 7.6 5.4 14.2 12.8 15.7l89.3 17.8c33.6 6.7 57.8 36.3 57.8 70.6 0 39.7-32.2 72-72 72l-8 0 0 36-56 0 0-36-52 0 0-56 116 0c8.8 0 16-7.2 16-16 0-7.6-5.4-14.2-12.8-15.7l-89.3-17.8C172.2 267.8 148 238.3 148 204z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm28 68l52 0 0 56-116 0c-8.8 0-16 7.2-16 16 0 7.6 5.4 14.2 12.8 15.7l89.3 17.8c33.6 6.7 57.8 36.3 57.8 70.6 0 39.7-32.2 72-72 72l-8 0 0 36-56 0 0-36-52 0 0-56 116 0c8.8 0 16-7.2 16-16 0-7.6-5.4-14.2-12.8-15.7l-89.3-17.8c-33.6-6.7-57.8-36.3-57.8-70.6 0-39.7 32.2-72 72-72l8 0 0-36 56 0 0 36z"]],
    "cloud-bolt": [576, 512, [127785, "thunderstorm"], "f76c", ["M64 256c0 .7 0 1.3 0 2 .8 40.9 27.3 75.5 64 88.5l0 .1c5.2 1.8 10.6 3.2 16.2 4.2 2.5-4.8 5.6-9.3 9.2-13.5 72.2-84.2 119.8-139.8 142.8-166.7l109.3 93.7-41 47.8 3.5 0c26.9 0 51.4 15 63.8 38.7 5.6-.9 11-2.3 16.2-4.2l0-.1c36.1-12.8 62.3-46.4 63.9-86.5 .1-1.3 .1-2.6 .1-3.9 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5c-5.9-56.3-53.5-100.2-111.4-100.2-45.5 0-84.6 27.2-102.1 66.1 30.4 4.9 57.9 18.4 80 37.9-14.1 16-28.2 32-42.3 48-16.9-15-39.1-24-63.5-24-4 0-8 .3-11.9 .8-47.4 5.8-84.1 46.3-84.1 95.2z", "M341.1 274.4L269.7 356 368 356c11 0 21 6.5 25.5 16.5s2.7 21.8-4.6 30.1l-128 144-41.9-37.2 86.6-97.4-97.7 0c-11 0-21-6.4-25.5-16.4s-2.8-21.7 4.4-30l112-128 42.1 36.9zM288-32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 77.4-55 142-128 156.8l0-66.4c37.3-13.2 64-48.6 64-90.4 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5c-5.9-56.3-53.5-100.2-111.4-100.2-45.5 0-84.6 27.2-102.1 66.1 30.4 4.9 57.9 18.4 80 37.9-14.1 16-28.2 32-42.3 48-16.9-15-39.1-24-63.5-24-4 0-8 .3-11.9 .8-47.4 5.8-84.1 46.3-84.1 95.2 0 41.8 26.7 77.2 64 90.4l0 66.4c-73-14.8-128-79.4-128-156.8 0-2.6 .1-5.1 .2-7.6 0-.7 .1-1.5 .2-2.2 .1-1.8 .2-3.6 .4-5.3 .1-1.4 .3-2.8 .5-4.2 .1-1.2 .3-2.4 .4-3.5 .1-.8 .2-1.6 .3-2.3 .7-4.2 1.5-8.3 2.5-12.3 .7-2.8 1.4-5.5 2.2-8.2 .1-.4 .2-.7 .3-1.1 .4-1.1 .8-2.3 1.1-3.4 .4-1.2 .8-2.5 1.2-3.7 .4-1.1 .9-2.3 1.3-3.4 .5-1.2 1-2.5 1.5-3.7 .4-.9 .7-1.7 1.1-2.6 .6-1.4 1.3-2.8 1.9-4.2 .3-.7 .7-1.5 1-2.2 1-2 2-4.1 3.1-6.1 .6-1.2 1.3-2.3 2-3.5 .5-.9 1-1.9 1.6-2.8 .8-1.3 1.6-2.5 2.4-3.8 .5-.8 1-1.5 1.5-2.3 .7-1.1 1.4-2.1 2.2-3.2 .7-1 1.4-2 2.1-3 .4-.6 .9-1.2 1.3-1.8 1-1.3 2-2.6 3.1-3.9 .6-.7 1.1-1.4 1.7-2.1 1.4-1.7 2.9-3.4 4.4-5.1 .5-.6 1-1.1 1.6-1.7 1.2-1.2 2.3-2.5 3.5-3.7 .5-.5 1-1 1.5-1.5 1.1-1 2.1-2.1 3.2-3.1 .9-.8 1.8-1.7 2.7-2.5 .9-.8 1.8-1.6 2.7-2.3 .8-.7 1.7-1.4 2.5-2.1 .9-.7 1.8-1.4 2.7-2.1 6-4.6 12.3-8.9 18.9-12.7 .3-.2 .6-.3 .9-.5 3.5-2 5.6-3 6.1-3.3 4.8-2.5 9.8-4.7 14.9-6.6 .8-.3 1.5-.6 2.3-.9 .7-.2 1.3-.5 2-.7 1.3-.5 2.6-.9 4-1.3l1.6-.5c1.3-.4 2.6-.8 4-1.1 .2-.1 .5-.2 .7-.2 18.9-76.9 88.2-133.8 170.9-133.8z"]],
    "eye-slash": [640, 512, [], "f070", ["M99.7 256c9.2-18.1 20.1-35.7 32.4-52.3 70.3 70.3 140.6 140.6 210.9 210.9-7.5 .9-15.1 1.4-22.8 1.4-99.7 0-177.7-76-220.5-160zM297.4 97.4c7.5-.9 15.1-1.4 22.9-1.4 99.7 0 177.7 76 220.5 160-9.2 18.1-20.1 35.7-32.5 52.3-70.3-70.3-140.6-140.6-210.9-210.9z", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM132.2 203.7c-12.3 16.6-23.2 34.3-32.4 52.3 42.8 84 120.9 160 220.5 160 7.8 0 15.4-.5 22.8-1.4l53.7 53.7c-24.2 7.5-49.8 11.7-76.5 11.7-135.2 0-241.5-105.6-290.7-224 14.3-34.5 33.6-67.9 56.9-98l45.7 45.7zM320.3 32c135.2 0 241.5 105.6 290.7 224-14.3 34.5-33.6 67.9-56.9 98l-45.7-45.7c12.3-16.6 23.3-34.3 32.5-52.3-42.8-84-120.9-160-220.5-160-7.8 0-15.4 .5-22.9 1.4L243.7 43.7C267.9 36.2 293.5 32 320.3 32z"]],
    "mug-hot": [576, 512, [9749], "f7b6", ["M128 256l256 0 0 128c0 35.3-28.7 64-64 64l-128 0c-35.3 0-64-28.7-64-64l0-128z", "M100-10.5c0 24.4 9.7 47.8 26.9 65.1l26.5 26.5C160.2 87.8 164 97 164 106.5l0 21.5 56 0 0-21.5c0-24.4-9.7-47.8-26.9-65.1L166.5 14.9C159.8 8.2 156-1 156-10.5l0-21.5-56 0 0 21.5zM96 192l-32 0 0 192c0 70.7 57.3 128 128 128l128 0c59.6 0 109.8-40.8 124-96l20 0c61.9 0 112-50.1 112-112S525.9 192 464 192L96 192zm352 64l16 0c26.5 0 48 21.5 48 48s-21.5 48-48 48l-16 0 0-96zM128 384l0-128 256 0 0 128c0 35.3-28.7 64-64 64l-128 0c-35.3 0-64-28.7-64-64zM228-32l0 21.5c0 24.4 9.7 47.8 26.9 65.1l26.5 26.5C288.2 87.8 292 97 292 106.5l0 21.5 56 0 0-21.5c0-24.4-9.7-47.8-26.9-65.1L294.5 14.9C287.8 8.2 284-1 284-10.5l0-21.5-56 0z"]],
    "bolt": [576, 512, [9889, "zap"], "f0e7", ["M143.6 266.9c51.7-51.7 103.5-103.5 155.2-155.2 0 .3 0 .6 .1 1 1.6 20.5 3.2 41 4.7 61.5 2 26.6 18.4 49 41.4 59.7 7.7 3.6 16.1 5.8 24.9 6.5 20.8 1.6 41.6 3.2 62.4 4.8-51.7 51.7-103.5 103.5-155.2 155.2-1.6-20.8-3.2-41.6-4.8-62.4-2.7-35.4-30.9-63.5-66.3-66.3l-61.5-4.7c-.3 0-.6 0-1-.1z", "M0 320c50.5 3.9 117.6 9 201.2 15.5 3.9 .3 7.1 3.4 7.4 7.4 6.4 83.6 11.6 150.6 15.5 201.2 10.9-10.9 108.4-108.4 292.4-292.4L576 192c-50.5-3.9-117.6-9-201.2-15.5-3.9-.3-7.1-3.4-7.4-7.4-6.4-83.6-11.6-150.6-15.5-201.2-10.9 10.9-108.4 108.4-292.4 292.4L0 320zM298.9 111.6l4.8 62.4c2.7 35.4 30.9 63.5 66.3 66.3l62.4 4.8-155.2 155.2-4.8-62.4c-2.7-35.4-30.9-63.5-66.3-66.3l-62.4-4.8 155.2-155.2z"]],
    "aperture": [512, 512, [], "e2df", ["M64 256c0 .7 0 1.5 0 2.2 0 .4 0 .7 0 1.1l0 0c0 .4 0 .7 0 1.1l0 0c0 .4 0 .7 0 1.1l0 .1c0 .4 0 .7 0 1.1l0 .1c0 .3 0 .7 0 1 0 0 0 .1 0 .1 0 .3 0 .7 0 1 0 0 0 .1 0 .1 0 .3 0 .7 0 1 0 0 0 .1 0 .1 0 .3 0 .7 .1 1 0 0 0 .1 0 .1 0 .3 0 .6 .1 .9 0 .1 0 .1 0 .2 0 .3 0 .6 .1 .9 0 0 0 .1 0 .1 0 .3 0 .6 .1 .9 0 .1 0 .2 0 .2 0 .3 0 .6 .1 .9 0 .1 0 .1 0 .2 0 .3 0 .6 .1 .8 0 .1 0 .2 0 .3 0 .3 0 .6 .1 .8 0 .1 0 .2 0 .2 .1 .6 .1 1 .1 1.2 .1 .6 .1 .9 .1 1.1 .1 .5 .1 .9 .1 1.2 .1 .5 .1 .9 .1 1 .1 .5 .1 .9 .1 1.2 .1 .5 .1 .8 .1 1.1 .1 .9 .2 1.5 .2 1.7 .1 .6 .2 1.3 .2 1.6 .1 .7 .2 1.3 .2 1.4 .1 .6 .1 1 .2 1.1 .1 .5 .1 .8 .2 .9 0 .3 .1 .6 .1 .9 0 .1 0 .2 0 .3 0 .3 .1 .5 .1 .8 0 .1 0 .1 0 .2 .1 .3 .1 .7 .2 1 0 0 0 .1 0 .1 1.3 7.1 3 14 5 20.8 0 0 0 .1 0 .1 .2 .6 .3 .9 .3 1 .2 .6 .3 1 .4 1.1 .1 .2 .1 .4 .2 .6 .1 .2 .2 .6 .3 1.1 .1 .4 .2 .6 .2 .7 .9 2.7 1.8 5.4 2.8 8l75.5 0c-10.3-17.8-20.6-35.6-30.9-53.4-.1-.2-.2-.4-.3-.5s-.2-.4-.3-.5c-15.1-26.1-30.1-52.2-45.2-78.3-3.6 10.1-6.4 20.6-8.3 31.5-.5 2.7-.9 5.4-1.3 8.2-.2 1.4-.3 2.7-.5 4.1-.1 .7-.1 1.4-.2 2.1l0 0c0 .3-.1 .7-.1 1l0 0c0 .3-.1 .6-.1 .9 0 0 0 .1 0 .1-.2 2.8-.4 5.6-.5 8.4-.1 1.4-.1 2.8-.1 4.2 0 1.6 0 2.7 0 3.2 0 .4 0 .7 0 1.1zm43.2-121.4c12.6 21.8 25.2 43.6 37.8 65.4 10.4-17.9 20.7-35.9 31.1-53.8 .1-.1 .1-.2 .2-.3 15.2-26.3 30.4-52.6 45.6-78.9-40.2 7.2-76.1 27-103.4 55.2-.5 .5-.9 1-1.4 1.4-3.1 3.3-5.4 5.9-7 7.7-.9 1.1-1.8 2.2-2.7 3.3zM109.4 380c28.9 34.1 69.4 58 115.4 65.5l37.8-65.5-153.3 0zM248.9 132.1c20.6 0 41.2 0 61.8 0 .3 0 .7 0 1 0 30.3 0 60.7 0 91 0-28.9-34.2-69.7-58.2-115.9-65.6-12.6 21.9-25.3 43.7-37.9 65.6zm40.9 313c5.7-1 11.4-2.3 17-3.8 0 0 .1 0 .1 0 .6-.2 1.3-.4 1.9-.5 15.9-4.5 31-11.1 44.9-19.3 19.4-11.5 36.6-26.3 50.8-43.6-12.6-21.9-25.3-43.8-37.9-65.7-10.3 17.9-20.7 35.8-31 53.7-.1 .1-.2 .3-.2 .4-15.2 26.3-30.4 52.6-45.6 78.9zm69.9-257c10.3 17.8 20.5 35.6 30.8 53.3 0 0 0 0 0 0 .2 .4 .4 .8 .7 1.2 15.2 26.2 30.3 52.5 45.5 78.7 .9-2.5 1.8-5.1 2.6-7.7 0 0 0-.1 0-.1 .1-.3 .2-.6 .3-.9 0-.1 .1-.4 .2-.8 .2-.6 .4-1.2 .4-1.5 .2-.7 .3-1.2 .4-1.3 .1-.5 .2-.8 .3-1.1 .2-.8 .3-1.1 .4-1.6 .1-.2 .1-.5 .2-.9 .1-.2 .1-.6 .3-1.1 .1-.2 .1-.5 .2-.9 .1-.2 .1-.6 .3-1.1 .1-.6 .3-1.2 .3-1.3 .1-.5 .2-.8 .3-1.1 .2-.7 .3-1.2 .4-1.6 .2-.7 .2-1.1 .3-1.4 .1-.4 .2-.7 .2-1.1 .1-.3 .1-.6 .2-1 .1-.3 .1-.7 .2-1.1 0-.2 .1-.5 .2-1 .1-.3 .1-.6 .2-1.1 0-.2 .1-.5 .2-1 0-.2 .1-.6 .2-1.1 0-.1 0-.1 0-.2 1.9-10.9 2.9-22.1 2.9-33.6 0-23.9-4.4-46.8-12.4-67.9-25.3 0-50.6 0-76 0z", "M107.2 134.6l37.8 65.4 31.1-53.8 .2-.3 45.6-78.9c-45.9 8.3-86.2 32.9-114.5 67.6zm-32 56.6C68 211.4 64 233.3 64 256 64 279.9 68.4 302.9 76.4 324l75.5 0-30.9-53.4c-.2-.3-.4-.7-.6-1.1L75.2 191.2zM224.8 445.5l37.8-65.5-153.3 0c28.9 34.1 69.4 58 115.4 65.5zm64.9-.4c46-8.2 86.3-32.7 114.8-67.4l-37.9-65.7-31 53.7-.2 .4-45.6 78.9zM295 323.9l39.2-67.9-39.2-67.9-78.5 0-39.2 67.9 39.2 68 78.5 0zm96.1-81.4l45.5 78.7c7.4-20.4 11.4-42.4 11.4-65.3 0-23.9-4.4-46.8-12.4-67.9l-76 0 30.8 53.3c.2 .4 .5 .8 .7 1.2zM310.6 132.1c.3 0 .7 0 1 0l91 0C373.7 97.8 333 73.9 286.8 66.5l-37.9 65.6 61.8 0zM512 256a256 256 0 1 1 -512 0 256 256 0 1 1 512 0z"]],
    "signal-fair": [576, 512, ["signal-2"], "f68d", ["M79.1 448L196 346.1 196 448 79.1 448z", "M517.8 0C549.9 0 576 26.1 576 58.2L576 448c0 35.3-28.7 64-64 64L55 512c-30.4 0-55-24.6-55-55 0-15.9 6.9-31 18.9-41.5L479.6 14.3C490.2 5.1 503.7 0 517.8 0zM252 297.3l0 150.7 260 0 0-377.1-260 226.4zM79.1 448L196 448 196 346.1 79.1 448z"]],
    "arrow-rotate-left": [512, 512, [8634, "arrow-left-rotate", "arrow-rotate-back", "arrow-rotate-backward", "undo"], "f0e2", ["", "M32 192c-17.7 0-32-14.3-32-32L0 0 64 0 64 86.7C110.9 33.5 179.5 0 256 0 397.4 0 512 114.6 512 256S397.4 512 256 512C153.8 512 65.7 452.1 24.7 365.7l57.8-27.5c30.9 64.9 97 109.7 173.5 109.7 106 0 192-86 192-192S362 64 256 64c-56.8 0-107.9 24.7-143.1 64l79.1 0 0 64-160 0z"]],
    "wifi": [576, 512, ["wifi-3", "wifi-strong"], "f1eb", ["M46.3 238.3c58.7-67.6 145.2-110.3 241.7-110.3 48.3 0 94 10.7 135 29.8 0 0 0 0 .1 0 2.6 1.2 5.1 2.4 7.6 3.7 37.9 18.9 71.5 45.1 99 76.8-18.9 18.9-37.8 37.8-56.8 56.8-5.5-6.6-11.4-13-17.5-19-24.3-23.6-53.6-42.2-86.1-53.9-.5-.2-.9-.3-1.4-.5-.1 0-.2-.1-.3-.1-8.3-2.9-16.8-5.4-25.5-7.4-17.4-4-35.5-6.1-54.1-6.1-74.4 0-140.9 33.9-185 87-18.9-18.9-37.8-37.8-56.8-56.8zM148.6 340.6c32.2-41.7 82.7-68.6 139.4-68.6s107.2 26.9 139.4 68.6c-17.5 17.5-35.1 35.1-52.6 52.6-20.5-25.2-51.8-41.2-86.8-41.2s-66.3 16.1-86.8 41.2c-17.5-17.5-35.1-35.1-52.6-52.6z", "M201.3 393.2l86.8 86.8 86.8-86.8c-20.5-25.1-51.8-41.2-86.8-41.2s-66.3 16.1-86.8 41.2zm-52.6-52.6c32.2-41.7 82.7-68.6 139.4-68.6s107.2 26.9 139.4 68.6L473 295c-44-53.2-110.5-87-185-87s-140.9 33.9-185 87l45.5 45.5zM46.3 238.3C105 170.7 191.6 128 288.1 128s183 42.7 241.7 110.3l45.4-45.3C504.8 113.8 402.2 64 288.1 64S71.3 113.8 1 192.9l45.3 45.3z"]],
    "circle-arrow-up": [512, 512, ["arrow-circle-up"], "f0aa", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm60.2-3.8l112-112c10.9-10.9 28.7-10.9 39.6 0l112 112-39.6 39.6-64.2-64.2 0 156.4-56 0 0-156.4-64.2 64.2-39.6-39.6z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm-19.8 76.2c10.9-10.9 28.7-10.9 39.6 0l112 112-39.6 39.6-64.2-64.2 0 156.4-56 0 0-156.4-64.2 64.2-39.6-39.6 112-112z"]],
    "volume": [576, 512, [128265, "volume-medium"], "f6a8", ["M64 192l0 128 74.7 0 8.5 6.4 108.8 81.6 0-304-108.8 81.6-8.5 6.4-74.7 0z", "M320 480l-53.3 0c-13.8 0-27.3-4.5-38.4-12.8L117.3 384 64 384C30.9 384 3.6 358.8 .3 326.5L0 320 0 192c0-35.3 28.7-64 64-64l53.3 0 110.9-83.2C239.4 36.5 252.8 32 266.7 32l53.3 0 0 448zM384 34.3c108.5 15.5 192 108.8 192 221.7 0 112.8-83.5 206.2-192 221.7l0-56.8c77.5-14.9 136-83.1 136-164.9 0-81.8-58.5-150-136-164.9l0-56.8zM147.2 185.6l-8.5 6.4-74.7 0 0 128 74.7 0 8.5 6.4 108.8 81.6 0-304-108.8 81.6zM384 132c55.2 14.2 96 64.3 96 124 0 59.6-40.8 109.8-96 124l0-59.6c23.7-11.8 40-36.2 40-64.4 0-28.3-16.3-52.7-40-64.4l0-59.5z"]],
    "tag": [512, 512, [127991], "f02b", ["M64.5 256C130.3 321.8 196.1 387.6 262 453.5l192-192 0-197.5-197.5 0c-64 64-128 128-192 192zM318 160c0-5.5 1.1-10.8 3.1-15.6 .1-.3 .3-.6 .4-.9 .1-.1 .1-.3 .2-.4 .1-.1 .1-.3 .2-.4 .1-.2 .2-.3 .2-.5 .1-.1 .1-.3 .2-.4 0 0 0 0 0 0 .1-.3 .3-.6 .4-.8 .6-1.1 1.3-2.2 2-3.3 1.2-1.8 2.6-3.6 4.2-5.2 .2-.2 .4-.4 .6-.6 0 0 .1-.1 .1-.1 7.2-7.2 17.2-11.7 28.3-11.7s21 4.5 28.3 11.7c3.4 3.4 6.3 7.5 8.3 12 0 0 0 0 0 0 .1 .1 .1 .3 .2 .4 0 0 0 .1 0 .1 0 .1 0 .1 .1 .2 2 4.8 3.1 10 3.1 15.6s-1.1 10.8-3.1 15.6c0 .1 0 .1-.1 .2 0 0 0 .1 0 .1-.1 .1-.1 .3-.2 .4 0 0 0 0 0 0-2 4.5-4.8 8.6-8.3 12-7.2 7.2-17.2 11.7-28.3 11.7s-21-4.5-28.3-11.7c0 0-.1-.1-.1-.1-.2-.2-.4-.4-.6-.6-1.5-1.6-2.9-3.4-4.2-5.2-.7-1.1-1.4-2.2-2-3.3-.2-.3-.3-.6-.4-.8 0 0 0 0 0 0-.1-.1-.1-.3-.2-.4-.1-.2-.2-.3-.2-.5-.1-.1-.1-.3-.2-.4-.1-.1-.1-.3-.2-.4-.1-.3-.2-.5-.4-.9-2-4.8-3.1-10-3.1-15.6z", "M262 453.5L64.5 256 256.5 64 454 64 454 261.5 262 453.5zM454 0L230 0 19.2 210.7c-25 25-25 65.5 0 90.5L216.7 498.7c25 25 65.5 25 90.5 0L518 288 518 64c0-35.3-28.7-64-64-64zM358 200a40 40 0 1 0 0-80 40 40 0 1 0 0 80z"]],
    "compact-disc": [512, 512, [128191, 128192, 128440], "f51f", ["M64 256c0-1.1 0-2.2 0-3.4 .2-9.8 1.1-19.4 2.7-28.8l94.8 14.9c-1 5.3-1.5 10.7-1.5 16.3 0 .1 0 .3 0 .4l0 0c0 .2 0 .3 0 .5 0 53 43 96 96 96 1.5 0 2.9 0 4.4-.1 0 0 .1 0 .1 0 .3 0 .6 0 .9 0 21.6-1.2 41.3-9.5 56.7-22.7l60.4 74.6c-28.1 23.3-62.8 38.7-101 43-1.4 .2-2.8 .3-4.2 .4l-.1 0c-5.7 .5-11.5 .8-17.3 .8-106 0-192-86-192-192zm69.5-147.8c22.9-19 50.2-32.7 80.1-39.5 2.7-.6 5.5-1.2 8.2-1.7l0 0c11.1-2 22.5-3 34.1-3 106 0 192 86 192 192 0 1.3 0 2.6 0 3.9-.2 9.6-1.2 19.1-2.7 28.3l-94.8-14.9c.9-5.1 1.4-10.3 1.5-15.6 0-.2 0-.4 0-.6 0 0 0-.1 0-.1 0-.3 0-.6 0-.8 0-53-43-96-96-96-3 0-5.9 .1-8.8 .4-20.3 1.8-38.7 10-53.4 22.4l-60.4-74.7z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm0 288a96 96 0 1 1 0-192 96 96 0 1 1 0 192zm0-128a32 32 0 1 0 0 64 32 32 0 1 0 0-64z"]],
    "phone-slash": [640, 512, [], "f3dd", ["M130.2 216.2c-7.9-41.7 5.3-84.9 35.2-114.7l26.9-26.9 53.5 53.5-33.4 33.4c-17.1 17.1-23.7 42-17.3 65.2 1.3 4.9 2.8 9.7 4.4 14.4l32.1-32.1 0 0-84.5 84.5 0 0 6.5-6.5c-10.7-22.2-18.6-45.9-23.3-70.8zM289.3 422.7l45.9-45.9c4.7 1.6 9.5 3.1 14.4 4.5 23.3 6.3 48.2-.3 65.3-17.3l33.4-33.4 53.5 53.5-26.9 26.9c-29.9 29.9-73 43.1-114.8 35.2-24.9-4.7-48.6-12.7-70.8-23.4z", "M621.5 0L64.3 557.3 19 512 576.3-45.2 621.5 0zM445.3 266.7c17.3-.8 34.9 5.4 48.2 18.6L547 338.7c25 25 25 65.5 0 90.5l-26.9 26.9-8.7 8.2c-41.4 36.5-96.8 53.5-151.6 46.5l-11.7-1.8c-37.9-7.2-73.7-20.6-106.3-38.8l47.4-47.4c22.2 10.7 45.9 18.6 70.8 23.4 41.7 7.9 84.9-5.3 114.8-35.2l26.9-26.9-53.5-53.5-33.4 33.4c-17.1 17.1-42 23.7-65.3 17.3-4.9-1.3-9.7-2.8-14.4-4.5L445.3 266.7zM147 29.2c25-25 65.5-25 90.5 0L291 82.8c13.2 13.2 19.4 30.8 18.6 48.1L199.4 241c-1.6-4.7-3.1-9.5-4.4-14.4-6.3-23.3 .3-48.2 17.3-65.2l33.4-33.4-53.5-53.5-26.9 26.9c-29.9 29.9-43.1 73-35.2 114.7 4.7 24.9 12.7 48.6 23.3 70.8l-47.4 47.4c-18.3-32.6-31.6-68.3-38.8-106.2-11.1-58.5 5.5-119 44.7-163.3l8.2-8.7 26.9-26.9z"]],
    "grid-2": [512, 512, [], "e196", ["M64 64l0 96 96 0 0-96-96 0zm0 288l0 96 96 0 0-96-96 0zM352 64l0 96 96 0 0-96-96 0zm0 288l0 96 96 0 0-96-96 0z", "M224 512L64 512c-35.3 0-64-28.7-64-64l0-160 224 0 0 224zm288-64c0 35.3-28.7 64-64 64l-160 0 0-224 224 0 0 160zM64 448l96 0 0-96-96 0 0 96zm288 0l96 0 0-96-96 0 0 96zM224 224L0 224 0 64C0 28.7 28.7 0 64 0l160 0 0 224zM448 0c35.3 0 64 28.7 64 64l0 160-224 0 0-224 160 0zM64 160l96 0 0-96-96 0 0 96zm288 0l96 0 0-96-96 0 0 96z"]],
    "arrow-up-right-from-square": [512, 512, ["external-link"], "f08e", ["", "M320 0l-32 0 0 64 114.7 0-201.4 201.4-22.6 22.6 45.3 45.3 22.6-22.6 201.4-201.4 0 114.7 64 0 0-192c0-17.7-14.3-32-32-32L320 0zM64 64C28.7 64 0 92.7 0 128L0 448c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-128-64 0 0 128-320 0 0-320 128 0 0-64-128 0z"]],
    "rectangle-tall": [384, 512, [], "e791", ["M64 32l0 448 256 0 0-448-256 0z", "M326.5-31.7C358.8-28.4 384-1.1 384 32l0 448-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-256 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 480 0 32C0-3.3 28.7-32 64-32l256 0 6.5 .3zM64 480l256 0 0-448-256 0 0 448z"]],
    "compass": [512, 512, [129517], "f14e", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm80 112l24.5-146.9c4.2-25.3 23-45.4 47.6-51.6l5-1 146.9-24.5-24.5 146.9c-4.5 27-25.6 48.1-52.6 52.6L144 368z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm87.5 226.9c-4.5 27-25.6 48.1-52.6 52.6L144 368 168.5 221.1c4.2-25.3 23-45.4 47.6-51.6l5-1 146.9-24.5-24.5 146.9zM230.3 223.7c-3.4 .6-6 3.2-6.6 6.6l-11.6 69.5 69.6-11.6c3.4-.6 6-3.2 6.6-6.6l11.6-69.6-69.5 11.6z"]],
    "pen-nib": [512, 512, [10001], "f5ad", ["M90.8 381.9l98.7-98.7c-.8-3.6-1.2-7.3-1.2-11.1 0-28.7 23.3-52 52-52s52 23.3 52 52c0 28.7-23.3 52-52 52-3.8 0-7.6-.5-11.2-1.3l-98.7 98.7 108.8-13.6c32.5-4.1 62.7-18.9 85.9-42 27.6-27.6 43.1-65.1 43.1-104.1l0-35 66.8-66.8-82.8-82.8-66.7 66.8-35 0c-39 0-76.5 15.5-104.1 43.1-23.1 23.2-37.9 53.4-42 85.9L90.8 381.9z", "M307.1 32c25-25 65.5-25 90.5 0l82.7 82.8c25 25 25 65.5 0 90.5l-48 48 0 8.5c0 56-22.3 109.8-61.9 149.4-33.2 33.2-76.6 54.4-123.2 60.2l-195 24.4-40.8 5.1 5.1-40.8 24.4-195c5.8-46.6 27-90 60.2-123.2 39.6-39.6 93.4-61.9 149.4-61.9l8.5 0 48-48zM285.6 144l-35 0c-39 0-76.5 15.5-104.1 43.1-23.1 23.2-37.9 53.4-42 85.9l-13.6 108.8 98.7-98.7c-.8-3.6-1.2-7.3-1.2-11.1 0-28.7 23.3-52 52-52s52 23.3 52 52c0 28.7-23.3 52-52 52-3.8 0-7.6-.5-11.2-1.3l-98.7 98.7 108.8-13.6c32.5-4.1 62.7-18.9 85.9-42 27.6-27.6 43.1-65.1 43.1-104.1l0-35 66.8-66.8-82.8-82.8-66.7 66.8z"]],
    "square": [448, 512, [9632, 9723, 9724, 61590], "f0c8", ["M64 96l0 320 320 0 0-320-320 0z", "M384 32c35.3 0 64 28.7 64 64l0 320-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-320 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 416 0 96C0 60.7 28.7 32 64 32l320 0zM64 416l320 0 0-320-320 0 0 320z"]],
    "angle-up": [512, 512, [8963], "f106", ["", "M448.3 365.3l-192-192-192 192-45.2-45.3 214.6-214.6c12.5-12.5 32.8-12.5 45.3 0L493.5 320 448.3 365.3z"]],
    "face-smile": [512, 512, [128578, "smile"], "f118", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm60.4 68l41.5-24c18 31.1 51.6 52 90.1 52s72.1-20.9 90.1-52l41.5 24c-26.2 45.4-75.4 76-131.7 76s-105.4-30.6-131.6-76zM208 208a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm160 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z", "M448 256a192 192 0 1 0 -384 0 192 192 0 1 0 384 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm256 96c38.5 0 72.1-20.9 90.1-52l41.5 24c-26.2 45.4-75.4 76-131.7 76s-105.4-30.6-131.6-76l41.5-24c18 31.1 51.6 52 90.1 52zM144 208a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm192-32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"]],
    "cloud-showers": [576, 512, [], "f73f", ["M64 256c0-49 36.7-89.4 84.1-95.2 3.9-.5 7.9-.8 11.9-.8 24.4 0 46.6 9 63.5 24 14.1-16 28.2-32 42.3-48-22.1-19.5-49.6-32.9-80-37.9 17.5-39 56.6-66.1 102.1-66.1 57.9 0 105.5 43.9 111.4 100.2l2.6 25.5 25.4 3c47.6 5.6 84.6 46.2 84.6 95.3 0 41.8-26.7 77.2-64 90.4l0-90.4-128 0 0 32-64 0 0-32-128 0 0 90.4C90.7 333.2 64 297.8 64 256z", "M316 540l-56 0 0-216 56 0 0 216zM220 292l0 216-56 0 0-216 56 0zm192 0l0 216-56 0 0-216 56 0zM288-32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 77.4-55 142-128 156.8l0-66.4c37.3-13.2 64-48.6 64-90.4 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5c-5.9-56.3-53.5-100.2-111.4-100.2-45.5 0-84.6 27.2-102.1 66.1 30.4 4.9 57.9 18.4 80 37.9-14.1 16-28.2 32-42.3 48-16.9-15-39.1-24-63.5-24-4 0-8 .3-11.9 .8-47.4 5.8-84.1 46.3-84.1 95.2 0 41.8 26.7 77.2 64 90.4l0 66.4c-73-14.8-128-79.4-128-156.8 0-2.6 .1-5.1 .2-7.6 0-.7 .1-1.5 .2-2.2 .1-1.8 .2-3.6 .4-5.3 .1-1.4 .3-2.8 .5-4.2 .1-1.2 .3-2.4 .4-3.5 .1-.8 .2-1.6 .3-2.3 .7-4.2 1.5-8.3 2.5-12.3 .7-2.8 1.4-5.5 2.2-8.2 .1-.4 .2-.7 .3-1.1 .4-1.1 .8-2.3 1.1-3.4 .4-1.2 .8-2.5 1.2-3.7 .4-1.1 .9-2.3 1.3-3.4 .5-1.2 1-2.5 1.5-3.7 .4-.9 .7-1.7 1.1-2.6 .6-1.4 1.3-2.8 1.9-4.2 .3-.7 .7-1.5 1-2.2 1-2 2-4.1 3.1-6.1 .6-1.2 1.3-2.3 2-3.5 .5-.9 1-1.9 1.6-2.8 .8-1.3 1.6-2.5 2.4-3.8 .5-.8 1-1.5 1.5-2.3 .7-1.1 1.4-2.1 2.2-3.2 .7-1 1.4-2 2.1-3 .4-.6 .9-1.2 1.3-1.8 1-1.3 2-2.6 3.1-3.9 .6-.7 1.1-1.4 1.7-2.1 1.4-1.7 2.9-3.4 4.4-5.1 .5-.6 1-1.1 1.6-1.7 1.2-1.2 2.3-2.5 3.5-3.7 .5-.5 1-1 1.5-1.5 1.1-1 2.1-2.1 3.2-3.1 .9-.8 1.8-1.7 2.7-2.5 .9-.8 1.8-1.6 2.7-2.3 .8-.7 1.7-1.4 2.5-2.1 .9-.7 1.8-1.4 2.7-2.1 6-4.6 12.3-8.9 18.9-12.7 .3-.2 .6-.3 .9-.5 3.5-2 5.6-3 6.1-3.3 4.8-2.5 9.8-4.7 14.9-6.6 .8-.3 1.5-.6 2.3-.9 .7-.2 1.3-.5 2-.7 1.3-.5 2.6-.9 4-1.3l1.6-.5c1.3-.4 2.6-.8 4-1.1 .2-.1 .5-.2 .7-.2 18.9-76.9 88.2-133.8 170.9-133.8z"]],
    "umbrella": [512, 512, [], "f0e9", ["M66.7 224l378.7 0C430.2 133.2 351.2 64 256.1 64S81.9 133.2 66.7 224z", "M256.1 64c95.1 0 174.1 69.2 189.4 160L66.7 224C81.9 133.2 160.9 64 256.1 64zm0-64C127 0 20.3 95.4 2.6 219.6-3 259.4 30.2 288 64.1 288l160 0 0 128c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-32-64 0 0 32c0 53 43 96 96 96s96-43 96-96l0-128 160 0C482 288 515.2 259.4 509.5 219.6 491.8 95.4 385.1 0 256.1 0z"]],
    "briefcase": [512, 512, [128188], "f0b1", ["M64 284l384 0 0 164-384 0 0-164z", "M192 60l128 0c2.2 0 4 1.8 4 4l0 32-136 0 0-32c0-2.2 1.8-4 4-4zm-60 4l0 32-68 0C28.7 96 0 124.7 0 160L0 448c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-288c0-35.3-28.7-64-64-64l-68 0 0-32c0-33.1-26.9-60-60-60L192 4c-33.1 0-60 26.9-60 60zm316 96l0 68-384 0 0-68 384 0zm0 124l0 164-384 0 0-164 384 0z"]],
    "microchip": [576, 512, [], "f2db", ["M128 96l0 320 320 0 0-320-320 0zm36 36l248 0 0 248-248 0 0-248zm56 56l0 136 136 0 0-136-136 0zm4 4l128 0 0 128-128 0 0-128z", "M256 32l64 0 0-64 64 0 0 64 64 0c35.3 0 64 28.7 64 64l0 64 64 0 0 64-64 0 0 64 64 0 0 64-64 0 0 64c0 35.3-28.7 64-64 64l-64 0 0 64-64 0 0-64-64 0 0 64-64 0 0-64-64 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1l-.3-6.5 0-64-64 0 0-64 64 0 0-64-64 0 0-64 64 0 0-64 .3-6.5c3.1-30.1 27-54.1 57.1-57.1l6.5-.3 64 0 0-64 64 0 0 64zM128 416l320 0 0-320-320 0 0 320zm284-36l-248 0 0-248 248 0 0 248zM220 324l136 0 0-136-136 0 0 136z"]],
    "pause": [256, 512, [9208], "f04c", ["", "M64 64l-64 0 0 384 64 0 0-384zm192 0l-64 0 0 384 64 0 0-384z"]],
    "arrow-down": [512, 512, [8595], "f063", ["", "M448.3 210.8l-160 160 0-338.7-64 0 0 338.7-160-160-45.3 45.2 214.6 214.6c12.5 12.5 32.8 12.5 45.3 0L493.5 256 448.3 210.8z"]],
    "location-dot": [384, 512, ["map-marker-alt"], "f3c5", ["M64 192c0 27.7 9 54.7 25.6 76.8 34.1 45.5 68.3 91 102.4 136.6L294.4 268.8C311 246.7 320 219.7 320 192 320 121.3 262.7 64 192 64S64 121.3 64 192zm168 0a40 40 0 1 1 -80 0 40 40 0 1 1 80 0z", "M38.4 307.2C13.5 274 0 233.5 0 192 0 86 86 0 192 0S384 86 384 192c0 41.5-13.5 82-38.4 115.2L192 512 38.4 307.2zm256-38.4C311 246.7 320 219.7 320 192 320 121.3 262.7 64 192 64S64 121.3 64 192c0 27.7 9 54.7 25.6 76.8L192 405.4 294.4 268.8zM192 152a40 40 0 1 1 0 80 40 40 0 1 1 0-80z"]],
    "bars": [512, 512, ["navicon"], "f0c9", ["", "M512 128l-512 0 0-64 512 0 0 64zm0 320l-512 0 0-64 512 0 0 64zM480 288l-480 0 0-64 512 0 0 64-32 0z"]],
    "battery-empty": [640, 512, ["battery-0"], "f244", ["M64 128l0 256 416 0 0-256-416 0z", "M480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l416 0zM64 384l416 0 0-256-416 0 0 256zm576-32l-64 0 0-192 64 0 0 192z"]],
    "keyboard": [576, 512, [9000], "f11c", ["M64 96l0 320 448 0 0-320-448 0zm48 32l64 0 0 64-64 0 0-64zm0 96l64 0 0 64-64 0 0-64zm48 100l256 0 0 56-256 0 0-56zm48-196l64 0 0 64-64 0 0-64zm0 96l64 0 0 64-64 0 0-64zm96-96l64 0 0 64-64 0 0-64zm0 96l64 0 0 64-64 0 0-64zm96-96l64 0 0 64-64 0 0-64zm0 96l64 0 0 64-64 0 0-64z", "M512 32c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l448 0zM64 416l448 0 0-320-448 0 0 320zm352-36l-256 0 0-56 256 0 0 56zM176 288l-64 0 0-64 64 0 0 64zm96 0l-64 0 0-64 64 0 0 64zm96 0l-64 0 0-64 64 0 0 64zm96 0l-64 0 0-64 64 0 0 64zM176 192l-64 0 0-64 64 0 0 64zm96 0l-64 0 0-64 64 0 0 64zm96 0l-64 0 0-64 64 0 0 64zm96 0l-64 0 0-64 64 0 0 64z"]],
    "stopwatch": [512, 512, [9201], "f2f2", ["M96.4 288a160 160 0 1 0 320 0 160 160 0 1 0 -320 0zm132-124l56 0 0 124c0 15.5-12.5 28-28 28s-28-12.5-28-28l0-124z", "M160.4-32l192 0 0 64-192 0 0-64zm256 320a160 160 0 1 0 -320 0 160 160 0 1 0 320 0zm64 0c0 123.7-100.3 224-224 224s-224-100.3-224-224 100.3-224 224-224c64.6 0 122.8 27.3 163.7 71.1 17.7-11.8 35.4-23.6 53.2-35.5l35.5 53.3c-17.9 12-35.3 23.5-52.1 34.7 15.2 30.2 23.7 64.3 23.7 100.4zm-196-96l0 96c0 15.5-12.5 28-28 28s-28-12.5-28-28l0-124 56 0 0 28z"]],
    "train": [512, 512, [128646], "f238", ["M96.3 288c0 21.3 0 42.7 0 64 0 29.8 20.4 54.9 48 62 1 .3 2 .5 3.1 .7l0 0c4.2 .9 8.5 1.3 12.9 1.3l192 0c17.7 0 33.7-7.2 45.3-18.7 0 0 0 0 0 0 .4-.4 .7-.7 1-1.1 0 0 0 0 0 0 .2-.2 .3-.3 .5-.5 .2-.2 .4-.4 .6-.6 .3-.4 .7-.7 1-1.1 9.7-11.2 15.6-25.9 15.6-41.9 0-21.3 0-42.7 0-64l-320 0zm32 64c0-14.9 10.2-27.4 24-31 .5-.1 1-.2 1.5-.4 0 0 0 0 0 0 2.1-.4 4.2-.7 6.5-.7 8.8 0 16.8 3.6 22.6 9.4 .4 .4 .7 .7 1.1 1.1 0 0 0 0 0 0 .2 .2 .3 .4 .5 .5 4.9 5.6 7.8 12.9 7.8 21s-2.9 15.3-7.8 21c-.2 .2-.3 .4-.5 .5 0 0 0 0 0 0-.3 .4-.7 .8-1.1 1.1-5.8 5.8-13.8 9.4-22.6 9.4-2.2 0-4.4-.2-6.4-.7 0 0 0 0 0 0-.5-.1-1-.2-1.5-.4-13.8-3.6-24-16.1-24-31zm192 0c0-15.2 10.6-27.9 24.8-31.2 .2-.1 .5-.1 .7-.2 0 0 0 0 .1 0 2.1-.4 4.2-.7 6.5-.7 4.4 0 8.6 .9 12.5 2.5s7.3 4 10.2 6.9c1.4 1.4 2.8 3 3.9 4.7 3.5 5.1 5.5 11.3 5.5 17.9s-2 12.8-5.5 17.9c-2.3 3.4-5.2 6.3-8.6 8.6-1.7 1.2-3.5 2.1-5.4 3-3.8 1.6-8 2.5-12.5 2.5-2.2 0-4.4-.2-6.4-.7 0 0 0 0-.1 0-.2 0-.5-.1-.7-.2-14.2-3.3-24.8-16-24.8-31.2z", "M352.3 0c70.7 0 128 57.3 128 128l0 224c0 40.1-18.5 75.9-47.4 99.4l60.6 60.6-45.2 45.3-78.5-78.5c-5.7 .8-11.6 1.3-17.5 1.3l-192 0-6.6-.2c-3.7-.2-7.4-.6-11-1.1L64.2 557.3 19 512 79.6 451.4C50.7 427.9 32.2 392.1 32.2 352l0-224c0-70.7 57.3-128 128-128l192 0zM96.2 352c0 35.3 28.7 64 64 64l192 0c35.3 0 64-28.7 64-64l0-64-320 0 0 64zm64 32a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm192 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64zM160.2 64c-35.3 0-64 28.7-64 64l0 96 320 0 0-96c0-35.3-28.7-64-64-64l-192 0z"]],
    "train-subway": [512, 512, ["subway"], "f239", ["M96.3 288c0 21.3 0 42.7 0 64 0 29.8 20.4 54.9 48 62 1 .3 2 .5 3.1 .7l0 0c4.2 .9 8.5 1.3 12.9 1.3l192 0c17.7 0 33.7-7.2 45.3-18.7 0 0 0 0 0 0 .4-.4 .7-.7 1-1.1 0 0 0 0 0 0 .2-.2 .3-.3 .5-.5 .2-.2 .4-.4 .6-.6 .3-.4 .7-.7 1-1.1 9.7-11.2 15.6-25.9 15.6-41.9 0-21.3 0-42.7 0-64l-320 0zm32 64c0-14.9 10.2-27.4 24-31 .5-.1 1-.2 1.5-.4 0 0 0 0 0 0 2.1-.4 4.2-.7 6.5-.7 8.8 0 16.8 3.6 22.6 9.4 .4 .4 .7 .7 1.1 1.1 0 0 0 0 0 0 .2 .2 .3 .4 .5 .5 4.9 5.6 7.8 12.9 7.8 21s-2.9 15.3-7.8 21c-.2 .2-.3 .4-.5 .5 0 0 0 0 0 0-.3 .4-.7 .8-1.1 1.1-5.8 5.8-13.8 9.4-22.6 9.4-2.2 0-4.4-.2-6.4-.7 0 0 0 0 0 0-.5-.1-1-.2-1.5-.4-13.8-3.6-24-16.1-24-31zm192 0c0-15.2 10.6-27.9 24.8-31.2 .2-.1 .5-.1 .7-.2 0 0 0 0 .1 0 2.1-.4 4.2-.7 6.5-.7 4.4 0 8.6 .9 12.5 2.5s7.3 4 10.2 6.9c1.4 1.4 2.8 3 3.9 4.7 3.5 5.1 5.5 11.3 5.5 17.9s-2 12.8-5.5 17.9c-2.3 3.4-5.2 6.3-8.6 8.6-1.7 1.2-3.5 2.1-5.4 3-3.8 1.6-8 2.5-12.5 2.5-2.2 0-4.4-.2-6.4-.7 0 0 0 0-.1 0-.2 0-.5-.1-.7-.2-14.2-3.3-24.8-16-24.8-31.2z", "M352.3 0c70.7 0 128 57.3 128 128l0 224c0 40.1-18.5 75.9-47.4 99.4l60.6 60.6-45.2 45.3-78.5-78.5c-5.7 .8-11.6 1.3-17.5 1.3l-192 0-6.6-.2c-3.7-.2-7.4-.6-11-1.1L64.2 557.3 19 512 79.6 451.4C52.3 429.2 34.3 396 32.4 358.6l-.2-6.6 0-224c0-70.7 57.3-128 128-128l192 0zM96.2 352c0 35.3 28.7 64 64 64l192 0c35.3 0 64-28.7 64-64l0-64-320 0 0 64zm64 32a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm192 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64zM160.2 64c-35.3 0-64 28.7-64 64l0 96 132 0 0-160-68 0zm124 160l132 0 0-96c0-35.3-28.7-64-64-64l-68 0 0 160z"]],
    "cloud-drizzle": [576, 512, [], "f738", ["M64 256c0-49 36.7-89.4 84.1-95.2 3.9-.5 7.9-.8 11.9-.8 24.4 0 46.6 9 63.5 24 14.1-16 28.2-32 42.3-48-22.1-19.5-49.6-32.9-80-37.9 17.5-39 56.6-66.1 102.1-66.1 57.9 0 105.5 43.9 111.4 100.2l2.6 25.5 25.4 3c47.6 5.6 84.6 46.2 84.6 95.3 0 41.8-26.7 77.2-64 90.4l0-90.4-128 0 0 32-64 0 0-32-128 0 0 90.4C90.7 333.2 64 297.8 64 256z", "M316 540l-56 0 0-88 56 0 0 88zm-96-32l-56 0 0-88 56 0 0 88zm192 0l-56 0 0-88 56 0 0 88zM288-32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 77.4-55 142-128 156.8l0-66.4c37.3-13.2 64-48.6 64-90.4 0-49.1-36.9-89.7-84.6-95.3l-25.4-3-2.6-25.5c-5.9-56.3-53.5-100.2-111.4-100.2-45.5 0-84.6 27.2-102.1 66.1 30.4 4.9 57.9 18.4 80 37.9-14.1 16-28.2 32-42.3 48-16.9-15-39.1-24-63.5-24-4 0-8 .3-11.9 .8-47.4 5.8-84.1 46.3-84.1 95.2 0 41.8 26.7 77.2 64 90.4l0 66.4c-73-14.8-128-79.4-128-156.8 0-2.6 .1-5.1 .2-7.6 0-.7 .1-1.5 .2-2.2 .1-1.8 .2-3.6 .4-5.3 .1-1.4 .3-2.8 .5-4.2 .1-1.2 .3-2.4 .4-3.5 .1-.8 .2-1.6 .3-2.3 .7-4.2 1.5-8.3 2.5-12.3 .7-2.8 1.4-5.5 2.2-8.2 .1-.4 .2-.7 .3-1.1 .4-1.1 .8-2.3 1.1-3.4 .4-1.2 .8-2.5 1.2-3.7 .4-1.1 .9-2.3 1.3-3.4 .5-1.2 1-2.5 1.5-3.7 .4-.9 .7-1.7 1.1-2.6 .6-1.4 1.3-2.8 1.9-4.2 .3-.7 .7-1.5 1-2.2 1-2 2-4.1 3.1-6.1 .6-1.2 1.3-2.3 2-3.5 .5-.9 1-1.9 1.6-2.8 .8-1.3 1.6-2.5 2.4-3.8 .5-.8 1-1.5 1.5-2.3 .7-1.1 1.4-2.1 2.2-3.2 .7-1 1.4-2 2.1-3 .4-.6 .9-1.2 1.3-1.8 1-1.3 2-2.6 3.1-3.9 .6-.7 1.1-1.4 1.7-2.1 1.4-1.7 2.9-3.4 4.4-5.1 .5-.6 1-1.1 1.6-1.7 1.2-1.2 2.3-2.5 3.5-3.7 .5-.5 1-1 1.5-1.5 1.1-1 2.1-2.1 3.2-3.1 .9-.8 1.8-1.7 2.7-2.5 .9-.8 1.8-1.6 2.7-2.3 .8-.7 1.7-1.4 2.5-2.1 .9-.7 1.8-1.4 2.7-2.1 6-4.6 12.3-8.9 18.9-12.7 .3-.2 .6-.3 .9-.5 3.5-2 5.6-3 6.1-3.3 4.8-2.5 9.8-4.7 14.9-6.6 .8-.3 1.5-.6 2.3-.9 .7-.2 1.3-.5 2-.7 1.3-.5 2.6-.9 4-1.3l1.6-.5c1.3-.4 2.6-.8 4-1.1 .2-.1 .5-.2 .7-.2 18.9-76.9 88.2-133.8 170.9-133.8zm28 356l0 88-56 0 0-88 56 0zm-96 56l-56 0 0-88 56 0 0 88zm192-88l0 88-56 0 0-88 56 0z"]],
    "ship": [640, 512, [128674], "f21a", ["M140 320l36.6 0 0 0 0 0c-10-14.7-15.9-32.2-16.6-50.6 0-.1 0-.3 0-.4 0-.2 0-.3 0-.5 0-.2 0-.4 0-.6 0-.1 0-.2 0-.2 0-.3 0-.5 0-.8 0 0 0-.1 0-.1 0-.3 0-.6 0-.8 0-6.9 0-13.9 0-20.8l132-42.6 0 118.3-130.6 31.4c-8.8-9.6-16-20.5-21.5-32.3zM348 202.6l132 42.6 0 20.8 0 0c0 .3 0 .6 0 .8 0 0 0 .1 0 .1 0 .3 0 .5 0 .8 0 .1 0 .2 0 .2 0 .2 0 .4 0 .6 0 .2 0 .3 0 .5 0 .1 0 .3 0 .4-.7 18.3-6.5 35.8-16.6 50.5l0 0 0 0 36.6 0c-5.5 11.8-12.7 22.7-21.5 32.3L348 320.9 348 202.6z", "M64 384c0 35.3 28.7 64 64 64s64-28.7 64-64l64 0c0 35.3 28.7 64 64 64s64-28.7 64-64l64 0c0 35.3 28.7 64 64 64s64-28.7 64-64l64 0c0 70.7-57.3 128-128 128-38.2 0-72.5-16.8-96-43.4-23.5 26.6-57.8 43.4-96 43.4s-72.5-16.8-96-43.4C200.5 495.2 166.2 512 128 512 57.3 512 0 454.7 0 384l64 0zM448 0c35.3 0 64 28.7 64 64l0 125.8c19.5 11.3 32 32.2 32 55.4l0 20.8c0 18.7-3.3 36.9-9.4 54l-71.2 0C474 304.3 480 285.6 480 266l0-20.8-132-42.6 0 149.4-56 0 0-149.4-132 42.6 0 20.8c0 19.6 6 38.3 16.6 54l-71.2 0c-6.1-17.1-9.4-35.3-9.4-54l0-20.8c0-23.2 12.5-44.1 32-55.4L128 64c0-35.3 28.7-64 64-64L448 0zM192 167.6l118.2-38.1 9.8-3.2 9.8 3.2 118.2 38.1 0-103.6-256 0 0 103.6z"]],
    "arrows-rotate": [512, 512, [128472, "refresh", "sync"], "f021", ["", "M256 64c56.8 0 107.9 24.7 143.1 64l-79.1 0 0 64 160 0c17.7 0 32-14.3 32-32l0-160-64 0 0 86.7C401.1 33.5 332.5 0 256 0 114.6 0 0 114.6 0 256l64 0C64 150 150 64 256 64zm0 384c-56.8 0-107.9-24.7-143.1-64l79.1 0 0-64-160 0c-17.7 0-32 14.3-32 32l0 160 64 0 0-86.7c46.9 53.1 115.5 86.7 192 86.7 141.4 0 256-114.6 256-256l-64 0c0 106-86 192-192 192z"]],
    "quotes": [512, 512, [], "e234", ["M64 288l96 0 0 96-96 0 0-96zm288 0l96 0 0 96-96 0 0-96z", "M0 160C0 89.3 57.3 32 128 32l32 0 0 64-32 0c-35.3 0-64 28.7-64 64l0 64 96 0c35.3 0 64 28.7 64 64l0 96c0 35.3-28.7 64-64 64l-96 0c-35.3 0-64-28.7-64-64L0 160zM64 320l0 64 96 0 0-96-96 0 0 32zm288-32l0 96 96 0 0-96-96 0zm0-64l96 0c35.3 0 64 28.7 64 64l0 96c0 35.3-28.7 64-64 64l-96 0c-35.3 0-64-28.7-64-64l0-224c0-70.7 57.3-128 128-128l32 0 0 64-32 0c-35.3 0-64 28.7-64 64l0 64z"]],
    "book-open": [576, 512, [128214, 128366], "f518", ["M64 96.6c76.9 3.2 147.1 18.2 196 50.7l0 278.7c-57.9-27.5-127.1-38.8-194.7-41.5-.3 0-.5-.1-.7-.1s-.3-.2-.5-.3c-.1-.1-.1-.1-.1-.2L64 96.6z", "M32 32L0 32 0 384c0 35.7 28.7 63.3 62.7 64.6 82.7 3.3 157 20.2 206.1 57L288 520 307.2 505.6c49.1-36.8 123.4-53.8 206.1-57 34-1.3 62.7-28.9 62.7-64.6l0-352-32 0C454.5 32 359.1 45.4 288 89.3 216.9 45.4 121.5 32 32 32zM64 384L64 96.6c76.9 3.2 147.1 18.2 196 50.7l0 278.7c-57.9-27.5-127.1-38.8-194.7-41.5-.5 0-.9-.2-1.1-.5-.1-.1-.1-.1-.1-.2l0 0zm252 42.1l0-278.7c48.9-32.5 119.1-47.6 196-50.7L512 384c0 0-.1 .1-.1 .2-.2 .2-.6 .4-1.1 .5-67.6 2.7-136.9 14-194.7 41.5z"]],
    "box-archive": [512, 512, ["archive"], "f187", ["M96 192l0 256 320 0 0-256-320 0zm64 68l192 0 0 56-192 0 0-56z", "M448 64l0 64-384 0 0-64 384 0zM0 128c0 23.7 12.9 44.4 32 55.4L32 448c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-264.6c19.1-11.1 32-31.7 32-55.4l0-64c0-35.3-28.7-64-64-64L64 0C28.7 0 0 28.7 0 64l0 64zM96 448l0-256 320 0 0 256-320 0zM352 260l-192 0 0 56 192 0 0-56z"]],
    "list-ul": [512, 512, ["list-dots"], "f0ca", ["", "M48 144a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm432-16l32 0 0-64-352 0 0 64 320 0zm0 320l32 0 0-64-352 0 0 64 320 0zm32-160l0-64-352 0 0 64 352 0zM96 256a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM48 464a48 48 0 1 0 0-96 48 48 0 1 0 0 96z"]],
    "money-bill": [576, 512, [], "f0d6", ["M64 160l0 192c35.3 0 64 28.7 64 64l320 0c0-35.3 28.7-64 64-64l0-192c-35.3 0-64-28.7-64-64L128 96c0 35.3-28.7 64-64 64zm320 96a96 96 0 1 1 -192 0 96 96 0 1 1 192 0z", "M64 96l0 320 448 0 0-320-448 0zM0 96C0 60.7 28.7 32 64 32l448 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zM328 256a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm-136 0a96 96 0 1 1 192 0 96 96 0 1 1 -192 0z"]],
    "arrow-pointer": [512, 512, ["mouse-pointer"], "f245", ["M100.7 100.3l108.4 308 49.3-131.5 5.1-13.6 13.6-5.1 131.5-49.3-308-108.4z", "M59 17.8L483.3 167.1c17.4 6.1 29 22.5 29 41 0 18.1-11.2 34.3-28.2 40.7l-171 64.1-64.1 171c-6.4 16.9-22.6 28.2-40.7 28.2-18.4 0-34.9-11.6-41-29L18.2 58.6-4-4.3 59 17.8zM209 408.3l49.3-131.5 5.1-13.6 13.6-5.1 131.5-49.3-308-108.4 108.4 308z"]],
    "cake-candles": [512, 512, [127874, "birthday-cake", "cake"], "f1fd", ["M64 224l0 86.2c13.3 8.9 29 13.8 45.3 13.8l2.7 0c23.3 0 45.7-9.3 62.1-25.7l7.4-7.4C201.3 271.1 228.1 260 256 260s54.7 11.1 74.4 30.8l7.4 7.4C354.3 314.7 376.7 324 400 324l2.7 0c16.2 0 32-4.9 45.3-13.8l0-86.2-384 0z", "M60.7 9.2L96-32 131.3 9.2c8.2 9.5 12.7 21.7 12.7 34.2l0 4.6c0 14.2-6.2 27-16 35.8l0 76.2 96 0 0-76.2C214.2 75 208 62.2 208 48l0-4.6c0-12.5 4.5-24.7 12.7-34.2L256-32 291.3 9.2c8.2 9.5 12.7 21.7 12.7 34.2l0 4.6c0 14.2-6.2 27-16 35.8l0 76.2 96 0 0-76.2C374.2 75 368 62.2 368 48l0-4.6c0-12.5 4.5-24.7 12.7-34.2L416-32 451.3 9.2c8.2 9.5 12.7 21.7 12.7 34.2l0 4.6c0 14.2-6.2 27-16 35.8l0 76.2c35.3 0 64 28.7 64 64l0 224c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 224c0-35.3 28.7-64 64-64l0-76.2C54.2 75 48 62.2 48 48l0-4.6c0-12.5 4.5-24.7 12.7-34.2zM448 224l-384 0 0 86.2c13.3 8.9 29 13.8 45.3 13.8l2.7 0c23.3 0 45.7-9.3 62.1-25.7l7.4-7.4C201.3 271.1 228.1 260 256 260s54.7 11.1 74.4 30.8l7.4 7.4C354.3 314.7 376.7 324 400 324l2.7 0c16.2 0 32-4.9 45.3-13.8l0-86.2zM64 372.3l0 75.7 384 0 0-75.7c-14.4 5-29.7 7.7-45.3 7.7l-2.7 0c-38.2 0-74.8-15.2-101.7-42.1l-7.4-7.4c-9.2-9.2-21.8-14.4-34.8-14.4s-25.6 5.2-34.8 14.4l-7.4 7.4c-27 27-63.6 42.1-101.7 42.1l-2.7 0c-15.6 0-30.8-2.6-45.3-7.7z"]],
    "bug-slash": [640, 512, [], "e490", ["M224.3 295.8l0 56.2c0 3.3 .2 6.6 .5 9.8 0 .4 .1 .8 .1 1.2 0 0 0 0 0 0 0 .4 .1 .8 .1 1.2 .1 .8 .2 1.6 .3 2.4 .2 1.6 .5 3.2 .8 4.7 .1 .5 .2 .8 .2 1.2 0 0 0 0 0 0 .2 .8 .3 1.4 .4 1.7 0 .2 .1 .3 .1 .5 4.2 17.4 13.2 32.9 25.4 45.1 17.4 17.4 41.4 28.1 67.9 28.1 16.3 0 31.6-4.1 45-11.3l-141-141zM298.5 98.5l117.7 117.7 0-24.2c0-13.3-2.7-25.9-7.5-37.4-.3-.8-.6-1.5-.9-2.2-.3-.7-.6-1.4-1-2.1-.7-1.5-1.4-2.8-2.1-4.2-.4-.7-.8-1.4-1.1-2.1-.4-.7-.8-1.3-1.1-1.9 0 0 0 0 0-.1-1.7-2.8-3.2-5-4.5-6.7-.2-.3-.4-.6-.6-.9-1.6-2.2-3.3-4.3-5.1-6.3-.2-.3-.5-.5-.7-.8-.8-.8-1.6-1.7-2.3-2.5-.2-.2-.5-.5-.7-.7-.1-.1-.1-.1-.2-.2-17.4-17.4-41.4-28.1-67.9-28.1-7.5 0-14.7 .9-21.7 2.5z", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM224.3 295.8l0 56.2c0 53 43 96 96 96 16.3 0 31.6-4.1 45-11.3l46.5 46.5c-25.9 18.1-57.4 28.8-91.5 28.8-52.3 0-98.8-25.1-128-64l-96 0 0-64 67.2 0c-1.6-7.7-2.6-15.7-3-23.8l-.2-8.2 0-32-64 0 0-64 64 0 0-24.2 64 64zm250.6-278L433.8 79.3c13.8 13.9 25.1 30.4 33.1 48.7l77.3 0 0 64-64 0 0 64 64 0 0 64-24.2 0-103.8-103.8 0-24.2c0-53-43-96-96-96-7.5 0-14.7 .9-21.7 2.5L248.8 48.8c21.5-10.7 45.8-16.8 71.4-16.8 21.3 0 41.7 4.2 60.3 11.8l41.1-61.5 53.2 35.5z"]],
    "circle-info": [512, 512, ["info-circle"], "f05a", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm132-28l88 0 0 96 32 0 0 56-120 0 0-56 32 0 0-40-32 0 0-56zm100-68a40 40 0 1 1 -80 0 40 40 0 1 1 80 0z", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-448a192 192 0 1 0 0 384 192 192 0 1 0 0-384zm28 260l32 0 0 56-120 0 0-56 32 0 0-40-32 0 0-56 88 0 0 96zM256 200a40 40 0 1 1 0-80 40 40 0 1 1 0 80z"]],
    "feather": [512, 512, [129718], "f52d", ["M128 186.5c0 50.8 0 101.5 0 152.2 22.7-22.7 45.3-45.3 68-68 0-50.8 0-101.5 0-152.2l-68 68zM173.3 384l152.2 0 68-68-152.2 0c-22.7 22.7-45.3 45.3-68 68zM252 74.8c0 46.6 0 93.3 0 139.9 25.8-25.8 51.6-51.6 77.4-77.4l45.3 45.3-77.4 77.4 139.9 0c.4-1 .9-2 1.3-3 4.7-11.6 7.8-23.8 9-36.4 0-.1 0-.3 .1-.7 0-.2 0-.5 .1-.9 0-.3 0-.5 .1-.7 0-.4 0-.7 .1-.9 0-.4 0-.7 .1-.8 0-.2 0-.4 0-.6 0-.1 0-.1 0-.2 0-.2 0-.4 0-.7 0 0 0-.1 0-.1 0-.2 0-.5 0-.7 0 0 0-.1 0-.1 0-.2 0-.5 0-.7l0-.1c0-.3 0-.5 0-.8 0 0 0 0 0-.1 0-.3 0-.5 0-.8l0 0c0-1.1 0-2.2 0-3.4l0-16.5c0-17.7-3.6-34.5-10.1-49.8-1.6-3.8-3.4-7.6-5.4-11.2-1-1.8-2-3.6-3.1-5.4-5.3-8.8-11.7-16.9-19-24.1-23.2-23.2-55.2-37.5-90.5-37.5l-16.5 0c-17.9 0-35.4 3.8-51.5 10.8z", "M303.5 64c-17.9 0-35.4 3.8-51.5 10.8l0 139.9 77.4-77.4 45.3 45.3-77.4 77.4 139.9 0c7.1-16.1 10.8-33.6 10.8-51.5l0-16.5c0-70.7-57.3-128-128-128l-16.5 0zM196 118.5l-68 68 0 152.2 68-68 0-152.2zM241.3 316l-68 68 152.2 0 68-68-152.2 0zM64 402.7L64 160 167.8 56.2C203.8 20.2 252.6 0 303.5 0L320 0C426 0 512 86 512 192l0 16.5c0 50.9-20.2 99.8-56.2 135.8L352 448 109.3 448 54.6 502.6 9.4 457.4 64 402.7z"]],
    "phone-arrow-down-left": [512, 512, ["phone-arrow-down", "phone-incoming"], "e223", ["M66.2 216.2c13.8 72.6 54.8 135.6 112 178 11.4 8.5 23.5 16.2 36.1 22.9 25.3 13.5 52.8 23.4 81.8 28.9 41.7 7.9 84.9-5.3 114.7-35.2L437.8 384c-17.8-17.8-35.7-35.7-53.5-53.5l-33.4 33.4c-17.1 17.1-42 23.7-65.3 17.3-17.6-4.8-34.4-11.7-49.9-20.4-1-.6-2-1.2-3.1-1.8 0 0-.1 0-.1 0-4.1-2.4-8.1-4.9-12-7.6l0 0c-1-.6-1.9-1.3-2.9-2-.4-.3-.7-.5-.8-.6-41.3-29.1-72.1-72-85.8-122.2-6.3-23.3 .3-48.2 17.3-65.2L181.8 128c-17.8-17.8-35.7-35.7-53.5-53.5l-26.9 26.9c-29.9 29.9-43.1 73-35.2 114.8z", "M83 29.2c25-25 65.5-25 90.5 0L227 82.8c25 25 25 65.5 0 90.5l-33.4 33.4c-.8 .8-1.1 2-.8 3.2 13.7 50.1 51.2 89.9 99.8 106.7l9.9 3c.6 .2 1.1 .1 1.7 0l1.5-.8 33.4-33.4c25-25 65.5-25 90.5 0L483 338.7c25 25 25 65.5 0 90.5l-26.9 26.9-8.7 8.2c-41.4 36.6-96.8 53.5-151.6 46.5l-11.7-1.8C142.2 481.9 30.4 370 3.3 228.1-7.8 169.6 8.8 109.1 48 64.8L56.1 56.1 83 29.2zm18.4 72.2c-29.9 29.9-43.1 73-35.2 114.7 22.1 116.1 113.8 207.8 229.9 229.9 41.7 7.9 84.9-5.3 114.7-35.2l26.9-26.9-53.5-53.5-33.4 33.4c-17.1 17.1-42 23.7-65.2 17.3-75.3-20.5-134.1-79.3-154.6-154.6-6.3-23.3 .3-48.2 17.3-65.2l33.4-33.4-53.5-53.5-26.9 26.9zM519.5 32l-19.8 19.8-112.2 112.2 88.4 0 0 56-156 0c-7.4 0-14.6-2.9-19.8-8.2S292 199.4 292 192l0-156 56 0 0 88.4 112.2-112.2 19.8-19.8 39.6 39.6z"]],
    "wind": [512, 512, [], "f72e", ["", "M192 0l0 64 32 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0 0 64 224 0c53 0 96-43 96-96S277 0 224 0L192 0zm64 512l32 0c53 0 96-43 96-96s-43-96-96-96l-288 0 0 64 288 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-32 0 0 64zM416 96l-32 0 0 64 32 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-416 0 0 64 416 0c53 0 96-43 96-96s-43-96-96-96z"]],
    "layer-group": [576, 512, [], "f5fd", ["M104 128L288.5 35.8 472.9 128 288.5 220.2 104 128z", "M555.4 414.3l-28.6 14.3-209.7 104.8c-18 9-39.2 9-57.2 0L50.2 428.6 21.5 414.3 50.2 357 78.8 371.4 288.5 476.2 526.8 357 555.4 414.3zm0-128L317.1 405.5c-18 9-39.2 9-57.2 0l-238.3-119.2 28.6-57.2 238.3 119.2 238.3-119.2 28.6 57.2zM259.8-21.5c18-9 39.2-9 57.2 0l227.4 113.7 0 71.6-227.4 113.7c-18 9-39.2 9-57.2 0L32.5 163.8 32.5 92.2 259.8-21.5zM104 128L288.5 220.2 472.9 128 288.5 35.8 104 128z"]],
    "shield": [448, 512, [128737, "shield-blank"], "f132", ["M64 119l160-53.3 160 53.3 0 146.3c0 60.6-34.2 116-88.4 143.1l-71.6 35.8-71.6-35.8C98.2 381.3 64 325.9 64 265.3L64 119z", "M234.1 1.6L404.2 58.3C430.4 67 448 91.5 448 119l0 146.3c0 84.8-47.9 162.4-123.8 200.3L224 515.8 123.8 465.7C47.9 427.7 0 350.2 0 265.3L0 119C0 91.5 17.6 67 43.8 58.3L213.9 1.6 224-1.7 234.1 1.6zM64 119l0 146.3c0 60.6 34.2 116 88.4 143.1l71.6 35.8 71.6-35.8c54.2-27.1 88.4-82.5 88.4-143.1L384 119 224 65.7 64 119z"]],
    "face-laugh": [512, 512, ["laugh"], "f599", ["M64 256a192 192 0 1 0 384 0 192 192 0 1 0 -384 0zm56 24l272 0 0 54.4-3.2 5.6c-26.4 45.6-76.7 76-132.8 76s-106.4-30.4-132.8-76l-3.2-5.6 0-54.4zm88-72a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm160 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z", "M448 256a192 192 0 1 0 -384 0 192 192 0 1 0 384 0zM0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm176-80a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM144 280l248 0 0 54.4-3.2 5.6c-26.4 45.6-76.7 76-132.8 76s-106.4-30.4-132.8-76l-3.2-5.6 0-54.4 24 0zm112 88c33.4 0 63.9-15.7 83-40l-166.1 0c19.2 24.3 49.6 40 83.1 40z"]],
    "cart-shopping": [640, 512, [128722, "shopping-cart"], "f07a", ["M147.8 128c11.1 55.4 22.2 110.9 33.3 166.3 3 15 16.1 25.7 31.4 25.7L430 320c14.7 0 27.5-10 31-24.2 14-55.9 28-111.8 41.9-167.8l-355.2 0z", "M0 0L122.2 0c3 15.1 7.3 36.4 12.8 64l368 0c41.6 0 72.2 39.1 62.1 79.5L523.2 311.3C512.5 354 474.1 384 430 384l-217.6 0c-45.8 0-85.2-32.3-94.1-77.2L69.8 64 0 64 0 0zM147.8 128l33.3 166.3c3 15 16.1 25.7 31.4 25.7L430 320c14.7 0 27.5-10 31-24.2L503 128 147.8 128zM160 464a48 48 0 1 1 96 0 48 48 0 1 1 -96 0zm272-48a48 48 0 1 1 0 96 48 48 0 1 1 0-96z"]],
    "arrow-up-arrow-down": [576, 512, ["sort-up-down"], "e099", ["", "M438.9 470.6C515.1 394.4 554.7 354.9 557.5 352l-45.3-45.3c-12 12-33.3 33.3-64 64l0-338.7-64 0 0 338.7-64-64-45.3 45.3c2.9 2.9 42.4 42.4 118.6 118.6 6 6 14.1 9.4 22.6 9.4s16.6-3.4 22.6-9.4zM182.9 41.4C170.4 28.9 150.1 28.9 137.6 41.4 61.4 117.6 21.9 157.1 19 160l45.3 45.3c12-12 33.3-33.3 64-64l0 338.7 64 0 0-338.7c30.7 30.7 52 52 64 64L301.5 160c-2.9-2.9-42.4-42.4-118.6-118.6z"]]
  };

  bunker(function () {
    defineIcons('faudsb', icons);
  });

}());
