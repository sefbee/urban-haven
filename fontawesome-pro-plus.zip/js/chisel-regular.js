/*!
 * Font Awesome Pro 7.3.0 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license (Commercial License)
 * Copyright 2026 Fonticons, Inc.
 */
(function () {
  'use strict';

  var _WINDOW = {};
  var _DOCUMENT = {};
  try {
    if (typeof window !== 'undefined') _WINDOW = window;
    if (typeof document !== 'undefined') _DOCUMENT = document;
  } catch (e) {} // eslint-disable-line no-empty

  var _ref = _WINDOW.navigator || {},
    _ref$userAgent = _ref.userAgent,
    userAgent = _ref$userAgent === void 0 ? '' : _ref$userAgent;
  var WINDOW = _WINDOW;
  var DOCUMENT = _DOCUMENT;
  var IS_BROWSER = !!WINDOW.document;
  var IS_DOM = !!DOCUMENT.documentElement && !!DOCUMENT.head && typeof DOCUMENT.addEventListener === 'function' && typeof DOCUMENT.createElement === 'function';
  var IS_IE = ~userAgent.indexOf('MSIE') || ~userAgent.indexOf('Trident/');

  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _arrayWithoutHoles(r) {
    if (Array.isArray(r)) return _arrayLikeToArray(r);
  }
  function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[r] = t, e;
  }
  function _iterableToArray(r) {
    if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
  }
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function (r) {
        return Object.getOwnPropertyDescriptor(e, r).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
        _defineProperty(e, r, t[r]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
        Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
      });
    }
    return e;
  }
  function _toConsumableArray(r) {
    return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }

  var _cl;
  var rl = {
      classic: {
        fa: "solid",
        fas: "solid",
        "fa-solid": "solid",
        far: "regular",
        "fa-regular": "regular",
        fal: "light",
        "fa-light": "light",
        fat: "thin",
        "fa-thin": "thin",
        fab: "brands",
        "fa-brands": "brands"
      },
      duotone: {
        fa: "solid",
        fad: "solid",
        "fa-solid": "solid",
        "fa-duotone": "solid",
        fadr: "regular",
        "fa-regular": "regular",
        fadl: "light",
        "fa-light": "light",
        fadt: "thin",
        "fa-thin": "thin"
      },
      sharp: {
        fa: "solid",
        fass: "solid",
        "fa-solid": "solid",
        fasr: "regular",
        "fa-regular": "regular",
        fasl: "light",
        "fa-light": "light",
        fast: "thin",
        "fa-thin": "thin"
      },
      "sharp-duotone": {
        fa: "solid",
        fasds: "solid",
        "fa-solid": "solid",
        fasdr: "regular",
        "fa-regular": "regular",
        fasdl: "light",
        "fa-light": "light",
        fasdt: "thin",
        "fa-thin": "thin"
      },
      slab: {
        "fa-regular": "regular",
        faslr: "regular"
      },
      "slab-press": {
        "fa-regular": "regular",
        faslpr: "regular"
      },
      "slab-duo": {
        "fa-regular": "regular",
        fasldr: "regular"
      },
      "slab-press-duo": {
        "fa-regular": "regular",
        faslpdr: "regular"
      },
      thumbprint: {
        "fa-light": "light",
        fatl: "light"
      },
      vellum: {
        "fa-solid": "solid",
        favs: "solid"
      },
      pixel: {
        "fa-regular": "regular",
        fapr: "regular"
      },
      mosaic: {
        "fa-solid": "solid",
        fams: "solid"
      },
      whiteboard: {
        "fa-semibold": "semibold",
        fawsb: "semibold"
      },
      notdog: {
        "fa-solid": "solid",
        fans: "solid"
      },
      "notdog-duo": {
        "fa-solid": "solid",
        fands: "solid"
      },
      etch: {
        "fa-solid": "solid",
        faes: "solid"
      },
      graphite: {
        "fa-thin": "thin",
        fagt: "thin"
      },
      jelly: {
        "fa-regular": "regular",
        fajr: "regular"
      },
      "jelly-fill": {
        "fa-regular": "regular",
        fajfr: "regular"
      },
      "jelly-duo": {
        "fa-regular": "regular",
        fajdr: "regular"
      },
      chisel: {
        "fa-regular": "regular",
        facr: "regular"
      },
      utility: {
        "fa-semibold": "semibold",
        fausb: "semibold"
      },
      "utility-duo": {
        "fa-semibold": "semibold",
        faudsb: "semibold"
      },
      "utility-fill": {
        "fa-semibold": "semibold",
        faufsb: "semibold"
      }
    };
  var u = "classic",
    l = "duotone",
    h = "sharp",
    t = "sharp-duotone",
    g = "chisel",
    n = "etch",
    m = "graphite",
    p = "jelly",
    s = "jelly-duo",
    y = "jelly-fill",
    w = "mosaic",
    x = "notdog",
    e = "notdog-duo",
    b = "pixel",
    c = "slab",
    o = "slab-duo",
    I = "slab-press",
    a = "slab-press-duo",
    r = "thumbprint",
    v = "utility",
    i = "utility-duo",
    F = "utility-fill",
    d = "vellum",
    S = "whiteboard",
    A = "Classic",
    P = "Duotone",
    j = "Sharp",
    B = "Sharp Duotone",
    N = "Chisel",
    D = "Etch",
    k = "Graphite",
    T = "Jelly",
    C = "Jelly Duo",
    W = "Jelly Fill",
    R = "Mosaic",
    K = "Notdog",
    L = "Notdog Duo",
    U = "Pixel",
    J = "Slab",
    _ = "Slab Duo",
    M = "Slab Press",
    E = "Slab Press Duo",
    G = "Thumbprint",
    V = "Utility",
    z = "Utility Duo",
    O = "Utility Fill",
    Y = "Vellum",
    q = "Whiteboard",
    cl = (_cl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, u, A), l, P), h, j), t, B), g, N), n, D), m, k), p, T), s, C), y, W), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, w, R), x, K), e, L), b, U), c, J), o, _), I, M), a, E), r, G), v, V), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, i, z), F, O), d, Y), S, q));
  var Al = {
      classic: {
        900: "fas",
        400: "far",
        normal: "far",
        300: "fal",
        100: "fat"
      },
      duotone: {
        900: "fad",
        400: "fadr",
        300: "fadl",
        100: "fadt"
      },
      sharp: {
        900: "fass",
        400: "fasr",
        300: "fasl",
        100: "fast"
      },
      "sharp-duotone": {
        900: "fasds",
        400: "fasdr",
        300: "fasdl",
        100: "fasdt"
      },
      slab: {
        400: "faslr"
      },
      "slab-press": {
        400: "faslpr"
      },
      "slab-duo": {
        400: "fasldr"
      },
      "slab-press-duo": {
        400: "faslpdr"
      },
      vellum: {
        900: "favs"
      },
      mosaic: {
        900: "fams"
      },
      pixel: {
        400: "fapr"
      },
      whiteboard: {
        600: "fawsb"
      },
      thumbprint: {
        300: "fatl"
      },
      notdog: {
        900: "fans"
      },
      "notdog-duo": {
        900: "fands"
      },
      etch: {
        900: "faes"
      },
      graphite: {
        100: "fagt"
      },
      chisel: {
        400: "facr"
      },
      jelly: {
        400: "fajr"
      },
      "jelly-fill": {
        400: "fajfr"
      },
      "jelly-duo": {
        400: "fajdr"
      },
      utility: {
        600: "fausb"
      },
      "utility-duo": {
        600: "faudsb"
      },
      "utility-fill": {
        600: "faufsb"
      }
    };
  var $l = {
      chisel: {
        regular: "facr"
      },
      classic: {
        brands: "fab",
        light: "fal",
        regular: "far",
        solid: "fas",
        thin: "fat"
      },
      duotone: {
        light: "fadl",
        regular: "fadr",
        solid: "fad",
        thin: "fadt"
      },
      etch: {
        solid: "faes"
      },
      graphite: {
        thin: "fagt"
      },
      jelly: {
        regular: "fajr"
      },
      "jelly-duo": {
        regular: "fajdr"
      },
      "jelly-fill": {
        regular: "fajfr"
      },
      mosaic: {
        solid: "fams"
      },
      notdog: {
        solid: "fans"
      },
      "notdog-duo": {
        solid: "fands"
      },
      pixel: {
        regular: "fapr"
      },
      sharp: {
        light: "fasl",
        regular: "fasr",
        solid: "fass",
        thin: "fast"
      },
      "sharp-duotone": {
        light: "fasdl",
        regular: "fasdr",
        solid: "fasds",
        thin: "fasdt"
      },
      slab: {
        regular: "faslr"
      },
      "slab-duo": {
        regular: "fasldr"
      },
      "slab-press": {
        regular: "faslpr"
      },
      "slab-press-duo": {
        regular: "faslpdr"
      },
      thumbprint: {
        light: "fatl"
      },
      utility: {
        semibold: "fausb"
      },
      "utility-duo": {
        semibold: "faudsb"
      },
      "utility-fill": {
        semibold: "faufsb"
      },
      vellum: {
        solid: "favs"
      },
      whiteboard: {
        semibold: "fawsb"
      }
    };
  var rt = {
      kit: {
        fak: "kit",
        "fa-kit": "kit"
      },
      "kit-duotone": {
        fakd: "kit-duotone",
        "fa-kit-duotone": "kit-duotone"
      }
    },
    it = ["kit"];
  var H = "kit",
    f = "kit-duotone",
    Q = "Kit",
    X = "Kit Duotone",
    ht = _defineProperty(_defineProperty({}, H, Q), f, X);
  var mt = {
    kit: {
      "fa-kit": "fak"
    },
    "kit-duotone": {
      "fa-kit-duotone": "fakd"
    }
  };
  var It = {
      kit: {
        fak: "fa-kit"
      },
      "kit-duotone": {
        fakd: "fa-kit-duotone"
      }
    };
  var St = {
      kit: {
        kit: "fak"
      },
      "kit-duotone": {
        "kit-duotone": "fakd"
      }
    };

  var _jl;
  var l$1 = {
      GROUP: "duotone-group",
      SWAP_OPACITY: "swap-opacity",
      PRIMARY: "primary",
      SECONDARY: "secondary"
    };
  var g$1 = "classic",
    a$1 = "duotone",
    m$1 = "sharp",
    t$1 = "sharp-duotone",
    p$1 = "chisel",
    y$1 = "etch",
    b$1 = "graphite",
    w$1 = "jelly",
    e$1 = "jelly-duo",
    x$1 = "jelly-fill",
    c$1 = "mosaic",
    I$1 = "notdog",
    o$1 = "notdog-duo",
    v$1 = "pixel",
    F$1 = "slab",
    r$1 = "slab-duo",
    S$1 = "slab-press",
    i$1 = "slab-press-duo",
    d$1 = "thumbprint",
    A$1 = "utility",
    f$1 = "utility-duo",
    P$1 = "utility-fill",
    u$1 = "vellum",
    j$1 = "whiteboard",
    B$1 = "Classic",
    N$1 = "Duotone",
    D$1 = "Sharp",
    k$1 = "Sharp Duotone",
    C$1 = "Chisel",
    T$1 = "Etch",
    L$1 = "Graphite",
    W$1 = "Jelly",
    R$1 = "Jelly Duo",
    K$1 = "Jelly Fill",
    U$1 = "Mosaic",
    J$1 = "Notdog",
    _$1 = "Notdog Duo",
    M$1 = "Pixel",
    E$1 = "Slab",
    G$1 = "Slab Duo",
    O$1 = "Slab Press",
    V$1 = "Slab Press Duo",
    z$1 = "Thumbprint",
    Y$1 = "Utility",
    $$1 = "Utility Duo",
    q$1 = "Utility Fill",
    H$1 = "Vellum",
    Q$1 = "Whiteboard",
    jl$1 = (_jl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, g$1, B$1), a$1, N$1), m$1, D$1), t$1, k$1), p$1, C$1), y$1, T$1), b$1, L$1), w$1, W$1), e$1, R$1), x$1, K$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, c$1, U$1), I$1, J$1), o$1, _$1), v$1, M$1), F$1, E$1), r$1, G$1), S$1, O$1), i$1, V$1), d$1, z$1), A$1, Y$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, f$1, $$1), P$1, q$1), u$1, H$1), j$1, Q$1));
  var X$1 = "kit",
    h$1 = "kit-duotone",
    Z$1 = "Kit",
    ll$1 = "Kit Duotone",
    ws = _defineProperty(_defineProperty({}, X$1, Z$1), h$1, ll$1);
  var ra = {
      classic: {
        "fa-brands": "fab",
        "fa-duotone": "fad",
        "fa-light": "fal",
        "fa-regular": "far",
        "fa-solid": "fas",
        "fa-thin": "fat"
      },
      duotone: {
        "fa-regular": "fadr",
        "fa-light": "fadl",
        "fa-thin": "fadt"
      },
      sharp: {
        "fa-solid": "fass",
        "fa-regular": "fasr",
        "fa-light": "fasl",
        "fa-thin": "fast"
      },
      "sharp-duotone": {
        "fa-solid": "fasds",
        "fa-regular": "fasdr",
        "fa-light": "fasdl",
        "fa-thin": "fasdt"
      },
      slab: {
        "fa-regular": "faslr"
      },
      "slab-press": {
        "fa-regular": "faslpr"
      },
      "slab-duo": {
        "fa-regular": "fasldr"
      },
      "slab-press-duo": {
        "fa-regular": "faslpdr"
      },
      pixel: {
        "fa-regular": "fapr"
      },
      mosaic: {
        "fa-solid": "fams"
      },
      vellum: {
        "fa-solid": "favs"
      },
      whiteboard: {
        "fa-semibold": "fawsb"
      },
      thumbprint: {
        "fa-light": "fatl"
      },
      notdog: {
        "fa-solid": "fans"
      },
      "notdog-duo": {
        "fa-solid": "fands"
      },
      etch: {
        "fa-solid": "faes"
      },
      graphite: {
        "fa-thin": "fagt"
      },
      jelly: {
        "fa-regular": "fajr"
      },
      "jelly-fill": {
        "fa-regular": "fajfr"
      },
      "jelly-duo": {
        "fa-regular": "fajdr"
      },
      chisel: {
        "fa-regular": "facr"
      },
      utility: {
        "fa-semibold": "fausb"
      },
      "utility-duo": {
        "fa-semibold": "faudsb"
      },
      "utility-fill": {
        "fa-semibold": "faufsb"
      }
    },
    al$1 = {
      classic: ["fas", "far", "fal", "fat", "fad"],
      duotone: ["fadr", "fadl", "fadt"],
      sharp: ["fass", "fasr", "fasl", "fast"],
      "sharp-duotone": ["fasds", "fasdr", "fasdl", "fasdt"],
      slab: ["faslr"],
      "slab-press": ["faslpr"],
      "slab-duo": ["fasldr"],
      "slab-press-duo": ["faslpdr"],
      pixel: ["fapr"],
      mosaic: ["fams"],
      vellum: ["favs"],
      whiteboard: ["fawsb"],
      thumbprint: ["fatl"],
      notdog: ["fans"],
      "notdog-duo": ["fands"],
      etch: ["faes"],
      graphite: ["fagt"],
      jelly: ["fajr"],
      "jelly-fill": ["fajfr"],
      "jelly-duo": ["fajdr"],
      chisel: ["facr"],
      utility: ["fausb"],
      "utility-duo": ["faudsb"],
      "utility-fill": ["faufsb"]
    },
    da = {
      classic: {
        fab: "fa-brands",
        fad: "fa-duotone",
        fal: "fa-light",
        far: "fa-regular",
        fas: "fa-solid",
        fat: "fa-thin"
      },
      duotone: {
        fadr: "fa-regular",
        fadl: "fa-light",
        fadt: "fa-thin"
      },
      sharp: {
        fass: "fa-solid",
        fasr: "fa-regular",
        fasl: "fa-light",
        fast: "fa-thin"
      },
      "sharp-duotone": {
        fasds: "fa-solid",
        fasdr: "fa-regular",
        fasdl: "fa-light",
        fasdt: "fa-thin"
      },
      slab: {
        faslr: "fa-regular"
      },
      "slab-press": {
        faslpr: "fa-regular"
      },
      "slab-duo": {
        fasldr: "fa-regular"
      },
      "slab-press-duo": {
        faslpdr: "fa-regular"
      },
      pixel: {
        fapr: "fa-regular"
      },
      mosaic: {
        fams: "fa-solid"
      },
      vellum: {
        favs: "fa-solid"
      },
      whiteboard: {
        fawsb: "fa-semibold"
      },
      thumbprint: {
        fatl: "fa-light"
      },
      notdog: {
        fans: "fa-solid"
      },
      "notdog-duo": {
        fands: "fa-solid"
      },
      etch: {
        faes: "fa-solid"
      },
      graphite: {
        fagt: "fa-thin"
      },
      jelly: {
        fajr: "fa-regular"
      },
      "jelly-fill": {
        fajfr: "fa-regular"
      },
      "jelly-duo": {
        fajdr: "fa-regular"
      },
      chisel: {
        facr: "fa-regular"
      },
      utility: {
        fausb: "fa-semibold"
      },
      "utility-duo": {
        faudsb: "fa-semibold"
      },
      "utility-fill": {
        faufsb: "fa-semibold"
      }
    },
    el$1 = ["solid", "regular", "light", "thin", "duotone", "brands", "semibold"],
    sl$1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    ol$1 = sl$1.concat([11, 12, 13, 14, 15, 16, 17, 18, 19, 20]),
    rl$1 = ["aw", "fw", "pull-left", "pull-right"],
    ga = [].concat(_toConsumableArray(Object.keys(al$1)), el$1, rl$1, ["2xs", "xs", "sm", "lg", "xl", "2xl", "beat", "beat-fade", "border", "bounce", "buzz", "canvas-square", "canvas-roomy", "fade", "flip-360", "flip-both", "flip-horizontal", "flip-vertical", "flip", "float", "inverse", "jello", "layers", "layers-bottom-left", "layers-bottom-right", "layers-counter", "layers-text", "layers-top-left", "layers-top-right", "li", "pull-end", "pull-start", "pulse", "rotate-180", "rotate-270", "rotate-90", "rotate-by", "shake", "spin-pulse", "spin-reverse", "spin", "spin-snap", "spin-snap-4", "spin-snap-8", "stack-1x", "stack-2x", "stack", "swing", "ul", "wag", "width-auto", "width-fixed", l$1.GROUP, l$1.SWAP_OPACITY, l$1.PRIMARY, l$1.SECONDARY]).concat(sl$1.map(function (s) {
      return "".concat(s, "x");
    })).concat(ol$1.map(function (s) {
      return "w-".concat(s);
    }));

  var NAMESPACE_IDENTIFIER = '___FONT_AWESOME___';
  var PRODUCTION = function () {
    try {
      return "production" === 'production';
    } catch (e$$1) {
      return false;
    }
  }();
  function familyProxy(obj) {
    // Defaults to the classic family if family is not available
    return new Proxy(obj, {
      get: function get(target, prop) {
        return prop in target ? target[prop] : target[u];
      }
    });
  }
  var _PREFIX_TO_STYLE = _objectSpread2({}, rl);

  // We changed FACSSClassesToStyleId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _PREFIX_TO_STYLE below, so we are manually adding
  // {'fa-duotone': 'duotone'}
  _PREFIX_TO_STYLE[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    'fa-duotone': 'duotone'
  }), rl[u]), rt['kit']), rt['kit-duotone']);
  var PREFIX_TO_STYLE = familyProxy(_PREFIX_TO_STYLE);
  var _STYLE_TO_PREFIX = _objectSpread2({}, $l);

  // We changed FAStyleIdToShortPrefixId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _STYLE_TO_PREFIX below, so we are manually adding {duotone: 'fad'}
  _STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    duotone: 'fad'
  }), _STYLE_TO_PREFIX[u]), St['kit']), St['kit-duotone']);
  var STYLE_TO_PREFIX = familyProxy(_STYLE_TO_PREFIX);
  var _PREFIX_TO_LONG_STYLE = _objectSpread2({}, da);
  _PREFIX_TO_LONG_STYLE[u] = _objectSpread2(_objectSpread2({}, _PREFIX_TO_LONG_STYLE[u]), It['kit']);
  var PREFIX_TO_LONG_STYLE = familyProxy(_PREFIX_TO_LONG_STYLE);
  var _LONG_STYLE_TO_PREFIX = _objectSpread2({}, ra);
  _LONG_STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2({}, _LONG_STYLE_TO_PREFIX[u]), mt['kit']);
  var LONG_STYLE_TO_PREFIX = familyProxy(_LONG_STYLE_TO_PREFIX);
  var _FONT_WEIGHT_TO_PREFIX = _objectSpread2({}, Al);
  var FONT_WEIGHT_TO_PREFIX = familyProxy(_FONT_WEIGHT_TO_PREFIX);
  var RESERVED_CLASSES = [].concat(_toConsumableArray(it), _toConsumableArray(ga));

  function bunker(fn) {
    try {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      fn.apply(void 0, args);
    } catch (e) {
      if (!PRODUCTION) {
        throw e;
      }
    }
  }

  var w$2 = WINDOW || {};
  if (!w$2[NAMESPACE_IDENTIFIER]) w$2[NAMESPACE_IDENTIFIER] = {};
  if (!w$2[NAMESPACE_IDENTIFIER].styles) w$2[NAMESPACE_IDENTIFIER].styles = {};
  if (!w$2[NAMESPACE_IDENTIFIER].hooks) w$2[NAMESPACE_IDENTIFIER].hooks = {};
  if (!w$2[NAMESPACE_IDENTIFIER].shims) w$2[NAMESPACE_IDENTIFIER].shims = [];
  var namespace = w$2[NAMESPACE_IDENTIFIER];

  function normalizeIcons(icons) {
    return Object.keys(icons).reduce(function (acc, iconName) {
      var icon = icons[iconName];
      var expanded = !!icon.icon;
      if (expanded) {
        acc[icon.iconName] = icon.icon;
      } else {
        acc[iconName] = icon;
      }
      return acc;
    }, {});
  }
  function defineIcons(prefix, icons) {
    var params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var _params$skipHooks = params.skipHooks,
      skipHooks = _params$skipHooks === void 0 ? false : _params$skipHooks;
    var normalized = normalizeIcons(icons);
    if (typeof namespace.hooks.addPack === 'function' && !skipHooks) {
      namespace.hooks.addPack(prefix, normalizeIcons(icons));
    } else {
      namespace.styles[prefix] = _objectSpread2(_objectSpread2({}, namespace.styles[prefix] || {}), normalized);
    }

    /**
     * Font Awesome 4 used the prefix of `fa` for all icons. With the introduction
     * of new styles we needed to differentiate between them. Prefix `fa` is now an alias
     * for `fas` so we'll ease the upgrade process for our users by automatically defining
     * this as well.
     */
    if (prefix === 'fas') {
      defineIcons('fa', icons);
    }
  }

  var icons = {
    "question": [384, 576, [10067, 10068, 61736], "3f", "M48.6 64.7C81.9 37.1 130.3 24 192 24S302.1 37.1 335.4 64.7c34.1 28.3 48.6 68.6 48.6 114.2 0 47-18 86.9-52.9 114.5-27.9 22-64.8 35-108.3 39 11.2 42.9 18.8 72.1 22.9 87.6l-107.1 0c2.8-10.7 12.9-49.4 30.3-116.2l4.4-16.7 17.2-1.2c34.3-2.4 57.9-13.7 73.1-30.4 15.2-16.7 24.6-41.7 24.6-76.6 0-39.9-7.7-65.7-21.2-81.5-12.8-15-34.8-25.5-74.8-25.5-39.5 0-61.7 11.1-74.7 26.6-13.7 16.4-21.3 42.4-21.3 80.3l-96 0C0 133.3 14.5 93 48.6 64.7zM192 552c-33.6 0-48-21.5-48-48s14.4-48 48-48 48 21.5 48 48-14.4 48-48 48z"],
    "minus": [384, 576, [8211, 8722, 10134, "subtract"], "f068", "M.1 337.7l0-99.3 25.6 1.7 360 24 0 47.9-360 24-25.6 1.7z"],
    "microphone-slash": [576, 576, [], "f131", "M360.4 168c0-22.4-6.1-40.1-16.7-51.8-10.2-11.3-27.1-20.2-55.3-20.2s-45.2 8.8-55.3 20.2c-5.5 6.1-9.8 13.8-12.6 23L346.2 264.9c9-11.7 14.2-28.3 14.2-48.9l0-48zm38.2 149.3L442 360.6c9.7-18.7 14.5-40.6 14.5-64.6l0-56 72 0 0 56c0 41.2-12.5 80.1-39.5 111.6L568.4 487 534.4 521 54.4 41 88.4 7 171.3 90c4-19.8 12.3-38.5 26.1-53.9 21-23.4 52.1-36.1 91.1-36.1s70 12.7 91.1 36.1c20.6 23 28.9 53.3 28.9 83.9l0 144c0 18.4-3 36.6-9.8 53.3zM168.4 264l0-43 158.3 158.3c-11.7 3.1-24.5 4.7-38.3 4.7-39 0-70-12.7-91.1-36.1-20.6-23-28.9-53.3-28.9-83.9zm120 168c31.7 0 58-4.2 79.5-11.5l40.7 40.7c-27.5 10.1-59.6 16.3-96.2 18.2l0 48.6 96 0 0 48-240 0 0-48 96 0 0-48.6c-67.3-3.4-119.4-21.6-156-51.7-41.3-34.1-60-81.2-60-131.7l0-56 72 0 0 56c0 38.9 12.5 72 37.9 95.5 25.5 23.7 67 40.5 130.1 40.5z"],
    "car": [576, 576, [128664, "automobile"], "f1b9", "M198.3 24c-42.9 0-80.5 28.4-92.3 69.6L77.9 192 0 192 0 240 31.6 240c-7 12.1-11.5 26-12.6 40.8l-13 173.4-1.9 25.8 91.9 0 0 36c0 19.9 16.1 36 36 36l24 0c19.9 0 36-16.1 36-36l0-36 192 0 0 36c0 19.9 16.1 36 36 36l24 0c19.9 0 36-16.1 36-36l0-36 91.9 0-1.9-25.8-13-173.4c-1.1-14.8-5.6-28.7-12.6-40.8l31.6 0 0-48-77.9 0-28.1-98.4C458.2 52.4 420.6 24 377.7 24L198.3 24zM192 432l-96 0 0-144c0-26.5 21.5-48 48-48l288 0c26.5 0 48 21.5 48 48l0 144-288 0zM408 192l-240 0 0-72c0-26.5 21.5-48 48-48l144 0c26.5 0 48 21.5 48 48l0 72zM240 336c0-26.5-14.4-48-48-48s-48 21.5-48 48 14.4 48 48 48 48-21.5 48-48zm144 48c33.6 0 48-21.5 48-48s-14.4-48-48-48-48 21.5-48 48 14.4 48 48 48z"],
    "filter": [576, 576, [], "f0b0", "M434.8 59c17.8 4.5 29.4 10.2 36.2 16.3 5.9 5.3 9 11.4 9 20.7s-3.1 15.4-9 20.7c-6.8 6.1-18.4 11.8-36.2 16.3-35.8 9.1-86.8 11-146.8 11s-111.1-1.9-146.8-11c-17.8-4.5-29.4-10.2-36.2-16.3-5.9-5.3-9-11.4-9-20.7s3.1-15.4 9-20.7c6.8-6.1 18.4-11.8 36.2-16.3 35.8-9.1 86.8-11 146.8-11s111.1 1.9 146.8 11zM576 96C576 71 564 51.6 545.4 38.1 528 25.3 504.7 17.4 479.5 12.2 429 1.7 360.6 0 288 0S147 1.7 96.5 12.2C71.3 17.4 48 25.3 30.6 38.1 12 51.6 0 71 0 96l0 98.9C0 249.4 26.5 300.6 71 332l107.8 76.2 0 166.1 28-4.7 170.4-28.5 20-3.4 0-129.6 107.8-76.2c44.5-31.5 71-82.6 71-137.2L576 96zm-96 83.7l0 23.5c0 36.1-16.2 70.2-44.2 93l-104.2 85-8.8 7.2 0 113.2-69.5 11.6 0-124.9-8.8-7.2-104.2-85c-27.9-22.8-44.2-56.9-44.2-93l0-23.5 .5 .1C146.9 190.3 215.2 192 287.7 192l.3 0c72.6 0 141-1.7 191.5-12.2l.5-.1z"],
    "envelope": [576, 576, [128386, 9993, 61443], "f0e0", "M0 48l576 0 0 384c0 53-43 96-96 96L96 528c-53 0-96-43-96-96L0 48zM479.8 96L96.2 96 288 278.8 479.8 96zM96 162.1L96 432c0 26.5 21.5 48 48 48l288 0c26.5 0 48-21.5 48-48l0-269.9-175.4 167.3-16.6 15.8-16.6-15.8-175.4-167.3z"],
    "at": [576, 576, [61946], "40", "M288 0C190.2 0 117.2 31.5 68.8 85.3 20.9 138.7 0 211 0 288S20.9 437.3 68.8 490.7c48.3 53.8 121.4 85.3 219.2 85.3 73 0 132.5-17.5 178.2-49.2l22.9-15.9c-29.7-31.6-39.2-41.7-50.8-54.1l-17.5 18.8C390.9 507.8 348 528 288 528 219.5 528 172.9 501.7 142.6 460.5 111.6 418.2 96 357.8 96 288s15.6-130.2 46.6-172.5C172.9 74.3 219.5 48 288 48s115.1 26.3 145.4 67.5C464.4 157.8 480 218.2 480 288l0 42c0 16.6-13.4 30-30 30s-30-13.4-30-30l0-162-70.1 0c-17.8-7.9-38.5-12-61.9-12-43.2 0-77.2 14-100.2 39.6-22.6 25.1-31.8 58.5-31.8 92.4s9.2 67.3 31.8 92.4c23 25.6 57 39.6 100.2 39.6 39.3 0 71.1-11.6 93.8-33 20.6 20.4 48.9 33 80.2 33 63 0 114-51 114-114l0-30-.2 0C573.7 203.5 552.6 135.9 507.2 85.3 458.8 31.5 385.8 0 288 0zM234 290c0-26 5.4-46.7 14.4-60.1 8.2-12.2 20.3-19.9 39.6-19.9s31.3 7.6 39.6 19.9c9.1 13.4 14.4 34.1 14.4 60.1 0 22.6-4.1 41.4-11.3 54.9-8.5 15.8-21.4 25.1-42.7 25.1-19.3 0-31.3-7.6-39.6-19.9-9.1-13.4-14.4-34.1-14.4-60.1z"],
    "truck": [576, 576, [128666, 9951], "f0d1", "M96 24C43 24 0 67 0 120l0 360 72 0 0 36c0 19.9 16.1 36 36 36l24 0c19.9 0 36-16.1 36-36l0-36 240 0 0 36c0 19.9 16.1 36 36 36l24 0c19.9 0 36-16.1 36-36l0-36 72 0 0-240c0-53-43-96-96-96l-96 0 0-120-288 0zM480 432l-96 0 0-96 96 0 0 96zm0-192l0 48-96 0 0-96 48 0c26.5 0 48 21.5 48 48zM144 432l-48 0 0-312c0-26.5 21.5-48 48-48l144 0 0 360-144 0z"],
    "bell": [576, 576, [128276, 61602], "f0f3", "M240.4 40.2C243.1 17.4 257.8 0 288 0s44.9 17.4 47.6 40.2c41.3 7.8 74.3 26.1 98.4 52.9 32.3 36 46 84.4 46 134.8l0 37.3c66.5 33.8 96 97.3 96 166.7l0 48-192 0c0 24-6.5 48.3-23.2 66.9-17.1 19.1-42.2 29.1-72.8 29.1s-55.6-10-72.8-29.1C198.5 528.3 192 504 192 480L0 480 0 432c0-69.4 29.5-132.8 96-166.7L96 228c0-50.5 13.7-98.8 46-134.8 24.1-26.8 57.1-45.2 98.4-52.9zm-27 81.4C198.6 146.4 192 183 192 228l0 68.8-14.9 6.1C121.4 325.7 96 373.2 96 432l384 0c0-58.8-25.4-106.3-81.1-129.1l-14.9-6.1 0-68.8c0-45-6.6-81.6-21.5-106.4-13.6-22.7-35.5-37.6-74.5-37.6s-60.9 14.9-74.5 37.6zm58.5 397c3.9 6.6 8.5 9.4 16 9.4s12.1-2.8 16-9.4c4.7-7.9 8-21 8-38.6l-48 0c0 17.6 3.3 30.7 8 38.6z"],
    "mobile": [432, 576, [128241, "mobile-android", "mobile-phone"], "f3ce", "M24 0L0 0 0 480c0 53 43 96 96 96l240 0c53 0 96-43 96-96L432 0 24 0zM336 48l0 432c0 26.5-21.5 48-48 48l-144 0c-26.5 0-48-21.5-48-48l0-432 240 0zM264 432c0-26.5-14.4-48-48-48s-48 21.5-48 48 14.4 48 48 48 48-21.5 48-48zM156 144l120 0 0-48-120 0 0 48z"],
    "trophy": [576, 576, [127942], "f091", "M96 0L480 0c53 0 96 43 96 96l0 12 0 0c-1.3 57.7-34.4 110-86.1 135.9l-24.5 12.2c-6.9 24.9-16.4 48-28.8 68.2-27.5 44.9-68.9 75.4-124.6 82.2l0 25.4 12.2 0c38.4 0 68.7 8.9 90.8 27.3 22.2 18.5 32.8 43.7 37.4 69.7 1.9 11 4.7 26.7 8.3 47l-345.2 0c3.6-20.3 6.4-36 8.3-47 4.6-26 15.2-51.2 37.4-69.7 22.1-18.4 52.4-27.3 90.8-27.3l12.2 0 0-25.4c-55.6-6.8-97.1-37.4-124.6-82.2-12.4-20.3-21.9-43.3-28.8-68.2L86.2 243.9C34.4 218 1.3 165.7 0 108l0 0 0-12C0 43 43 0 96 0zM384 72l0-24-192 0 0 90.9c0 66.1 8.9 123.7 26.5 163.7 17.4 39.7 40.8 57.5 69.5 57.5s52.1-17.8 69.5-57.5c17.6-40 26.5-97.5 26.5-163.7L384 72zm144 32.5c0-18-14.6-32.5-32.5-32.5l-15.5 0 0 65.6c0 20-1 39.6-3.2 58.7 31.6-19.5 51.2-54.2 51.2-91.8zM80.5 72c-18 0-32.5 14.6-32.5 32.5 0 37.6 19.6 72.3 51.2 91.8-2.2-19.1-3.2-38.7-3.2-58.7L96 72 80.5 72zM257.9 480c-24.4 0-37.8 6.6-45.9 14.7-7.3 7.3-12.7 18.1-15.9 33.3l183.9 0c-3.2-15.2-8.6-26-15.9-33.3-8.1-8.1-21.5-14.7-45.9-14.7l-60.3 0z"],
    "gift": [576, 576, [127873], "f06b", "M156 109.7c0-13 3.5-22 8.5-27.6 4.6-5.1 13-10.1 29.2-10.1 11.6 0 18.8 3.6 24.1 8.7 6.1 5.7 11.3 14.8 15.8 27.8 4.4 12.9 7.5 27.7 10.3 43.5 .6 3.2 1.1 6.4 1.7 9.7-3.3-.6-6.6-1.1-9.7-1.7-15.8-2.8-30.6-5.9-43.5-10.3-13-4.5-22.1-9.7-27.8-15.8-5.1-5.4-8.7-12.5-8.7-24.1zM193.7 24c-27 0-49.5 8.8-64.9 26-15.1 16.8-20.8 38.5-20.8 59.7 0 23.4 8 42.5 21.8 57.1 .4 .4 .7 .8 1.1 1.2L0 168 0 456c0 53 43 96 96 96l384 0c53 0 96-43 96-96l0-288-130.9 0c.4-.4 .7-.8 1.1-1.2 13.8-14.6 21.8-33.7 21.8-57.1 0-21.1-5.7-42.9-20.8-59.7-15.5-17.2-37.9-26-64.9-26-23.5 0-42.5 8-57.1 21.8-13.9 13.2-22.4 30.4-28.2 47-3.8 11-6.7 22.7-9 33.9-2.3-11.3-5.2-22.9-9-33.9-5.7-16.6-14.2-33.8-28.2-47-14.6-13.8-33.7-21.8-57.1-21.8zM420 109.7c0 11.6-3.6 18.8-8.7 24.1-5.7 6-14.8 11.3-27.8 15.8-12.9 4.4-27.7 7.5-43.5 10.3-3.2 .6-6.4 1.1-9.7 1.7 .6-3.3 1.1-6.5 1.7-9.7 2.8-15.8 5.9-30.6 10.3-43.5 4.5-13 9.7-22.1 15.8-27.8 5.4-5.1 12.5-8.7 24.1-8.7 16.2 0 24.6 5 29.2 10.1 5 5.6 8.5 14.6 8.5 27.6zM96 216l138.2 0c-.2 .4-.4 .8-.6 1.3-15.6 31.1-41.8 58.7-89.5 58.7l0 72c74.3 0 113.5-53 133.1-98.5 4.4-10.4 8-20.7 10.9-30.4 2.9 9.7 6.5 20.1 10.9 30.4 19.5 45.6 58.8 98.5 133.1 98.5l0-72c-47.8 0-74-27.6-89.5-58.7-.2-.4-.4-.8-.6-1.3l138.2 0 0 240c0 26.5-21.5 48-48 48l-288 0c-26.5 0-48-21.5-48-48l0-240z"],
    "gauge": [576, 576, ["dashboard", "gauge-med", "tachometer-alt-average"], "f624", "M288 120c68.5 0 115.1 26.3 145.4 67.5 31.1 42.3 46.6 102.6 46.6 172.5l0 96-384 0 0-96c0-69.8 15.6-130.2 46.6-172.5 30.3-41.2 76.9-67.5 145.4-67.5zM0 504l576 0 0-144c0-77-20.9-149.3-68.8-202.7-48.3-53.8-121.4-85.3-219.2-85.3S117.2 103.5 68.8 157.3C20.9 210.7 0 283 0 360L0 504zM336 360c0-8.1-1.3-15.8-4.2-22.5L404 229.3 364 202.7 291.1 312.1c-1 0-2.1-.1-3.1-.1-33.6 0-48 21.5-48 48s14.4 48 48 48 48-21.5 48-48z"],
    "signal": [528, 576, [128246, "signal-5", "signal-perfect"], "f012", "M504.2 528l25.3 0-1.3-25.3-24-456-47.9 0-24 456-1.3 25.3 73.3 0zm-144 0l25.7 0-1.7-25.6-24-360-47.9 0-24 360-1.7 25.6 73.7 0zM99.8 528l-3.9-27.4-24-168-47.5 0-24 168-3.9 27.4 103.3 0zm116.3 0l26.3 0-2.4-26.2-24-264-47.8 0-24 264-2.4 26.2 74.3 0z"],
    "share-nodes": [528, 576, ["share-alt"], "f1e0", "M443.6 82.9c6.4 8 12.4 23 12.4 49.1s-6 41.1-12.4 49.1C437.8 188.5 430 192 420 192s-17.8-3.5-23.6-10.9c-6.4-8-12.4-23-12.4-49.1s6-41.1 12.4-49.1C402.2 75.5 410 72 419.9 72l.1 0c10 0 17.7 3.5 23.6 10.9zM331.5 199.3c3.8 5.3 8.2 10.2 13.1 14.6 20.8 18.7 48.2 26.1 75.4 26.1s54.6-7.4 75.4-26.1C516.7 194.8 528 166.8 528 132s-11.3-62.8-32.6-81.9C474.6 31.4 447.3 24 420 24s-54.6 7.4-75.4 26.1c-21.2 19.1-32.6 47.1-32.6 81.9 0 7.9 .6 15.4 1.7 22.6L196.5 208.7c-3.8-5.3-8.2-10.2-13.1-14.6-20.8-18.6-48.1-26.1-75.3-26.1l-.1 0C80.7 168 53.4 175.4 32.6 194.1 11.3 213.2 0 241.2 0 276s11.3 62.8 32.6 81.9C53.4 376.6 80.7 384 108 384s54.6-7.4 75.4-26.1c3.2-2.9 6.2-6 8.9-9.2l122.6 66c-2 9.1-3 18.9-3 29.3 0 34.8 11.3 62.8 32.6 81.9 20.8 18.7 48.2 26.1 75.4 26.1s54.6-7.4 75.4-26.1C516.7 506.8 528 478.8 528 444s-11.3-62.8-32.6-81.9c-20.8-18.6-48.1-26.1-75.3-26.1l-.3 0c-27.2 0-54.5 7.4-75.3 26.1-3.2 2.9-6.2 6-8.9 9.2L213 305.3c2-9.1 3-18.9 3-29.3 0-7.9-.6-15.4-1.7-22.6l117.2-54.1zM84.4 325.1C78 317.1 72 302.1 72 276s6-41.1 12.4-49.1C90.2 219.5 98 216 107.9 216l.1 0c10 0 17.8 3.5 23.6 10.9 6.4 8 12.4 23 12.4 49.1s-6 41.1-12.4 49.1C125.8 332.5 118 336 108 336s-17.8-3.5-23.6-10.9zm359.3 69.8c6.4 8 12.4 23 12.4 49.1s-6 41.1-12.4 49.1C437.8 500.5 430 504 420 504s-17.8-3.5-23.6-10.9c-6.4-8-12.4-23-12.4-49.1s6-41.1 12.4-49.1c5.8-7.4 13.6-10.9 23.6-10.9l.1 0c10 0 17.7 3.5 23.6 10.9z"],
    "percent": [480, 576, [62101, 62785, "percentage"], "25", "M144 144c0 19.8-6.1 30.8-13.1 37-7.4 6.7-19.1 11-34.9 11s-27.4-4.3-34.9-11c-7-6.3-13.1-17.2-13.1-37s6.1-30.8 13.1-37c7.4-6.7 19.1-11 34.9-11s27.4 4.3 34.9 11c7 6.3 13.1 17.2 13.1 37zm48 0C192 106.9 183.1 76.7 165.3 55.4 147.2 33.6 122 24 96 24S44.8 33.6 26.7 55.4C8.9 76.7 0 106.9 0 144s8.9 67.3 26.7 88.6C44.8 254.4 70 264 96 264s51.2-9.6 69.3-31.4C183.1 211.3 192 181.1 192 144zM451.4 62.2l-37.5-29.8-378 438-16 18.5c9.6 8 27.9 23.2 54.8 45.6l19.6 16.4 15.1-20.7 342-468zM418.9 395c7 6.3 13.1 17.2 13.1 37s-6.1 30.8-13.1 37c-7.4 6.7-19.1 11-34.9 11s-27.4-4.3-34.9-11c-7-6.3-13.1-17.2-13.1-37s6.1-30.8 13.1-37c7.4-6.7 19.1-11 34.9-11s27.4 4.3 34.9 11zM288 432c0 37.1 8.9 67.3 26.7 88.6 18.2 21.8 43.3 31.4 69.3 31.4s51.2-9.6 69.3-31.4C471.1 499.3 480 469.1 480 432s-8.9-67.3-26.7-88.6C435.2 321.6 410 312 384 312s-51.2 9.6-69.3 31.4C296.9 364.7 288 394.9 288 432z"],
    "magnifying-glass": [576, 576, [128269, "search"], "f002", "M109.7 109.2c30-30 62.5-37.8 95.8-31.3 34.8 6.8 72.2 29.7 107.8 65.2s58.5 73.1 65.2 107.8c6.5 33.3-1.3 65.8-31.2 95.8l-.1 .1c-30 30-62.5 37.8-95.8 31.3-34.8-6.8-72.2-29.7-107.8-65.2S85.2 239.8 78.4 205c-6.5-33.3 1.3-65.9 31.3-95.8zM419.5 333.8c24.1-37.4 34.5-76.2 32.5-114.6-2.9-54.1-30.4-103.5-70.7-143.9S291.4 7.4 237.3 4.5C182.5 1.6 127.1 23.9 75.7 75.3S2 182.1 5 236.8C7.9 291 35.4 340.4 75.7 380.7s89.8 67.8 143.9 70.7c38.4 2.1 77.2-8.3 114.6-32.5l127.7 154.3 35.5 1.7 78-78-1.7-35.5-154.3-127.7zm-29.6 37.8l106.7 88.3-36.2 36.2-88.3-106.7c6-5.6 12.2-11.8 17.8-17.8zM115.3 148.7l33.9 33.9 17-17c8.8-8.8 17.3-10.6 26.2-8.8 10.4 2 23.2 9.3 36.5 22.6l17 17 33.9-33.9-17-17c-17.2-17.2-38.2-31.3-61.3-35.8-24.5-4.8-49.2 1.8-69.4 22l-17 17z"],
    "palette": [576, 576, [127912], "f53f", "M288 72c-69.4 0-116.1 24.3-146 61.4-30.6 37.8-46 91.9-46 154.6s15.4 116.8 46 154.6c29.9 37.1 76.7 61.4 146 61.4 26.1 0 41.3-12.2 52-29 11.5-18.2 16.9-40.6 20.6-57.4 6.2-28.3 17.2-50.1 35.5-64.2 18.2-14 39.7-17.3 60-17.3 30.2 0 45.9-3.4 55.1-11.1 8.1-6.8 16.9-22.2 16.9-63.6 0-50.5-17.7-97.1-54.9-131.2-37.4-34.2-97-58.2-185.1-58.2zM69.6 101.4c48.5-49.1 121.3-77.4 218.4-77.4 96.7 0 169.1 26.4 217.5 70.8 48.6 44.4 70.5 104.6 70.5 166.6 0 .9 0 1.8 0 2.7l0 0c0 44.9-6 86.2-24.4 117-19.7 33-51.9 51-95.6 51-19.3 0-28.1 .5-35.7 4.8-6.9 3.9-16.8 13.4-28.4 42.7l-.2-.1c-3.1 7.2-6.8 14.4-11.2 21.3-17.5 27.5-46.6 51.3-92.5 51.3-97.1 0-169.9-28.3-218.4-77.4-48.4-49-69.6-115.6-69.6-186.6S21.3 150.4 69.6 101.4zM480 240c0 26.5-14.4 48-48 48s-48-21.5-48-48 14.4-48 48-48 48 21.5 48 48zM312 216c-33.6 0-48-21.5-48-48s14.4-48 48-48 48 21.5 48 48-14.4 48-48 48zm-72 24c0 26.5-14.4 48-48 48s-48-21.5-48-48 14.4-48 48-48 48 21.5 48 48zM216 420c-33.6 0-48-21.5-48-48s14.4-48 48-48 48 21.5 48 48-14.4 48-48 48z"],
    "key": [336, 576, [128273], "f084", "M288 144c0 11.2-2.8 18.3-6.5 23.1-3.9 5.1-10.2 9.9-20.4 13.9-21.4 8.4-53.2 10.9-93.1 10.9s-71.7-2.6-93.1-10.9c-10.2-4-16.6-8.8-20.4-13.9-3.7-4.9-6.5-11.9-6.5-23l0-.1c0-11.2 2.8-18.3 6.5-23.1 3.9-5.1 10.2-9.9 20.4-13.9 21.4-8.4 53.2-10.9 93.1-10.9s71.7 2.6 93.1 10.9c10.2 4 16.6 8.8 20.4 13.9 3.7 4.9 6.5 11.9 6.5 23.1zm48 0C336 95 316.8 57.7 284.2 33.3 252.6 9.7 210.9 0 168 0S83.4 9.7 51.8 33.3C19.2 57.7 0 95 0 144s19.2 86.3 51.8 110.7c25.7 19.2 58 29.2 92.2 32.2L144 480c0 53 43 96 96 96l96 0 0-96-96 0c-26.5 0-48-21.5-48-48l144 0 0-96-144 0 0-49.1c34.2-3.1 66.6-13 92.2-32.2 32.6-24.4 51.8-61.8 51.8-110.7z"],
    "skull": [576, 576, [128128], "f54c", "M69.6 77.4C21.3 126.4 0 193 0 264 0 356.8 36.6 441.6 120 489l0 87 336 0 0-87C539.4 441.6 576 356.8 576 264 576 193 554.7 126.4 506.4 77.4 457.9 28.3 385.1 0 288 0S118.1 28.3 69.6 77.4zm404.6 69.5c36.7 29.7 53.8 70.5 53.8 117.1 0 62.9-31.2 117.2-104.8 146.2l-15.2 6 0 87.9-48 0 0-72-48 0 0 72-48 0 0-72-48 0 0 72-48 0 0-87.9-15.2-6C79.2 381.2 48 326.9 48 264 48 217.4 65.2 176.6 101.8 146.9 139 116.7 199 96 288 96s149 20.7 186.2 50.9zM192 216c-33.6 0-48 21.5-48 48s14.4 48 48 48 48-21.5 48-48-14.4-48-48-48zm144 48c0 26.5 14.4 48 48 48s48-21.5 48-48-14.4-48-48-48-48 21.5-48 48zm-48 60c-24 0-36 24-36 42 0 13.3 19.2 18 36 18s36-4.7 36-18c0-18-12-42-36-42z"],
    "tree": [576, 576, [127794], "f1bb", "M237.3 63.6c-10.4 9-17.3 22.2-20 39.4l-4.2 26.7-26-7.4c-5.1-1.5-11.4-2.4-19-2.4-19.8 0-30.8 6.1-37 13.1-6.7 7.4-11 19.1-11 34.9 0 7 .9 13.4 2.4 18.8l7.6 26.3-27 4.1c-20.6 3.1-33.5 11.9-41.7 23-8.5 11.6-13.3 27.8-13.3 47.8 0 22.4 6.1 40.1 16.7 51.8 10.2 11.3 27.1 20.2 55.3 20.2l77.2 0-71.2-80.1 35.9-31.9 102.1 114.8 0 117.1c0 53-43 96-96 96l-24 0 0-48 24 0c26.5 0 48-21.5 48-48l0-24-48 0c-53.8 0-96.7-17-126-48.5-29-31.2-42-73.6-42-119.5 0-27.3 6.6-54.3 22.7-76.2 12.1-16.5 28.8-28.9 49.6-36.2-.1-2.5-.2-5-.2-7.6 0-24 6.5-48.3 23.2-66.9 17.1-19.1 42.2-29.1 72.8-29.1 2.6 0 5.2 .1 7.7 .2 6-17 15.8-32.5 30-44.8 20.7-18 48.6-27.4 82.2-27.4s61.5 9.4 82.2 27.4c14.3 12.4 24 27.9 30 44.8 2.5-.1 5.1-.2 7.7-.2 30.6 0 55.6 10 72.8 29.1 16.7 18.6 23.2 43 23.2 66.9 0 2.5-.1 5.1-.2 7.6 20.8 7.3 37.4 19.7 49.6 36.2 16.1 21.9 22.7 48.9 22.7 76.2 0 45.8-13 88.3-42 119.5-29.3 31.5-72.2 48.5-126 48.5l-48 0 0 24c0 26.5 21.5 48 48 48l24 0 0 48-24 0c-53 0-96-43-96-96l0-117.1 102.1-114.8 35.9 31.9-71.2 80.1 77.2 0c28.2 0 45.2-8.8 55.3-20.2 10.6-11.8 16.7-29.4 16.7-51.8 0-20-4.8-36.2-13.3-47.8-8.2-11.1-21.1-19.9-41.7-23l-27-4.1 7.6-26.3c1.6-5.5 2.4-11.8 2.4-18.8 0-15.8-4.3-27.4-11-34.9-6.3-7-17.2-13.1-37-13.1-7.6 0-13.9 .9-19 2.4l-26 7.4-4.2-26.7c-2.7-17.2-9.6-30.4-20-39.4-10.3-8.9-26.2-15.6-50.7-15.6s-40.5 6.7-50.7 15.6zm-3 124.8l53.8 62.7 53.8-62.7 36.4 31.2-72 84-36.4 0-72-84 36.4-31.2z"],
    "circle-half": [576, 576, [], "e110", "M264 49.1C208.4 54.6 169.2 79.3 142.6 115.5 111.6 157.8 96 218.2 96 288s15.6 130.2 46.6 172.5c26.6 36.2 65.8 60.9 121.4 66.4l0-477.7zm48 477.7c55.6-5.5 94.8-30.2 121.4-66.4 31.1-42.3 46.6-102.6 46.6-172.5s-15.6-130.2-46.6-172.5C406.8 79.3 367.6 54.6 312 49.1l0 477.7zM68.8 85.3C117.2 31.5 190.2 0 288 0S458.8 31.5 507.2 85.3C555.1 138.7 576 211 576 288s-20.9 149.3-68.8 202.7C458.8 544.5 385.8 576 288 576S117.2 544.5 68.8 490.7C20.9 437.3 0 365 0 288S20.9 138.7 68.8 85.3z"],
    "flower": [576, 576, [127804, 10047], "f7ff", "M39.4 40c27.1-29.3 64.6-40 104.6-40 15.2 0 30.1 3 43.5 10.8 11.7 6.8 21.1 16.5 28.5 28.5 7.3-12 16.7-21.7 28.5-28.5 13.5-7.8 28.3-10.8 43.5-10.8s30.1 3 43.5 10.8c11.7 6.8 21.1 16.5 28.5 28.5 7.3-12 16.7-21.7 28.5-28.5 13.5-7.8 28.3-10.8 43.5-10.8 40.1 0 77.6 10.6 104.6 40 26.7 28.9 39.4 71.9 39.4 128 0 36.9-8.4 68.4-24.6 94.7-16.1 26.3-39.2 45.8-66.2 60.2-47.4 25.1-108.8 34.9-173.2 36.8l0 108.8c3-3.6 6.1-7.2 9.3-10.7 36.2-39.4 90.1-73.8 158.7-73.8l0 96c-54.7 0-91.4 16.3-117 36.7-22 17.6-37 39.3-47.9 59.3l-54.1 0c-10.9-20-25.9-41.6-47.9-59.3-25.6-20.5-62.3-36.7-117-36.7l0-96c68.5 0 122.5 34.3 158.7 73.8 3.2 3.5 6.3 7.1 9.3 10.7l0-108.8C199.5 357.8 138.2 348 90.8 322.9 63.7 308.6 40.7 289 24.6 262.7 8.4 236.4 0 204.9 0 168 0 111.9 12.7 68.9 39.4 40zM432 48c-8.8 0-14.9 1.7-19.5 4.4-4.5 2.6-9 7-13.3 15.1-9.1 17.3-15.2 48.3-15.2 100.6l-48 0c0-52.3-6.1-83.3-15.2-100.6-4.3-8.1-8.9-12.5-13.3-15.1-4.5-2.6-10.7-4.4-19.5-4.4s-14.9 1.7-19.5 4.4c-4.5 2.6-9 7-13.3 15.1-9.1 17.3-15.2 48.3-15.2 100.6l-48 0 0-.1c0-52.2-6.1-83.2-15.2-100.5-4.3-8.1-8.9-12.5-13.3-15.1-4.5-2.6-10.7-4.4-19.5-4.4s-14.9 1.7-19.5 4.4c-4.5 2.6-9 7-13.3 15.1-9.1 17.3-15.2 48.3-15.2 100.6 0 59.5 21 93.3 52.1 113.6 33.1 21.6 81.4 30.4 139.9 30.4s106.8-8.8 139.9-30.4c31.1-20.3 52.1-54.1 52.1-113.6 0-52.3-6.1-83.3-15.2-100.6-4.3-8.1-8.9-12.5-13.3-15.1-4.5-2.6-10.7-4.4-19.5-4.4z"],
    "camera": [576, 576, [62258, "camera-alt"], "f030", "M216 24L204.6 24 197.4 32.8 145.8 96 0 96 0 432c0 53 43 96 96 96l384 0c53 0 96-43 96-96l0-336-145.8 0-51.6-63.2-7.2-8.8-155.4 0zM432 480l-288 0c-26.5 0-48-21.5-48-48l0-288 72.6 0 7.2-8.8 51.6-63.2 121.2 0 51.6 63.2 7.2 8.8 72.6 0 0 288c0 26.5-21.5 48-48 48zM216 300c0-26.4 6.4-47.4 17.6-61.4 10.5-13.1 27.2-22.6 54.4-22.6s44 9.5 54.4 22.6c11.1 14 17.6 35 17.6 61.4s-6.4 47.4-17.6 61.4C332 374.5 315.2 384 288 384s-44-9.5-54.4-22.6c-11.1-14-17.6-35-17.6-61.4zm180.5 93.3c25-25.1 35.5-58.7 35.5-93.3s-10.5-68.3-35.5-93.3C371.4 181.5 334.6 168 288 168s-83.4 13.5-108.5 38.7c-25 25.1-35.5 58.7-35.5 93.3s10.5 68.3 35.5 93.3C204.6 418.5 241.4 432 288 432s83.4-13.5 108.5-38.7z"],
    "eye": [576, 576, [128065], "f06e", "M7.8 308.1c8.9-74.5 32.4-140 78.4-186.9 46.7-47.7 113.5-73.2 202.3-73.2S444 73.5 490.7 121.2c46 47 69.5 112.4 78.4 186.9l.8 3.9-1 4.9C556.4 376.7 528 430 480.7 468.2 433.4 506.5 369.3 528 288.4 528s-145-21.5-192.3-59.8C48.8 430 20.5 376.7 8 316.9l-1-4.9 .8-3.9zM126.3 430.9c37.1 30 89.9 49.1 162.1 49.1s125-19.1 162.1-49.1c35.9-29.1 59.1-70 70.2-118.9-11.1-48.9-34.3-89.8-70.2-118.9-2.9-2.3-5.9-4.6-9-6.8 10.3 23.9 14.9 50.5 14.9 77.7 0 43.9-11.9 86.2-40.3 117.9-28.8 32.1-71.9 50.1-127.7 50.1s-98.8-18-127.7-50.1c-28.4-31.7-40.3-74-40.3-117.9 0-27.2 4.6-53.9 14.9-77.7-3.1 2.2-6.1 4.5-9 6.8-35.9 29.1-59.1 70-70.2 118.9 11.1 48.9 34.3 89.8 70.2 118.9zM288.4 144c-35 0-57.7 13-72.3 32.6-15.4 20.5-23.7 50.8-23.7 87.4s8.3 66.9 23.7 87.4C230.8 371 253.4 384 288.4 384s57.7-13 72.3-32.6c15.4-20.5 23.7-50.8 23.7-87.4s-8.3-66.9-23.7-87.4C346.1 157 323.5 144 288.4 144zm0 168c-33.6 0-48-21.5-48-48s14.4-48 48-48 48 21.5 48 48-14.4 48-48 48z"],
    "trash": [528, 576, [], "f1f8", "M204 0c-33.1 0-60 26.9-60 60l0 36-144 0 0 48 48 0 0 336c0 53 43 96 96 96l240 0c53 0 96-43 96-96l0-336 48 0 0-48-144 0 0-36c0-33.1-26.9-60-60-60L204 0zM336 96l-144 0 0-36c0-6.6 5.4-12 12-12l120 0c6.6 0 12 5.4 12 12l0 36zm48 48l0 336c0 26.5-21.5 48-48 48l-144 0c-26.5 0-48-21.5-48-48l0-336 240 0z"],
    "equals": [384, 576, [62764], "3d", "M.1 216l0 25.7 25.6-1.7 360-24 0-47.9-360-24-25.6-1.7 0 73.7zm0 192l0 25.7 25.6-1.7 360-24 0-47.9-360-24-25.6-1.7 0 73.7z"],
    "expand": [576, 576, [], "f065", "M348 5l25 1 144 6 9.4 .4c3.5 3.5 9.7 9.7 18.6 18.6l0 0c8.9 8.9 15.1 15.1 18.6 18.6l.4 9.4 6 144 1 25c-36.6 0-71 0-80.9 0 .6-7.2 3.4-44.5 8.6-111.8l-132.6 151.6-16.9 19.3c-26.2-26.2-55.1-55.1-60.3-60.3l19.3-16.9 151.6-132.6c-67.3 5.2-104.5 8-111.8 8.6 0-38.3 0-71.4 0-80.9zM116.3 498.7c67.3-5.2 104.5-8 111.8-8.6 0 38.3 0 71.4 0 80.9l-25-1-144-6-9.4-.4-18.6-18.6 0 0c-8.9-8.9-15.1-15.1-18.6-18.6l-.4-9.4-6-144-1-25 80.9 0c-.6 7.2-3.4 44.5-8.6 111.8L210 308.2 226.9 288.9c26.2 26.2 55.1 55.1 60.3 60.3l-19.3 16.9-151.6 132.6z"],
    "stop": [432, 576, [9209], "f04d", "M24 72l-24 0 0 432 432 0 0-432-408 0zm360 48l0 288-288 0 0-288 288 0z"],
    "tv-retro": [576, 576, [128250], "f401", "M288 80L235.2 9.6 196.8 38.4 240 96 0 96 0 456c0 53 43 96 96 96l384 0c53 0 96-43 96-96L576 96 336 96 379.2 38.4 340.8 9.6 288 80zM432 504l-288 0c-26.5 0-48-21.5-48-48l0-312 384 0 0 312c0 26.5-21.5 48-48 48zM144 192l0 264 240 0 0-264-240 0zm48 48l144 0 0 168-144 0 0-168zm264-24c0-13.3-7.2-24-24-24s-24 10.7-24 24 7.2 24 24 24 24-10.7 24-24zm-24 96c16.8 0 24-10.7 24-24s-7.2-24-24-24-24 10.7-24 24 7.2 24 24 24z"],
    "angle-left": [288, 576, [8249], "f104", "M210.1 90l17-17-18.2-18.2-16.9 19.4 18.1 15.8zm30 30l15.8 18.1 19.3-16.9-18.1-18.1-17 17zm-30 366l-18.1 15.8 16.9 19.4 18.2-18.2-17-17zm30-30l17 17 18.1-18.1-19.3-16.9-15.8 18.1zM48.1 300l-24 0 0 9 5.9 6.8 18.1-15.8zm0-24l-18.1-15.8-5.9 6.8 0 9 24 0zm15.8 30.1l192-168-31.6-36.1-192 168 31.6 36.1zM257.1 103l-30-30-33.9 33.9 30 30 33.9-33.9zM32.3 306.1l192 168 31.6-36.1-192-168-31.6 36.1zM223.1 439l-30 30 33.9 33.9 30-30-33.9-33.9zM24.1 288l0 12 48 0 0-12-48 0zM30 315.8l162 186 36.2-31.5-162-186-36.2 31.5zM72.1 288l0-12-48 0 0 12 48 0zm-5.9 3.8l162-186-36.2-31.5-162 186 36.2 31.5z"],
    "clock": [576, 576, [128339, "clock-four"], "f017", "M142.6 115.5C111.6 157.8 96 218.2 96 288s15.6 130.2 46.6 172.5C172.9 501.7 219.5 528 288 528s115.1-26.3 145.4-67.5C464.4 418.2 480 357.8 480 288s-15.6-130.2-46.6-172.5C403.1 74.3 356.5 48 288 48S172.9 74.3 142.6 115.5zM68.8 85.3C117.2 31.5 190.2 0 288 0S458.8 31.5 507.2 85.3C555.1 138.7 576 211 576 288s-20.9 149.3-68.8 202.7C458.8 544.5 385.8 576 288 576S117.2 544.5 68.8 490.7C20.9 437.3 0 365 0 288S20.9 138.7 68.8 85.3zM312 120l0 151.8 104.9 42-17.8 44.6-120-48-15.1-6 0-184.2 48 0z"],
    "book": [480, 576, [128212], "f02d", "M0 96C0 43 43 0 96 0l384 0 0 576-384 0c-53 0-96-43-96-96L0 96zM432 48L144 48c-26.5 0-48 21.5-48 48l0 296.1c10.9-5.2 23.1-8.1 36-8.1l300 0 0-336zm0 480l0-96-288 0c-26.5 0-48 21.5-48 48s21.5 48 48 48l288 0zM264 144c-19.8 0-30.8 6.1-37 13.1-6.7 7.4-11 19.1-11 34.9s4.3 27.4 11 34.9c6.3 7 17.2 13.1 37 13.1s30.8-6.1 37-13.1c6.7-7.4 11-19.1 11-34.9s-4.3-27.4-11-34.9c-6.3-7-17.2-13.1-37-13.1zm88.6 117.3C331.3 279.1 301.1 288 264 288s-67.3-8.9-88.6-26.7C153.6 243.2 144 218 144 192s9.6-51.2 31.4-69.3C196.7 104.9 226.9 96 264 96s67.3 8.9 88.6 26.7C374.4 140.8 384 166 384 192s-9.6 51.2-31.4 69.3z"],
    "paper-plane": [576, 576, [61913], "f1d8", "M576 267.2l0 41.6-378.4 229.3c-15 9.1-32.2 13.9-49.8 13.9L3.7 552 13 521.1 82.9 288 13 54.9 3.7 24 147.9 24c17.5 0 34.8 4.8 49.8 13.9L576 267.2zM116.3 504l31.6 0c8.8 0 17.4-2.4 24.9-7l305.3-185-304.2 0-57.6 192zM478.1 264L172.8 79c-7.5-4.5-16.1-7-24.9-7l-31.6 0 57.6 192 304.2 0z"],
    "heart": [576, 576, [128153, 128154, 128155, 128156, 128420, 129293, 129294, 129505, 9829, 10084, 61578], "f004", "M298.5 96.3c-3.9 5.4-7.4 10.7-10.5 15.9-3.1-5.2-6.6-10.5-10.5-15.9-23.1-32.1-61.8-68.6-120-72.2-54-3.4-95.1 13.2-122 45.6-25.9 31.3-35.5 73.6-35.5 116.4 0 70.8 30.6 130.1 79.2 187.3 46.8 55.1 112.3 110.5 187.2 173.9l6.1 5.2 31 0 6.1-5.2c74.9-63.3 140.4-118.7 187.2-173.9 48.6-57.2 79.2-116.5 79.2-187.3 0-42.8-9.6-85.1-35.5-116.4-26.8-32.4-67.9-48.9-122-45.6-58.2 3.6-96.9 40.1-120 72.2zm-140.4-.3c43.2-3.8 84.5 29.9 107.1 97.7l45.5 0c22.6-67.8 64-101.5 107.1-97.7 21.5 1.9 36.3 10 46.7 21.8 10.8 12.2 18.4 30.1 21.7 53.8 8 58.3-8.8 109.3-46.2 162.8-35.1 50.3-87.3 101.3-152.1 161.1-64.8-59.8-117-110.8-152.1-161.1-37.3-53.5-54.1-104.5-46.2-162.8 3.2-23.7 10.9-41.7 21.7-53.8 10.4-11.8 25.2-19.9 46.7-21.8z"],
    "font-awesome": [528, 576, [62501, 62694, "font-awesome-flag", "font-awesome-logo-full"], "f2b4", "M96 24l-96 0 0 528 96 0 0-95.1 408-.6 21.4-34.7-78.7-157.6 78.7-158.3-21.5-34.7-408 .6 0-47.6zm0 384.9l0-289.3 321.2-.4-66.7 134.2-5.3 10.7 5.3 10.7 66.7 133.7-321.3 .4z"],
    "clone": [576, 576, [], "f24d", "M0 24l384 0 0 144 192 0 0 384-384 0 0-144-192 0 0-384zM96 360l96 0 0-192 96 0 0-96-192 0 0 288zm360 24l-48 0 0 48-48 0 0-48-48 0 0-48 48 0 0-48 48 0 0 48 48 0 0 48zm24 120l0-288-192 0 0 288 192 0z"],
    "forward": [576, 576, [9193], "f04e", "M36.8 75.7L0 52.6 0 523.4c.7-.5 72.8-45.7 216-135.5l0 135.5 36.8-23.1 306-192 0-40.7-306-192-36.8-23.1 0 135.5-179.2-112.5zM216 244.8l0 86.4-120 75.3 0-237 120 75.3zm96 161.7L312 169.5 500.8 288 312 406.5z"],
    "triangle": [576, 576, [9650], "f2ec", "M225.2 24L0 480 17.3 552 558.7 552 576 492 350.8 24 225.2 24zM66.8 456L288 94 509.2 456 66.8 456z"],
    "strikethrough": [480, 576, [], "f0cc", "M240 72c-46.3 0-75.7 12.3-93.5 28.7-17.6 16.3-26.5 39.4-26.5 67.3 0 28 7.2 44.4 22.8 57.4 17.5 14.5 47.8 26.9 99.8 38.6l237.3 0 0 48-480 0 0-48 77 0C59.3 253 45.7 239.5 36.6 222.8 27.5 205.9 24 187.5 24 168 24 127 42.2 89.7 79.9 63.4 116.6 37.9 170.1 24 240 24S363.4 37.9 400.1 63.4C437.8 89.7 456 127 456 168l-96 0c0-27.8-8.9-50.9-26.5-67.3-17.7-16.5-47.2-28.7-93.5-28.7zM346.5 360l100.2 0c6.6 15 9.3 31.1 9.3 48 0 41-18.2 78.4-55.9 104.6-36.7 25.5-90.2 39.4-160.1 39.4S116.6 538.1 79.9 512.6C42.2 486.4 24 449 24 408l96 0c0 27.8 8.9 50.9 26.5 67.3 17.7 16.5 47.2 28.7 93.5 28.7s75.7-12.3 93.5-28.7c17.6-16.3 26.5-39.4 26.5-67.3 0-21.7-4.3-36.4-13.5-48z"],
    "arrow-down-to-bracket": [576, 576, [], "e094", "M315.1 366.7l14.9-317.6 1.2-25.1-86.3 0 1.2 25.1 14.9 317.6c-64.8-71-97.5-106.8-98.1-107.5-25.5 25.5-55 55-60.4 60.4l20.3 16.8 138 114 6.7 5.5 41.3 0 6.7-5.5 138-114 20.3-16.8c-27.3-27.3-55.4-55.4-60.4-60.4-.6 .6-33.3 36.5-98.1 107.5zM576 456l0-48-96 0 0 48c0 26.5-21.5 48-48 48l-288 0c-26.5 0-48-21.5-48-48l0-48-96 0 0 48c0 53 43 96 96 96l384 0c53 0 96-43 96-96z"],
    "star-half": [576, 576, [61731], "f089", "M264.5 154.5l0 241.3-111.2 81.8 44.1-140.5 4.9-15.7-12.8-10.3-98.9-79.2 130-3.7 16-.5c1.1-2.8 10.4-27.2 27.9-73.4zM267 13.3l-75 150.9-170.6 22-13.9 40.8 116.9 116.9-39.4 191.8 35.9 25.4 180-108.5 11.6-7 0-421.6-45.5-10.7z"],
    "arrow-down-to-line": [480, 576, ["arrow-to-bottom"], "f33d", "M282 49.1L267.1 366.7c64.8-71 97.5-106.8 98.1-107.5 25.5 25.5 55 55 60.4 60.4l-20.3 16.8-138 114-6.7 5.5-41.3 0-6.7-5.5-138-114-20.3-16.8c27.3-27.3 55.4-55.4 60.4-60.4 .6 .6 33.3 36.5 98.1 107.5L198 49.1 196.8 24 283.2 24 282 49.1zM480 552l-480 0 0-48 480 0 0 48z"],
    "fire": [480, 576, [128293], "f06d", "M211.4 3.9L192 18 172.8 3.7 211.4 3.9zM240 576c80.1 0 140.8-22.6 181.5-62.5 40.7-39.8 58.5-94.1 58.5-151.4 0-27.5-10-73-26.1-120.8-16.3-48.4-39.9-102.3-68.8-146.5l-37.9-2.9-43.7 48.5c-23.4-36.6-44.2-67.7-60.1-91-9.8-14.4-17.8-25.7-23.3-33.5-2.8-3.9-4.9-6.9-6.4-8.9l-2.1-2.9-.1-.2 0 0 0 0 0 0-19.4 14.1C172.8 3.7 172.8 3.7 172.7 3.7l0 0 0 0-.1 .1-.4 .5-1.5 2c-1.3 1.7-3.1 4.3-5.5 7.5-4.7 6.5-11.3 15.9-19.3 27.6-32 46.8-85 128.9-117.9 207.6-16.1 38.7-28.1 78.6-28.1 113.1 0 57.3 17.8 111.5 58.5 151.4 40.7 39.9 101.4 62.5 181.5 62.5zM378.3 417.4c-3.9-13.1-9.4-26-15.7-38.2-12.1-23.7-28.1-47-43.6-67.2-15.6-20.3-31-38-42.6-50.6-5.8-6.3-10.7-11.4-14.1-14.9-1.7-1.8-3.1-3.1-4-4.1l-1.1-1.1-.3-.3-.1-.1 0 0 0 0-16.8 17.1c-16.8-17.1-16.8-17.1-16.8-17.1l0 0 0 0-.1 .1-.3 .3-1.1 1.1c-.9 .9-2.3 2.3-4 4.1-3.4 3.5-8.3 8.6-14.1 14.9-11.6 12.6-27.1 30.3-42.6 50.6-15.5 20.2-31.4 43.5-43.6 67.2-6.2 12.2-11.8 25.1-15.7 38.2-3.8-17-5.7-35.5-5.7-55.3 0-26.2 6.7-59.5 17.7-96 21.7-72 58.8-151.2 81-195.3l2.2-4.3c2.2 3.1 4.4 6.4 6.8 9.9 19.4 28.3 46.2 68.5 76 116.2l38.2 3.4 34.9-38.7c22.1 77.8 31.3 174.5 31.3 204.8 0 19.8-1.9 38.3-5.7 55.3zM240 258l16.8-17.1-33.6 0 16.8 17.1zm0 270c-38 0-61.5-9.9-75.3-22.5-13.6-12.4-20.7-30.1-20.7-51.9 0-13.9 5.6-31.9 16.1-52.5 10.4-20.2 24.4-41 38.9-59.9 14.4-18.9 29-35.4 39.9-47.3l1.1-1.2 1.1 1.2c10.9 11.9 25.4 28.5 39.9 47.3 14.5 18.9 28.6 39.7 38.9 59.9 10.6 20.6 16.1 38.6 16.1 52.5 0 21.8-7.1 39.4-20.7 51.9-13.8 12.6-37.4 22.5-75.3 22.5z"],
    "rectangle-vertical": [480, 576, ["rectangle-portrait"], "f2fb", "M24 24l-24 0 0 528 480 0 0-528-456 0zM96 72l336 0 0 384-336 0 0-384z"],
    "print": [576, 576, [128424, 128438, 9113], "f02f", "M168 24l-24 0 0 144-144 0 0 264c0 39.8 32.2 72 72 72l72 0 0 48 288 0 0-48 72 0c39.8 0 72-32.2 72-72l0-264-144 0 0-144-264 0zM384 168l-192 0 0-96 192 0 0 96zM144 216l336 0 0 216c0 13.3-10.7 24-24 24l-24 0 0-144-288 0 0 144-24 0c-13.3 0-24-10.7-24-24l0-216 48 0zm48 288l0-144 192 0 0 144-192 0z"],
    "users": [576, 576, [], "f0c0", "M200.5 134.2c8.3 9.9 15.5 27.8 15.5 57.8s-7.2 47.9-15.5 57.8c-7.9 9.4-18.7 14.2-32.5 14.2s-24.6-4.8-32.5-14.2c-8.3-9.9-15.5-27.8-15.5-57.8s7.2-47.9 15.5-57.8c7.9-9.4 18.7-14.2 32.5-14.2s24.6 4.8 32.5 14.2zm52.9 147.5c22.5-21 34.6-51.5 34.6-89.7 0-39-12.7-70-36.1-91.1-23-20.6-53.3-28.9-83.9-28.9s-60.9 8.3-83.9 28.9C60.7 122 48 153 48 192 48 230.1 60.1 260.7 82.6 281.7 71.2 287.1 60.5 293.8 50.8 301.9 18.6 328.8 0 369 0 420.5l0 83.5 576 0 0-77.5c0-44.3-17.9-79.9-47.6-103.9-8.6-6.9-17.9-12.8-28-17.5 18-18.9 27.6-45.1 27.6-77 0-34.8-11.3-62.8-32.6-81.9-20.8-18.7-48.2-26.1-75.4-26.1s-54.6 7.4-75.4 26.1c-21.2 19.1-32.6 47.1-32.6 81.9 0 31.9 9.5 58.2 27.6 77-10 4.8-19.4 10.6-28 17.5-1.3 1.1-2.6 2.2-3.9 3.3-6.5-8.9-14-16.9-22.5-23.9-9.7-8.1-20.4-14.8-31.8-20.2zM504 456l-168 0 0-29.6c0-31.9 10.2-54 24.5-68.1 14.4-14.2 35-22.3 59.5-22.3s45.1 8.1 59.5 22.3c14.3 14.1 24.5 36.2 24.5 68.1l0 29.5zm-240 0l-192 0 0-53.5c0-31.1 11-53 27.1-67.3 16.5-14.7 40.4-23.2 68.9-23.2s52.4 8.6 68.9 23.2C253 349.5 264 371.4 264 402.5l0 53.5zM443.6 178.9c6.4 8 12.4 23 12.4 49.1s-6 41.1-12.4 49.1C437.8 284.5 430 288 420 288s-17.8-3.5-23.6-10.9c-6.4-8-12.4-23-12.4-49.1s6-41.1 12.4-49.1C402.2 171.5 410 168 420 168s17.8 3.5 23.6 10.9z"],
    "alarm-clock": [576, 576, [9200], "f34e", "M44.6 23C-9.1 63.4-6.2 115.1 25.7 157.4L179 41.9C147.1-.5 98.2-17.5 44.6 23zM399.9 41.9L553.2 157.4c31.9-42.3 34.8-94-18.9-134.4S431.8-.5 399.9 41.9zM288 120c51.2 0 85.7 20.5 108.4 53 23.5 33.7 35.6 82.2 35.6 139s-12.1 105.3-35.6 139c-22.7 32.5-57.3 53-108.4 53s-85.7-20.5-108.4-53C156.1 417.3 144 368.8 144 312s12.1-105.3 35.6-139c22.7-32.5 57.3-53 108.4-53zm0-48c-81 0-142 26.1-182.6 71.2-40.1 44.7-57.4 105-57.4 168.8 0 50 10.7 98 34.7 137.9l-53 62.6 36.6 31 46.5-55c40.4 40.3 99 63.5 175.2 63.5s134.8-23.1 175.2-63.5l46.5 55 36.6-31-53-62.6C517.3 410 528 362 528 312 528 248.3 510.7 187.9 470.6 143.2 430 98.1 369 72 288 72zm24 120l-48 0 0 137.3c1.7 .6 31.1 10.4 88.4 29.5l12 4 15.2-45.5c-.7-.2-23.3-7.8-67.6-22.5L312 192z"],
    "database": [528, 576, [], "f1c0", "M264 24c65.9 0 128.8 1.8 175.5 13.4 23.4 5.8 45.2 14.5 61.5 28.7 15.8 13.8 25.4 31.9 26.9 53.9l.2 0 0 330c0 24.7-9.9 44.9-27.1 59.9-16.3 14.2-38.1 23-61.5 28.7-46.7 11.5-109.5 13.4-175.5 13.4s-128.8-1.8-175.5-13.4C65.1 532.8 43.3 524.1 27.1 509.9 9.9 494.9 0 474.7 0 450l0-330 .2 0C1.7 98 11.3 79.9 27.1 66.1 43.3 51.9 65.1 43.2 88.5 37.4 135.2 25.8 198.1 24 264 24zm-.3 372l.6 0c53.3 0 97.9-2 128.9-10.8 15.3-4.4 25-9.8 30.7-15.5 5-5 8.1-11.4 8.1-21.7l0-22.8C386.4 334.4 326.9 336 264.3 336l-.6 0c-62.6 0-122.1-1.6-167.7-10.8L96 348c0 10.2 3.1 16.6 8.1 21.7 5.7 5.7 15.4 11.2 30.7 15.5 31 8.8 75.6 10.8 128.9 10.8zM96 433.2L96 450c0 12.2 3.5 19.8 8.8 25.6 5.8 6.3 15.4 12.1 30.5 16.8 30.8 9.5 75.3 11.6 128.7 11.6s97.9-2.1 128.7-11.6c15.1-4.7 24.7-10.5 30.5-16.8 5.3-5.7 8.8-13.4 8.8-25.6l0-16.8C386.6 442.4 327.3 444 265 444l-2 0c-62.3 0-121.6-1.6-167-10.8zM264 288l.3 0c53.3 0 97.9-2 128.9-10.8 15.3-4.4 25-9.8 30.7-15.5 5-5 8.1-11.4 8.1-21.7l0-23.6c-45.8 10-105.5 11.6-168 11.6s-122.2-1.7-168-11.6L96 240c0 10.2 3.1 16.6 8.1 21.7 5.7 5.7 15.4 11.2 30.7 15.5 31.1 8.8 75.8 10.8 129.2 10.8zM423.2 100.4c-5.8-6.3-15.4-12.1-30.5-16.8-30.8-9.5-75.3-11.6-128.7-11.6s-97.9 2.1-128.7 11.6c-15.1 4.7-24.7 10.5-30.5 16.8-5.3 5.7-8.8 13.4-8.8 25.6s3.5 19.8 8.8 25.6c5.8 6.3 15.4 12.1 30.5 16.8 30.8 9.5 75.3 11.6 128.7 11.6s97.9-2.1 128.7-11.6c15.1-4.7 24.7-10.5 30.5-16.8 5.3-5.7 8.8-13.4 8.8-25.6s-3.5-19.8-8.8-25.6z"],
    "newspaper": [528, 576, [128240], "f1ea", "M0 399.8l0-399.8 480 0 0 480-48 0 0 72-29.8 23.3-329.5-82.4C30 482.2 0 443.8 0 399.8zM60.4 432c.4 .4 .8 .8 1.1 1.2-.2-.4-.5-.8-.7-1.2l-.4 0zM384 521.3l0-41.3-165 0 165 41.3zM96 48l0 336c0 26.5 21.5 48 48 48l288 0 0-384-336 0zm96 144l48 0 0 192-96 0 0-192 48 0zm96 48l0-48 96 0 0 48-96 0zm96 96l-96 0 0-48 96 0 0 48zM144 144l0-48 240 0 0 48-240 0z"],
    "location-arrow": [576, 576, [], "f124", "M544.3 1.3l-539.9 186-2.5 44.4 232.3 110.3 110.3 232.3 44.4-2.5 186-539.9 0-.1-30.5-30.5-.1 0zM297.9 266.1l-160.7-71.4 375.8-131.5-131.5 375.8-71.4-160.7-3.7-8.4-8.4-3.7z"],
    "arrow-right-to-bracket": [528, 576, ["sign-in"], "f090", "M432 0l-48 0 0 96 48 0c26.5 0 48 21.5 48 48l0 288c0 26.5-21.5 48-48 48l-48 0 0 96 48 0c53 0 96-43 96-96l0-384c0-53-43-96-96-96zm0 276l0-8.6-5.5-6.7-114-138-16.8-20.3c-27.3 27.3-55.4 55.4-60.4 60.4 .6 .6 36.5 33.3 107.5 98.1L25.1 246 0 244.8 0 331.2 25.1 330 342.7 315.1c-71 64.8-106.8 97.5-107.5 98.1 25.5 25.5 55 55 60.4 60.4l16.8-20.3 114-138 5.5-6.7 0-32.6z"],
    "share": [576, 576, ["mail-forward"], "f064", "M302.9 51.1l-37.4-29.9 0 1.9-46.1 0 0 138.2-46.1 0C84.2 161.3 12 233.5 12 322.6l0 207.4 92.2 0 0-23c0-63.6 51.6-115.2 115.2-115.2l0 138.2 46.1 0 0 1.9 37.4-29.9 259.2-207.4 0-36-259.2-207.4zM104.2 394l0-71.4c0-63.6 51.6-115.2 115.2-115.2l92.2 0 0-90.3 199.3 159.4-199.3 159.4 0-90.3-92.2 0c-45.1 0-85.9 18.5-115.2 48.4z"],
    "video-slash": [576, 576, [], "f4e2", "M7 41l492 492 33.9-33.9-101-101 0-14.1c86.8 36.2 134.8 56.2 144 60l0-312c-9.2 3.8-57.2 23.9-144 60L432 72 105.9 72 41 7 7 41zm146.9 79L384 120 384 350.1 153.9 120zM504 362l-72-30 0-88 72-30 0 148zM96 189.9L18 112C6.7 127.7 0 147.1 0 168L0 408c0 53 43 96 96 96l314.1 0-48-48-218.1 0c-26.5 0-48-21.5-48-48l0-218.1z"],
    "comment": [576, 576, [128489, 61669], "f075", "M288 96c-70.2 0-117.2 22.3-146.8 55.3-30.1 33.5-45.2 81.1-45.2 136.7 0 32 5 61.6 15.1 87.2l3.2 8.2-2.8 8.3-27.9 82 75-12.5 6.1-1 5.8 2.1c31.7 11.2 70.5 17.7 117.4 17.7 70.2 0 117.2-22.3 146.8-55.3 30.1-33.5 45.2-81.1 45.2-136.7s-15.1-103.2-45.2-136.7C405.2 118.3 358.2 96 288 96zm0 432c-48.6 0-91-6.4-127.5-18.4-85 14.2-132.2 22-141.7 23.6 2.4-14.3 8.7-52 18.8-112.9-25.9-38.7-37.6-84.4-37.6-132.3 0-65.1 21.7-126 70.5-170.5 48.6-44.3 121-69.5 217.5-69.5s168.9 25.3 217.5 69.5C554.3 162 576 222.9 576 288s-21.7 126-70.5 170.5C456.9 502.7 384.4 528 288 528zM408 264l-240 0 0-48 240 0 0 48zM168 360l0-48 168 0 0 48-168 0z"],
    "video": [576, 576, ["video-camera"], "f03d", "M0 168c0-53 43-96 96-96l336 0 0 120c86.8-36.2 134.8-56.2 144-60l0 312c-9.2-3.8-57.2-23.9-144-60l0 120-336 0c-53 0-96-43-96-96L0 168zM384 364l0-244-240 0c-26.5 0-48 21.5-48 48l0 240c0 26.5 21.5 48 48 48l240 0 0-92zm48-32l72 30 0-148-72 30 0 88zM288 264c-33.6 0-48-21.5-48-48s14.4-48 48-48 48 21.5 48 48-14.4 48-48 48z"],
    "bold": [432, 576, [], "f032", "M0 552L0 24 223.6 24c50.6 0 92 15 120.5 44.2 28.4 28.9 39.8 67.4 39.8 105.8 0 33.7-8.8 67.3-30 94.6 14.7 7.1 27.7 16.3 38.8 27.8 28 29 39.3 67.3 39.3 105.6s-11.3 76.7-39.3 105.6C364.4 536.9 323.5 552 273.2 552L0 552zm120-72l81.2 0c35.7 0 56.1-10.4 67.7-22.4 11.9-12.3 19-30.9 19-55.6s-7.1-43.3-19-55.6c-11.6-12-32-22.4-67.7-22.4l-81.2 0 0 156zm0-228l31.6 0c36.4 0 57.3-10.5 69.1-22.6 12.1-12.3 19.3-30.9 19.3-55.4s-7.2-43.1-19.3-55.4C208.9 106.5 188 96 151.6 96l-31.6 0 0 156z"],
    "clipboard": [480, 576, [128203], "f328", "M164.8 56.4C166.6 38 182.1 24 200.6 24l78.8 0c18.5 0 34 14 35.8 32.4l.4 3.6 164.4 0 0 420c0 53-43 96-96 96L96 576c-53 0-96-43-96-96l0-420 164.4 0 .4-3.6zM156 144l3.6-36-63.6 0 0 372c0 26.5 21.5 48 48 48l192 0c26.5 0 48-21.5 48-48l0-372-63.6 0 3.6 36-168 0zM144 264l0-48 192 0 0 48-192 0zm192 96l-192 0 0-48 192 0 0 48zM144 456l0-48 192 0 0 48-192 0z"],
    "laptop": [576, 576, [128187], "f109", "M48.1 24l480 0 0 308.3 44.3 141.8c12.1 38.6-16.8 77.9-57.3 77.9L61 552c-40.5 0-69.3-39.3-57.3-77.9L48.1 332.3 48.1 24zM459.4 72l-337.3 0 20 240 292.3 0 25-240zM97.6 488.4c-2.4 7.7 3.4 15.6 11.5 15.6l358.1 0c8.1 0 13.9-7.9 11.5-15.6L438.4 360 137.7 360 97.6 488.4zM192.1 456l0-48 192 0 0 48-192 0z"],
    "thumbs-down": [528, 576, [128078, 61576], "f165", "M0 144l0-24 33.6 0c33.2 0 64.9-13.7 87.5-37.9L140 61.9C162.7 37.7 194.4 24 227.6 24L408 24c53 0 96 43 96 96 0 12.8-3.4 24.9-9.2 35.3 20 12.8 33.2 35.2 33.2 60.7 0 18.4-6.9 35.3-18.3 48 11.4 12.7 18.3 29.6 18.3 48 0 53-43 96-96 96l-65.8 0 5.8 46.6C380.1 519.1 329.8 576 264.8 576l-55.6 0-4.4-17.6-33.8-111.5c-6.4-14.5-12.3-23.8-18.9-29.7-6-5.3-14-9.2-28.4-9.2L0 408 0 144zM480 312c0-13.3-10.7-24-24-24l-48 0 0-48 48 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-48 0 0-48 24 0c13.3 0 24-10.7 24-24s-10.7-24-24-24L251.7 96c-22.7 0-44.9 6.4-64.1 18.5L144 142c-26.8 17-58 26-89.7 26l-6.3 0 0 168 75.8 0c44.1 0 82.4 30 93.1 72.7l29.8 119c33.2-3.2 57.9-33.3 53.7-67.2-9.6-76.8-14.8-118.3-15.6-124.6L456 336c13.3 0 24-10.7 24-24z"],
    "utensils": [480, 576, [127860, 61685, "cutlery"], "f2e7", "M480 24L440.2 5.9c-6.3 5.5-12 11.6-17.7 17.7-10.5 11.3-25.1 28.2-41.4 50.8-32.7 45.2-73 113.4-103.8 206l-10.5 31.6 157 0-72 240 128.3 0 0-528zm-48 85.1l0 154.9-54.2 0C393.5 197 414 145.6 432 109.1zM96 192c-26.5 0-48-21.5-48-48L48 24 0 24 0 192c0 49.5 37.5 90.3 85.6 95.4l-55.1 264.6 179 0-55.1-264.6c48.1-5.2 85.6-45.9 85.6-95.4l0-168-48 0 0 120c0 26.5-21.5 48-48 48l0-168-48 0 0 168zm54.5 312l-61 0 30.5-146.3 30.5 146.3z"],
    "microphone": [480, 576, [], "f130", "M312 168l0 48c0 22.4-6.1 40.1-16.7 51.8-10.2 11.3-27.1 20.2-55.3 20.2s-45.2-8.8-55.3-20.2C174.1 256.1 168 238.4 168 216l0-48c0-22.4 6.1-40.1 16.7-51.8 10.2-11.3 27.1-20.2 55.3-20.2s45.2 8.8 55.3 20.2C305.9 127.9 312 145.6 312 168zM120 216l0 48c0 30.6 8.3 60.9 28.9 83.9 21 23.4 52.1 36.1 91.1 36.1s70-12.7 91.1-36.1c20.6-23 28.9-53.3 28.9-83.9l0-144C360 89.4 351.7 59.1 331.1 36.1 310 12.7 279 0 240 0s-70 12.7-91.1 36.1C128.3 59.1 120 89.4 120 120l0 96zM360 576l0-48-96 0 0-48.6c67.3-3.4 119.4-21.6 156-51.7 41.3-34.1 60-81.2 60-131.7l0-56-72 0 0 56c0 38.9-12.5 72-37.9 95.5-25.5 23.7-67 40.5-130.1 40.5s-104.5-16.8-130.1-40.5C84.5 368 72 334.9 72 296l0-56-72 0 0 56c0 50.4 18.7 97.6 60 131.7 36.5 30.1 88.6 48.3 156 51.7l0 48.6-96 0 0 48 240 0z"],
    "crown": [576, 576, [128081], "f521", "M305.7 43.8L288 24.5 270.3 43.8 153.2 171.5C64.2 102.7 13.1 63.3 0 53.1L0 456c0 25 12 44.4 30.6 57.9 17.4 12.8 40.7 20.6 65.9 25.9 50.5 10.5 119 12.2 191.5 12.2s141-1.7 191.5-12.2c25.2-5.2 48.5-13.1 65.9-25.9 18.5-13.6 30.6-32.9 30.6-57.9l0-402.9c-13.1 10.2-64.2 49.6-153.2 118.4L305.7 43.8zM480 193.1l0 179.2-.5-.1C429 361.7 360.6 360 288 360s-141 1.7-191.5 12.2l-.5 .1 0-179.2c54.4 42.3 84.1 65.4 89.3 69.5l14.4-20.9 88.3-127.5 88.3 127.5 14.4 20.9c5.1-4 34.9-27.2 89.3-69.5zM105 435.3c6.8-6.1 18.4-11.8 36.2-16.3 35.8-9.1 86.8-11 146.8-11s111.1 1.9 146.8 11c17.8 4.5 29.4 10.2 36.2 16.3 5.9 5.3 9 11.4 9 20.7s-3.1 15.4-9 20.7c-6.8 6.1-18.4 11.8-36.2 16.3-35.8 9.1-86.8 11-146.8 11s-111.1-1.9-146.8-11c-17.8-4.5-29.4-10.2-36.2-16.3-5.9-5.3-9-11.4-9-20.7l0 0c0-9.3 3.1-15.4 9-20.7z"],
    "arrow-up-wide-short": [528, 576, ["sort-amount-up"], "f161", "M27.1 95.2L5.9 111.9c27.8 27.8 55.9 55.9 62.2 62.2 4.3-5.4 29.2-37 74.8-94.7l-16.8 471.8-.9 24.9 85.7 0-.9-24.9-16.8-471.8c45.6 57.7 70.5 89.3 74.8 94.7 27.8-27.8 55.9-55.9 62.2-62.2l-21.2-16.7-114-90-6.5-5.2-40.7 0-6.5 5.2-114 90zM528 267.2l0-102.4-27 3.4-192 24 0 47.6 192 24 27 3.4zM480 528l0-76.3-27.9 4.7-144 24 0 47.3 144 24 27.9 4.7 0-28.3zM312 411.7l27.4-3.9 168-24 0-47.5-168-24-27.4-3.9 0 103.3z"],
    "sun": [576, 576, [9728], "f185", "M309.6 0L266.4 0 222 47.9c-13.9 15-33.5 23.3-53.9 23L89.2 63 63 89.4 70.9 164.2c.3 19.5-7.3 38.3-21.1 52.1L0 266.1 0 309.6 47.9 354c15 13.9 23.3 33.5 23 53.9l-7.9 78.8 28 26 73.3-12.8c23.9-2.2 47.3 7.7 62.4 26.4l40.2 49.6 42.3 0 40.2-49.6c15.1-18.7 38.5-28.5 62.4-26.4l73.3 12.8 28-26-7.9-78.8c-.3-20.4 8-40 23-53.9l47.9-44.4 0-43.5-49.8-49.8c-13.8-13.8-21.4-32.6-21.1-52.1l7.9-74.8-26.3-26.4-78.8 7.9c-20.4 .3-40-8-53.9-23L309.6 0zM288 64.4l4.8 9.4c26.8 52.1 87.4 77.2 143.2 59.3l10-3.2-3.2 10c-17.9 55.8 7.2 116.4 59.3 143.2l9.4 4.8-9.4 4.8c-52.1 26.8-77.2 87.4-59.3 143.2l3.2 10-10-3.2c-55.8-17.9-116.4 7.2-143.2 59.3l-4.8 9.4-4.8-9.4c-26.8-52.1-87.4-77.2-143.2-59.3l-10 3.2 3.2-10c17.9-55.8-7.2-116.4-59.3-143.2l-9.4-4.8 9.4-4.8c52.1-26.8 77.2-87.4 59.3-143.2l-3.2-10 10 3.2c55.8 17.9 116.4-7.2 143.2-59.3l4.8-9.4zM322.3 224c8.6 14.4 13.7 36.5 13.7 64s-5.1 49.6-13.7 64c-7.8 13.1-18.4 20-34.3 20s-26.5-6.9-34.3-20c-8.6-14.4-13.7-36.5-13.7-64s5.1-49.6 13.7-64c7.8-13.1 18.4-20 34.3-20s26.5 6.9 34.3 20zM288 156c-43.2 0-77.2 14-100.2 39.6-22.6 25.1-31.8 58.5-31.8 92.4s9.2 67.3 31.8 92.4c23 25.6 57 39.6 100.2 39.6s77.2-14 100.2-39.6C410.8 355.3 420 321.9 420 288s-9.2-67.3-31.8-92.4C365.2 170 331.2 156 288 156z"],
    "image": [528, 576, [], "f03e", "M0 24l528 0 0 528-528 0 0-528zM480 456l0-82.7c0-33-8.5-60.2-24.3-78.7-15.2-17.9-39.6-30.6-78-30.6-37.8 0-62.7 21.5-81.1 53.8-21.6 38.1-43.5 58-72.2 64.4-13 2.9-25.9 2.7-37.6 2.1-3.6-.2-7.1-.4-10.6-.6l0 0c-8.4-.5-16.5-1-26-1-40 0-64.5 10.7-79.1 25.8-10.9 11.2-18.3 26.9-21.5 47.6L480 456zm0-229.1L480 72 48 72 48 350.2c24.8-24.5 59-39.5 102.3-39.5 17.1 0 31.8 3.2 43.6 6.2 2.8 .7 5.3 1.4 7.7 2 8.4 2.2 14.1 3.6 19.6 4.1 5.6 .5 9.1-.3 12.8-2.8 4.7-3 11.7-10 20.8-26 3-5.3 5.5-10.3 8.4-15.8l0 0c2-4 4.2-8.2 6.8-13.1 5.7-10.6 12.5-22.4 21.3-33.2 18.6-22.7 45.4-40.1 86.4-40.1 42.6 0 77.1 12.5 102.3 34.9zM204 192c0 26.5-14.4 48-48 48s-48-21.5-48-48 14.4-48 48-48 48 21.5 48 48z"],
    "notdef": [480, 576, [], "e1fe", "M24 24l-24 0 0 528 480 0 0-528-456 0zM96 414.6L96 111.1 227.6 259.2 96 414.6zM127 456L267.7 304.3 402.6 456 127 456zM300.5 268.9L432 127.2 432 416.9 300.5 268.9zM386.2 72L259 222.2 125.4 72 386.2 72z"],
    "pencil": [576, 576, [9999, 61504, "pencil-alt"], "f303", "M353.3 113l-7 7 110.1 110.1 7-7c30.4-30.4 30.4-79.7 0-110.1s-79.7-30.4-110.1 0zm-223 223L240.3 446.1 422.4 264 312.3 153.9 130.3 336zM96.3 369.9l-2.3 2.3-22.3 89.1 43.2 43.2 89.1-22.3 2.3-2.3-110.1-110.1zM319.4 79l42-42c49.1-49.1 128.8-49.1 177.9 0s49.1 128.8 0 177.9l-306 306-4.7 4.7-6.4 1.6-192 48-29.1-29.1 48-192 1.6-6.5 4.7-4.7 264-264 0 0z"],
    "lightbulb": [480, 576, [128161], "f0eb", "M240 48c52.2 0 86.9 18.9 109.2 47.5 23 29.5 34.8 72.2 34.8 122.4 0 79.8-29.2 143.9-85.3 166l-34.7 0 0-110.1 65-65-33.9-33.9-55 55-55-55-33.9 33.9 65 65 0 110.1-34.7 0C125.2 361.9 96 297.8 96 218 96 167.7 107.9 125.1 130.8 95.5 153.1 66.9 187.8 48 240 48zm96 380.6C436.5 396.8 480 308.8 480 218 480 159.7 462.3 104.5 421.7 63.8 381 23.1 320.2 0 240 0S99 23.1 58.3 63.8C17.7 104.5 0 159.7 0 218 0 308.8 43.5 396.8 144 428.6l0 51.4c0 53 43 96 96 96s96-43 96-96l0-51.4zM288 432l0 24c0 26.5-21.5 48-48 48s-48-21.5-48-48l0-24 96 0z"],
    "code": [576, 576, [], "f121", "M318.6 7.4l-108 552 47.1 9.2 108-552-47.1-9.2zM150.4 112l-18.8 22.8-114 138-12.6 15.3 12.6 15.3 114 138 18.8 22.8c27.3-34.1 54.8-68.5 57.6-72l-19.1-14.9-113.8-89.1 113.8-89.1 19.1-15c-20.7-25.9-53.2-66.5-57.6-72zm275.4 0c-27.3 34.1-54.8 68.5-57.6 72l19.1 15 113.8 89.1-113.8 89.1-19.1 14.9c20.7 25.9 53.2 66.5 57.6 72l18.8-22.8 114-138 12.6-15.3-12.6-15.3-114-138-18.8-22.8z"],
    "address-card": [432, 576, [62140, "contact-card", "vcard"], "f2bb", "M172.5 96c-2.3 11.1-5.7 27.1-10.1 48l107.2 0c-4.4-20.9-7.8-36.9-10.1-48l124.5 0 0 336c0 12.4-4.7 23.6-12.3 32.1-2.6-39.5-19.9-71.4-47.2-93.5-9.8-7.9-20.6-14.4-32.3-19.5 13.1-16.4 19.9-37.8 19.9-63.1 0-30.6-10-55.6-29.1-72.8-18.6-16.7-43-23.2-66.9-23.2s-48.3 6.5-66.9 23.2c-19.1 17.1-29.1 42.2-29.1 72.8 0 25.2 6.8 46.7 19.9 63.1-11.7 5.1-22.5 11.6-32.3 19.5-27.4 22.1-44.7 54-47.2 93.5-7.7-8.5-12.3-19.8-12.3-32.1l0-336 124.5 0zM300 480l-168 0 0-5.5c0-31.9 10.2-54.1 24.5-68.1 14.4-14.2 35-22.3 59.5-22.3s45.1 8.1 59.5 22.3c14.3 14.1 24.5 36.2 24.5 68.1l0 5.5zM182.6 48L0 48 0 480c0 53 43 96 96 96l240 0c53 0 96-43 96-96l0-432-182.6 0-9.9-46.9-47 0-9.9 46.9zM216 240c7.6 0 13.3 2.6 17.6 8 4.8 6 9.8 18.1 9.8 40s-5 33.9-9.8 40c-4.3 5.4-9.9 8-17.6 8s-13.3-2.6-17.6-8c-4.8-6-9.8-18.1-9.8-40s5-33.9 9.8-40c4.3-5.4 9.9-8 17.6-8z"],
    "angle-right": [288, 576, [8250], "f105", "M78.1 486l-17 17 18.2 18.2 16.9-19.4-18.1-15.8zm-30-30l-15.8-18.1-19.3 16.9 18.1 18.1 17-17zm30-366L96.2 74.2 79.3 54.8 61.1 73 78.1 90zm-30 30l-17-17-18.1 18.1 19.3 16.9 15.8-18.1zm192 156l24 0 0-9-5.9-6.8-18.1 15.8zm0 24l18.1 15.8 5.9-6.8 0-9-24 0zm-15.8-30.1l-192 168 31.6 36.1 192-168-31.6-36.1zM31.1 473l30 30 33.9-33.9-30-30-33.9 33.9zm224.8-203l-192-168-31.6 36.1 192 168 31.6-36.1zM65.1 137l30-30-33.9-33.9-30 30 33.9 33.9zm199 151l0-12-48 0 0 12 48 0zm-5.9-27.8l-162-186-36.2 31.5 162 186 36.2-31.5zM216.1 288l0 12 48 0 0-12-48 0zm5.9-3.8l-162 186 36.2 31.5 162-186-36.2-31.5z"],
    "face-meh": [576, 576, [128528, "meh"], "f11a", "M142.6 115.5C111.6 157.8 96 218.2 96 288s15.6 130.2 46.6 172.5C172.9 501.7 219.5 528 288 528s115.1-26.3 145.4-67.5C464.4 418.2 480 357.8 480 288s-15.6-130.2-46.6-172.5C403.1 74.3 356.5 48 288 48S172.9 74.3 142.6 115.5zM68.8 85.3C117.2 31.5 190.2 0 288 0S458.8 31.5 507.2 85.3C555.1 138.7 576 211 576 288s-20.9 149.3-68.8 202.7C458.8 544.5 385.8 576 288 576S117.2 544.5 68.8 490.7C20.9 437.3 0 365 0 288S20.9 138.7 68.8 85.3zM216 264c-33.6 0-48-21.5-48-48s14.4-48 48-48 48 21.5 48 48-14.4 48-48 48zm192-48c0 26.5-14.4 48-48 48s-48-21.5-48-48 14.4-48 48-48 48 21.5 48 48zm-7 139l-17 17 17-17-24.5 39.7 0 0-.1 0c-.2-.1-.4-.1-.9-.3-.8-.3-2.2-.6-4.1-1.1-3.8-1-9.5-2.3-17.2-3.7-15.2-2.8-37.8-5.6-66.2-5.6s-51 2.8-66.2 5.6c-7.6 1.4-13.4 2.8-17.2 3.7-1.9 .5-3.3 .9-4.1 1.1-.4 .1-.7 .2-.9 .3l-.1 0 0 0-24.5-39.7 17 17c-17-17-17-17-17-17l0 0 0 0 .1-.1 .2-.2 .6-.5c.4-.4 1-1 1.8-1.6 1.5-1.3 3.5-3.1 6.1-5.1 5.2-4.1 12.7-9.3 22.2-14.5 19.1-10.4 47.1-20.9 82-20.9s62.8 10.5 82 20.9c9.6 5.2 17 10.5 22.2 14.5 2.6 2 4.6 3.8 6.1 5.1 .7 .7 1.3 1.2 1.8 1.6l.6 .5 .2 .2 .1 .1 0 0zm-33.9 34l0 0 0 0 0 0z"],
    "map": [576, 576, [128506, 62072], "f279", "M229.3 28l-8.8-5.9-10.3 2.6-192 48-18.2 4.5 0 310.5c0 62.5 58.7 108.3 119.3 93.1 80.5-20.1 39.4-9.9 92.2-23.1l135.2 90.1 8.8 5.9 10.3-2.6 60-15 0 .1 29.6-7.4c1.2-.3 2.4-.6 3.6-1l44.3-11.1C546 506.2 576 467.8 576 423.8l0-358.5-29.8 7.5-181.7 45.4-135.2-90.1zM155.6 422.3l0 0C125.3 429.9 96 407 96 375.8l0-273 96-24 0 334.5-36.4 9.1zM480 138.7l0 297.1c0 21.1-13.8 39.6-33.8 45.8l-62.2 15.6 0-334.5 96-24zM240 419.2l0-326.3 96 64 0 326.3-96-64z"],
    "thumbtack": [480, 576, [128204, 128392, "thumb-tack"], "f08d", "M480 432c0-90.2-35.1-173.3-117.4-214.1L376.7 90.7C379.4 66.4 400 48 424.4 48l31.6 0 0-48-432 0 0 48 31.6 0c24.5 0 45 18.4 47.7 42.7l14.1 127.2C35.1 258.7 0 341.8 0 432l0 24 216 0 0 120 48 0 0-120 216 0 0-24zM168 48l144 0 0 209.6 9.5 7.2c36.5 27.6 57.6 78.4 61.7 143.2L96.7 408c4.1-64.8 25.2-115.6 61.7-143.2l9.5-7.2 0-209.6z"],
    "money-bill-wave": [576, 576, [], "f53a", "M274.7 140c-41.7-27.8-91.9-39.6-141.6-33.4l-37.1 4.6 0 293.6 31.2-3.9c61.1-7.6 122.9 7 174.2 41.1 41.7 27.8 91.9 39.6 141.6 33.4l37.1-4.6 0-293.6-31.2 3.9c-61.1 7.6-122.9-7-174.2-41.1zM127.2 58.9c61.1-7.6 122.9 7 174.2 41.1 41.7 27.8 91.9 39.6 141.6 33.4 84-10.5 128.3-16 133.1-16.6l0 390.4-21 2.6-106.1 13.3c-61.1 7.6-122.9-7-174.2-41.1-41.7-27.8-91.9-39.6-141.6-33.4-84 10.5-128.3 16-133.1 16.6L0 74.8 21 72.2 127.2 58.9zM310.3 257.5c-5-1-10.3-1.9-16-2.7-5.4-.8-10.5-1.3-15.3-1.7-16.8-.5-27.9 2.7-34.8 6.8-8.1 4.8-12.7 12-14.1 21.9s1 18.1 7.5 24.9c7 7.4 21.1 15.4 46.9 19.1s41.5-.2 50.4-5.4c8.1-4.8 12.7-12 14.1-21.9s-1-18.1-7.5-24.9c-5.4-5.7-15.1-11.9-31.2-16zm64.3 108.4c-24.6 10.8-57.3 13.3-97 7.7s-70.5-17-91.1-34.2c-21.6-18-31.5-41.9-27.9-67.4S178.3 226.3 204 215c20.5-9 46.7-12.3 77.8-9.8 6.3 .2 12.7 .8 19.4 1.8 6.9 1 13.5 2.2 19.7 3.8 30.2 6.3 54.1 16.6 71.2 30.7 21.6 18 31.5 41.9 27.9 67.4s-19.7 45.8-45.4 57.1z"],
    "folder": [576, 576, [128193, 128447, 61716, "folder-blank"], "f07b", "M24 48L0 48 0 432c0 53 43 96 96 96l384 0c53 0 96-43 96-96l0-288-249.2 0-21.5-42.9C289.1 68.5 255.9 48 219.5 48L24 48zM480 192l0 240c0 26.5-21.5 48-48 48l-288 0c-26.5 0-48-21.5-48-48l0-336 99.5 0c18.2 0 34.8 10.3 42.9 26.5 22.3 44.6 33.9 67.8 34.7 69.5L480 192z"],
    "arrow-up-from-bracket": [576, 576, [], "e09a", "M276 24l-8.6 0-6.7 5.5-138 114-20.3 16.8c27.3 27.3 55.4 55.4 60.4 60.4 .6-.6 33.3-36.5 98.1-107.5l-14.9 317.6-1.2 25.1 86.3 0-1.2-25.1-14.9-317.6c64.8 71 97.5 106.8 98.1 107.5 25.5-25.5 55-55 60.4-60.4l-20.3-16.8-138-114-6.7-5.5-32.6 0zM576 456l0-48-96 0 0 48c0 26.5-21.5 48-48 48l-288 0c-26.5 0-48-21.5-48-48l0-48-96 0 0 48c0 53 43 96 96 96l384 0c53 0 96-43 96-96z"],
    "cloud": [576, 576, [9729], "f0c2", "M120 264c0 7.6 .3 14.9 .9 22.1l2.1 26-26.1-.1-.8 0 0 0c-19.8 0-30.7 6.1-37 13.1-6.7 7.4-11 19.1-11 34.9 0 26.5 21.5 48 48 48l384 0c26.5 0 48-21.5 48-48 0-15.8-4.3-27.4-11-34.9-6.3-7-17.2-13.1-37-13.1-.6 0-1.1 0-1.7 0l-29.5 .5 5.5-29c1.1-6.1 1.7-12.6 1.7-19.6 0-22.4-6.1-40.1-16.7-51.8-10.2-11.3-27.1-20.2-55.3-20.2-12.8 0-23.3 1.8-31.7 4.8l-21.5 7.6-8.6-21.1c-8.2-20.1-19.9-35.7-34.8-46.2-14.7-10.5-34-17-59.4-17-38.7 0-64.2 15.2-81 39-17.6 25-27 61.5-27 105zM0 360c0-24 6.5-48.3 23.2-66.9 12.4-13.8 29-22.9 48.8-26.8 0-.8 0-1.5 0-2.3 0-49.3 10.4-96.8 35.7-132.6 26.1-37 66.5-59.4 120.3-59.4 34.1 0 63.4 9 87.2 25.9 17.9 12.7 31.8 29.3 42.3 48.2 8.4-1.4 17.2-2.1 26.5-2.1 39 0 70 12.7 91.1 36.1 20.6 23 28.9 53.3 28.9 83.9 0 .8 0 1.5 0 2.3 19.8 3.9 36.4 13 48.8 26.8 16.7 18.6 23.2 43 23.2 66.9 0 79.5-64.5 144-144 144l-288 0C64.5 504 0 439.5 0 360z"],
    "circle": [576, 576, [128308, 128309, 128992, 128993, 128994, 128995, 128996, 9679, 9898, 9899, 11044, 61708, 61915], "f111", "M288 48c68.5 0 115.1 26.3 145.4 67.5 31.1 42.3 46.6 102.6 46.6 172.5s-15.6 130.2-46.6 172.5C403.1 501.7 356.5 528 288 528s-115.1-26.3-145.4-67.5C111.6 418.2 96 357.8 96 288s15.6-130.2 46.6-172.5C172.9 74.3 219.5 48 288 48zm0-48C190.2 0 117.2 31.5 68.8 85.3 20.9 138.7 0 211 0 288S20.9 437.3 68.8 490.7C117.2 544.5 190.2 576 288 576s170.8-31.5 219.2-85.3C555.1 437.3 576 365 576 288S555.1 138.7 507.2 85.3C458.8 31.5 385.8 0 288 0z"],
    "backward": [576, 576, [9194], "f04a", "M354 52.6l-36.8 23.1-306 192 0 40.7 306 192 36.8 23.1 0-135.5c143.3 89.9 215.2 135.1 216 135.5l0-470.8c-.7 .5-72.8 45.7-216 135.5l0-135.5zM474 406.5l-120-75.3 0-86.4 120-75.3 0 237zm-216 0L69.2 288 258 169.5 258 406.5z"],
    "link": [576, 576, [128279, "chain"], "f0c1", "M292.3 349.7c.5-.5 1.1-1.1 1.6-1.7-15.3-4.2-29.7-12.3-41.7-24.3-37-37-37-97 0-134.1l84-84c37-37 97-37 134.1 0 36 36 37 93.6 3.1 130.8 5.5 20.1 7.6 41 6.3 61.7l54.5-54.5c55.8-55.8 55.8-146.2 0-201.9S388-14 332.2 41.7c-11 11-49 49-114 114l-30 30c-55.8 55.8-55.8 146.2 0 201.9 11.6 11.6 24.7 20.8 38.6 27.5l65.5-65.5zm-8.7-123.5c-.5 .5-1.1 1.1-1.6 1.7 15.3 4.2 29.7 12.3 41.7 24.3 37 37 37 97 0 134.1l-84 84c-37 37-97 37-134.1 0-36-36-37-93.6-3.1-130.8-5.5-20.1-7.6-41-6.3-61.7l-24.5 24.5-.1 .1-29.9 29.9c-55.8 55.8-55.8 146.2 0 201.9s146.2 55.8 201.9 0c11-11 49-49 114-114l30-30c55.8-55.8 55.8-146.2 0-201.9-11.6-11.6-24.7-20.8-38.6-27.5l-65.5 65.5z"],
    "backward-step": [528, 576, ["step-backward"], "f048", "M490.9 75.9l37.1-24.2 0 472.7-37.1-24.2-250.9-163.8 0 167.7-240 0 0-432 240 0 0 167.7 250.9-163.8zM253.9 288L432 404.3 432 171.7 253.9 288zM120 456l0-336-72 0 0 336 72 0z"],
    "circle-user": [576, 576, [62142, "user-circle"], "f2bd", "M288 48c68.5 0 115.1 26.3 145.4 67.5 31.1 42.3 46.6 102.6 46.6 172.5 0 52.3-8.7 99.3-26.2 137.4-6-33.4-23.9-60.3-49.7-79.4-9.1-6.8-19.1-12.5-29.8-17.2 21.9-21 33.7-51.2 33.7-88.8 0-39-12.7-70-36.1-91.1-23-20.6-53.3-28.9-83.9-28.9s-60.9 8.3-83.9 28.9c-23.4 21-36.1 52.1-36.1 91.1 0 37.6 11.8 67.9 33.7 88.8-10.7 4.7-20.7 10.4-29.8 17.2-25.8 19.1-43.7 46-49.7 79.4-17.4-38.1-26.2-85.1-26.2-137.4 0-69.8 15.6-130.2 46.6-172.5 30.3-41.2 76.9-67.5 145.4-67.5zm0 312c28.5 0 52.4 8.6 68.9 23.2 16.1 14.3 27.1 36.2 27.1 67.3l0 54.4c-25.7 14.7-57.4 23.1-96 23.1s-70.3-8.4-96-23.1l0-54.4c0-31.1 11-53 27.1-67.3 16.5-14.7 40.4-23.2 68.9-23.2zm.1-48l-.1 0c-13.7 0-24.6-4.8-32.5-14.2-8.3-9.9-15.5-27.8-15.5-57.8s7.2-47.9 15.5-57.8c7.9-9.4 18.7-14.2 32.5-14.2s24.6 4.8 32.5 14.2c8.3 9.9 15.5 27.8 15.5 57.8s-7.2 47.9-15.5 57.8c-7.9 9.4-18.7 14.2-32.4 14.2zM288 0C190.2 0 117.2 31.5 68.8 85.3 20.9 138.7 0 211 0 288S20.9 437.3 68.8 490.7C117.2 544.5 190.2 576 288 576s170.8-31.5 219.2-85.3C555.1 437.3 576 365 576 288S555.1 138.7 507.2 85.3C458.8 31.5 385.8 0 288 0z"],
    "hand": [480, 576, [129306, 9995, "hand-paper"], "f256", "M179.1 51.2c16.1-30.5 48.1-51.2 84.9-51.2 38 0 70.8 22.1 86.4 54.1 10.5-3.9 21.8-6.1 33.6-6.1 53 0 96 43 96 96l0 216c0 119.3-96.7 216-216 216l-48 0C96.7 576 0 479.3 0 360l0-168 24 0c17.1 0 33.3 3.6 48 10l0-70c0-46.4 37.6-84 84-84 8 0 15.7 1.1 23.1 3.2zM336 204l0 84-48 0 0-192c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 192-48 0 0-144c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 240-48 0 0-72c0-26.5-21.5-48-48-48l0 96c0 92.8 75.2 168 168 168s168-75.2 168-168l0-216c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 60z"],
    "thumbs-up": [528, 576, [128077, 61575], "f164", "M0 192l0-24 123.8 0c14.3 0 22.4-3.9 28.4-9.2 6.7-5.9 12.5-15.2 18.9-29.7L204.9 17.6 209.3 0 264.8 0c65 0 115.2 56.9 107.2 121.4l-5.8 46.6 65.8 0c53 0 96 43 96 96 0 18.4-6.9 35.3-18.3 48 11.4 12.7 18.3 29.6 18.3 48 0 25.5-13.3 47.9-33.2 60.7 5.9 10.4 9.2 22.5 9.2 35.3 0 53-43 96-96 96l-180.4 0c-33.2 0-64.9-13.7-87.5-37.9l-18.9-20.1C98.5 469.7 66.8 456 33.6 456L0 456 0 192zm480 72c0-13.3-10.7-24-24-24l-171.2 0c.8-6.2 6-47.7 15.6-124.6 4.2-33.9-20.5-64-53.7-67.2l-29.8 119C206.2 210 167.8 240 123.8 240l-75.8 0 0 168 6.3 0c31.8 0 62.9 9 89.7 26l43.5 27.5C206.8 473.6 229 480 251.7 480L432 480c13.3 0 24-10.7 24-24s-10.7-24-24-24l-24 0 0-48 48 0c13.3 0 24-10.7 24-24s-10.7-24-24-24l-48 0 0-48 48 0c13.3 0 24-10.7 24-24z"],
    "building": [480, 576, [127970, 61687], "f1ad", "M0 96C0 43 43 0 96 0L384 0c53 0 96 43 96 96l0 480-480 0 0-480zM144 48c-26.5 0-48 21.5-48 48l0 432 96 0 0-120 96 0 0 120 96 0 0-432c0-26.5-21.5-48-48-48L144 48zm36 144c-25.2 0-36-16.1-36-36s10.8-36 36-36 36 16.1 36 36-10.8 36-36 36zm156-36c0 19.9-10.8 36-36 36s-36-16.1-36-36 10.8-36 36-36 36 16.1 36 36zM180 336c-25.2 0-36-16.1-36-36s10.8-36 36-36 36 16.1 36 36-10.8 36-36 36zm156-36c0 19.9-10.8 36-36 36s-36-16.1-36-36 10.8-36 36-36 36 16.1 36 36z"],
    "gear": [576, 576, [9881, "cog"], "f013", "M248.4 0L229.7 0 226 14.7c-10.5 30.1-24.6 40-36.5 42.9-14.4 3.5-34.8-.7-60.6-15.2l-10-6c-1.7 1.7-24.8 24.8-69.3 69.3l-13.3 13.3 6 9.9c14.5 25.8 18.7 46.2 15.2 60.6-2.9 11.9-12.8 26-42.9 36.5L0 229.7 0 346.3 14.7 350c30.1 10.5 40 24.6 42.9 36.5 3.5 14.4-.7 34.8-15.2 60.6l-6 9.9c1.7 1.7 24.8 24.8 69.3 69.3l13.3 13.3 9.9-6c25.7-14.5 46.2-18.7 60.6-15.2 11.9 2.9 26 12.8 36.5 42.9l3.7 14.7 116.7 0 3.7-14.7c10.5-30.1 24.6-40 36.5-42.9 14.4-3.5 34.8 .7 60.5 15.2l10 6 82.5-82.5-6-9.9c-14.5-25.7-18.7-46.2-15.2-60.6 2.9-11.9 12.8-26 42.9-36.5l14.7-3.7 0-116.7-14.7-3.7c-30.1-10.5-40-24.6-42.9-36.5-3.5-14.4 .7-34.8 15.2-60.6l6-9.9c-1.7-1.7-24.8-24.8-69.3-69.3l-13.3-13.3-10 6c-25.7 14.5-46.2 18.7-60.6 15.2-11.9-2.9-26-12.8-36.5-42.9L346.3 0 248.4 0zm2.9 91.4c5.8-11.5 10.8-26 15.6-43.4l42.2 0c4.8 17.3 9.8 31.9 15.6 43.4 7.8 15.4 19.2 29.7 38.1 34.3 17 4.1 33.9-1.4 48.4-8l47.3 47.3-.5 1.2c-6.6 14.9-12.1 32.3-7.2 49.5 5.2 18.6 20 29.4 35.1 36.6 11.3 5.4 25.5 10 42.2 14.6l0 42.1c-17.4 4.8-32 9.8-43.4 15.5-15.4 7.7-29.8 19.1-34.4 38-4.2 17.1 1.5 34.1 8.1 48.6l-46.1 46.1c-1.3-.7-2.6-1.3-3.8-2-13.9-7-31.6-14.5-49.3-9.9-19.7 5.1-29.7 22.1-35.8 36.9-4.9 11.8-9.5 27.2-14.3 45.7l-41.9 0c-4.8-18.5-9.3-33.9-14.3-45.7-6.2-14.8-16.1-31.7-35.8-36.9-17.7-4.6-35.4 2.9-49.3 9.9-1.2 .6-2.5 1.3-3.8 2l-45.1-45.1c.7-1.3 1.4-2.7 2.1-4 7-13.9 14.6-31.6 10-49.3-5.1-19.8-22.2-29.7-37-35.8-11.8-4.9-27.3-9.4-45.8-14.3l0-41.9c18.5-4.8 34-9.3 45.8-14.3 14.7-6.1 31.8-16 37-35.8 4.6-17.7-2.9-35.4-10-49.3-.7-1.3-1.3-2.6-2.1-4l46.1-46.1c14.5 6.6 31.4 12.1 48.4 8 18.8-4.6 30.3-18.9 38.1-34.3zm52.7 158c4.7 7.9 8 21 8 38.6s-3.3 30.7-8 38.6c-3.9 6.6-8.5 9.4-16 9.4s-12.1-2.8-16-9.4c-4.7-7.9-8-21-8-38.6s3.3-30.7 8-38.6c3.9-6.6 8.5-9.4 16-9.4s12.1 2.8 16 9.4zM288 192c-30.6 0-55.6 10-72.8 29.1-16.7 18.6-23.2 43-23.2 66.9s6.5 48.3 23.2 66.9C232.4 374 257.4 384 288 384s55.6-10 72.8-29.1C377.5 336.3 384 312 384 288s-6.5-48.3-23.2-66.9C343.6 202 318.6 192 288 192z"],
    "circle-question": [576, 576, [62108, "question-circle"], "f059", "M288 48C219.5 48 172.9 74.3 142.6 115.5 111.6 157.8 96 218.2 96 288s15.6 130.2 46.6 172.5C172.9 501.7 219.5 528 288 528s115.1-26.3 145.4-67.5C464.4 418.2 480 357.8 480 288s-15.6-130.2-46.6-172.5C403.1 74.3 356.5 48 288 48zM68.8 85.3C117.2 31.5 190.2 0 288 0S458.8 31.5 507.2 85.3C555.1 138.7 576 211 576 288s-20.9 149.3-68.8 202.7C458.8 544.5 385.8 576 288 576S117.2 544.5 68.8 490.7C20.9 437.3 0 365 0 288S20.9 138.7 68.8 85.3zM324 420c0 19.9-10.8 36-36 36s-36-16.1-36-36 10.8-36 36-36 36 16.1 36 36zM252.1 183.2c-7.4 9.6-12.1 24.8-12.1 44.8l-72 0c0-28.1 8.8-55.9 30.1-76.6S250 120 288 120 356.7 130.7 377.9 151.4 408 199.9 408 228c0 29.9-11.6 55.4-34.7 72.6-15.1 11.3-34 18.1-55.1 21.3l6.5 26.1-73.5 0c11.9-47.6 15.7-62.9 18-72l18.7 0c17.7 0 29-5 35.9-11.7 6.8-6.6 12.1-17.8 12.1-36.3 0-19.9-4.7-35.1-12.1-44.8-6.7-8.7-17.4-15.2-35.9-15.2s-29.2 6.5-35.9 15.2z"],
    "file": [480, 576, [128196, 128459, 61462], "f15b", "M0 0L282.2 0c25.5 0 49.9 10.1 67.9 28.1L451.9 129.9c18 18 28.1 42.4 28.1 67.9l0 378.2-384 0c-53 0-96-43-96-96L0 0zM384 240l-120 0 0-192-168 0 0 432c0 26.5 21.5 48 48 48l240 0 0-288zm33.9-76.1L316.1 62.1c-1.3-1.3-2.7-2.5-4.1-3.7l0 109.6 109.6 0c-1.1-1.4-2.4-2.8-3.7-4.1z"],
    "volume-slash": [576, 576, [128263], "f2e2", "M7.5 41l528 528 33.9-33.9-137-137 0-374.1-41.7-16.2-125 136.3c-28.6 .6-54.3 3.9-76.6 10.7L41.4 7 7.5 41zM235.1 200.6c11.6-5.7 25.5-8.6 41.4-8.6l10.6 0 97.4-106.3 0 264.4-149.4-149.4zM96.5 288c0 46.7 13.6 85.1 46.9 110.6 29.8 22.8 71.5 32.2 122.4 33.3l125 136.3 35.4-32.4-139.1-151.8-10.6 0c-25.3 0-45.6-7.5-59.5-21.5-13.9-13.9-24.5-37.1-24.5-74.5 0-.7 0-1.4 0-2l-77.1-77.1c-13.1 22-18.9 48.9-18.9 79.2z"],
    "arrow-up": [480, 576, [8593], "f062", "M228.2 24l-9 0-6.8 5.9-186 162-19.4 16.9c25.3 25.3 65.1 65.1 66.3 66.3l16.9-19.3 122.5-140-20.6 411-1.3 25.2 98.5 0-1.3-25.2-20.6-411 122.5 140 16.9 19.3c25.2-25.2 65.1-65.1 66.3-66.3l-19.4-16.9-186-162-6.8-5.9-33 0z"],
    "rectangle": [528, 576, [9644, "rectangle-landscape"], "f2fa", "M24 48l-24 0 0 480 528 0 0-480-504 0zM96 96l384 0 0 336-384 0 0-336z"],
    "grid": [528, 576, ["grid-3"], "e195", "M24 24l-24 0 0 528 528 0 0-528-504 0zM312 72l0 108-96 0 0-108 96 0zM168 72l0 108-72 0 0-108 72 0zm0 156l0 120-72 0 0-120 72 0zm0 168l0 108-72 0 0-108 72 0zm48 0l96 0 0 108-96 0 0-108zm96-48l-96 0 0-120 96 0 0 120zm48 48l72 0 0 108-72 0 0-108zm72-48l-72 0 0-120 72 0 0 120zm0-276l0 108-72 0 0-108 72 0z"],
    "shirt": [576, 576, [128085, "t-shirt", "tshirt"], "f553", "M386.5 14l-24.2-6.2-5.1 24.7-.6 2.8 0 0c-6 29.4-10.2 49.7-19.4 64-4.2 6.5-9.2 11.2-16.1 14.6-7.1 3.5-17.5 6.1-33.2 6.1-15.3 0-25.5-2.9-32.5-6.6-6.9-3.7-12.1-8.9-16.6-16-8.7-14.1-12.9-32.5-18.2-56.1-.7-3-1.4-6.2-2.1-9.4l-5.5-24-23.9 6.1-.5 .1 0-.2C57.7 46.1 .5 168 0 263.9l-.1 24.1 103.8 0-32.3 236.8-3.7 27.2 439.8 0-3.7-27.2-32.3-236.8 103.8 0-.1-24.1c-.5-95.8-57.7-217.8-188.6-249.9 0 0 0 0-.1 0zm114 226l-84 0 0 0-34.8 0 2.4 26.2 21.6 237.8-235.4 0 21.6-237.8 2.4-26.2-35.6 0 0 0-83.2 0c5.3-36.3 16.7-72.9 34.4-103.8 17.2-30.1 39.8-53.7 67.9-67.2 4.4 18.1 10.3 37.5 20.3 53.7 8.1 13.1 19.3 24.8 34.8 33.1 15.4 8.2 33.7 12.2 55 12.2 20.9 0 39-3.5 54.3-11 15.6-7.6 26.9-18.7 35.3-31.7 10.6-16.4 16.5-36.4 21-56.1 27.8 13.5 50.3 37.1 67.4 67 17.7 30.8 29.1 67.5 34.4 103.8z"],
    "suitcase": [576, 576, [129523], "f0f2", "M191.6 66.9C211.6 38.8 243.9 24 288 24s76.4 14.8 96.4 42.9C400.1 89 406 116.5 407.6 144l72.4 0c53 0 96 43 96 96l0 312-576 0 0-312c0-53 43-96 96-96l72.4 0c1.5-27.5 7.5-55 23.2-77.1zM324.4 92.1c-3.7-7-8.1-11.7-13.2-14.7s-12.4-5.4-23.2-5.4-18.1 2.3-23.2 5.4-9.5 7.7-13.2 14.7c-6.5 12.1-10.1 29.6-11.2 51.9l95.2 0c-1.1-22.3-4.7-39.8-11.2-51.9zM480 504l0-120-148.5 0c2.3 11.1 5.7 27.1 10.1 48l-107.2 0c4.4-20.9 7.8-36.9 10.1-48l-148.5 0 0 120 384 0zM321.4 336l158.6 0 0-96c0-26.5-21.5-48-48-48l-288 0c-26.5 0-48 21.5-48 48l0 96 158.6 0 9.9-46.9 47 0 9.9 46.9z"],
    "play": [384, 576, [9654], "f04b", "M35.6 75l-35.6-19.6 0 465.3 35.6-19.6 348-192 0-42-348-192zM96 163.1L322.3 288 96 412.9 96 163.1z"],
    "paperclip": [336, 576, [128206], "f0c6", "M168 576c92.8 0 168-75.2 168-168l0-288C336 53.7 282.3 0 216 0S96 53.7 96 120l0 240c0 39.8 32.2 72 72 72s72-32.2 72-72l0-192-48 0 0 192c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-192c0-39.8 32.2-72 72-72s72 32.2 72 72l0 192c0 66.3-53.7 120-120 120-66.3 0-120-53.7-120-119.9L48 216 0 216 0 408c0 92.8 75.2 168 168 168z"],
    "wrench": [576, 576, [128295], "f0ad", "M177.6 266c-6.2-19.6-9.6-40.4-9.6-62 0-112.7 91.3-204 204-204l12 0c32.8 0 63.8 8.2 90.9 22.7L503.5 38C486.9 54.5 474 67.3 464.6 76.7l0 0-74.4 74c-8.5 9.5-8.2 24.2 1 33.4 9.5 9.4 24.8 9.4 34.3 0 70.8-70.5 108.3-107.7 112.3-111.7l15.3 28.2c14.6 27 22.9 57.9 22.9 90.6 0 .3 0 .6 0 .8l0 0 0 12c0 112.7-91.3 204-204 204-22.2 0-43.6-3.5-63.6-10.1L160.9 547.8c-35.7 36.3-93.9 37.5-131.1 2.5-38.5-36.2-39.4-97.1-2-134.5L177.6 266zM384 48c-79.6 0-144 64.2-144 143.2 0 18.3 3.4 35.7 9.7 51.7l5.7 14.6-11.1 11.1-131.1 130.4c-17.2 17.1-17.2 44.9 0 62 17.1 17 44.6 17 61.7 0l131.5-130.9 11-11 14.5 5.6c16.1 6.2 33.7 9.6 52.1 9.6 79.6 0 144-64.2 144-143.2 0-12.6-1.6-24.9-4.7-36.5l-75.9 75.5c-28.2 28.1-73.8 28.1-102 0-28.4-28.3-28.4-74.2 0-102.5l10.3-10.2c.6-.6 1.2-1.2 1.7-1.8l63.3-63C409 49.6 396.7 48 384 48l0 0z"],
    "life-ring": [576, 576, [], "f1cd", "M288 48c-56.5 0-98.1 17.9-127.9 47.3l59.9 89.8C238.5 173.9 261.4 168 288 168s49.5 5.9 68.1 17.1l59.9-89.8C386.1 65.9 344.5 48 288 48zM113.5 172.3C101.9 206 96 245.2 96 288s5.9 82 17.5 115.7L185.2 356c-12.1-20.2-17.2-44-17.2-68s5.1-47.7 17.2-68l-71.7-47.8zm46.6 308.4C189.9 510.1 231.5 528 288 528s98.1-17.9 127.9-47.3l-59.9-89.8C337.5 402.1 314.6 408 288 408s-49.5-5.9-68.1-17.1l-59.9 89.8zm302.4-77C474.1 370 480 330.8 480 288s-5.9-82-17.5-115.7L390.8 220c12.1 20.2 17.2 44 17.2 68s-5.1 47.7-17.2 68l71.7 47.8zM68.8 85.3C117.2 31.5 190.2 0 288 0S458.8 31.5 507.2 85.3C555.1 138.7 576 211 576 288s-20.9 149.3-68.8 202.7C458.8 544.5 385.8 576 288 576S117.2 544.5 68.8 490.7C20.9 437.3 0 365 0 288S20.9 138.7 68.8 85.3zM232.7 236.2C222.1 247.9 216 265.6 216 288s6.1 40.1 16.7 51.8C242.8 351.2 259.8 360 288 360s45.2-8.8 55.3-20.2C353.9 328.1 360 310.4 360 288s-6.1-40.1-16.7-51.8C333.2 224.8 316.2 216 288 216s-45.2 8.8-55.3 20.2z"],
    "calendar": [576, 576, [128197, 128198], "f133", "M192 0l0 48 192 0 0-48 48 0 0 48 144 0 0 384c0 53-43 96-96 96L96 528c-53 0-96-43-96-96l0-384 144 0 0-48 48 0zM96 96l0 48 384 0 0-48-384 0zm0 96l0 240c0 26.5 21.5 48 48 48l288 0c26.5 0 48-21.5 48-48l0-240-384 0zM288 312c-25.2 0-36-16.1-36-36s10.8-36 36-36 36 16.1 36 36-10.8 36-36 36zm144-36c0 19.9-10.8 36-36 36s-36-16.1-36-36 10.8-36 36-36 36 16.1 36 36zM180 312c-25.2 0-36-16.1-36-36s10.8-36 36-36 36 16.1 36 36-10.8 36-36 36zm144 84c0 19.9-10.8 36-36 36s-36-16.1-36-36 10.8-36 36-36 36 16.1 36 36zm72 36c-25.2 0-36-16.1-36-36s10.8-36 36-36 36 16.1 36 36-10.8 36-36 36zM216 396c0 19.9-10.8 36-36 36s-36-16.1-36-36 10.8-36 36-36 36 16.1 36 36z"],
    "italic": [432, 576, [], "f033", "M432 72L316.5 111.4c-15.8 5.4-27.6 18.5-31.3 34.7L221.2 425.8c-4 17.3 5.3 35 21.9 41.5l92.9 36.6 0 48-336 0 0-48 115.5-39.4c15.8-5.4 27.6-18.5 31.3-34.7l63.9-279.7c4-17.3-5.3-35-21.9-41.5L96 72 96 24 432 24 432 72z"],
    "check": [480, 576, [10003, 10004], "f00c", "M167.5 352.1l272.5-249.8 33.9 34-288 312-18.3 19.8-17.6-20.5-144-168 33.6-34.1 127.9 106.6z"],
    "chart-bar": [528, 576, ["bar-chart"], "f080", "M384 528l0-504 144 0 0 432c0 53-43 96-96 96l-48 0 0-24zm96-120l0-336-48 0 0 384c26.5 0 48-21.5 48-48zM192 528l0-384 144 0 0 408-144 0 0-24zm96-72l0-264-48 0 0 264 48 0zM144 528l0 24-48 0c-53 0-96-43-96-96l0-192 144 0 0 264zM96 456l0-144-48 0 0 96c0 26.5 21.5 48 48 48z"],
    "house": [528, 576, [127968, 63498, 63500, "home", "home-alt", "home-lg-alt"], "f015", "M277.8 16.3L264 6.7 250.2 16.3 10.2 184.3 0 191.5 0 456c0 53 43 96 96 96l336 0c53 0 96-43 96-96l0-408-96 0 0 76.3-154.2-108zM48 297.9l216-216 216 216 0 158.1c0 26.5-21.5 48-48 48l-48 0 0-144c0-40-14.8-70.8-38.7-91.4-23.3-20-53.2-28.6-81.3-28.6s-58.1 8.6-81.3 28.6C158.8 289.2 144 320 144 360l0 144-48 0c-26.5 0-48-21.5-48-48l0-158.1zM216 504l0-144c0-30.1 7.2-47.9 15.5-57.8 7.9-9.4 18.7-14.2 32.5-14.2s24.6 4.8 32.5 14.2c8.3 9.9 15.5 27.8 15.5 57.8l0 144-96 0z"],
    "play-pause": [528, 576, [], "e22f", "M37.4 82.1l-37.4-25.2 0 462.2 37.4-25.2 226.6-152.7 0 162.8 96 0 0-432-96 0 0 162.8-226.6-152.7zM96 396.5L96 179.5 257.1 288 96 396.5zM432 72l0 432 96 0 0-432-96 0z"],
    "sliders": [576, 576, ["sliders-h"], "f1de", "M120 266.9c17.1 4.3 32.8 13.6 45.3 28.5 17.8 21.3 26.7 51.4 26.7 88.6s-8.9 67.3-26.7 88.6c-12.5 14.9-28.3 24.2-45.3 28.5l0 50.9-48 0 0-50.9C54.9 496.8 39.2 487.5 26.7 472.6 8.9 451.3 0 421.1 0 384s8.9-67.3 26.7-88.6c12.5-14.9 28.3-24.2 45.3-28.5l0-242.9 48 0 0 242.9zm192-192c17.1 4.3 32.8 13.6 45.3 28.5 17.8 21.3 26.7 51.4 26.7 88.6s-8.9 67.3-26.7 88.6c-12.5 14.9-28.3 24.2-45.3 28.5l0 242.9-48 0 0-242.9c-17.1-4.3-32.8-13.6-45.3-28.5-17.8-21.3-26.7-51.4-26.7-88.6s8.9-67.3 26.7-88.6c12.5-14.9 28.3-24.2 45.3-28.5l0-50.9 48 0 0 50.9zM384 384c0-37.1 8.9-67.3 26.7-88.6 12.5-14.9 28.3-24.2 45.3-28.5l0-242.9 48 0 0 242.9c17.1 4.3 32.8 13.6 45.3 28.5 17.8 21.3 26.7 51.4 26.7 88.6s-8.9 67.3-26.7 88.6c-12.5 14.9-28.3 24.2-45.3 28.5l0 50.9-48 0 0-50.9c-17.1-4.3-32.8-13.6-45.3-28.5-17.8-21.3-26.7-51.4-26.7-88.6zM322.9 155c-7.4-6.7-19.1-11-34.9-11s-27.4 4.3-34.9 11c-7 6.3-13.1 17.2-13.1 37s6.1 30.8 13.1 37c7.4 6.7 19.1 11 34.9 11s27.4-4.3 34.9-11c7-6.3 13.1-17.2 13.1-37s-6.1-30.8-13.1-37zm192 192c-7.4-6.7-19.1-11-34.9-11s-27.4 4.3-34.9 11c-7 6.3-13.1 17.2-13.1 37s6.1 30.8 13.1 37c7.4 6.7 19.1 11 34.9 11s27.4-4.3 34.9-11c7-6.3 13.1-17.2 13.1-37s-6.1-30.8-13.1-37zM61.1 421c7.4 6.7 19.1 11 34.9 11s27.4-4.3 34.9-11c7-6.3 13.1-17.2 13.1-37s-6.1-30.8-13.1-37c-7.4-6.7-19.1-11-34.9-11s-27.4 4.3-34.9 11c-7 6.3-13.1 17.2-13.1 37s6.1 30.8 13.1 37z"],
    "face-frown": [576, 576, [9785, "frown"], "f119", "M288 48c68.5 0 115.1 26.3 145.4 67.5 31.1 42.3 46.6 102.6 46.6 172.5s-15.6 130.2-46.6 172.5C403.1 501.7 356.5 528 288 528s-115.1-26.3-145.4-67.5C111.6 418.2 96 357.8 96 288s15.6-130.2 46.6-172.5C172.9 74.3 219.5 48 288 48zm0-48C190.2 0 117.2 31.5 68.8 85.3 20.9 138.7 0 211 0 288S20.9 437.3 68.8 490.7C117.2 544.5 190.2 576 288 576s170.8-31.5 219.2-85.3C555.1 437.3 576 365 576 288S555.1 138.7 507.2 85.3C458.8 31.5 385.8 0 288 0zM228 420c0-30.8 8.3-51.9 19-64.9 10.6-12.7 24.7-19.1 41-19.1s30.4 6.5 41 19.1c10.8 13 19 34.1 19 64.9l72 0c0-40.8-14.3-74.5-39.2-97.8-24.7-23.1-57.9-34.2-92.8-34.2s-68 11.2-92.7 34.2c-25 23.3-39.3 57-39.3 97.8l72 0zm36-204c0-26.5-14.4-48-48-48s-48 21.5-48 48 14.4 48 48 48 48-21.5 48-48zm96 48c33.6 0 48-21.5 48-48s-14.4-48-48-48-48 21.5-48 48 14.4 48 48 48z"],
    "forward-step": [528, 576, ["step-forward"], "f051", "M37.1 75.9L0 51.7 0 524.3 37.1 500.1 288 336.3 288 504 528 504 528 72 288 72 288 239.7 37.1 75.9zM274.1 288L96 404.3 96 171.7 274.1 288zM408 456l0-336 72 0 0 336-72 0z"],
    "sort": [384, 576, ["unsorted"], "f0dc", "M171.5 24l41.3 0 6.7 5.5 138 114 20.3 16.8c-27.3 27.3-55.4 55.4-60.4 60.4-.5-.6-33.4-36.5-98.6-108l13.6 335.5c53.9-59 82.2-90 85-93.1 25.5 25.5 55 55 60.4 60.4l-20.3 16.8-138 114-6.7 5.5-41.3 0-6.7-5.5-138-114-20.3-16.8c27.3-27.3 55.4-55.4 60.4-60.4 2.8 3 31.1 34.1 85 93.1l13.6-335.5c-65.2 71.4-98.1 107.4-98.6 108-25.5-25.5-55-55-60.4-60.4l20.3-16.8 138-114 6.7-5.5z"],
    "user": [480, 576, [128100, 62144, 62470, "user-alt", "user-large"], "f007", "M240 72c20.9 0 37.9 6.9 50 20.5 12.3 13.8 22 37.4 22 75.5s-9.7 61.7-22 75.5c-12 13.5-29 20.5-49.9 20.5l-.1 0c-20.9 0-37.9-6.9-50-20.5-12.3-13.8-22-37.4-22-75.5s9.7-61.7 22-75.5C202.1 78.9 219.1 72 240 72zM139.1 277.4c.6 .5 1.1 1 1.7 1.5-25.1 8.2-48.2 19.9-68.2 35.3-45.2 34.9-72.6 87.4-72.6 155.2l0 82.6 480 0 0-82.6c0-67.9-27.4-120.3-72.6-155.2-20-15.4-43.1-27.1-68.2-35.3 .6-.5 1.1-1 1.7-1.5 27.8-24.9 43.1-62 43.1-109.4S368.6 83.6 340.9 58.6C313.6 34.1 277.2 24 240 24S166.4 34.1 139.1 58.6C111.4 83.6 96 120.6 96 168s15.4 84.4 43.1 109.4zm-2.1 69c25.1-21.9 61-34.3 102.7-34.3l.6 0c41.7 .1 77.6 12.4 102.7 34.3 24.7 21.6 41 54.1 41 99.1l0 58.6-288 0 0-58.6c0-45 16.2-77.5 41-99.1z"],
    "snowflake": [576, 576, [10052, 10054], "f2dc", "M312.2 49.4l0-49.4-48 0 0 49.4-46-32.9-32 35.3 78.1 89.2 0 105.4-91.3-52.7-38.2-112.2-46.6 10.1 5.5 56.3-42.8-24.7-24 41.6 42.7 24.7-51.5 23.4 14.6 45.4 116.3-23 91.3 52.7-91.3 52.7-116.3-23-14.6 45.4 51.5 23.4-42.8 24.7 24 41.6 42.8-24.7-5.5 56.3 46.6 10.1 38.2-112.2 91.3-52.7 0 105.4-78.1 89.2 32 35.3 46-32.9 0 49.4 48 0 0-49.4 46.1 32.9 32-35.3-78.1-89.2 0-105.4 91.3 52.7 38.2 112.2 46.6-10.1-5.5-56.3 42.8 24.7 24-41.6-42.8-24.7 51.5-23.4-14.6-45.4-116.3 23-91.3-52.7 91.3-52.7 116.3 23 14.6-45.4-51.5-23.4 42.7-24.7-24-41.6-42.7 24.7 5.5-56.3-46.6-10.1-38.2 112.2-91.3 52.7 0-105.4 78.1-89.2-32-35.3-46.1 32.9z"],
    "ticket": [432, 576, [127903], "f145", "M0 24l142.8 0 1.5 22.4c1.6 23.4 8.6 41.7 19.5 53.8 10.4 11.5 26.6 19.9 52.1 19.9s41.7-8.3 52.1-19.9c11-12.1 17.9-30.4 19.6-53.8l1.5-22.4 142.8 0 0 528-142.8 0-1.5-22.4c-1.6-23.4-8.6-41.7-19.6-53.8-10.4-11.5-26.6-19.9-52.1-19.9s-41.7 8.3-52.1 19.9c-11 12.1-17.9 30.4-19.5 53.8L142.8 552 0 552 0 24zm48 96l0 336 51.4 0c4.5-22.4 13.6-43.5 28.9-60.4 20.8-23 50.6-35.6 87.7-35.6s66.9 12.7 87.7 35.6c15.3 16.9 24.4 37.9 28.9 60.4l51.4 0 0-336-51.4 0c-4.5 22.4-13.6 43.5-28.9 60.4-20.8 23-50.6 35.6-87.7 35.6s-66.9-12.7-87.7-35.6C113 163.5 103.9 142.4 99.4 120L48 120z"],
    "wheelchair": [528, 576, [], "f193", "M204.3 39c-8.9 9.9-11.8 22.3-11.8 33s2.9 23.1 11.8 33c9.3 10.4 22.4 15 36.2 15s26.8-4.6 36.2-15c8.9-9.9 11.8-22.3 11.8-33s-2.9-23.1-11.8-33c-9.3-10.4-22.4-15-36.2-15s-26.8 4.6-36.2 15zM144.4 221.7l0-31.1-30.1 7.9c-38.9 10.2-68 31.9-87.1 61.3-18.8 29-26.8 64-26.8 100.2 0 43.9 11.9 86.2 40.3 117.9 28.8 32.1 71.9 50.1 127.7 50.1 75.6 0 126.5-33.2 151.1-85.8l16-34.2-98.5 0-5.3 16.9c-5.8 18.7-14.2 32.4-24.3 41.3-9.7 8.6-22.2 13.8-39.1 13.8-24.3 0-40.9-10.9-52.6-30.5-12.5-20.9-19.4-52.1-19.4-89.5 0-55 14.6-93.7 37.8-110l10.2-7.2 0-21.1zM319.7 312c-6 0-11-4.4-11.9-10.3l-8.8-61.7 109.5 0 0-48-116.3 0-1-7c-3.4-23.5-23.5-41-47.3-41-29.1 0-51.4 25.7-47.3 54.5l11.3 79.1c6.8 47.3 47.3 82.4 95 82.4l89.4 0c5.5 0 10.3 3.7 11.6 9.1l29.2 116.7 5.4 21.5c6.2-1 37.5-6.3 93.9-15.6l-7.9-47.3-50.1 8.4-23.8-95.2c-6.7-26.7-30.7-45.4-58.2-45.4l-72.7 0z"],
    "bookmark": [480, 576, [128278, 61591], "f02e", "M96 0C43 0 0 43 0 96L0 558 41.2 574.7 240 370.4 438.8 574.7 480 558 480 96c0-53-43-96-96-96L96 0zm48 48l192 0c26.5 0 48 21.5 48 48L384 406.6 254.8 305.1 240 293.5 225.2 305.1 96 406.6 96 96c0-26.5 21.5-48 48-48z"],
    "bomb": [576, 576, [128163], "f1e2", "M449.8 29.9l6.9-29.9 46.6 0 6.9 29.9c4.1 17.8 18 31.8 35.9 35.9l29.9 6.9 0 46.6-29.9 6.9c-17.8 4.1-31.8 18-35.9 35.9l-6.9 29.9-46.6 0-6.9-29.9c-4.1-17.8-18-31.8-35.9-35.9l-29.9-6.9 0-46.6 29.9-6.9c17.8-4.1 31.8-18 35.9-35.9zM480 76.2a19.8 19.8 0 1 0 0 39.6 19.8 19.8 0 1 0 0-39.6zM273.6 174.3l30.4-30.3 47.3 47.2 30.6-30.5 33.4 33.3-30.6 30.5 47.3 47.2-29.9 29.8c12.6 29.7 17.4 61.9 11.8 95-5.9 34.7-23 68.9-52 101.3-7.1 8.3-13.6 14.5-17.8 18.3-45.9 43.3-95.3 62.3-144.2 59.7-50.5-2.7-96.4-28.2-133.9-65.6S3 427 .2 376.6c-2.7-50.9 18.1-102.4 65.8-149.9 35.9-35.8 74.1-56.5 113-63.3 33-5.8 65-1.2 94.6 10.9zM257 257.5L241.2 248c-25.5-15.3-50.4-22.6-73.3-21.4-22.4 1.2-45.2 10.5-67.3 32.4-28.8 28.7-36.5 59.3-31 89.9 5.7 32 26.3 66.4 59 99s67.1 53.1 99.2 58.8c28.6 5.1 57.2-1.2 84.2-25.3 1.6-1.5 3.2-3 4.7-4.6 3.3-3.3 6.5-6.7 9.5-10 16.3-19.4 23.4-39.2 24.3-58.8 1-23.1-6.6-48.2-22.4-73.9l-9.8-15.9 46.7-46.6-61.1-61-47 46.8z"],
    "arrow-right": [528, 576, [8594], "f061", "M528 276l0-9-5.9-6.8-162-186-16.9-19.4c-25.3 25.3-65.1 65.1-66.3 66.3l19.3 16.9 140 122.5-411-20.6-25.2-1.3 0 98.5 25.2-1.3 411-20.6-140 122.5-19.3 16.9c25.2 25.2 65.1 65.1 66.3 66.3l16.9-19.4 162-186 5.9-6.8 0-33z"],
    "battery-bolt": [432, 576, [], "f376", "M120 0l192 0 0 48 120 0 0 432c0 53-43 96-96 96L96 576c-53 0-96-43-96-96l0-432 120 0 0-48zM264 96l0-48-96 0 0 48-72 0 0 384c0 26.5 21.5 48 48 48l144 0c26.5 0 48-21.5 48-48l0-384-72 0zm-45.6 96l21.6 0 0 96 60 0-86.4 144-21.6 0 0-96-60 0 86.4-144z"],
    "buildings": [576, 576, [], "e0cc", "M96 0C43 0 0 43 0 96l0 480 576 0 0-324c0-33.1-26.9-60-60-60l-108 0 0-96c0-53-43-96-96-96L96 0zM312 144l0 384-60 0 0-120-96 0 0 120-60 0 0-432c0-26.5 21.5-48 48-48l120 0c26.5 0 48 21.5 48 48l0 48zm96 384l0-288 60 0c6.6 0 12 5.4 12 12l0 276-72 0zM240 156c0-19.9-10.8-36-36-36s-36 16.1-36 36 10.8 36 36 36 36-16.1 36-36zM204 336c25.2 0 36-16.1 36-36s-10.8-36-36-36-36 16.1-36 36 10.8 36 36 36z"],
    "xmark": [336, 576, [128473, 10005, 10006, 10060, 215, "close", "multiply", "remove", "times"], "f00d", "M305.7 116.9l-137.3 115.7-137.3-115.7-33.6 34 118.4 137-118.4 137 33.6 34 137.3-115.7 137.3 115.7 33.6-34-118.4-137 118.4-137-33.6-34z"],
    "lock-open": [528, 576, [], "f3c1", "M120 168l0 24-120 0 0 288c0 53 43 96 96 96l336 0c53 0 96-43 96-96l0-288-336 0 0-24c0-38.8 4.8-69.7 16.2-90.2 5.4-9.8 12.1-16.9 20.4-21.7 8.3-4.8 19.6-8.1 35.4-8.1 24.4 0 38.7 7.7 48.2 18.7 10.4 12 17.5 30.7 21.1 56.6l2.9 20.7 72.7 0-4.9-28.1c-5.4-31-17.1-60.7-40.8-82.5-24-22.1-57-33.4-99.2-33.4-54 0-92.3 18.6-115.7 52.5-22.2 32.1-28.3 74.2-28.3 115.5zm0 72l312 0 0 240c0 26.5-21.5 48-48 48l-240 0c-26.5 0-48-21.5-48-48l0-240 24 0zM281.4 393.7c21.2-6.2 30.6-24.3 30.6-45.7 0-26.5-14.4-48-48-48s-48 21.5-48 48c0 21.4 9.4 39.5 30.6 45.7l-18.6 74.3 72 0-18.6-74.3z"],
    "droplet": [480, 576, [128167, "tint"], "f043", "M249 9.4l8.4-8-34.7 0 8.4 8 0 0c-8.4-8-8.4-8-8.4-8l0 0 0 0-.6 .7c-.4 .5-1.1 1.1-1.9 2-1.6 1.7-4 4.3-7 7.5-6 6.5-14.6 15.9-24.8 27.6-20.5 23.3-47.9 55.6-75.4 91.9-27.4 36.1-55.2 76.5-76.3 115.9-20.7 38.6-36.6 79.3-36.6 115.2 0 57.3 17.8 111.5 58.5 151.4 40.7 39.9 101.4 62.5 181.5 62.5s140.8-22.6 181.5-62.5c40.7-39.8 58.5-94.1 58.5-151.4 0-35.8-15.9-76.5-36.6-115.2-21.1-39.4-48.9-79.8-76.3-115.9-27.5-36.2-54.9-68.6-75.4-91.9-10.3-11.7-18.8-21.1-24.8-27.6-3-3.3-5.4-5.8-7-7.5-.8-.9-1.4-1.5-1.9-2l-.6-.7 0 0 0 0-8.4 8 0 0zM233.4 73.9c2.3-3.3 4.5-6.4 6.6-9.3 2.1 2.9 4.3 6 6.6 9.3 15.5 22.1 36.2 52.8 56.8 87 20.7 34.3 41.1 71.8 56.2 107.6 15.4 36.3 24.4 68.7 24.4 93.5 0 49-11.8 90.5-34.7 119.3-22.2 27.9-56.9 46.5-109.3 46.5s-87.1-18.6-109.3-46.5c-22.9-28.8-34.7-70.3-34.7-119.3 0-24.8 9-57.2 24.4-93.5 15.1-35.8 35.5-73.3 56.2-107.6 20.6-34.2 41.3-64.9 56.8-87z"],
    "shop": [576, 576, ["store-alt"], "f54f", "M480 305.3L480 480c0 26.5-21.5 48-48 48l-288 0c-26.5 0-48-21.5-48-48l0-174.7c4.9 .5 9.9 .7 15 .7 11.8 0 22.8-1.3 33-3.9l0 153.9 288 0 0-153.9c10.2 2.6 21.2 3.9 33 3.9 5.1 0 10.1-.2 15-.7zm-99.6-34.6c1.2 1.3 2.3 2.7 3.6 3.9l0 109.4-192 0 0-109.4c1.2-1.3 2.4-2.6 3.6-3.9 .9-1 1.7-2 2.5-3 1.1 1.4 2.3 2.7 3.5 4.1 20.1 22.3 49.6 34.3 86.5 34.3s66.4-12 86.5-34.3c1.2-1.3 2.3-2.7 3.5-4.1 .8 1 1.6 2 2.5 3zM74.3 13.8L10.1 142.1C3.5 155.4 0 170.1 0 185l0 10c0 28.1 7.6 56.2 26.8 77.6 6.2 6.9 13.3 12.7 21.2 17.5L48 480c0 53 43 96 96 96l288 0c53 0 96-43 96-96l0-189.9c7.9-4.8 15-10.7 21.2-17.5 19.2-21.3 26.8-49.4 26.8-77.6l0-10c0-14.9-3.5-29.6-10.1-42.9L501.7 13.8 495.7 0 80.3 0 74.3 13.8zM111.7 48l352.7 0 45.5 103.6c1.1 2.5 1.7 4.3 2 5.7 3.5 16.7 .6 29.4-5.5 37.5-5.7 7.5-17.5 15.2-41.3 15.2-24.5 0-39.2-8.2-48.1-18.6-9.4-11-14.9-27.4-14.9-47.4l-48 0c0 20.8-5.6 36.9-15.2 47.6-9.2 10.2-24.6 18.4-50.8 18.4s-41.6-8.2-50.8-18.4C227.6 180.9 222 164.8 222 144l-48 0c0 20-5.4 36.4-14.9 47.4-8.9 10.4-23.6 18.6-48.1 18.6-23.9 0-35.6-7.7-41.3-15.2-6.1-8-9-20.8-5.5-37.5 .3-1.4 .9-3.2 2-5.7L111.7 48z"],
    "film": [576, 576, [127902, 62368, "film-alt", "film-simple"], "f008", "M0 0L0 48c26.5 0 48 21.5 48 48l0 480 480 0 0-480c0-53-43-96-96-96L0 0zM131.2 48L168 48c26.5 0 48 21.5 48 48l0 24-72 0 0-24c0-17.5-4.7-33.9-12.8-48zM144 168l72 0 0 96-72 0 0-96zm0 144l72 0 0 96-72 0 0-96zm0 144l72 0 0 72-72 0 0-72zM251.2 48L312 48c26.5 0 48 21.5 48 48l0 432-96 0 0-432c0-17.5-4.7-33.9-12.8-48zM408 312l72 0 0 96-72 0 0-96zm0 216l0-72 72 0 0 72-72 0zm0-264l0-96 72 0 0 96-72 0zm0-144l0-24c0-17.5-4.7-33.9-12.8-48L432 48c26.5 0 48 21.5 48 48l0 24-72 0z"],
    "comments": [576, 576, [128490, 61670], "f086", "M240 432c79.7 0 140.3-21.3 181-59.1 40.9-38 59-89.9 59-144.9S461.9 121.1 421 83.1C380.3 45.3 319.7 24 240 24S99.7 45.3 59 83.1c-40.9 38-59 89.9-59 144.9 0 40 9.5 78.4 30.6 111.1-8 48.7-13.3 81.4-16.1 98.2 13-2.2 53.3-9 120.8-20.5 30.1 10 65 15.2 104.7 15.2zM79.1 377.6l20.7-62 2.7-8.2-3.1-8c-8-20.9-12.1-45-12.1-71.4 0-45.7 12.2-84.4 36-111.4 23.3-26.5 60.4-44.6 116.8-44.6s93.4 18.1 116.8 44.6c23.8 27 36 65.7 36 111.4s-12.2 84.4-36 111.4c-23.3 26.5-60.4 44.6-116.8 44.6-38 0-69.2-5.4-94.5-14.5l-5.9-2.1-6.2 1.1-54.3 9.2zm395.2 18.9l-7.4 8.5 1.8 11.2 10.1 61.4-88.4-17.7-6.6-1.3-6.4 2.3c-39.6 14.6-88.2 23-146.8 23-39.5 0-74.4-3.8-105.1-10.8L114.7 520c34.6 7.9 73.2 12 115.7 12 60.2 0 112.4-8.3 156.9-23.7 90.9 18.2 140.9 28.2 149.9 30-2.4-14.4-8.8-54.1-19.5-119 40.1-50.4 58.3-113 58.3-179.3l-48 0c0 61-17.6 115.1-53.8 156.6z"],
    "moon": [576, 576, [127769, 9214], "f186", "M99.1 99.8c36.8-31.2 88.7-50.7 158.9-51.8 70.8 1.3 118.7 27.7 149.8 67.9 32.6 42.2 48.7 102.3 48.7 172s-16.1 129.8-48.7 172c-31 40.2-79 66.6-149.8 67.9-70.2-1.1-122.1-20.6-158.9-51.8 14.2 2.5 29.3 3.8 45.4 3.8 4.1 0 8.1-.1 12-.2l0 .2c80.4 0 138.3-19.7 176.2-55.9 38-36.3 51.8-85.6 51.8-136.1s-13.8-99.8-51.8-136.1C294.8 115.7 236.9 96 156.5 96l0 .2c-3.9-.2-7.9-.2-12-.2-16.1 0-31.2 1.3-45.4 3.8zM252.5 .2C125.1 3.6 42.8 62.2 3.5 150.3l38.2 27.5c21.9-20.1 54.9-33.8 102.8-33.8 53.4 0 88.4 16.9 110.2 41.2 22.3 24.8 33.8 60.5 33.8 102.8S277 366 254.7 390.8c-21.9 24.4-56.8 41.2-110.2 41.2-47.9 0-80.9-13.6-102.8-33.8L3.5 425.7c39.3 88.2 121.6 146.7 249 150.1l0 .2c1.9 0 3.8 0 5.6 0 2.1 0 4.2 0 6.4 0 97.8 0 170.8-31.5 219.2-85.3 47.9-53.4 68.8-125.7 68.8-202.7S531.6 138.7 483.6 85.3c-48.3-53.8-121.4-85.3-219.2-85.3-2.1 0-4.3 0-6.4 0-1.9 0-3.7 0-5.6 0l0 .2zM216.5 252c0-26.5-14.4-48-48-48s-48 21.5-48 48 14.4 48 48 48 48-21.5 48-48zm-144 96c25.2 0 36-16.1 36-36s-10.8-36-36-36-36 16.1-36 36 10.8 36 36 36z"],
    "plane": [576, 576, [], "f072", "M252.7 0l-115.4 0 7.5 29.8 40.5 162.2-11.3 0-8.4-11.2c-28.9-38.6-76.6-58.3-124.3-51.5-13.8 2-27.6 3.9-41.3 5.9L0 440.8c13.7 2 27.5 3.9 41.3 5.9 47.7 6.8 95.3-12.9 124.3-51.5l8.4-11.2 11.3 0-40.5 162.2-7.5 29.8 115.4 0c45.5 0 87-25.7 107.3-66.3L422.8 384 480 384c53 0 96-43 96-96s-43-96-96-96L422.8 192 360 66.3C339.7 25.7 298.1 0 252.7 0zM432 240c26.5 0 48 21.5 48 48s-21.5 48-48 48l-86.8 0-6.6 13.3-69.5 138.9c-12.2 24.4-37.1 39.8-64.4 39.8l-5.9 0 40.5-162.2 7.5-29.8-96.7 0c-3.4 4.5-11 14.7-22.8 30.4-16.6 22.2-43 34.6-70.4 33.5l37.7-103.8 3-8.2-3-8.2-37.7-103.8c27.3-1 53.7 11.4 70.4 33.5 11.8 15.8 19.4 25.9 22.8 30.4l96.7 0-7.5-29.8-40.5-162.2 5.9 0c27.3 0 52.2 15.4 64.4 39.8l69.5 138.9 6.6 13.3 86.8 0z"],
    "images": [576, 576, [], "f302", "M528 48l-384 0 0-48 432 0 0 432-48 0 0-384zM0 96l480 0 0 480-480 0 0-480zm432 48l-384 0 0 236.6c22.3-20.3 52.4-32.7 89.7-32.7 15.7 0 29.2 3 39.9 5.7 2.6 .7 4.9 1.3 7 1.8l0 0c7.5 2 12.3 3.2 17.1 3.6 4.5 .4 7.1-.2 9.9-2.1 3.8-2.5 9.8-8.4 18-22.9 2.7-4.8 4.9-9.2 7.5-14.2l0 0 0 0c1.8-3.6 3.8-7.5 6.1-12 5.1-9.7 11.3-20.5 19.4-30.5 17.1-21.1 41.9-37.3 79.7-37.3 36.7 0 66.9 10.2 89.7 28.9L432 144zm0 336l0-73c0-29.7-7.6-53.9-21.4-70.3-13.2-15.7-34.4-27-68.3-27-32.7 0-54.5 18.7-70.8 47.8-19.6 34.9-39.7 53.6-66.5 59.7-12.1 2.7-24 2.5-34.5 2-3.3-.2-6.5-.4-9.6-.6-7.5-.5-14.7-.9-23.1-.9-35.5 0-56.8 9.6-69.4 22.7-9 9.3-15.4 22.4-18.4 39.6L432 480zM132 264c-25.2 0-36-16.1-36-36s10.8-36 36-36 36 16.1 36 36-10.8 36-36 36z"],
    "bag-shopping": [528, 576, ["shopping-bag"], "f290", "M264 0c-44.1 0-76.4 14.8-96.4 42.9-18.8 26.4-23.6 60.6-23.6 93.1l0 32-80.3 0-3.3 20.1-46 276.2C4.6 522.7 49.7 576 109 576l310 0c59.3 0 104.4-53.3 94.7-111.8l-46-276.2-3.3-20.1-80.3 0 0-32c0-32.5-4.9-66.7-23.6-93.1-20-28.1-52.2-42.9-96.4-42.9zm48 168l-96 0 0-32c0-30 3.7-53 11.6-67.9 3.7-7 8.1-11.7 13.2-14.7s12.4-5.4 23.2-5.4 18.1 2.3 23.2 5.4 9.5 7.7 13.2 14.7C308.4 83 312 106 312 136l0 32zM168 528c-26.5 0-47.9-21.5-47.9-48l0-264 288 0 0 264c0 26.5-21.5 48-48 48L168 528z"],
    "phone": [576, 576, [128222, 128379], "f095", "M156.4 2.1l17 17 129.5 129.5 16.5 16.5c-1.6 1.7-30.3 32.2-86.2 91.6 19.3 37 49.4 67.2 86.3 86.5l89-89 165.9 165.9-106.8 106.8C419.1 575.2 346 589.2 283 562.7 162.1 511.6 64.8 414.3 13.8 293.4-12.8 230.5 1.2 157.3 49.6 108.9l69.5-69.5 0 0c14.2-14.2 26.6-26.6 37.4-37.4zm222 349.9c-28.9 28.9-45.1 45.1-48.5 48.5L315 394.1c-59.6-25.5-107.1-73-132.6-132.6L176.2 247c2.9-3.1 18.6-19.8 47.2-50.1l-96.9-96.9-10.5 10.5c-34.5 34.5-44.6 86.8-25.5 131.9 46.2 109.4 134.3 197.5 243.7 243.7 45 19 97.2 9 131.7-25.4l.2-.2 10.5-10.5-98.1-98.1z"],
    "leaf": [576, 576, [], "f06c", "M552.5 48l0-24-24 0 0 24 24 0zM129.3 481.1c46.3 39.7 95.4 57 143.9 54.4 54.1-2.9 103.5-30.4 143.9-70.7 69.4-69.4 102.6-175.4 118.8-260.4 8.2-43.1 12.3-82 14.4-110.1 1-14.1 1.5-25.5 1.8-33.5 .1-4 .2-7.1 .2-9.2 0-1.1 0-1.9 0-2.5l0-.7 0-.2 0-.1 0 0-24 0c0-24 0-24 0-24l-.1 0-.2 0-.7 0c-.6 0-1.4 0-2.5 0-2.2 0-5.3 .1-9.2 .2-8 .3-19.4 .8-33.5 1.8-28.1 2.1-67 6.2-110.1 14.4-83.4 15.9-186.8 48.1-256.2 114.7l0 0c-.7 .7-1.4 1.4-2 2.1-.7 .7-1.4 1.4-2.1 2.1-40.4 40.4-67.8 89.8-70.8 143.9-2.6 48.5 14.7 97.7 54.4 143.9L7.5 535 41.4 569 129.3 481.1zm67.5-67.5l29.6-29.6 134.1 0 0-48-86.1 0 151-151-33.9-33.9-151 151 0-86.1-48 0 0 134.1-29.7 29.7c-34.2-38.2-49.8-71-52.7-99-3.1-30.2 8.4-59.6 37.7-89.7 59-57.5 151.6-87.9 233.4-103.5 40.8-7.8 77.8-11.7 104.6-13.7 6.6-.5 12.6-.8 17.9-1.1-.3 5.3-.6 11.2-1.1 17.9-2 26.8-5.9 63.8-13.7 104.6-14.5 75.7-41.6 160.9-91.3 219.8l-.1-.1c-31.1 31.1-64.3 46.4-98.6 45.5-29.9-.8-64.3-14.1-102.1-46.9z"],
    "universal-access": [576, 576, [], "f29a", "M433.4 115.5C464.4 157.8 480 218.2 480 288s-15.6 130.2-46.6 172.5C403.1 501.7 356.5 528 288 528s-115.1-26.3-145.4-67.5C111.6 418.2 96 357.8 96 288s15.6-130.2 46.6-172.5C172.9 74.3 219.5 48 288 48s115.1 26.3 145.4 67.5zM288 0C190.2 0 117.2 31.5 68.8 85.3 20.9 138.7 0 211 0 288S20.9 437.3 68.8 490.7C117.2 544.5 190.2 576 288 576s170.8-31.5 219.2-85.3C555.1 437.3 576 365 576 288S555.1 138.7 507.2 85.3C458.8 31.5 385.8 0 288 0zm0 120c-13.8 0-26.8 4.6-36.2 15-8.9 9.9-11.8 22.3-11.8 33s2.9 23.1 11.8 33c9.3 10.4 22.4 15 36.2 15s26.8-4.6 36.2-15c8.9-9.9 11.8-22.3 11.8-33s-2.9-23.1-11.8-33c-9.3-10.4-22.4-15-36.2-15zM245.5 283.1c-2.2 46.5-12.2 85-22.1 112.7-5.6 15.7-11.2 27.8-15.3 35.9-2 4-3.7 7.1-4.8 9-.6 1-1 1.7-1.2 2.1l-.3 .4 0 .1 0 0 0 0 0 0 20.2 12.9c20.2 12.9 20.2 12.9 20.2 12.9l0 0 0 0 .1-.1 .2-.3 .5-.9c.4-.7 1.1-1.8 1.8-3.1 1.5-2.6 3.6-6.4 6-11.2 4.9-9.7 11.3-23.6 17.7-41.3 7.3-20.2 14.5-45.5 19.4-74.9 4.9 29.4 12.1 54.7 19.4 74.9 6.4 17.7 12.8 31.7 17.7 41.3 2.5 4.8 4.5 8.6 6 11.2 .8 1.3 1.4 2.3 1.8 3.1l.5 .9 .2 .3 .1 .1 0 0 0 0 20.2-12.9c20.2-12.9 20.2-12.9 20.2-12.9l0 0-.3-.4c-.3-.4-.7-1.1-1.2-2.1-1.1-1.9-2.8-5-4.8-9-4.1-8.1-9.7-20.2-15.3-35.9-9.9-27.6-19.9-66.1-22.1-112.7 45.3-10.5 79.8-35.4 94.5-50.1L391 199c-12.9 12.9-53.6 41-103 41s-90.1-28-103-41L151 233c14.7 14.7 49.2 39.6 94.5 50.1z"],
    "hourglass": [480, 576, [9203, 62032, "hourglass-empty"], "f254", "M0 24l480 0 0 48-48 0 0 40c0 52.4-13.6 102.6-45.7 140.1-12.3 14.4-27 26.5-44.1 35.9 17 9.5 31.7 21.5 44.1 35.9 32.1 37.5 45.7 87.6 45.7 140.1l0 40 48 0 0 48-480 0 0-48 48 0 0-40c0-52.4 13.6-102.6 45.7-140.1 12.3-14.4 27-26.5 44.1-35.9-17-9.5-31.7-21.5-44.1-35.9-32.1-37.5-45.7-87.6-45.7-140.1l0-40-48 0 0-48zM144 72l0 56c0 5.5 .1 10.8 .4 16l191.1 0c.3-5.2 .4-10.5 .4-16l0-56-192 0zM336 482.2l-10.2-11.7c-45.4-51.9-126.2-51.9-171.6 0l-10.2 11.7 0 21.8 192 0 0-21.8zm-2.2-68.7c-3.5-26.3-11-48.5-22.2-65.2-15.1-22.4-37.6-36.3-71.6-36.3s-56.5 13.9-71.6 36.3c-11.2 16.7-18.8 38.9-22.2 65.2 55.9-39.8 131.8-39.8 187.7 0zM311.6 227.7c6.7-10 12.2-22 16.2-35.7l-175.5 0c4 13.7 9.4 25.7 16.2 35.7 15.1 22.4 37.6 36.3 71.6 36.3s56.5-13.9 71.6-36.3z"],
    "fish": [576, 576, [128031], "f578", "M528 288c0 42.3-11.5 78-33.8 102.8-21.9 24.4-56.8 41.2-110.2 41.2-30.4 0-67.7-13.8-106.8-35.7-38.4-21.5-75.7-49.1-105.3-73.3l-12-9.8-.2 .1-.2-.2-1.1 .8-12.4 6.2-98 49 0-162.3 98 49 12.4 6.2 1.1 .8 .2-.2 .2 .1 12-9.8c29.6-24.1 66.9-51.8 105.3-73.3 39.1-21.8 76.4-35.7 106.8-35.7 53.4 0 88.4 16.9 110.2 41.2 22.3 24.8 33.8 60.5 33.8 102.8zm48 0c0-62.4-13.1-123.3-44.1-168.6-31.9-46.6-81.8-74.9-149.1-71.4-44.6 2.3-91.5 30.5-132 62.3-35.2 27.5-68.9 60.3-96.8 89-90.1-66.1-141.4-103.7-154-112.9L0 489.6c12.5-9.2 63.9-46.8 154-112.9 27.9 28.7 61.6 61.4 96.8 89 40.6 31.7 87.4 60 132 62.3 67.3 3.4 117.2-24.8 149.1-71.4 31-45.2 44.1-106.1 44.1-168.6zM408 312c33.6 0 48-21.5 48-48s-14.4-48-48-48-48 21.5-48 48 14.4 48 48 48z"],
    "list": [528, 576, ["list-squares"], "f03a", "M528 120l0 25.9-25.8-2-312-24 0-47.9 312-24 25.8-2 0 73.9zM72 144c-33.6 0-48-21.5-48-48s14.4-48 48-48 48 21.5 48 48-14.4 48-48 48zm0 192c-33.6 0-48-21.5-48-48s14.4-48 48-48 48 21.5 48 48-14.4 48-48 48zm48 144c0 26.5-14.4 48-48 48s-48-21.5-48-48 14.4-48 48-48 48 21.5 48 48zM528 337.9l-25.8-2-312-24 0-47.9 312-24 25.8-2 0 99.8zM528 504l0 25.9-25.8-2-312-24 0-47.9 312-24 25.8-2 0 73.9z"],
    "headphones": [576, 576, [127911, 62863, "headphones-alt", "headphones-simple"], "f025", "M288 72c-68.5 0-115.1 26.3-145.4 67.5-27.4 37.3-42.8 88.8-46 148.5l11.4 0c43.2 0 77.2 14 100.2 39.6 22.6 25.1 31.8 58.5 31.8 92.4s-9.2 67.3-31.8 92.4C185.2 538 151.2 552 108 552L0 552 0 312C0 235 20.9 162.7 68.8 109.3 117.2 55.5 190.2 24 288 24s170.8 31.5 219.2 85.3C555.1 162.7 576 235 576 312l0 240-108 0c-43.2 0-77.2-14-100.2-39.6-22.6-25.1-31.8-58.5-31.8-92.4s9.2-67.3 31.8-92.4c23-25.6 57-39.6 100.2-39.6l11.4 0c-3.2-59.6-18.6-111.1-46-148.5-30.3-41.2-76.9-67.5-145.4-67.5zM427.5 359.7C415 373.6 408 394.3 408 420s7 46.4 19.5 60.3c10.5 11.7 27 21 52.5 23.2l0-167c-25.5 2.2-41.9 11.4-52.5 23.2zM96 503.5c25.5-2.2 41.9-11.4 52.5-23.2 12.5-13.9 19.5-34.6 19.5-60.3s-7-46.4-19.5-60.3c-10.5-11.7-27-21-52.5-23.2l0 167z"],
    "bus": [576, 576, [128653], "f207", "M384 456l-239.2 0-.3-144 286.9 0-.3 144-47.2 0zm142.9 24.1l.4-168.1 48.7 0 0-48-48.6 0 .4-167.8C528 43.1 484.9 0 431.8 0L144.2 0C91.1 0 48 43.1 48.2 96.2l.4 167.8-48.6 0 0 48 48.7 0 .4 168.1 .1 23.9 70.8 0 0 36c0 19.9 16.1 36 36 36l24 0c19.9 0 36-16.1 36-36l0-36 144 0 0 36c0 19.9 16.1 36 36 36l24 0c19.9 0 36-16.1 36-36l0-36 70.8 0 .1-23.9zM431.8 144l-.2 120-287.1 0-.2-120 287.5 0zm.1-48L144.1 96c0-26.5 21.5-48 48-48l191.7 0c26.5 0 48 21.5 48 48zM264 384c0-19.9-10.8-36-36-36s-36 16.1-36 36 10.8 36 36 36 36-16.1 36-36zm84 36c25.2 0 36-16.1 36-36s-10.8-36-36-36-36 16.1-36 36 10.8 36 36 36z"],
    "quote-left": [576, 576, [8220, "quote-left-alt"], "f10d", "M426.2 182c-5.8 17.3-9.8 37.6-12.6 60.5 9.5-1.7 19.7-2.5 30.4-2.5 43.2 0 77.2 14 100.2 39.6 22.6 25.1 31.8 58.5 31.8 92.4s-9.2 67.3-31.8 92.4C521.2 490 487.2 504 444 504s-77.2-14-100.2-39.6c-22.6-25.1-31.8-58.5-31.8-92.4 0-85.4 11.8-159.4 41.6-212.7 15.1-27 35.1-49.2 60.7-64.4 25.7-15.3 55.7-22.9 89.7-22.9l0 48c-22.4 0-37.7 5.9-49 15.3-11.7 9.7-21.3 24.8-28.7 46.7zM415.9 439c2.8 6.6 6 10.3 9.3 12.5 3.4 2.3 8.9 4.4 18.8 4.4s15.4-2.2 18.8-4.4c3.4-2.3 6.6-6 9.3-12.5 6.1-14.5 7.9-36.8 7.9-67s-1.8-52.6-7.9-67c-2.8-6.6-6-10.3-9.3-12.5-3.4-2.3-8.9-4.4-18.8-4.4s-15.4 2.2-18.8 4.4c-3.4 2.3-6.6 6-9.3 12.5-6.1 14.5-7.9 36.8-7.9 67s1.8 52.6 7.9 67zM103.9 305c-6.1 14.5-7.9 36.8-7.9 67s1.8 52.6 7.9 67c2.8 6.6 6 10.3 9.3 12.5 3.4 2.3 8.9 4.4 18.8 4.4s15.4-2.2 18.8-4.4c3.4-2.3 6.6-6 9.3-12.5 6.1-14.5 7.9-36.8 7.9-67s-1.8-52.6-7.9-67c-2.8-6.6-6-10.3-9.3-12.5-3.4-2.3-8.9-4.4-18.8-4.4s-15.4 2.2-18.8 4.4c-3.4 2.3-6.6 6-9.3 12.5zM192 72l0 48c-22.4 0-37.7 5.9-49 15.3-11.7 9.7-21.3 24.8-28.7 46.7-5.8 17.3-9.8 37.6-12.6 60.5 9.5-1.7 19.7-2.5 30.4-2.5 43.2 0 77.2 14 100.2 39.6 22.6 25.1 31.8 58.5 31.8 92.4s-9.2 67.3-31.8 92.4C209.2 490 175.2 504 132 504S54.8 490 31.8 464.4C9.2 439.3 0 405.9 0 372 0 286.6 11.8 212.6 41.6 159.3 56.7 132.2 76.7 110.1 102.3 94.9 128 79.6 158 72 192 72z"],
    "martini-glass": [528, 576, [127864, "glass-martini-alt"], "f57b", "M264 72c-53.4 0-98.1 1.9-129.2 10.8-15.3 4.4-25 9.8-30.7 15.5-5 5-8.1 11.4-8.1 21.7s3.1 16.6 8.1 21.7c5.7 5.7 15.4 11.2 30.7 15.5 31.1 8.8 75.8 10.8 129.2 10.8s98.1-1.9 129.2-10.8c15.3-4.4 25-9.8 30.7-15.5 5-5 8.1-11.4 8.1-21.7s-3.1-16.6-8.1-21.7c-5.7-5.7-15.4-11.2-30.7-15.5-31-8.8-75.8-10.8-129.2-10.8zm236.2-9.3C517.5 76.7 528 95.9 528 120l0 2.3c0 56.2-28.1 108.7-74.9 139.8l-165.1 110 0 35.9 12.2 0c38.4 0 68.7 8.9 90.8 27.3 22.2 18.5 32.8 43.7 37.4 69.7 1.9 11 4.7 26.7 8.3 47L91.4 552c3.6-20.3 6.4-36 8.3-47 4.6-26 15.2-51.2 37.4-69.7 22.1-18.4 52.4-27.3 90.8-27.3l12.2 0 0-34.5-165.7-111.4C27.9 231 0 178.7 0 122.7L0 120C0 95.9 10.5 76.7 27.8 62.7 44.1 49.6 65.7 41.6 89 36.3 135.4 25.7 198.1 24 264 24s128.6 1.7 175 12.3c23.2 5.3 44.9 13.3 61.2 26.4zM264 216c-54.2 0-106.2-1.2-148.8-7.5 7.2 11.1 16.4 21 27.1 29.2L263 329.9 395.2 230.1c8.2-6.2 15.3-13.7 20.9-22-43.2 6.7-96.5 8-152.1 8zm91.9 288c-3.2-15.2-8.6-26-15.9-33.3-8.1-8.1-21.5-14.7-45.9-14.7l-60.3 0c-24.4 0-37.8 6.6-45.9 14.7-7.3 7.3-12.7 18.1-15.9 33.3l183.9 0z"],
    "rectangle-wide": [576, 576, [], "f2fc", "M24 72l-24 0 0 432 576 0 0-432-552 0zm72 48l432 0 0 288-432 0 0-288z"],
    "arrow-up-right": [528, 576, [], "e09f", "M528 228l0-8.6-5.5-6.7-114-138-16.8-20.3c-27.3 27.3-55.4 55.4-60.4 60.4 .7 .7 36.4 33.2 106.8 97.5L257 202.2c-113.5-6.3-209 84-209 197.7l0 80.1 84 0 0-80.5c0-63.5 49.4-115.9 112.7-119.8l192.9-11.7c-70.1 64-105.6 96.4-106.4 97.1 25.5 25.5 55 55 60.4 60.4l16.8-20.3 114-138 5.5-6.7 0-32.6z"],
    "angle-down": [480, 576, [8964], "f107", "M42.2 222L25.2 205 7 223.2 26.4 240.1 42.2 222zm30-30l18.1-15.8-16.9-19.3-18.1 18.1 17 17zm366 30l15.8 18.1 19.4-16.9-18.2-18.2-17 17zm-30-30l17-17-18.1-18.1-16.9 19.3 18.1 15.8zm-156 192l0 24 9 0 6.8-5.9-15.8-18.1zm-24 0l-15.8 18.1 6.8 5.9 9 0 0-24zm30.1-15.8l-168-192-36.1 31.6 168 192 36.1-31.6zM55.2 175l-30 30 33.9 33.9 30-30-33.9-33.9zm203 224.8l168-192-36.1-31.6-168 192 36.1 31.6zM391.2 209l30 30 33.9-33.9-30-30-33.9 33.9zm-151 199l12 0 0-48-12 0 0 48zm27.8-5.9l186-162-31.5-36.2-186 162 31.5 36.2zM240.2 360l-12 0 0 48 12 0 0-48zm3.8 5.9l-186-162-31.5 36.2 186 162 31.5-36.2z"],
    "chart-pie": [576, 576, ["pie-chart"], "f200", "M142.6 115.5C169.2 79.3 208.4 54.6 264 49.1l0 228.9-143.5 143.5c-16.3-37.4-24.5-83-24.5-133.6 0-69.8 15.6-130.2 46.6-172.5zm2.9 348.8L297.9 312 479.4 312c-3.2 59.6-18.6 111.1-46 148.5-30.3 41.2-76.9 67.5-145.4 67.5-66.3 0-112.1-24.7-142.4-63.6zM433.4 115.5c27.4 37.3 42.8 88.8 46 148.5L312 264 312 49.1c55.6 5.5 94.8 30.2 121.4 66.4zM288 0C190.2 0 117.2 31.5 68.8 85.3 20.9 138.7 0 211 0 288S20.9 437.3 68.8 490.7C117.2 544.5 190.2 576 288 576s170.8-31.5 219.2-85.3C555.1 437.3 576 365 576 288S555.1 138.7 507.2 85.3C458.8 31.5 385.8 0 288 0z"],
    "inbox": [528, 576, [], "f01c", "M120 24l-13.9 0-6.9 12.1-96 168-3.2 5.5 0 246.4c0 53 43 96 96 96l336 0c53 0 96-43 96-96l0-246.4-3.2-5.5-96-168-6.9-12.1-301.9 0zM476.4 216l-139.2 0-1.5 22.4c-1.6 23.4-8.6 41.7-19.6 53.8-10.4 11.5-26.6 19.9-52.1 19.9s-41.7-8.3-52.1-19.9c-11-12.1-17.9-30.4-19.5-53.8l-1.5-22.4-139.2 0 82.3-144 260.1 0 82.3 144zM48 288l96.4 0 0 .9 0 .7c2.1 30.6 11.6 60.3 31.8 82.7 20.8 23 50.6 35.6 87.7 35.6s66.9-12.7 87.7-35.6c20.3-22.4 29.8-52.1 31.8-82.7l0-.7 0-.7 0-.2 96.4 0 0 120c0 26.5-21.5 48-48 48L96 456c-26.5 0-48-21.5-48-48l0-120z"],
    "credit-card": [576, 576, [128179, 62083, "credit-card-alt"], "f09d", "M96 72C43 72 0 115 0 168L0 408c0 53 43 96 96 96l384 0c53 0 96-43 96-96l0-240c0-53-43-96-96-96L96 72zm336 48c26.5 0 48 21.5 48 48l0 24-384 0 0-24c0-26.5 21.5-48 48-48l288 0zM96 408l0-120 384 0 0 120c0 26.5-21.5 48-48 48l-288 0c-26.5 0-48-21.5-48-48zm48-24l168 0 0-48-168 0 0 48z"],
    "wand-magic-sparkles": [576, 576, ["magic-wand-sparkles"], "e2ca", "M300.2 72c25.2 0 36-16.1 36-36s-10.8-36-36-36-36 16.1-36 36 10.8 36 36 36zm155-49.4l-17-17-17 17c-175 175-293 293-354 354l0 0-39.3 39.3c-37.3 37.3-36.4 98.1 2 134.2 37.2 35 95.6 33.7 131.2-2.9l156.2-160.8 233.9-233.9 17-17-17-17-96-96zm-354 387.9c83-83 157-157 221.8-221.8l62.1 62.1-221.8 221.8c-17.1 17.1-44.9 17.1-62.1 0s-17.1-44.9 0-62.1zM356.9 154.8l63.3-63.3 62.1 62.1-63.3 63.3-62.1-62.1zM120.2 142.1a22.1 22.1 0 1 1 0-44.2 22.1 22.1 0 1 1 0 44.2zM88.9 52.8c-4.1 17.9-18.1 31.9-36 36l-34.2 7.9 0 46.8 34.2 7.9c17.9 4.1 31.9 18.1 36 36l7.9 34.2 46.8 0 7.9-34.2c4.1-17.9 18.1-31.9 36-36l34.2-7.9 0-46.8-34.2-7.9c-17.9-4.1-31.9-18.1-36-36l-7.9-34.2-46.8 0-7.9 34.2zM478.3 456a22.1 22.1 0 1 1 -44.2 0 22.1 22.1 0 1 1 44.2 0zM432.8 354.6l-7.9 34.2c-4.1 17.9-18.1 31.8-36 36l-34.2 7.9 0 46.8 34.2 7.9c17.9 4.1 31.9 18.1 36 36l7.9 34.2 46.8 0 7.9-34.2c4.1-17.9 18.1-31.8 36-36l34.2-7.9 0-46.8-34.2-7.9c-17.9-4.1-31.8-18.1-36-36l-7.9-34.2-46.8 0zM312.2 540c0-19.9-10.8-36-36-36s-36 16.1-36 36 10.8 36 36 36 36-16.1 36-36z"],
    "folders": [576, 576, [], "f660", "M96 72l113.6 0c42.1 0 80.9 22.8 101.4 59.7l6.9 12.3 210.1 0 0 288c26.5 0 48-21.5 48-48l0-288-230.6 0c-30.3-44.8-81.1-72-135.8-72L96 24 96 72zM0 120L0 432c0 53 43 96 96 96l288 0c53 0 96-43 96-96l0-240-193.9 0-12.6-22.6c-16.9-30.5-49.1-49.4-83.9-49.4L0 120zM408 432c0 26.5-21.5 48-48 48l-216 0c-26.5 0-48-21.5-48-48l0-264 62 0c17.6 0 33.7 9.6 42.1 25 14.5 26.6 23.1 42.3 25.6 47l182.2 0 0 192z"],
    "star": [576, 576, [11088, 61446], "f005", "M310 13.3l-43 0-75 150.9-170.6 22-13.9 40.8 116.9 116.9-39.4 191.8 35.9 25.4 167.6-101 167.6 101 35.9-25.4-39.4-191.8 116.9-116.9-13.9-40.8-170.6-22-74.9-150.9zM242.2 212.9l46.2-121.4 46.2 121.4 5.7 15 16 .5 130 3.7-98.9 79.2-12.8 10.3 4.9 15.7 44.1 140.5-120.9-89-14.2-10.5-14.2 10.5-120.9 89 44.1-140.5 4.9-15.7-12.8-10.3-98.9-79.2 130-3.7 16-.5 5.7-15z"],
    "flag": [528, 576, [127988, 61725], "f024", "M121.7 76.6L96 80.1 96 369 115.3 366.4c57.5-7.8 115.8 6.8 162.8 40.8 37 26.8 82.9 38.3 128.2 32.2l25.7-3.5 0-288.9-19.3 2.6c-57.5 7.8-115.8-6.8-162.8-40.8-37-26.8-82.9-38.3-128.2-32.2zm0 337.3L96 417.4 96 552 0 552 0 44.7c1.6-.2 40-5.4 115.3-15.6 57.5-7.8 115.8 6.8 162.8 40.8 37 26.8 82.9 38.3 128.2 32.2 74.2-10.1 114.8-15.6 121.7-16.5l0 385.8c-1.6 .2-40 5.4-115.3 15.6-57.5 7.8-115.8-6.8-162.8-40.8-37-26.8-82.9-38.3-128.2-32.2z"],
    "triangle-exclamation": [576, 576, [9888, "exclamation-triangle", "warning"], "f071", "M288 456c25.2 0 36-16.1 36-36s-10.8-36-36-36-36 16.1-36 36 10.8 36 36 36zm46-240l-91.9 0 22.2 145.2 47.4 0 22.2-145.2zM225.2 24L0 480 17.3 552 558.7 552 576 480 350.8 24 225.2 24zM523.9 480L52.1 480 288 94 523.9 480z"],
    "lock": [528, 576, [128274], "f023", "M264 0C318 0 356.3 18.6 379.7 52.5 402 84.7 408 126.7 408 168l0 24 120 0 0 288c0 53-43 96-96 96L96 576c-53 0-96-43-96-96l0-288 120 0 0-24C120 126.7 126 84.7 148.3 52.5 171.7 18.6 210 0 264 0zm72 192l0-24c0-38.8-4.8-69.7-16.2-90.2-5.4-9.8-12.1-16.9-20.4-21.7-8.3-4.8-19.6-8.1-35.4-8.1s-27.1 3.3-35.4 8.1c-8.3 4.8-15 11.9-20.4 21.7-11.4 20.6-16.2 51.5-16.2 90.2l0 24 144 0zM192 240l-96 0 0 240c0 26.5 21.5 48 48 48l240 0c26.5 0 48-21.5 48-48l0-240-240 0zm89.4 153.7l18.6 74.3-72 0 18.6-74.3c-21.2-6.2-30.6-24.3-30.6-45.7 0-26.5 14.4-48 48-48s48 21.5 48 48c0 21.4-9.4 39.5-30.6 45.7z"],
    "anchor": [528, 576, [9875], "f13d", "M228 108c0 12.5 3.4 21.1 8.1 26.4 4.3 4.8 12.3 9.6 27.9 9.6s23.6-4.8 27.9-9.6c4.7-5.3 8.1-13.9 8.1-26.4s-3.4-21.1-8.1-26.4C287.6 76.8 279.6 72 264 72s-23.6 4.8-27.9 9.6c-4.7 5.3-8.1 13.9-8.1 26.4zm115 61.2c-14 11.1-32.1 18.1-53.5 21.1l3.3 49.7 115.1 0 0 48-111.9 0 14.1 212.2c37.4-6.6 64.1-21.5 82.6-41.5 25.7-27.8 39.2-69.1 39.2-122.7l96 0c0 62.5-19.8 117.9-65.3 157.2-44.9 38.8-111.4 58.8-198.7 58.8S110.2 531.9 65.3 493.2C19.8 453.9 0 398.5 0 336l96 0c0 53.6 13.5 94.9 39.2 122.7 18.5 20 45.2 34.9 82.6 41.5l14.1-212.2-111.9 0 0-48 115.1 0 3.3-49.7c-21.4-3-39.4-10-53.4-21.1-19.9-15.9-29-38.1-29-61.2s9.1-45.4 29-61.2C204.3 31.4 231.3 24 264 24s59.7 7.4 79 22.8c19.9 15.9 29 38.1 29 61.2s-9.1 45.4-29 61.2z"],
    "scissors": [480, 576, [9984, 9986, 9988, "cut"], "f0c4", "M97.1 242.9c1.1 .4 2.1 .7 3.2 1.1-25.2 14.6-49.2 36.3-67 68.4-23.3 42.1-29.2 104.5-30.1 152.5-.5 24.7 .3 47 1.2 63.1 .5 8.1 1 14.6 1.3 19.2 .2 2.3 .4 4.1 .5 5.3l.1 1.4 0 .4 0 .1 0 0 0 0 23.9-2.5-23.9 2.5 43.8 10.9 189.9-282.2 189.9 282.2 43.8-10.9-23.9-2.5c23.9 2.5 23.9 2.5 23.9 2.5l0 0 0 0 0-.1 0-.4 .1-1.4c.1-1.2 .3-3 .5-5.3 .4-4.6 .9-11.1 1.3-19.2 .9-16.1 1.7-38.4 1.2-63.1-1-48-6.8-110.4-30.1-152.5-17.8-32.1-41.8-53.8-67-68.4 1.1-.4 2.2-.7 3.2-1.1 47.8-16.7 97.1-49.9 97.1-112.6 0-26.8-7.3-53.7-25.7-74.2-18.8-20.9-46.4-32.1-80.6-32.1-60.1 0-95.7 40.7-117 83.5-6.6 13.2-12.1 27.2-16.9 41.4-4.8-14.1-10.3-28.2-16.9-41.4-21.3-42.9-56.8-83.5-117-83.5-34.2 0-61.8 11.1-80.6 32.1-18.4 20.5-25.7 47.4-25.7 74.2 0 62.7 49.3 95.9 97.1 112.6zM405 335.6c17 30.8 23.2 82.4 24.1 130.2 .1 4.2 .1 8.4 .1 12.4L285 263.9c6.9 .7 14.3 1.8 21.9 3.4 35.3 7.4 74.4 25.6 98.1 68.4zM346.6 114c27.9 0 43.7 20.7 43.7 43.7 0 18.3-14 33.5-48 44.6-21.9 7.2-47.5 10.9-70.7 12.5 5.4-19.5 12.3-40.1 21.6-58.1 14.8-28.3 31.9-42.8 53.3-42.8zM75.3 335.6c23.7-42.8 62.7-61 98.1-68.4 7.7-1.6 15-2.7 21.9-3.4L51 478.2c0-4.1 .1-8.2 .1-12.4 1-47.8 7.1-99.4 24.1-130.2zM90 157.7c0-23 15.8-43.7 43.7-43.7 21.5 0 38.6 14.4 53.3 42.8 9.4 18 16.2 38.6 21.6 58.1-23.2-1.6-48.8-5.3-70.7-12.5-34-11.1-48-26.3-48-44.6z"],
    "bug": [576, 576, [], "f188", "M120 0l24 0c53 0 96 43 96 96l0 4.2c15-2.8 31-4.2 48-4.2s33 1.4 48 4.2l0-4.2c0-53 43-96 96-96l24 0 0 48-24 0c-26.5 0-48 21.5-48 48l0 18.8c27.8 12.4 50.9 30.6 69.2 53.5 21.1 26.5 35.1 58.3 42.9 92.9 18.6-6.6 31.9-24.4 31.9-45.2l0-48 48 0 0 48c0 45.1-31.1 82.9-72.9 93.2 .6 8.8 .9 17.8 .9 26.8 0 17-1.1 33.9-3.4 50.2 43.1 9.4 75.4 47.8 75.4 93.8l0 48-48 0 0-48c0-23.1-16.3-42.3-38-46.9-8.3 26-20.4 50-36.9 70.7-36.3 45.5-91.6 72.3-165.2 72.3s-128.8-26.8-165.2-72.3c-16.5-20.7-28.6-44.6-36.9-70.7-21.7 4.6-38 23.9-38 46.9l0 48-48 0 0-48c0-46 32.3-84.4 75.4-93.8-2.3-16.3-3.4-33.2-3.4-50.2 0-9 .3-17.9 .9-26.8-41.9-10.3-72.9-48.1-72.9-93.2l0-48 48 0 0 48c0 20.9 13.3 38.6 31.9 45.2 7.9-34.7 21.8-66.5 42.9-92.9 18.3-22.9 41.4-41.1 69.2-53.5L192 96c0-26.5-21.5-48-48-48l-24 0 0-48zm54.3 264l227.3 0c-5.1-26.6-13.3-49.8-24.4-68.4-19.5-32.6-48.1-51.6-89.2-51.6s-69.7 19-89.2 51.6c-11.1 18.6-19.3 41.8-24.4 68.4zM264 525.6l0-213.6-95.4 0c-.4 7.8-.6 15.8-.6 24 0 57.3 10.5 106.5 30.8 140.4 15.5 25.9 36.6 43.1 65.2 49.2zm48 0c28.6-6.1 49.7-23.3 65.2-49.2 20.3-33.9 30.8-83.1 30.8-140.4 0-8.2-.2-16.2-.6-24l-95.4 0 0 213.6z"],
    "arrow-right-from-bracket": [528, 576, ["sign-out"], "f08b", "M96 576l48 0 0-96-48 0c-26.5 0-48-21.5-48-48l0-288c0-26.5 21.5-48 48-48l48 0 0-96-48 0C43 0 0 43 0 96L0 480c0 53 43 96 96 96zM528 276l0-8.6-5.5-6.7-114-138-16.8-20.3c-27.3 27.3-55.4 55.4-60.4 60.4 .6 .6 36.5 33.3 107.5 98.1l-317.6-14.9-25.1-1.2 0 86.3 25.1-1.2 317.6-14.9c-71 64.8-106.8 97.5-107.5 98.1 25.5 25.5 55 55 60.4 60.4l16.8-20.3 114-138 5.5-6.7 0-32.6z"],
    "arrow-right-arrow-left": [576, 576, [8644, "exchange"], "f0ec", "M464.1 5.9l16.7 21.2 90 114 5.2 6.5 0 40.7-5.2 6.5-90 114-16.7 21.2-62.2-62.2c5.6-4.4 36.8-29.1 93.7-74l-278.3 16.1-25.4 1.5 0-86.8 25.4 1.5 278.3 16.1c-56.9-44.9-88.1-69.6-93.7-74 27.8-27.8 55.9-55.9 62.2-62.2zM95.2 267.1l16.7-21.2c27.8 27.8 55.9 55.9 62.2 62.2-5.6 4.4-36.8 29.1-93.7 74l278.3-16.1 25.4-1.5 0 86.8-25.4-1.5-278.3-16.1c56.9 44.9 88.1 69.6 93.7 74-27.8 27.8-55.9 55.9-62.2 62.2l-16.7-21.2-90-114-5.2-6.5 0-40.7 5.2-6.5 90-114z"],
    "arrow-up-from-line": [480, 576, [8613, "arrow-from-bottom"], "f342", "M0 72l0-48 480 0 0 48-480 0zm219.4 48l41.3 0 6.7 5.5 138 114 20.3 16.8c-27.3 27.3-55.4 55.4-60.4 60.4-.6-.6-33.3-36.5-98.1-107.5l14.9 317.6 1.2 25.1-86.3 0 1.2-25.1 14.9-317.6c-64.8 71-97.5 106.8-98.1 107.5-25.5-25.5-55-55-60.4-60.4l20.3-16.8 138-114 6.7-5.5z"],
    "battery-full": [432, 576, [128267, "battery", "battery-5"], "f240", "M144 0l-24 0 0 48-120 0 0 432c0 53 43 96 96 96l240 0c53 0 96-43 96-96l0-432-120 0 0-48-168 0zM288 96l48 0 0 384c0 26.5-21.5 48-48 48l-144 0c-26.5 0-48-21.5-48-48l0-384 72 0 0-48 96 0 0 48 24 0zm0 72l-144 0 0 288 144 0 0-288z"],
    "font": [528, 576, [], "f031", "M46.8 199.6l-46.8-7.6 0-168 528 0 0 168-46.8 7.6-23.6-70.8C451.1 109.2 432.8 96 412.1 96L348 96c-26.5 0-48 21.5-48 48l0 288.1c0 20.7 13.2 39 32.8 45.5l82.8 27.6-7.6 46.8-288 0-7.6-46.8 82.8-27.6c19.6-6.5 32.8-24.9 32.8-45.5L228 144c0-26.5-21.5-48-48-48l-64.1 0c-20.7 0-39 13.2-45.5 32.8L46.8 199.6z"],
    "language": [576, 576, [], "f1ab", "M288 96c-70.2 0-117.2 22.3-146.8 55.3-30.1 33.5-45.2 81.1-45.2 136.7 0 32 5 61.6 15.1 87.2l3.2 8.2-2.8 8.3-27.9 82 75-12.5 6.1-1 5.8 2.1c31.7 11.2 70.5 17.7 117.4 17.7 70.2 0 117.2-22.3 146.8-55.3 30.1-33.5 45.2-81.1 45.2-136.7s-15.1-103.2-45.2-136.7C405.2 118.3 358.2 96 288 96zm0 432c-48.6 0-91-6.4-127.5-18.4-85 14.2-132.2 22-141.7 23.6 2.4-14.3 8.7-52 18.8-112.9-25.9-38.7-37.6-84.4-37.6-132.3 0-65.1 21.7-126 70.5-170.5 48.6-44.3 121-69.5 217.5-69.5s168.9 25.3 217.5 69.5C554.3 162 576 222.9 576 288s-21.7 126-70.5 170.5C456.9 502.7 384.4 528 288 528zM168 264l0-48 96 0 0-48 48 0 0 48 96 0 0 48-41.4 0c-8 22.2-23.6 45.3-42.5 65.8 20.4 14.5 42.9 25.7 65.3 30.8l-10.8 46.8c-33-7.6-64.2-24.4-90.6-44.6-26.5 20.3-57.7 37-90.6 44.6l-10.8-46.8c33.6-7.8 67.4-29 93.7-54.6 14.9-14.5 26.1-29.2 33.5-42.1L168 264z"],
    "person-biking": [576, 576, [128692, "biking"], "f84a", "M323.8 39C314.9 48.9 312 61.3 312 72s2.9 23.1 11.8 33c9.3 10.4 22.4 15 36.2 15s26.8-4.6 36.2-15c8.9-9.9 11.8-22.3 11.8-33s-2.9-23.1-11.8-33c-9.3-10.4-22.4-15-36.2-15s-26.8 4.6-36.2 15zm11 116.5c-15.1-25.1-48.9-31-71.6-12.5l-73.7 60.3c-30.8 25.2-29 72.8 3.6 95.6l65.7 46c3.2 2.2 5.1 5.9 5.1 9.8l0 125.3 48 0 0-126.3c0-18.6-8.7-36.2-23.4-47.6l-29.5-22.7c-6-4.6-6.3-13.5-.7-18.5l54.5-48.5 38.6 60.1 6.8 11.3 121.6 0 0-48-94.4 0-50.7-84.5zM85 377.5c7.3-10.8 17.8-17.5 35-17.5s27.7 6.8 35 17.5c8.1 12 13 30.7 13 54.5s-4.9 42.5-13 54.5c-7.3 10.8-17.8 17.5-35 17.5s-27.7-6.8-35-17.5c-8.1-12-13-30.7-13-54.5s4.9-42.5 13-54.5zM28.9 348.1C8.3 371.1 0 401.4 0 432s8.3 60.9 28.9 83.9C50 539.3 81 552 120 552s70-12.7 91.1-36.1c20.6-23 28.9-53.3 28.9-83.9s-8.3-60.9-28.9-83.9C190 324.7 159 312 120 312s-70 12.7-91.1 36.1zM408 432c0-23.8 4.9-42.5 13-54.5 7.3-10.8 17.8-17.5 35-17.5s27.7 6.8 35 17.5c8.1 12 13 30.7 13 54.5s-4.9 42.5-13 54.5c-7.3 10.8-17.8 17.5-35 17.5s-27.7-6.8-35-17.5c-8.1-12-13-30.7-13-54.5zm139.1 83.9c20.6-23 28.9-53.3 28.9-83.9s-8.3-60.9-28.9-83.9C526 324.7 495 312 456 312s-70 12.7-91.1 36.1c-20.6 23-28.9 53.3-28.9 83.9s8.3 60.9 28.9 83.9C386 539.3 417 552 456 552s70-12.7 91.1-36.1z"],
    "globe": [576, 576, [127760], "f0ac", "M288 48c16.3 0 35.2 14.1 50.4 60.8 5.6 17.1 10.1 37.1 13.5 59.2l-127.8 0c3.4-22.2 7.9-42.1 13.5-59.2 15.2-46.6 34.1-60.8 50.4-60.8zM192 93.9c-7.1 21.8-12.5 46.9-16.4 74.1l-60.5 0c7.2-19.6 16.4-37.2 27.6-52.5 15.6-21.3 35.6-38.5 60.6-50.3-4.3 9.2-8.1 18.8-11.3 28.7zM170.5 216c-3.4 45.7-3.4 98.3 0 144l-68.3 0c-4.1-22.5-6.2-46.6-6.2-72s2.1-49.5 6.2-72l68.3 0zm5.1 192c3.9 27.3 9.3 52.3 16.4 74.1 3.2 9.8 6.9 19.5 11.3 28.7-25.1-11.8-45-29.1-60.6-50.3-11.2-15.3-20.4-32.9-27.6-52.5l60.5 0zm48.5 0l127.8 0c-3.4 22.2-7.9 42.1-13.5 59.2-15.2 46.6-34.1 60.8-50.4 60.8s-35.2-14.1-50.4-60.8c-5.6-17.1-10.1-37.1-13.5-59.2zm133.2-48l-138.7 0c-1.8-22.6-2.7-46.8-2.7-72s.9-49.4 2.7-72l138.7 0c1.8 22.6 2.7 46.8 2.7 72s-.9 49.4-2.7 72zm43.1 48l60.5 0c-7.2 19.6-16.4 37.2-27.6 52.5-15.6 21.3-35.6 38.5-60.6 50.3 4.3-9.2 8.1-18.8 11.3-28.7 7.1-21.8 12.5-46.9 16.4-74.1zm73.4-48l-68.3 0c3.4-45.7 3.4-98.3 0-144l68.3 0c4.1 22.5 6.2 46.6 6.2 72s-2.1 49.5-6.2 72zM433.4 115.5c11.2 15.3 20.4 32.9 27.6 52.5l-60.5 0c-3.9-27.3-9.3-52.3-16.4-74.1-3.2-9.8-6.9-19.5-11.3-28.7 25.1 11.8 45 29.1 60.6 50.3zM288 576c97.8 0 170.8-31.5 219.2-85.3 47.9-53.4 68.8-125.7 68.8-202.7S555.1 138.7 507.2 85.3C458.8 31.5 385.8 0 288 0S117.2 31.5 68.8 85.3C20.9 138.7 0 211 0 288S20.9 437.3 68.8 490.7C117.2 544.5 190.2 576 288 576z"],
    "arrow-left": [528, 576, [8592], "f060", "M0 300l0 9 5.9 6.8 162 186 16.9 19.4c25.3-25.3 65.1-65.1 66.3-66.3l-19.3-16.9-140-122.5 411 20.5 25.2 1.3 0-98.5-25.2 1.3-411 20.6 140-122.5 19.3-16.9C225.9 95.9 186 56 184.8 54.8l-16.9 19.4-162 186-5.9 6.8 0 33z"],
    "paw": [528, 576, [], "f1b0", "M240 96c0 11.4 3.5 16.4 6.1 18.7 3.1 2.8 8.7 5.3 17.9 5.3s14.8-2.5 17.9-5.3c2.6-2.4 6.1-7.3 6.1-18.7s-3.5-16.4-6.1-18.7c-3.1-2.8-8.7-5.3-17.9-5.3s-14.8 2.5-17.9 5.3c-2.6 2.4-6.1 7.3-6.1 18.7zm-48 0C192 67.8 198 44.1 210.8 26.8 224.2 8.7 243.5 0 264 0s39.8 8.7 53.2 26.8C330 44.1 336 67.8 336 96s-6 51.9-18.8 69.2C303.8 183.3 284.5 192 264 192s-39.8-8.7-53.2-26.8C198 147.9 192 124.2 192 96zm72 192c-33.4 0-69.4 18.5-97.7 49.7-28.2 31-46.3 71.9-46.3 112.1 0 49.7 29.2 77 58 78.2 35.6-1.2 62-28.6 62-59.6l48 0c0 31 26.4 58.4 62 59.6 28.8-1.2 58-28.4 58-78.2 0-40.2-18.1-81.1-46.3-112.1-28.3-31.2-64.3-49.7-97.7-49.7zm0-48c54.5 0 113.6 24 159.1 60.7 45.3 36.6 80.9 89.3 80.9 149.1 0 51.1-25 84.2-57.4 103.2-30.9 18.1-67.5 23-94.2 23-.7 0-1.5 0-2.2 0-.7 0-1.4 0-2.1 0-33.9 0-64.2-15.6-84-40-19.8 24.4-50.1 40-84 40-.7 0-1.4 0-2.1 0-.7 0-1.5 0-2.2 0-26.7 0-63.4-5-94.2-23-32.4-19-57.4-52-57.4-103.2 0-59.8 35.6-112.5 80.9-149.1 45.4-36.7 104.6-60.7 159.1-60.7zM54.1 186.7c3.1 2.8 8.7 5.3 17.9 5.3s14.8-2.5 17.9-5.3c2.6-2.4 6.1-7.3 6.1-18.7s-3.5-16.4-6.1-18.7c-3.1-2.8-8.7-5.3-17.9-5.3s-14.8 2.5-17.9 5.3c-2.6 2.4-6.1 7.3-6.1 18.7s3.5 16.4 6.1 18.7zM144 168c0 28.2-6 51.9-18.8 69.2-13.4 18.1-32.7 26.8-53.2 26.8s-39.8-8.7-53.2-26.8C6 219.9 0 196.2 0 168s6-51.9 18.8-69.2C32.2 80.7 51.5 72 72 72s39.8 8.7 53.2 26.8C138 116.1 144 139.8 144 168zm294.1 18.7c3.1 2.8 8.7 5.3 17.9 5.3s14.8-2.5 17.9-5.3c2.6-2.4 6.1-7.3 6.1-18.7s-3.5-16.4-6.1-18.7c-3.1-2.8-8.7-5.3-17.9-5.3s-14.8 2.5-17.9 5.3c-2.6 2.4-6.1 7.3-6.1 18.7s3.5 16.4 6.1 18.7zM528 168c0 28.2-6 51.9-18.8 69.2-13.4 18.1-32.7 26.8-53.2 26.8s-39.8-8.7-53.2-26.8C390 219.9 384 196.2 384 168s6-51.9 18.8-69.2C416.2 80.7 435.5 72 456 72s39.8 8.7 53.2 26.8C522 116.1 528 139.8 528 168z"],
    "bed": [576, 576, [128716], "f236", "M48 120c0-53 43-96 96-96l288 0c53 0 96 43 96 96l0 156.8c28.7 16.6 48 47.6 48 83.2l0 192-96 0 0-48-384 0 0 48-96 0 0-192c0-35.5 19.3-66.6 48-83.2L48 120zm432 0c0-26.5-21.5-48-48-48L144 72c-26.5 0-48 21.5-48 48l0 36.8c14.1-8.2 30.5-12.8 48-12.8l72 0c28.7 0 54.4 12.6 72 32.5 17.6-19.9 43.3-32.5 72-32.5l72 0c17.5 0 33.9 4.7 48 12.8l0-36.8zm0 120c0-26.5-21.5-48-48-48l-72 0c-26.5 0-48 21.5-48 48l0 24 168 0 0-24zm-216 0c0-26.5-21.5-48-48-48l-72 0c-26.5 0-48 21.5-48 48l0 24 168 0 0-24zM528 408l0-48c0-26.5-21.5-48-48-48L96 312c-26.5 0-48 21.5-48 48l0 48 480 0z"],
    "landmark": [576, 576, [127963], "f66f", "M312 48.8l0-48.8-48 0 0 48.8C136.6 57.3 61.9 133.2 49.8 216l-49.8 0 0 48 48 0 0 264-48 0 0 48 576 0 0-48-48 0 0-264 48 0 0-48-49.8 0C514.1 133.2 439.4 57.3 312 48.8zM177.8 137.2C199.6 112.9 234.6 96 288 96s88.4 16.9 110.2 41.2c17.9 20 28.9 46.9 32.4 78.8l-285.4 0c3.6-31.8 14.5-58.8 32.4-78.8zM432 264l0 264-66 0 0-264 66 0zm-114 0l0 264-60 0 0-264 60 0zM144 528l0-264 66 0 0 264-66 0z"],
    "music": [528, 576, [127925], "f001", "M528 48l0-28-27.7 4.3-250.9 38.6c-46.8 7.2-81.4 47.5-81.4 94.9l0 193.1c-18-10.5-39-14.9-59.9-14.9l-.1 0C80.7 336 53.4 343.4 32.6 362.1 11.3 381.2 0 409.2 0 444s11.3 62.8 32.6 81.9C53.4 544.6 80.7 552 108 552s54.6-7.4 75.4-26.1C204.7 506.8 216 478.8 216 444l0-238.2c0-23.7 17.3-43.8 40.7-47.4L480 124 480 302.9c-18-10.5-39-14.9-59.9-14.9l-.1 0c-27.3 0-54.6 7.4-75.4 26.1-21.2 19.1-32.6 47.1-32.6 81.9s11.3 62.8 32.6 81.9C365.4 496.6 392.7 504 420 504s54.6-7.4 75.4-26.1C516.7 458.8 528 430.8 528 396l0-348zM108 504c-10 0-17.8-3.5-23.6-10.9-6.4-8-12.4-23-12.4-49.1s6-41.1 12.4-49.1C90.2 387.5 98 384 107.9 384l.1 0c10 0 17.8 3.5 23.6 10.9 6.4 8 12.4 23 12.4 49.1s-6 41.1-12.4 49.1C125.8 500.5 118 504 108 504zm312-48c-10 0-17.8-3.5-23.6-10.9-6.4-8-12.4-23-12.4-49.1s6-41.1 12.4-49.1c5.8-7.3 13.6-10.9 23.6-10.9l.1 0c10 0 17.8 3.5 23.6 10.9 6.4 8 12.4 23 12.4 49.1s-6 41.1-12.4 49.1C437.8 452.5 430 456 420 456z"],
    "files": [528, 576, [], "e178", "M144 48l126.9 0c31.6 0 61.9 12.4 84.3 34.6l89.1 88C467.1 193.2 480 223.9 480 256l0 200 48 0 0-200c0-44.9-18-88-50-119.5l-89.1-88C357.5 17.4 315.1 0 270.9 0L144 0 144 48zM48 96l-24 0 0 384c0 53 43 96 96 96l312 0 0-308c0-25.8-10.4-50.5-28.7-68.5l-77.4-76C307.9 105.9 283.7 96 258.6 96L48 96zM192 528l-24 0c-26.5 0-48-21.5-48-48l0-336 120 0 0 168 96 0 0 216-144 0zm96-288l0-85.9c1.5 1.1 2.9 2.4 4.2 3.7l77.4 76c2 1.9 3.7 4 5.3 6.2l-87 0z"],
    "plus": [432, 576, [10133, 61543, "add"], "2b", "M434.1 264.1l-178.9-15.3-15.3-178.9-47.8 .3-13.2 180.6-180.6 13.2-.3 47.9 178.9 15.3 15.3 178.9 47.8-.3 13.2-180.6 180.6-13.2 .3-47.9z"],
    "box": [528, 576, [128230], "f466", "M94.2 24l339.6 0 6.9 11.9 84 144 3.3 5.6 0 270.5c0 53-43 96-96 96L96 552c-53 0-96-43-96-96l0-270.5 3.3-5.6 84-144 6.9-11.9zM96 456c0 26.5 21.5 48 48 48l240 0c26.5 0 48-21.5 48-48l0-240-336 0 0 240zm9.3-288l134.7 0 0-96-102.7 0-32 96zM288 168l134.7 0-32-96-102.7 0 0 96z"],
    "arrow-rotate-right": [528, 576, [8635, "arrow-right-rotate", "arrow-rotate-forward", "redo"], "f01e", "M479.5 218.7l-191.7 18.2 0-90 102.9 9.4c-8.9-12.4-19.3-23-31.1-31.7-23.9-17.6-55.2-28.4-95.7-28.4-59.9 0-100.4 23.4-126.9 60.3-27.3 37.9-41.1 92.4-41.1 155.6s13.8 117.7 41.1 155.6C163.6 504.6 204.1 528 264 528s100.4-23.4 126.9-60.3c27.3-37.9 41.1-92.4 41.1-155.6l96 0c0 70.3-19.1 136.6-63.1 185.6-44.4 49.5-111.5 78.2-200.9 78.2S107.6 547.2 63.1 497.8C19.1 448.8 0 382.5 0 312.1S19.1 175.5 63.1 126.5c44.4-49.5 111.5-78.2 200.9-78.2 77 0 137.2 21.4 180.6 58.5l-9.7-106.8 90 0-18.3 191.6-27.1 27.1z"],
    "arrow-down-wide-short": [528, 576, ["sort-amount-asc", "sort-amount-down"], "f160", "M193.1 496.6c45.6-57.7 70.5-89.3 74.8-94.7l62.2 62.2-21.2 16.7-114 90-6.5 5.2-40.7 0-6.5-5.2-114-90-21.2-16.7c27.8-27.8 55.9-55.9 62.2-62.2 4.3 5.4 29.2 37 74.8 94.7L126 24.9 125.1 0 210.9 0 210 24.9 193.1 496.6zM528 123.2l-27-3.4-192-24 0-47.6 192-24 27-3.4 0 102.4zM480 384l0 28.3-27.9-4.7-144-24 0-47.3 144-24 27.9-4.7 0 76.3zM312 267.7l0-103.3 27.4 3.9 168 24 0 47.5-168 24-27.4 3.9z"],
    "compress": [576, 576, [], "f066", "M392.4 222.7L543.9 90.1 563.2 73.2C537 46.9 508.1 18.1 502.9 12.9L486 32.2 353.4 183.8c5.2-67.3 8-104.5 8.6-111.8l-80.9 0 1 25 6 144 .4 9.4 37.2 37.2 9.4 .4 144 6 25 1 0-80.9c-7.2 .6-44.5 3.4-111.8 8.6zM97.1 282l-25-1c0 36.6 0 71 0 80.9 7.2-.6 44.5-3.4 111.8-8.6L32.3 485.9 13 502.8c26.2 26.2 55.1 55.1 60.3 60.3l16.9-19.3 132.6-151.6c-5.2 67.3-8 104.5-8.6 111.8l80.9 0-1-25-6-144-.4-9.4-37.2-37.2-9.4-.4-144-6z"],
    "eye-slash": [576, 576, [], "f070", "M7.5 41l528 528 33.9-33.9-77-77c40.3-37.3 65-86.5 76.4-141.2l1-4.9-.8-3.9c-8.9-74.5-32.4-140-78.4-186.9-46.7-47.7-113.5-73.2-202.3-73.2-66.9 0-121.3 14.5-164 42L41.4 7 7.5 41zM214 179.6c.7-1 1.4-2.1 2.2-3 14.6-19.5 37.2-32.6 72.3-32.6s57.7 13 72.3 32.6c15.4 20.5 23.7 50.8 23.7 87.4 0 28.2-5 52.7-14.3 71.8l-41.9-41.9c5.6-8.2 8.2-18.6 8.2-29.9 0-26.5-14.4-48-48-48-12.6 0-22.5 3-29.9 8.2L214 179.6zM416.1 381.8c28.4-31.7 40.3-74 40.3-117.8 0-27.2-4.6-53.9-14.9-77.7 3.1 2.2 6.1 4.5 9 6.8 35.9 29.1 59.1 70 70.2 118.9-10.3 45.2-30.9 83.6-62.3 112.1l-42.3-42.3zm-131.7 2.2c-32.8-1-54.2-13.7-68.3-32.5-10.9-14.6-18.3-34.2-21.7-57.5l-70.4-70.4c-2.5 13.1-3.6 26.7-3.6 40.4 0 43.9 11.9 86.2 40.3 117.9 28.8 32.1 71.9 50.1 127.7 50.1 14.4 0 27.9-1.2 40.5-3.5l-44.5-44.5zM109.2 208.8L57.5 157C30 199.3 14.6 251 7.8 308.1L7 312 8 316.9c12.5 59.8 40.8 113.1 88.1 151.3 47.3 38.3 111.4 59.8 192.3 59.8 45.5 0 85.6-6.8 120.5-19.5l-38.3-38.3c-24.1 6.3-51.4 9.8-82.2 9.8-72.3 0-125-19.1-162.1-49.1-35.9-29.1-59.1-70-70.2-118.9 9.2-40.7 26.8-75.8 53.2-103.2z"],
    "mug-hot": [576, 576, [9749], "f7b6", "M240 24c59.3 0 116.2 1.7 158.6 12.4 21.3 5.4 41.4 13.6 56.4 27.1 16 14.3 25 33.4 25 56.5l0 24c53 0 96 43 96 96l0 96c0 53-43 96-96 96l-7 0c-20.7 69.4-84.9 120-161 120l-144 0C75.2 552 0 476.8 0 384L0 120C0 96.9 9 77.8 25 63.5 40 50.1 60.1 41.8 81.4 36.4 123.8 25.7 180.7 24 240 24zM528 312l0-48c0-26.5-21.5-48-48-48l0 144c26.5 0 48-21.5 48-48zM384 120c0-11.2-3.1-18-7.3-22.8-4.7-5.4-12.6-10.5-25.3-14.6-26.3-8.6-64.6-10.5-111.4-10.5s-85.1 2-111.4 10.5c-12.8 4.2-20.6 9.3-25.3 14.6-4.2 4.9-7.3 11.7-7.3 22.8s3.1 18 7.3 22.8c4.7 5.4 12.6 10.5 25.3 14.6 26.3 8.6 64.6 10.5 111.4 10.5s85.1-2 111.4-10.5c12.8-4.2 20.6-9.3 25.3-14.6 4.3-4.9 7.3-11.7 7.3-22.8zM96 206.8L96 384c0 66.3 53.7 120 120 120l48 0c66.3 0 120-53.7 120-120l0-177.2c-40.4 7.8-91.3 9.2-144 9.2s-103.6-1.3-144-9.2z"],
    "bolt": [480, 576, [9889, "zap"], "f0e7", "M71.7 360l.6 0 0-.9-.6 .9zm35.2-48l109.4 0 0 166.7 157.4-214.7-109.4 0 0-166.7-157.4 214.7zM5 369.8l264-360 43.4 14.2 0 144 144 0 19.4 38.2-264 360-43.4-14.2 0-144-144 0-19.4-38.2z"],
    "arrow-rotate-left": [528, 576, [8634, "arrow-left-rotate", "arrow-rotate-back", "arrow-rotate-backward", "undo"], "f0e2", "M48.5 218.7l191.7 18.2 0-90-102.9 9.4c8.9-12.4 19.3-23 31.1-31.7 23.9-17.6 55.2-28.4 95.7-28.4 59.9 0 100.4 23.4 126.9 60.3 27.3 37.9 41.1 92.4 41.1 155.6s-13.8 117.7-41.1 155.6C364.4 504.6 323.9 528 264 528s-100.4-23.4-126.9-60.3C109.8 429.8 96 375.4 96 312.1l-96 0C0 382.5 19.1 448.8 63.1 497.8 107.6 547.2 174.6 576 264 576s156.4-28.8 200.9-78.2c44-49 63.1-115.3 63.1-185.6s-19.1-136.6-63.1-185.6c-44.4-49.5-111.5-78.2-200.9-78.2-77 0-137.2 21.4-180.6 58.5L93.1 0 3.1 0 21.3 191.6 48.5 218.7z"],
    "wifi": [576, 576, ["wifi-3", "wifi-strong"], "f1eb", "M288 24C168.5 24 53.8 87.2 2 206.4l40.5 24.8C116.4 141.5 197.5 118 288 118s171.6 23.5 245.5 113.3L574 206.4C522.2 87.2 407.5 24 288 24zm0 168c-80 0-141.9 38.6-187.9 106.6L137.9 328c22-24.6 43.8-41.5 67.4-52.4 23.6-10.9 50.2-16.3 82.7-16.3s59.2 5.5 82.7 16.3c23.6 10.9 45.4 27.8 67.4 52.4l37.8-29.4C430 230.6 368 192 288 192zM182 378.3l29.5 37.7c19.6-13.1 45.4-19.9 75.3-19.9s55.8 6.9 75.3 19.9l29.5-37.7C363.5 352.4 327.1 336 286.9 336S210.3 352.4 182 378.3zM288 456c-33.6 0-48 21.5-48 48s14.4 48 48 48 48-21.5 48-48-14.4-48-48-48z"],
    "volume": [576, 576, [128265, "volume-medium"], "f6a8", "M197.7 184.2l-7.1 7.8-10.6 0c-25.3 0-45.6 7.5-59.5 21.5-13.9 13.9-24.5 37.1-24.5 74.5s10.6 60.7 24.5 74.5c14 14 34.2 21.5 59.5 21.5l10.6 0 7.1 7.8 90.3 98.5 0-404.6-90.3 98.5zm-28.4-40.1l125-136.3 41.7 16.2 0 528-41.7 16.2-125-136.3C118.5 430.8 76.7 421.3 46.9 398.6 13.6 373.1 0 334.7 0 288s13.6-85.1 46.9-110.6c29.8-22.8 71.5-32.2 122.4-33.3zM504 288c0-80.1-27.8-145.9-85-182.7l13-20.2 10.2-21.7C530.3 104.6 576 195.2 576 288S530.3 471.4 442.2 512.6l-10.2-21.7-13-20.2c57.2-36.8 85-102.6 85-182.7zm-108 0c0-30-6.9-55.8-19.9-75.3l19.9-13.3 17.7-16.2C439.6 211.4 456 247.8 456 288s-16.4 76.6-42.3 104.9l-17.7-16.2-19.9-13.3C389.1 343.8 396 318 396 288z"],
    "tag": [576, 576, [127991], "f02b", "M288 24l-9.9 0c-2.9 2.9-11.2 11.2-25 25l-195.1 195.1 0 0-30 30c-37.5 37.5-37.5 98.3 0 135.8L166.1 548.1c37.5 37.5 98.3 37.5 135.8 0l30-30 0 0 195.1-195.1 25-25 0-273.9-264 0zM91.9 278.1l182.1-182.1 206.1 0 0 206.1-182.1 182.1 0 0c-18.7 18.7-49.1 18.7-67.9 0L91.9 345.9c-18.7-18.7-18.7-49.1 0-67.9l0 0zM384 240c33.6 0 48-21.5 48-48s-14.4-48-48-48-48 21.5-48 48 14.4 48 48 48z"],
    "compact-disc": [576, 576, [128191, 128192, 128440], "f51f", "M288 48c68.5 0 115.1 26.3 145.4 67.5 31.1 42.3 46.6 102.6 46.6 172.5s-15.6 130.2-46.6 172.5C403.1 501.7 356.5 528 288 528s-115.1-26.3-145.4-67.5C111.6 418.2 96 357.8 96 288s15.6-130.2 46.6-172.5C172.9 74.3 219.5 48 288 48zm0-48C190.2 0 117.2 31.5 68.8 85.3 20.9 138.7 0 211 0 288S20.9 437.3 68.8 490.7C117.2 544.5 190.2 576 288 576s170.8-31.5 219.2-85.3C555.1 437.3 576 365 576 288S555.1 138.7 507.2 85.3C458.8 31.5 385.8 0 288 0zm1.5 132c24.4 0 44.3 4.4 60.6 11.7 10.6 4.8 19.8 10.9 27.8 18.1l32.1-35.7c-11.7-10.6-25.1-19.4-40.2-26.2-23.3-10.5-50.2-16-80.4-16-9.9 0-19.4 .6-28.5 1.7l6 47.6c7-.9 14.5-1.4 22.5-1.4zM226.4 431.1c-9.5-4.6-17.9-10.3-25.3-16.9l-32.1 35.6c10.8 9.7 23 18 36.7 24.5 24.1 11.6 52.2 17.6 83.9 17.6 8.6 0 17-.4 25.1-1.3L309.4 443c-6.3 .7-12.9 1-19.9 1-25.6 0-46.4-4.9-63.1-12.9zM336 288c0 19.8-6.1 30.8-13.1 37-7.4 6.7-19.1 11-34.9 11s-27.4-4.3-34.9-11c-7-6.3-13.1-17.2-13.1-36.9l0-.2c0-19.7 6.2-30.7 13.1-36.9 7.4-6.7 19.1-11 34.9-11s27.4 4.3 34.9 11c7 6.3 13.1 17.2 13.1 37zm-144 .2c0 37.1 8.9 67.2 26.7 88.4 18.2 21.8 43.3 31.4 69.3 31.4s51.2-9.6 69.3-31.4C375.1 355.3 384 325.1 384 288s-8.9-67.3-26.7-88.6C339.2 177.6 314 168 288 168s-51.2 9.6-69.3 31.4c-17.7 21.2-26.6 51.3-26.7 88.4l0 .4z"],
    "phone-slash": [576, 576, [], "f3dd", "M156.4 2.1l162.9 162.9-86.2 91.6c5.9 11.4 12.9 22.1 20.8 32.1L487.5 55 521.4 89 41.4 569 7.5 535 105.6 436.9c-38.2-42-69.5-90.5-91.9-143.5-26.6-62.9-12.6-136.1 35.8-184.5l69.5-69.5 0 0 37.4-37.4zM172 370.5l47.7-47.7c-15.2-18.4-27.8-39-37.4-61.3l-6.2-14.5 47.2-50.1-96.9-96.9-10.5 10.5c-34.5 34.5-44.6 86.8-25.5 131.9 20 47.2 47.7 90.5 81.6 128.2zm.2 127.6l66.7-66.7c29.3 21.8 61.2 40.2 95.2 54.6 45 19 97.2 9 131.7-25.4l.2-.2 10.5-10.5-98.1-98.1-48.5 48.5-14.9-6.4c-8.9-3.8-17.5-8.1-25.8-12.9l123.2-123.2 162 162-74.4 74.4-.2 .2-32.2 32.2c-48.4 48.4-121.6 62.4-184.5 35.8-39.8-16.8-77-38.6-110.8-64.5z"],
    "arrow-up-right-from-square": [576, 576, ["external-link"], "f08e", "M336 17l25 1 144 6 9.4 .4 18.6 18.6 0 0c8.9 8.9 15.1 15.1 18.6 18.6l.4 9.4 6 144 1 25-80.9 0c.5-7 3.4-44.7 8.7-113l-180.9 201-16.9 18.8C263.1 321 234 292 229.2 287.1L248 270.2 449 89.2 336 97.9 336 17zM96 48l168 0 0 48-144 0 0 360 360 0 0-144 48 0 0 240-504 0 0-504 72 0z"],
    "rectangle-tall": [432, 576, [], "e791", "M24 0L0 0 0 576 432 576 432 0 24 0zM96 48l288 0 0 432-288 0 0-432z"],
    "compass": [576, 576, [129517], "f14e", "M288 48c68.5 0 115.1 26.3 145.4 67.5 31.1 42.3 46.6 102.6 46.6 172.5s-15.6 130.2-46.6 172.5C403.1 501.7 356.5 528 288 528s-115.1-26.3-145.4-67.5C111.6 418.2 96 357.8 96 288s15.6-130.2 46.6-172.5C172.9 74.3 219.5 48 288 48zm0-48C190.2 0 117.2 31.5 68.8 85.3 20.9 138.7 0 211 0 288S20.9 437.3 68.8 490.7C117.2 544.5 190.2 576 288 576s170.8-31.5 219.2-85.3C555.1 437.3 576 365 576 288S555.1 138.7 507.2 85.3C458.8 31.5 385.8 0 288 0zM243.3 277.2l55.5 55.5-89.4 33.9 33.9-89.4zm33.9-33.9l89.4-33.9-33.9 89.4-55.5-55.5zm-51.7-31.7l-10.1 3.8-3.8 10.1-66 174 31 31 174-66 10.1-3.8 3.8-10.1 66-174-31-31-174 66z"],
    "duck": [576, 576, [129414], "f6d8", "M126 168c0 21.3 4.2 39.6 12.2 54.3 6.6 12.2 15.9 21.9 27.7 28.8l26.8 15.6-21.7 22c-30.7 31.1-50.9 60.6-50.9 95.4 0 46.6 17.3 74.5 45.5 92.2 30.2 18.9 75.7 27.8 134.5 27.8 57.9 0 103.6-10.8 134-30.8 29-19.1 46-47.4 46-89.2l0-70.3-76.4 21.4-11.2 3.2 0 0-.8 .2-9.7-7.1c-64.8-47.1-99.3-72.2-103.4-75.2L296 236.4c11.3-12.8 19.8-31.7 21.6-57.9 .2-3.4 .4-7 .4-10.6 0-29.1-7.9-52.7-22.4-68.8-14.1-15.7-37-27.2-73.6-27.2s-59.6 11.5-73.6 27.2C133.9 115.3 126 138.9 126 168zM56 300.5c13.1-16.6 29.2-31.6 45.9-45.4-2.2-3.3-4.2-6.6-6-10-1-1.8-1.9-3.6-2.8-5.5-72-4.1-93.1-39.3-93.1-95.6l79.5 0c3.6-28.6 14-55.5 33.2-76.9 24.9-27.8 62-43.1 109.4-43.1 2 0 4 0 6 .1l0-.1c63.1 0 108.9 14.1 139.1 41.4 30.6 27.7 40.9 65.3 40.9 102.6 0 35.1-14 72.1-33.3 97.9l26.5 19.4C515.8 250 574.1 232.1 576 231.5L576 384c0 60.1-32.1 103.5-82.9 130.5-49.4 26.2-116.9 37.5-193.1 37.5-75.6 0-143.2-9-192.7-34.1-25.1-12.7-46.3-30-61-52.8-14.8-23-22.3-50.1-22.3-81.1 0-32.6 13.6-60.2 32-83.5zM240 156c0 19.9-10.8 36-36 36s-36-16.1-36-36 10.8-36 36-36 36 16.1 36 36z"],
    "square": [528, 576, [9632, 9723, 9724, 61590], "f0c8", "M24 24l-24 0 0 528 528 0 0-528-504 0zM96 72l384 0 0 384-384 0 0-384z"],
    "face-grin": [576, 576, [128512, "grin"], "f580", "M142.6 115.5C111.6 157.8 96 218.2 96 288s15.6 130.2 46.6 172.5C172.9 501.7 219.5 528 288 528s115.1-26.3 145.4-67.5C464.4 418.2 480 357.8 480 288s-15.6-130.2-46.6-172.5C403.1 74.3 356.5 48 288 48S172.9 74.3 142.6 115.5zM68.8 85.3C117.2 31.5 190.2 0 288 0S458.8 31.5 507.2 85.3C555.1 138.7 576 211 576 288s-20.9 149.3-68.8 202.7C458.8 544.5 385.8 576 288 576S117.2 544.5 68.8 490.7C20.9 437.3 0 365 0 288S20.9 138.7 68.8 85.3zM372 276l48 0 0 24c0 40.8-14.3 74.3-39.3 97.5-24.7 22.9-57.9 33.8-92.7 33.8s-67.9-10.9-92.7-33.8c-25-23.2-39.3-56.7-39.3-97.5l0-24 216 0zM229.9 324c3 18.1 9.4 31.3 17.1 40.5 10.5 12.5 24.7 18.9 41 18.9s30.5-6.4 41-18.9c7.7-9.1 14.1-22.4 17.1-40.5l-116.2 0zM312 216c0-26.5 14.4-48 48-48s48 21.5 48 48l0 24-96 0 0-24zm-96-48c33.6 0 48 21.5 48 48l0 24-96 0 0-24c0-26.5 14.4-48 48-48z"],
    "angle-up": [480, 576, [8963], "f106", "M438.2 354l17 17 18.2-18.2-19.4-16.9-15.8 18.1zm-30 30l-18.1 15.8 16.9 19.3 18.1-18.1-17-17zm-366-30L26.4 335.9 7 352.8 25.2 371 42.2 354zm30 30l-17 17 18.1 18.1 16.9-19.3-18.1-15.8zm156-192l0-24-9 0-6.8 5.9 15.8 18.1zm24 0l15.8-18.1-6.8-5.9-9 0 0 24zm-30.1 15.8l168 192 36.1-31.6-168-192-36.1 31.6zM425.1 401l30-30-33.9-33.9-30 30 33.9 33.9zm-203-224.8l-168 192 36.1 31.6 168-192-36.1-31.6zM89.1 367l-30-30-33.9 33.9 30 30 33.9-33.9zm151-199l-12 0 0 48 12 0 0-48zm-27.8 5.9l-186 162 31.5 36.2 186-162-31.5-36.2zM240.2 216l12 0 0-48-12 0 0 48zm-3.8-5.9l186 162 31.5-36.2-186-162-31.5 36.2z"],
    "face-smile": [576, 576, [128578, "smile"], "f118", "M288 48c68.5 0 115.1 26.3 145.4 67.5 31.1 42.3 46.6 102.6 46.6 172.5s-15.6 130.2-46.6 172.5C403.1 501.7 356.5 528 288 528s-115.1-26.3-145.4-67.5C111.6 418.2 96 357.8 96 288s15.6-130.2 46.6-172.5C172.9 74.3 219.5 48 288 48zm0-48C190.2 0 117.2 31.5 68.8 85.3 20.9 138.7 0 211 0 288S20.9 437.3 68.8 490.7C117.2 544.5 190.2 576 288 576s170.8-31.5 219.2-85.3C555.1 437.3 576 365 576 288S555.1 138.7 507.2 85.3C458.8 31.5 385.8 0 288 0zM396 300l-48 0c0 30.8-8.3 51.7-19 64.5-10.5 12.5-24.7 18.9-41 18.9s-30.5-6.4-41-18.9c-10.7-12.8-19-33.7-19-64.5l-72 0c0 40.8 14.3 74.3 39.3 97.5 24.7 22.9 57.9 33.8 92.7 33.8s67.9-10.9 92.7-33.8c25-23.2 39.3-56.7 39.3-97.5l-24 0zM264 216c0-26.5-14.4-48-48-48s-48 21.5-48 48 14.4 48 48 48 48-21.5 48-48zm96 48c33.6 0 48-21.5 48-48s-14.4-48-48-48-48 21.5-48 48 14.4 48 48 48z"],
    "umbrella": [576, 576, [], "f0e9", "M312 48.7l0-48.7-48 0 0 48.7C178.2 53.4 113.1 84 68.8 133.3 20.9 186.7 0 259 0 336l0 24 264 0 0 96c0 26.5-21.5 48-48 48s-48-21.5-48-48l-48 0 0 24c0 53 43 96 96 96s96-43 96-96l0-120 264 0 0-24c0-77-20.9-149.3-68.8-202.7-44.3-49.3-109.3-79.9-195.2-84.6zM288 96c5.5 0 10.9 2.1 17 10.7 6.8 9.5 13 25.1 18 47.8 8.8 40 12.2 94.7 12.8 157.5l-95.8 0c.6-62.8 4-117.5 12.8-157.5 5-22.6 11.2-38.3 18-47.8 6.2-8.6 11.5-10.7 17-10.7zm-81.9 48.2c-9.9 45-13.3 104-13.9 167.8l-95.5 0c3.2-59.6 18.6-111.1 46-148.5 18.3-24.9 42.6-44.4 74.1-55.9-4.4 11.3-7.9 23.7-10.7 36.6zm163.9 0c-2.8-12.9-6.3-25.3-10.7-36.6 31.5 11.5 55.8 31 74.1 55.9 27.4 37.3 42.8 88.8 46 148.5l-95.5 0c-.6-63.9-4.1-122.9-13.9-167.8z"],
    "pause": [480, 576, [9208], "f04c", "M24 72l-24 0 0 432 216 0 0-432-192 0zM96 456l0-336 72 0 0 336-72 0zM264 72l0 432 216 0 0-432-216 0zm96 384l0-336 72 0 0 336-72 0z"],
    "desktop": [576, 576, [128421, 61704, "desktop-alt"], "f390", "M24 24L0 24 0 336c0 53 43 96 96 96l72 0 0 24c0 26.5-21.5 48-48 48l-24 0 0 48 384 0 0-48-24 0c-26.5 0-48-21.5-48-48l0-24 72 0c53 0 96-43 96-96l0-312-552 0zM348.8 504l-121.7 0c8.2-14.1 12.8-30.5 12.8-48l0-24 96 0 0 24c0 17.5 4.7 33.9 12.8 48zM480 72l0 216-384 0 0-216 384 0zM96 336l384 0c0 26.5-21.5 48-48 48l-288 0c-26.5 0-48-21.5-48-48z"],
    "arrow-down": [480, 576, [8595], "f063", "M267.6 460.2l20.6-411 1.3-25.2-98.5 0 1.3 25.2 20.6 411-122.5-140-16.9-19.3C48.1 326.1 8.2 366 7 367.2l19.4 16.9 186 162 6.8 5.9 42 0 6.8-5.9 186-162 19.4-16.9c-25.3-25.3-65.1-65.1-66.3-66.3l-16.9 19.3-122.5 140z"],
    "location-dot": [480, 576, ["map-marker-alt"], "f3c5", "M240 48c-52.3 0-87 18.8-109.2 47.1-22.9 29.2-34.8 71.3-34.8 120.9 0 31.2 9.3 67 24.5 104.3 15.1 37.1 35.4 74.1 55.9 107.3 20.5 33.1 41.1 61.9 56.5 82.5 2.5 3.3 4.9 6.4 7.1 9.3 2.2-2.9 4.6-6 7.1-9.3 15.4-20.6 36-49.4 56.5-82.5 20.6-33.2 40.8-70.2 55.9-107.3 15.2-37.3 24.5-73.2 24.5-104.3 0-49.6-11.8-91.8-34.8-120.9-22.2-28.3-56.9-47.1-109.2-47.1zM225.7 573.4c-2 2.2-2 2.2-2 2.2l0 0 0 0-.1-.1-.5-.5c-.4-.4-1.1-1-1.9-1.8-1.7-1.6-4-3.9-7.1-6.8-6.1-5.9-14.7-14.4-25-25.1-20.6-21.3-48.2-51.4-75.8-86-27.5-34.6-55.5-74.2-76.7-114.7-21-40.2-36.5-83.4-36.5-124.5 0-57.9 17.8-112.6 58.4-152.8 40.7-40.3 101.4-63.2 181.6-63.2S380.9 22.9 421.6 63.2c40.7 40.3 58.4 95 58.4 152.8 0 41.1-15.5 84.3-36.5 124.5-21.2 40.6-49.2 80.2-76.7 114.7-27.6 34.6-55.1 64.6-75.8 86-10.3 10.7-18.9 19.2-25 25.1-3 2.9-5.4 5.2-7.1 6.8-.8 .8-1.5 1.4-1.9 1.8l-.5 .5-.1 .1 0 0 0 0-2-2.2 0 0 2 2.2-32.6 0 2-2.2 0 0zM240 168c-7.5 0-12.1 2.8-16 9.4-4.7 7.9-8 21-8 38.6s3.3 30.7 8 38.6c3.9 6.6 8.5 9.4 16 9.4s12.1-2.8 16-9.4c4.7-7.9 8-21 8-38.6s-3.3-30.7-8-38.6c-3.9-6.6-8.5-9.4-16-9.4zm-72.8-18.9C184.4 130 209.4 120 240 120s55.6 10 72.8 29.1C329.5 167.7 336 192 336 216s-6.5 48.3-23.2 66.9C295.6 302 270.6 312 240 312s-55.6-10-72.8-29.1C150.5 264.3 144 240 144 216s6.5-48.3 23.2-66.9z"],
    "bars": [528, 576, ["navicon"], "f0c9", "M480.3 46.7l0 98.6-25.3-1.3-456-24 0-47.9 456-24 25.3-1.3zm0 384l0 98.6-25.3-1.3-456-24 0-47.9 456-24 25.3-1.3zm0-166.7l0 73.3-25.3-1.3-456-24 0-47.9 456-24 25.3-1.3 0 25.3z"],
    "stopwatch": [528, 576, [9201], "f2f2", "M336 48l-48 0 0 24.8c40.2 2.6 75.2 11.7 105 26.5l31.1-46.6 39.9 26.6-30.7 46c8 6.6 15.5 13.8 22.4 21.4 42.1 46.9 60.3 110.2 60.3 177.3s-18.2 130.4-60.3 177.3C413.2 548.6 349.2 576 264 576S114.8 548.6 72.3 501.3C30.2 454.4 12 391 12 324S30.2 193.6 72.3 146.7c38.4-42.8 94.4-69.3 167.7-74l0-24.8-48 0 0-48 144 0 0 48zm-72 72c-60.3 0-101 22.5-127.3 57.3-27 35.7-40.7 87-40.7 146.7s13.7 111 40.7 146.7C163 505.5 203.7 528 264 528s101-22.5 127.3-57.3c27-35.7 40.7-87 40.7-146.7s-13.7-111-40.7-146.7C365 142.5 324.3 120 264 120zm24 72l0 144-48 0 0-144 48 0z"],
    "castle": [576, 576, [], "e0de", "M0 211L0 0 576 0 576 211c0 32.7-16.6 63.1-44.1 80.8l-5.9 3.8c-13.7 8.8-22 24-22 40.4l0 240.1-432 0 0-240.1c0-16.3-8.3-31.5-22-40.4l-5.9-3.8 0 0C16.6 274.1 0 243.6 0 211zM528 48l-96 0 0 96-96 0 0-96-96 0 0 96-96 0 0-96-96 0 0 128.9c0 16.2 8.2 31.4 21.8 40.2l54.5 35.4c27.2 17.7 43.7 48 43.7 80.5l0 194.9 72 0 0-96c0-26.5 14.4-48 48-48s48 21.5 48 48l0 96 72 0 0-194.9c0-32.5 16.4-62.8 43.7-80.5l54.5-35.4c13.6-8.9 21.8-24 21.8-40.2L528 48zM456.5 326.3c-.3 2.2-.5 4.5-.5 6.7l0 2.8c0-3.2 .2-6.4 .5-9.5zM120 335.9l0-2.8c0-2.3-.2-4.5-.5-6.7 .3 3.2 .5 6.3 .5 9.5zM288 312c-33.6 0-48-21.5-48-48s14.4-48 48-48 48 21.5 48 48-14.4 48-48 48z"],
    "train": [480, 576, [128646], "f238", "M371.5 408l.3-144-263 0 .3 144 262.5 0zm.4-192l.1-72-263.5 0 .1 72 263.2 0zM324.2 48L156.5 48c-26.5 0-48 21.5-48 48l263.7 0c0-26.5-21.5-48-48-48zM443.3 456l-72.8 0c43.6 62.2 71.6 102.2 84 120l-98.3 0c-3.6-9.1-8.4-21.1-14.4-36L139 540c-6 14.9-10.8 26.9-14.4 36l-98.3 0c12.4-17.8 40.4-57.8 84-120l-96.8 0-.1-23.9-.9-335.8C12.4 43.1 55.4 0 108.5 0L372.1 0c53.1 0 96.1 43.1 96 96.2l-.9 335.8-.1 23.9-23.9 0zM158.2 492l164.3 0-14.4-36-135.5 0-14.4 36zm22.2-120c-25.2 0-36-16.1-36-36s10.8-36 36-36 36 16.1 36 36-10.8 36-36 36zm156-36c0 19.9-10.8 36-36 36s-36-16.1-36-36 10.8-36 36-36 36 16.1 36 36z"],
    "gamepad": [576, 576, [], "f11b", "M48 168c0-53 43-96 96-96l288 0c53 0 96 43 96 96l0 240c0 26.5-21.5 48-48 48s-48-21.5-48-48l0-72-288 0 0 72c0 26.5-21.5 48-48 48s-48-21.5-48-48l0-240zM576 408l0-240c0-79.5-64.5-144-144-144L144 24C64.5 24 0 88.5 0 168L0 456c0 53 43 96 96 96s96-43 96-96l0-24 192 0 0 24c0 53 43 96 96 96s96-43 96-96l0-48zM372 120l0 60-60 0 0 48 60 0 0 60 48 0 0-60 60 0 0-48-60 0 0-60-48 0zM144 192c25.2 0 36-16.1 36-36s-10.8-36-36-36-36 16.1-36 36 10.8 36 36 36zm108 60c0-19.9-10.8-36-36-36s-36 16.1-36 36 10.8 36 36 36 36-16.1 36-36z"],
    "ship": [528, 576, [128674], "f21a", "M198.1 6.8L192 30c6.1-23.2 6.2-23.2 6.2-23.2l0 0 .1 0 .2 .1 .6 .2c.5 .1 1.2 .3 2.1 .6 1.7 .5 4.2 1.3 7.3 2.3 6.2 2.1 14.9 5.2 25.5 9.7 21 8.9 49.5 23 79.5 44.1 60.1 42.3 126.9 113.3 150.8 226.2l5.5 26.1-26.6 2.7-221.3 22.8 0 40.5 279.6-28 26.4-2.6 0 62.5c0 89.5-72.5 162-162 162l-216 0C67.2 576 0 508.8 0 426l0-21.7 21.6-2.2 152.4-15.2 0-40.3c-82.4 8.5-131.5 13.6-147.2 15.2l15.7-37.3 127.4-303.7 8.1-19.3 20.2 5.3zM360.8 273.9c-9.9-73.5-50.1-127.1-90.8-163.7-16.9-15.2-33.7-27.3-48-36.5l0 216.9 138.8-16.7zM102.7 305l71.3-8.6 0-161.4-71.3 170zM216 528l102.1 0C381 528 432 476.9 432 414l0-4.7-334.6 33.5c8 48.3 50 85.2 100.6 85.2l18 0z"],
    "arrows-rotate": [528, 576, [128472, "refresh", "sync"], "f021", "M430.3 202.6L456.1 176.9 473 0 393.4 0 398.3 97C359.1 66.1 306.2 48.7 240 48.7 159 48.7 98 74.8 57.4 119.7 17.3 164.3 0 224.5 0 288l96 0c0-56.6 12.1-105 35.6-138.6 22.7-32.4 57.3-52.8 108.4-52.8 32.6 0 58 8.3 77.7 22 10.2 7.1 19.3 15.9 27.3 26.2l-92.2-4.7 0 79.3 177.4-16.8zM182.7 430.9l98.4 5 0-79.3-177.4 16.8-25.8 25.7-16.9 176.9 79.6 0-4.7-92.3c38.5 27.9 89.3 43.6 152.1 43.6 81 0 142-26 182.6-71 40.1-44.6 57.4-104.7 57.4-168.2l-96 0c0 56.6-12.1 105-35.6 138.6-22.7 32.4-57.3 52.8-108.4 52.8-32.6 0-58-8.3-77.7-22-10.4-7.2-19.5-16-27.5-26.5z"],
    "book-open": [576, 576, [128214, 128366], "f518", "M48 433.8l0-319.6C77.7 102.6 113.5 96 156 96s78.3 6.6 108 18.1l0 319.6c-1.8-.8-3.6-1.6-5.5-2.4-25.8-11.1-62.1-22.6-102.5-22.6S79.3 420.3 53.5 431.3c-1.9 .8-3.7 1.6-5.5 2.4zM312 114.1C341.7 102.6 377.5 96 420 96s78.3 6.6 108 18.1l0 319.6c-1.8-.8-3.6-1.6-5.5-2.4-25.8-11.1-62.1-22.6-102.5-22.6s-76.7 11.5-102.5 22.6c-1.9 .8-3.7 1.6-5.5 2.4l0-319.6zM288 72c-37.5-15.7-81.5-24-132-24-55.1 0-102.5 10-142.2 28.6L0 83 0 559.3 35.8 539.2C64.5 523.1 103.9 504 156 504s91.5 19.1 120.2 35.2l23.5 0C328.5 523.1 367.9 504 420 504s91.5 19.1 120.2 35.2l35.8 20.1 0-476.3-13.8-6.5C522.5 58 475.1 48 420 48 369.5 48 325.5 56.4 288 72zm72.2 261.6l0 0c16.5-4.2 37.6-9.7 59.8-9.7s43.3 5.4 59.8 9.7l0 0c2.2 .6 4.3 1.1 6.4 1.6l11.6-46.6c-1.7-.4-3.6-.9-5.7-1.5-16.1-4.2-43.4-11.3-72.2-11.3s-56 7.1-72.2 11.3l0 0c-2.1 .5-4 1-5.6 1.4l11.6 46.6c2-.5 4.2-1.1 6.4-1.6zm-6.4-94.4c2-.5 4.2-1.1 6.4-1.6 16.5-4.2 37.6-9.7 59.8-9.7s43.3 5.4 59.8 9.7c2.2 .6 4.3 1.1 6.4 1.6l11.6-46.6c-1.7-.4-3.6-.9-5.7-1.5-16.1-4.2-43.4-11.3-72.2-11.3s-56 7.1-72.2 11.3l0 0 0 0 0 0c-2.1 .5-4 1-5.7 1.5l11.6 46.6zM96.2 333.7l0 0c16.5-4.2 37.6-9.7 59.8-9.7s43.3 5.4 59.8 9.7l0 0c2.2 .6 4.3 1.1 6.4 1.6l11.6-46.6c-1.7-.4-3.6-.9-5.7-1.5-16.1-4.2-43.4-11.3-72.2-11.3s-56 7.1-72.2 11.3l0 0 0 0c-2.1 .5-4 1-5.7 1.5l11.6 46.6c2-.5 4.2-1.1 6.4-1.6zm-6.4-94.4c2-.5 4.2-1.1 6.4-1.6 16.5-4.2 37.6-9.7 59.8-9.7s43.3 5.4 59.8 9.7c2.2 .6 4.3 1.1 6.4 1.6l11.6-46.6c-1.7-.4-3.6-.9-5.7-1.5-16.1-4.2-43.4-11.3-72.2-11.3s-56 7.1-72.2 11.3l0 0c-2.1 .5-4 1-5.7 1.5l11.6 46.6z"],
    "box-archive": [576, 576, ["archive"], "f187", "M24 24l-24 0 0 168 48 0 0 264c0 53 43 96 96 96l288 0c53 0 96-43 96-96l0-264 48 0 0-168-552 0zM144 456l0-264 288 0 0 264c0 26.5-21.5 48-48 48l-192 0c-26.5 0-48-21.5-48-48zM96 144l0-72 384 0 0 72-384 0zm144 96c-19.9 0-36 16.1-36 36s16.1 36 36 36l96 0c19.9 0 36-16.1 36-36s-16.1-36-36-36l-96 0z"],
    "cake-candles": [576, 576, [127874, "birthday-cake", "cake"], "f1fd", "M312 144l0-96-48 0 0 96-72 0 0-96-48 0 0 96-48 0c-53 0-96 43-96 96l0 288 576 0 0-288c0-53-43-96-96-96l-48 0 0-96-48 0 0 96-72 0zm120 48c26.5 0 48 21.5 48 48l0 96c-7.4 0-17.6-3.6-31-17-18.6-18.6-40.4-31-65-31s-46.4 12.4-65 31c-13.4 13.4-23.6 17-31 17s-17.6-3.6-31-17c-18.6-18.6-40.4-31-65-31s-46.4 12.4-65 31c-13.4 13.4-23.6 17-31 17l0-96c0-26.5 21.5-48 48-48l288 0zM96 480l0-96c24.6 0 46.4-12.4 65-31 13.4-13.4 23.6-17 31-17s17.6 3.6 31 17c18.6 18.6 40.4 31 65 31s46.4-12.4 65-31c13.4-13.4 23.6-17 31-17s17.6 3.6 31 17c18.6 18.6 40.4 31 65 31l0 96-384 0z"],
    "circle-info": [576, 576, ["info-circle"], "f05a", "M433.4 115.5C464.4 157.8 480 218.2 480 288s-15.6 130.2-46.6 172.5C403.1 501.7 356.5 528 288 528s-115.1-26.3-145.4-67.5C111.6 418.2 96 357.8 96 288s15.6-130.2 46.6-172.5C172.9 74.3 219.5 48 288 48s115.1 26.3 145.4 67.5zM288 0C190.2 0 117.2 31.5 68.8 85.3 20.9 138.7 0 211 0 288S20.9 437.3 68.8 490.7C117.2 544.5 190.2 576 288 576s170.8-31.5 219.2-85.3C555.1 437.3 576 365 576 288S555.1 138.7 507.2 85.3C458.8 31.5 385.8 0 288 0zm0 120c-25.2 0-36 16.1-36 36s10.8 36 36 36 36-16.1 36-36-10.8-36-36-36zm24 108l-120 0 0 48 50.8 0 16.5 132-43.3 0 0 48 144 0 0-48-43.3 0 19.1-153 3.4-27-27.2 0z"],
    "layer-group": [528, 576, [], "f5fd", "M273.4 25.9l-9.4-4.4-9.4 4.4-251.1 95.7 0 44.9 130.1 49.6-130.1 49.6 0 44.9 130.1 49.6-130.1 49.6 0 44.9 251.1 95.7 9.4 4.4 9.4-4.4 251.2-95.7 0-44.9-130.1-49.6 130.1-49.6 0-44.9-130.1-49.6 130.1-49.6 0-44.9-251.2-95.7zm46 362.7l92.3 43.4-147.6 69.5-147.6-69.5 92.3-43.4 46 17.5 9.4 4.4 9.4-4.4 46-17.5zm0-144l92.3 43.4-147.6 69.5-147.6-69.5 92.3-43.4 46 17.5 9.4 4.4 9.4-4.4 46-17.5zM264 213.5L116.4 144 264 74.5 411.7 144 264 213.5z"],
    "shield": [528, 576, [128737, "shield-blank"], "f132", "M251.2 9.7l0 0 0 0-.1 0-.6 .4c-.6 .4-1.5 .9-2.8 1.6-2.6 1.5-6.5 3.7-11.8 6.3-10.5 5.3-26.1 12.5-46.1 19.7-40 14.5-97.2 29-165.8 29L0 66.8 0 259c0 99.5 56 190.6 144.8 235.6l107.5 54.4 11.7 7.1 11.7-7.1 107.5-54.4C472 449.6 528 358.6 528 259l0-192.2-24 0c-68.6 0-125.8-14.5-165.8-29-20-7.2-35.6-14.4-46.1-19.7-5.2-2.7-9.2-4.8-11.8-6.3-1.3-.7-2.2-1.3-2.8-1.6l-.6-.4-.1 0 0 0 0 0 0 0 0 0-12.8-8.1-12.8 8.1 0 0 0 0zM432 109.9l0 166.4c0 75.4-39.3 145.4-103.8 184.6l-64.2 39.1-64.2-39.1C135.3 421.7 96 351.7 96 276.3l0-166.4c43.7-5.9 81.1-16.4 110.2-27 22-8 39.4-16 51.4-22.1 2.3-1.2 4.5-2.3 6.4-3.3 1.9 1 4.1 2.1 6.4 3.3 12 6.1 29.4 14.1 51.4 22.1 29.1 10.5 66.4 21.1 110.2 27z"],
    "cart-shopping": [576, 576, [128722, "shopping-cart"], "f07a", "M0 0L72 0c53 0 96 43 96 96l0 24 408 0-59.1 239.3C506.2 402 467.8 432 423.8 432L168 432c-53 0-96-43-96-96L72 96c0-26.5-21.5-48-48-48L0 48 0 0zM168 168l0 168c0 26.5 21.5 48 48 48l159.8 0c22 0 41.2-15 46.6-36.4L467.3 168 168 168zm72 360c0 26.5-14.4 48-48 48s-48-21.5-48-48 14.4-48 48-48 48 21.5 48 48zm144 48c33.6 0 48-21.5 48-48s-14.4-48-48-48-48 21.5-48 48 14.4 48 48 48z"]
  };

  bunker(function () {
    defineIcons('facr', icons);
  });

}());
