/*!
 * Font Awesome Pro 7.3.0 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license (Commercial License)
 * Copyright 2026 Fonticons, Inc.
 */
(function () {
  'use strict';

  var _WINDOW = {};
  var _DOCUMENT = {};
  try {
    if (typeof window !== 'undefined') _WINDOW = window;
    if (typeof document !== 'undefined') _DOCUMENT = document;
  } catch (e) {} // eslint-disable-line no-empty

  var _ref = _WINDOW.navigator || {},
    _ref$userAgent = _ref.userAgent,
    userAgent = _ref$userAgent === void 0 ? '' : _ref$userAgent;
  var WINDOW = _WINDOW;
  var DOCUMENT = _DOCUMENT;
  var IS_BROWSER = !!WINDOW.document;
  var IS_DOM = !!DOCUMENT.documentElement && !!DOCUMENT.head && typeof DOCUMENT.addEventListener === 'function' && typeof DOCUMENT.createElement === 'function';
  var IS_IE = ~userAgent.indexOf('MSIE') || ~userAgent.indexOf('Trident/');

  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _arrayWithoutHoles(r) {
    if (Array.isArray(r)) return _arrayLikeToArray(r);
  }
  function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[r] = t, e;
  }
  function _iterableToArray(r) {
    if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
  }
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function (r) {
        return Object.getOwnPropertyDescriptor(e, r).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
        _defineProperty(e, r, t[r]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
        Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
      });
    }
    return e;
  }
  function _toConsumableArray(r) {
    return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }

  var _cl;
  var rl = {
      classic: {
        fa: "solid",
        fas: "solid",
        "fa-solid": "solid",
        far: "regular",
        "fa-regular": "regular",
        fal: "light",
        "fa-light": "light",
        fat: "thin",
        "fa-thin": "thin",
        fab: "brands",
        "fa-brands": "brands"
      },
      duotone: {
        fa: "solid",
        fad: "solid",
        "fa-solid": "solid",
        "fa-duotone": "solid",
        fadr: "regular",
        "fa-regular": "regular",
        fadl: "light",
        "fa-light": "light",
        fadt: "thin",
        "fa-thin": "thin"
      },
      sharp: {
        fa: "solid",
        fass: "solid",
        "fa-solid": "solid",
        fasr: "regular",
        "fa-regular": "regular",
        fasl: "light",
        "fa-light": "light",
        fast: "thin",
        "fa-thin": "thin"
      },
      "sharp-duotone": {
        fa: "solid",
        fasds: "solid",
        "fa-solid": "solid",
        fasdr: "regular",
        "fa-regular": "regular",
        fasdl: "light",
        "fa-light": "light",
        fasdt: "thin",
        "fa-thin": "thin"
      },
      slab: {
        "fa-regular": "regular",
        faslr: "regular"
      },
      "slab-press": {
        "fa-regular": "regular",
        faslpr: "regular"
      },
      "slab-duo": {
        "fa-regular": "regular",
        fasldr: "regular"
      },
      "slab-press-duo": {
        "fa-regular": "regular",
        faslpdr: "regular"
      },
      thumbprint: {
        "fa-light": "light",
        fatl: "light"
      },
      vellum: {
        "fa-solid": "solid",
        favs: "solid"
      },
      pixel: {
        "fa-regular": "regular",
        fapr: "regular"
      },
      mosaic: {
        "fa-solid": "solid",
        fams: "solid"
      },
      whiteboard: {
        "fa-semibold": "semibold",
        fawsb: "semibold"
      },
      notdog: {
        "fa-solid": "solid",
        fans: "solid"
      },
      "notdog-duo": {
        "fa-solid": "solid",
        fands: "solid"
      },
      etch: {
        "fa-solid": "solid",
        faes: "solid"
      },
      graphite: {
        "fa-thin": "thin",
        fagt: "thin"
      },
      jelly: {
        "fa-regular": "regular",
        fajr: "regular"
      },
      "jelly-fill": {
        "fa-regular": "regular",
        fajfr: "regular"
      },
      "jelly-duo": {
        "fa-regular": "regular",
        fajdr: "regular"
      },
      chisel: {
        "fa-regular": "regular",
        facr: "regular"
      },
      utility: {
        "fa-semibold": "semibold",
        fausb: "semibold"
      },
      "utility-duo": {
        "fa-semibold": "semibold",
        faudsb: "semibold"
      },
      "utility-fill": {
        "fa-semibold": "semibold",
        faufsb: "semibold"
      }
    };
  var u = "classic",
    l = "duotone",
    h = "sharp",
    t = "sharp-duotone",
    g = "chisel",
    n = "etch",
    m = "graphite",
    p = "jelly",
    s = "jelly-duo",
    y = "jelly-fill",
    w = "mosaic",
    x = "notdog",
    e = "notdog-duo",
    b = "pixel",
    c = "slab",
    o = "slab-duo",
    I = "slab-press",
    a = "slab-press-duo",
    r = "thumbprint",
    v = "utility",
    i = "utility-duo",
    F = "utility-fill",
    d = "vellum",
    S = "whiteboard",
    A = "Classic",
    P = "Duotone",
    j = "Sharp",
    B = "Sharp Duotone",
    N = "Chisel",
    D = "Etch",
    k = "Graphite",
    T = "Jelly",
    C = "Jelly Duo",
    W = "Jelly Fill",
    R = "Mosaic",
    K = "Notdog",
    L = "Notdog Duo",
    U = "Pixel",
    J = "Slab",
    _ = "Slab Duo",
    M = "Slab Press",
    E = "Slab Press Duo",
    G = "Thumbprint",
    V = "Utility",
    z = "Utility Duo",
    O = "Utility Fill",
    Y = "Vellum",
    q = "Whiteboard",
    cl = (_cl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, u, A), l, P), h, j), t, B), g, N), n, D), m, k), p, T), s, C), y, W), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, w, R), x, K), e, L), b, U), c, J), o, _), I, M), a, E), r, G), v, V), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, i, z), F, O), d, Y), S, q));
  var Al = {
      classic: {
        900: "fas",
        400: "far",
        normal: "far",
        300: "fal",
        100: "fat"
      },
      duotone: {
        900: "fad",
        400: "fadr",
        300: "fadl",
        100: "fadt"
      },
      sharp: {
        900: "fass",
        400: "fasr",
        300: "fasl",
        100: "fast"
      },
      "sharp-duotone": {
        900: "fasds",
        400: "fasdr",
        300: "fasdl",
        100: "fasdt"
      },
      slab: {
        400: "faslr"
      },
      "slab-press": {
        400: "faslpr"
      },
      "slab-duo": {
        400: "fasldr"
      },
      "slab-press-duo": {
        400: "faslpdr"
      },
      vellum: {
        900: "favs"
      },
      mosaic: {
        900: "fams"
      },
      pixel: {
        400: "fapr"
      },
      whiteboard: {
        600: "fawsb"
      },
      thumbprint: {
        300: "fatl"
      },
      notdog: {
        900: "fans"
      },
      "notdog-duo": {
        900: "fands"
      },
      etch: {
        900: "faes"
      },
      graphite: {
        100: "fagt"
      },
      chisel: {
        400: "facr"
      },
      jelly: {
        400: "fajr"
      },
      "jelly-fill": {
        400: "fajfr"
      },
      "jelly-duo": {
        400: "fajdr"
      },
      utility: {
        600: "fausb"
      },
      "utility-duo": {
        600: "faudsb"
      },
      "utility-fill": {
        600: "faufsb"
      }
    };
  var $l = {
      chisel: {
        regular: "facr"
      },
      classic: {
        brands: "fab",
        light: "fal",
        regular: "far",
        solid: "fas",
        thin: "fat"
      },
      duotone: {
        light: "fadl",
        regular: "fadr",
        solid: "fad",
        thin: "fadt"
      },
      etch: {
        solid: "faes"
      },
      graphite: {
        thin: "fagt"
      },
      jelly: {
        regular: "fajr"
      },
      "jelly-duo": {
        regular: "fajdr"
      },
      "jelly-fill": {
        regular: "fajfr"
      },
      mosaic: {
        solid: "fams"
      },
      notdog: {
        solid: "fans"
      },
      "notdog-duo": {
        solid: "fands"
      },
      pixel: {
        regular: "fapr"
      },
      sharp: {
        light: "fasl",
        regular: "fasr",
        solid: "fass",
        thin: "fast"
      },
      "sharp-duotone": {
        light: "fasdl",
        regular: "fasdr",
        solid: "fasds",
        thin: "fasdt"
      },
      slab: {
        regular: "faslr"
      },
      "slab-duo": {
        regular: "fasldr"
      },
      "slab-press": {
        regular: "faslpr"
      },
      "slab-press-duo": {
        regular: "faslpdr"
      },
      thumbprint: {
        light: "fatl"
      },
      utility: {
        semibold: "fausb"
      },
      "utility-duo": {
        semibold: "faudsb"
      },
      "utility-fill": {
        semibold: "faufsb"
      },
      vellum: {
        solid: "favs"
      },
      whiteboard: {
        semibold: "fawsb"
      }
    };
  var rt = {
      kit: {
        fak: "kit",
        "fa-kit": "kit"
      },
      "kit-duotone": {
        fakd: "kit-duotone",
        "fa-kit-duotone": "kit-duotone"
      }
    },
    it = ["kit"];
  var H = "kit",
    f = "kit-duotone",
    Q = "Kit",
    X = "Kit Duotone",
    ht = _defineProperty(_defineProperty({}, H, Q), f, X);
  var mt = {
    kit: {
      "fa-kit": "fak"
    },
    "kit-duotone": {
      "fa-kit-duotone": "fakd"
    }
  };
  var It = {
      kit: {
        fak: "fa-kit"
      },
      "kit-duotone": {
        fakd: "fa-kit-duotone"
      }
    };
  var St = {
      kit: {
        kit: "fak"
      },
      "kit-duotone": {
        "kit-duotone": "fakd"
      }
    };

  var _jl;
  var l$1 = {
      GROUP: "duotone-group",
      SWAP_OPACITY: "swap-opacity",
      PRIMARY: "primary",
      SECONDARY: "secondary"
    };
  var g$1 = "classic",
    a$1 = "duotone",
    m$1 = "sharp",
    t$1 = "sharp-duotone",
    p$1 = "chisel",
    y$1 = "etch",
    b$1 = "graphite",
    w$1 = "jelly",
    e$1 = "jelly-duo",
    x$1 = "jelly-fill",
    c$1 = "mosaic",
    I$1 = "notdog",
    o$1 = "notdog-duo",
    v$1 = "pixel",
    F$1 = "slab",
    r$1 = "slab-duo",
    S$1 = "slab-press",
    i$1 = "slab-press-duo",
    d$1 = "thumbprint",
    A$1 = "utility",
    f$1 = "utility-duo",
    P$1 = "utility-fill",
    u$1 = "vellum",
    j$1 = "whiteboard",
    B$1 = "Classic",
    N$1 = "Duotone",
    D$1 = "Sharp",
    k$1 = "Sharp Duotone",
    C$1 = "Chisel",
    T$1 = "Etch",
    L$1 = "Graphite",
    W$1 = "Jelly",
    R$1 = "Jelly Duo",
    K$1 = "Jelly Fill",
    U$1 = "Mosaic",
    J$1 = "Notdog",
    _$1 = "Notdog Duo",
    M$1 = "Pixel",
    E$1 = "Slab",
    G$1 = "Slab Duo",
    O$1 = "Slab Press",
    V$1 = "Slab Press Duo",
    z$1 = "Thumbprint",
    Y$1 = "Utility",
    $$1 = "Utility Duo",
    q$1 = "Utility Fill",
    H$1 = "Vellum",
    Q$1 = "Whiteboard",
    jl$1 = (_jl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, g$1, B$1), a$1, N$1), m$1, D$1), t$1, k$1), p$1, C$1), y$1, T$1), b$1, L$1), w$1, W$1), e$1, R$1), x$1, K$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, c$1, U$1), I$1, J$1), o$1, _$1), v$1, M$1), F$1, E$1), r$1, G$1), S$1, O$1), i$1, V$1), d$1, z$1), A$1, Y$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, f$1, $$1), P$1, q$1), u$1, H$1), j$1, Q$1));
  var X$1 = "kit",
    h$1 = "kit-duotone",
    Z$1 = "Kit",
    ll$1 = "Kit Duotone",
    ws = _defineProperty(_defineProperty({}, X$1, Z$1), h$1, ll$1);
  var ra = {
      classic: {
        "fa-brands": "fab",
        "fa-duotone": "fad",
        "fa-light": "fal",
        "fa-regular": "far",
        "fa-solid": "fas",
        "fa-thin": "fat"
      },
      duotone: {
        "fa-regular": "fadr",
        "fa-light": "fadl",
        "fa-thin": "fadt"
      },
      sharp: {
        "fa-solid": "fass",
        "fa-regular": "fasr",
        "fa-light": "fasl",
        "fa-thin": "fast"
      },
      "sharp-duotone": {
        "fa-solid": "fasds",
        "fa-regular": "fasdr",
        "fa-light": "fasdl",
        "fa-thin": "fasdt"
      },
      slab: {
        "fa-regular": "faslr"
      },
      "slab-press": {
        "fa-regular": "faslpr"
      },
      "slab-duo": {
        "fa-regular": "fasldr"
      },
      "slab-press-duo": {
        "fa-regular": "faslpdr"
      },
      pixel: {
        "fa-regular": "fapr"
      },
      mosaic: {
        "fa-solid": "fams"
      },
      vellum: {
        "fa-solid": "favs"
      },
      whiteboard: {
        "fa-semibold": "fawsb"
      },
      thumbprint: {
        "fa-light": "fatl"
      },
      notdog: {
        "fa-solid": "fans"
      },
      "notdog-duo": {
        "fa-solid": "fands"
      },
      etch: {
        "fa-solid": "faes"
      },
      graphite: {
        "fa-thin": "fagt"
      },
      jelly: {
        "fa-regular": "fajr"
      },
      "jelly-fill": {
        "fa-regular": "fajfr"
      },
      "jelly-duo": {
        "fa-regular": "fajdr"
      },
      chisel: {
        "fa-regular": "facr"
      },
      utility: {
        "fa-semibold": "fausb"
      },
      "utility-duo": {
        "fa-semibold": "faudsb"
      },
      "utility-fill": {
        "fa-semibold": "faufsb"
      }
    },
    al$1 = {
      classic: ["fas", "far", "fal", "fat", "fad"],
      duotone: ["fadr", "fadl", "fadt"],
      sharp: ["fass", "fasr", "fasl", "fast"],
      "sharp-duotone": ["fasds", "fasdr", "fasdl", "fasdt"],
      slab: ["faslr"],
      "slab-press": ["faslpr"],
      "slab-duo": ["fasldr"],
      "slab-press-duo": ["faslpdr"],
      pixel: ["fapr"],
      mosaic: ["fams"],
      vellum: ["favs"],
      whiteboard: ["fawsb"],
      thumbprint: ["fatl"],
      notdog: ["fans"],
      "notdog-duo": ["fands"],
      etch: ["faes"],
      graphite: ["fagt"],
      jelly: ["fajr"],
      "jelly-fill": ["fajfr"],
      "jelly-duo": ["fajdr"],
      chisel: ["facr"],
      utility: ["fausb"],
      "utility-duo": ["faudsb"],
      "utility-fill": ["faufsb"]
    },
    da = {
      classic: {
        fab: "fa-brands",
        fad: "fa-duotone",
        fal: "fa-light",
        far: "fa-regular",
        fas: "fa-solid",
        fat: "fa-thin"
      },
      duotone: {
        fadr: "fa-regular",
        fadl: "fa-light",
        fadt: "fa-thin"
      },
      sharp: {
        fass: "fa-solid",
        fasr: "fa-regular",
        fasl: "fa-light",
        fast: "fa-thin"
      },
      "sharp-duotone": {
        fasds: "fa-solid",
        fasdr: "fa-regular",
        fasdl: "fa-light",
        fasdt: "fa-thin"
      },
      slab: {
        faslr: "fa-regular"
      },
      "slab-press": {
        faslpr: "fa-regular"
      },
      "slab-duo": {
        fasldr: "fa-regular"
      },
      "slab-press-duo": {
        faslpdr: "fa-regular"
      },
      pixel: {
        fapr: "fa-regular"
      },
      mosaic: {
        fams: "fa-solid"
      },
      vellum: {
        favs: "fa-solid"
      },
      whiteboard: {
        fawsb: "fa-semibold"
      },
      thumbprint: {
        fatl: "fa-light"
      },
      notdog: {
        fans: "fa-solid"
      },
      "notdog-duo": {
        fands: "fa-solid"
      },
      etch: {
        faes: "fa-solid"
      },
      graphite: {
        fagt: "fa-thin"
      },
      jelly: {
        fajr: "fa-regular"
      },
      "jelly-fill": {
        fajfr: "fa-regular"
      },
      "jelly-duo": {
        fajdr: "fa-regular"
      },
      chisel: {
        facr: "fa-regular"
      },
      utility: {
        fausb: "fa-semibold"
      },
      "utility-duo": {
        faudsb: "fa-semibold"
      },
      "utility-fill": {
        faufsb: "fa-semibold"
      }
    },
    el$1 = ["solid", "regular", "light", "thin", "duotone", "brands", "semibold"],
    sl$1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    ol$1 = sl$1.concat([11, 12, 13, 14, 15, 16, 17, 18, 19, 20]),
    rl$1 = ["aw", "fw", "pull-left", "pull-right"],
    ga = [].concat(_toConsumableArray(Object.keys(al$1)), el$1, rl$1, ["2xs", "xs", "sm", "lg", "xl", "2xl", "beat", "beat-fade", "border", "bounce", "buzz", "canvas-square", "canvas-roomy", "fade", "flip-360", "flip-both", "flip-horizontal", "flip-vertical", "flip", "float", "inverse", "jello", "layers", "layers-bottom-left", "layers-bottom-right", "layers-counter", "layers-text", "layers-top-left", "layers-top-right", "li", "pull-end", "pull-start", "pulse", "rotate-180", "rotate-270", "rotate-90", "rotate-by", "shake", "spin-pulse", "spin-reverse", "spin", "spin-snap", "spin-snap-4", "spin-snap-8", "stack-1x", "stack-2x", "stack", "swing", "ul", "wag", "width-auto", "width-fixed", l$1.GROUP, l$1.SWAP_OPACITY, l$1.PRIMARY, l$1.SECONDARY]).concat(sl$1.map(function (s) {
      return "".concat(s, "x");
    })).concat(ol$1.map(function (s) {
      return "w-".concat(s);
    }));

  var NAMESPACE_IDENTIFIER = '___FONT_AWESOME___';
  var PRODUCTION = function () {
    try {
      return "production" === 'production';
    } catch (e$$1) {
      return false;
    }
  }();
  function familyProxy(obj) {
    // Defaults to the classic family if family is not available
    return new Proxy(obj, {
      get: function get(target, prop) {
        return prop in target ? target[prop] : target[u];
      }
    });
  }
  var _PREFIX_TO_STYLE = _objectSpread2({}, rl);

  // We changed FACSSClassesToStyleId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _PREFIX_TO_STYLE below, so we are manually adding
  // {'fa-duotone': 'duotone'}
  _PREFIX_TO_STYLE[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    'fa-duotone': 'duotone'
  }), rl[u]), rt['kit']), rt['kit-duotone']);
  var PREFIX_TO_STYLE = familyProxy(_PREFIX_TO_STYLE);
  var _STYLE_TO_PREFIX = _objectSpread2({}, $l);

  // We changed FAStyleIdToShortPrefixId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _STYLE_TO_PREFIX below, so we are manually adding {duotone: 'fad'}
  _STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    duotone: 'fad'
  }), _STYLE_TO_PREFIX[u]), St['kit']), St['kit-duotone']);
  var STYLE_TO_PREFIX = familyProxy(_STYLE_TO_PREFIX);
  var _PREFIX_TO_LONG_STYLE = _objectSpread2({}, da);
  _PREFIX_TO_LONG_STYLE[u] = _objectSpread2(_objectSpread2({}, _PREFIX_TO_LONG_STYLE[u]), It['kit']);
  var PREFIX_TO_LONG_STYLE = familyProxy(_PREFIX_TO_LONG_STYLE);
  var _LONG_STYLE_TO_PREFIX = _objectSpread2({}, ra);
  _LONG_STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2({}, _LONG_STYLE_TO_PREFIX[u]), mt['kit']);
  var LONG_STYLE_TO_PREFIX = familyProxy(_LONG_STYLE_TO_PREFIX);
  var _FONT_WEIGHT_TO_PREFIX = _objectSpread2({}, Al);
  var FONT_WEIGHT_TO_PREFIX = familyProxy(_FONT_WEIGHT_TO_PREFIX);
  var RESERVED_CLASSES = [].concat(_toConsumableArray(it), _toConsumableArray(ga));

  function bunker(fn) {
    try {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      fn.apply(void 0, args);
    } catch (e) {
      if (!PRODUCTION) {
        throw e;
      }
    }
  }

  var w$2 = WINDOW || {};
  if (!w$2[NAMESPACE_IDENTIFIER]) w$2[NAMESPACE_IDENTIFIER] = {};
  if (!w$2[NAMESPACE_IDENTIFIER].styles) w$2[NAMESPACE_IDENTIFIER].styles = {};
  if (!w$2[NAMESPACE_IDENTIFIER].hooks) w$2[NAMESPACE_IDENTIFIER].hooks = {};
  if (!w$2[NAMESPACE_IDENTIFIER].shims) w$2[NAMESPACE_IDENTIFIER].shims = [];
  var namespace = w$2[NAMESPACE_IDENTIFIER];

  function normalizeIcons(icons) {
    return Object.keys(icons).reduce(function (acc, iconName) {
      var icon = icons[iconName];
      var expanded = !!icon.icon;
      if (expanded) {
        acc[icon.iconName] = icon.icon;
      } else {
        acc[iconName] = icon;
      }
      return acc;
    }, {});
  }
  function defineIcons(prefix, icons) {
    var params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var _params$skipHooks = params.skipHooks,
      skipHooks = _params$skipHooks === void 0 ? false : _params$skipHooks;
    var normalized = normalizeIcons(icons);
    if (typeof namespace.hooks.addPack === 'function' && !skipHooks) {
      namespace.hooks.addPack(prefix, normalizeIcons(icons));
    } else {
      namespace.styles[prefix] = _objectSpread2(_objectSpread2({}, namespace.styles[prefix] || {}), normalized);
    }

    /**
     * Font Awesome 4 used the prefix of `fa` for all icons. With the introduction
     * of new styles we needed to differentiate between them. Prefix `fa` is now an alias
     * for `fas` so we'll ease the upgrade process for our users by automatically defining
     * this as well.
     */
    if (prefix === 'fas') {
      defineIcons('fa', icons);
    }
  }

  var icons = {
    "dollar-sign": [384, 512, [128178, 61781, "dollar", "usd"], "24", "M160 528l0-48-128 0 0-64 128 0 0-135.7-48.5-10.2C55.9 258.4 16 209.2 16 152.3 16 85.9 69.9 32 136.3 32l23.7 0 0-48 64 0 0 48 128 0 0 64-128 0 0 132.4 64.5 13.6c55.7 11.7 95.5 60.8 95.5 117.7 0 66.5-53.9 120.3-120.3 120.3l-39.7 0 0 48-64 0zM319.7 365.4c.2-1.9 .3-3.8 .3-5.7 0-.2 0-.4 0-.7 0 2.2-.1 4.3-.3 6.4z"],
    "calendar-check": [448, 512, [], "f274", "M160 32l128 0 0-64 64 0 0 64 32 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l32 0 0-64 64 0 0 64zm32 254.1l-64-64-33.9 33.9 81 81c9.4 9.4 24.6 9.4 33.9 0l145-145-33.9-33.9-128 128z"],
    "question": [320, 512, [10067, 10068, 61736], "3f", "M64 160c0-53 43-96 96-96s96 43 96 96c0 48.9-36.6 89.4-84 95.3-22.3 2.8-44 21.4-44 48.7l0 48 64 0 0-35.2C265 302 320 237.4 320 160 320 71.6 248.4 0 160 0S0 71.6 0 160l64 0zm96 328c22.1 0 40-17.9 40-40s-17.9-40-40-40-40 17.9-40 40 17.9 40 40 40z"],
    "minus": [448, 512, [8211, 8722, 10134, "subtract"], "f068", "M445.6 288l-443.1 0 0-64 443.1 0 0 64z"],
    "microphone-slash": [640, 512, [], "f131", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM160.4 231.9c4 82 69.8 147.8 151.8 151.8l40 40 0 88.2-64 0 0-66.3C179.7 430.1 96.3 336.8 96.3 224l0-32 24.2 0 39.9 39.9zM544.3 224c0 35.1-8.1 68.2-22.5 97.8l-49.1-49.1c4.9-15.3 7.6-31.7 7.6-48.7l0-32 64 0 0 32zM320.3 0c53 0 96 43 96 96l0 120.2-174.9-174.9C258.7 16.4 287.5 0 320.3 0z"],
    "cloud-slash": [640, 512, [], "e137", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zm-213-32l-216.2 0c-88.4 0-160-71.6-160-160 0-58.6 31.5-109.8 78.6-137.7L408.5 480zM320.3 32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 25.7-6.1 49.9-16.8 71.4L247.6 47.6c22.1-10 46.7-15.6 72.6-15.6z"],
    "car": [512, 512, [128664, "automobile"], "f1b9", "M314.8 32c55.1 0 104 35.3 121.4 87.5l35.9 107.7C496.7 250.5 512 283.5 512 320l0 192-64 0 0-64-384 0 0 64-64 0 0-192c0-36.5 15.3-69.5 39.8-92.8L75.8 119.5C93.2 67.3 142.1 32 197.2 32l117.6 0zM112 296a40 40 0 1 0 0 80 40 40 0 1 0 0-80zm288 0a40 40 0 1 0 0 80 40 40 0 1 0 0-80zM197.2 96c-27.5 0-52 17.6-60.7 43.8l-17.6 52.6c3-.2 6-.3 9.1-.3l256 0c3 0 6.1 .1 9.1 .3l-17.5-52.6C366.8 113.6 342.4 96 314.8 96L197.2 96z"],
    "filter": [512, 512, [], "f0b0", "M448 32c35.3 0 64 28.7 64 64l0 16c0 40.3-19 78.2-51.2 102.4L320 320 320 499.8 192 435.8 192 320 51.2 214.4C19 190.2 0 152.3 0 112L0 96C0 60.7 28.7 32 64 32l384 0z"],
    "envelope": [512, 512, [128386, 9993, 61443], "f0e0", "M448 96l0 28.4-192 137.1-192-137.1 0-28.4 384 0zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32z"],
    "cloud-arrow-up": [576, 512, [62338, "cloud-upload", "cloud-upload-alt"], "f0ee", "M288 32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 88.4-71.6 160-160 160l-104 0 0-206.1 72 72 33.9-33.9-113-113c-9.4-9.4-24.6-9.4-33.9 0l-113 113 33.9 33.9 72-72 0 206.1-104 0C71.6 480 0 408.4 0 320 0 246.5 49.6 184.6 117.1 165.9 136 89 205.3 32 288 32z"],
    "at": [512, 512, [61946], "40", "M64 256C64 150 150 64 256 64s192 86 192 192l0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-32c0-70.7-57.3-128-128-128s-128 57.3-128 128 57.3 128 128 128c33.5 0 64-12.9 86.8-33.9 17.6 20.7 43.9 33.9 73.2 33.9 53 0 96-43 96-96l0-32C512 114.6 397.4 0 256 0S0 114.6 0 256 114.6 512 256 512l32 0 0-64-32 0C150 448 64 362 64 256z"],
    "truck": [640, 512, [128666, 9951], "f0d1", "M384 32c35.3 0 64 28.7 64 64l0 32 32 0c88.4 0 160 71.6 160 160l0 160-65.2 0c-7.8 54.3-54.4 96-110.8 96s-103.1-41.7-110.8-96l-66.3 0c-7.8 54.3-54.4 96-110.8 96S72.9 502.3 65.2 448L64 448c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l320 0zM176 384a48 48 0 1 0 0 96 48 48 0 1 0 0-96zm288 0a48 48 0 1 0 0 96 48 48 0 1 0 0-96zm-16-96l128 0c0-53-43-96-96-96l-32 0 0 96z"],
    "user-check": [640, 512, [], "f4fc", "M288 320c88.4 0 160 71.6 160 160l0 32-448 0 0-32c0-88.4 71.6-160 160-160l128 0zM631.6 176l-19.8 19.8-112 112c-10.9 10.9-28.7 10.9-39.6 0-36.7-36.7-59.3-59.3-67.8-67.8L432 200.4c11.8 11.8 27.8 27.8 48 48l92.2-92.2 19.8-19.8 39.6 39.6zM224 256a128 128 0 1 1 0-256 128 128 0 1 1 0 256z"],
    "frame": [512, 512, [], "e495", "M160 96l192 0 0-96 64 0 0 96 96 0 0 64-96 0 0 192 96 0 0 64-96 0 0 96-64 0 0-96-192 0 0 96-64 0 0-96-96 0 0-64 96 0 0-192-96 0 0-64 96 0 0-96 64 0 0 96z"],
    "bell": [512, 512, [128276, 61602], "f0f3", "M320.3 512l-128 0 0-64 128 0 0 64zM256.3 0c88.4 0 160 71.6 160 160l0 88.4 83.8 167.6-487.6 0 83.8-167.6 0-88.4c0-88.4 71.6-160 160-160z"],
    "mobile": [384, 512, [128241, "mobile-android", "mobile-phone"], "f3ce", "M320 0c35.3 0 64 28.7 64 64l0 384c0 35.3-28.7 64-64 64l-256 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 448 0 64 .3 57.5C3.4 27.3 27.3 3.4 57.5 .3L64 0 320 0zM128 392l0 48 128 0 0-48-128 0z"],
    "trophy": [576, 512, [127942], "f091", "M192 0c-35.3 0-64 28.7-64 64l0 4-124 0 0 140c0 59.6 48.4 108 108 108l45.1 0c23.1 32.8 58.2 56.5 98.9 64.8l0 67.2-80 0 0 64 224 0 0-64-80 0 0-67.2c40.7-8.3 75.8-32 98.9-64.8l45.1 0c59.6 0 108-48.4 108-108l0-140-124 0 0-4c0-35.3-28.7-64-64-64L192 0zM464 260l-20.1 0c2.7-11.6 4.1-23.6 4.1-36l0-100 68 0 0 84c0 28.7-23.3 52-52 52zm-331.9 0L112 260c-28.7 0-52-23.3-52-52l0-84 68 0 0 100c0 12.4 1.4 24.4 4.1 36z"],
    "text": [448, 512, [], "f893", "M224.7 32c-.5 0-1 0-1.4 0L64 32C28.7 32 0 60.7 0 96l0 64 64 0 0-64 128 0 0 320-64 0 0 64 192 0 0-64-64 0 0-320 128 0 0 64 64 0 0-64c0-35.3-28.7-64-64-64L224.7 32z"],
    "pen-slash": [640, 512, [], "e213", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM339 410.5L237.5 512 64.3 512 64.3 338.7 165.8 237.2 339 410.5zM453.8 0c67.7 0 122.5 54.8 122.5 122.5 0 32.5-12.9 63.7-35.9 86.6l-65.6 65.6-173.2-173.2 65.6-65.6c23-23 54.1-35.9 86.6-35.9z"],
    "camera-slash": [640, 512, [], "e0d9", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zm-213-32l-280.2 0c-35.3 0-64-28.7-64-64l0-256c0-7.3 1.3-14.2 3.5-20.8L408.5 480zM480.3 96l32 0c35.3 0 64 28.7 64 64l0 216.2-344.2-344.2 184.2 0 64 64z"],
    "gift": [512, 512, [127873], "f06b", "M154.2 60L152 60c-19.9 0-36 16.1-36 36 0 13.9 7.9 26 19.5 32l80.5 0-28.9-49.2C180.2 67.2 167.7 60 154.2 60zm222.3 68c11.6-6 19.5-18.1 19.5-32 0-19.9-16.1-36-36-36l-2.2 0c-13.5 0-26 7.2-32.9 18.8L296 128 376.5 128zM512 192l-32 0 0 256c0 35.3-28.7 64-64 64L96 512c-35.3 0-64-28.7-64-64l0-256-32 0 0-64 65.7 0C62 118 60 107.3 60 96 60 45.2 101.2 4 152 4l2.2 0c33.4 0 64.2 17.7 81.2 46.4L256 85.6 276.7 50.4C293.6 21.7 324.5 4 357.8 4L360 4c50.8 0 92 41.2 92 92 0 11.3-2 22-5.7 32l65.7 0 0 64zm-280 0l0 256 48 0 0-256-48 0z"],
    "block-quote": [512, 512, [], "e0b5", "M64 64l0-32-64 0 0 448 64 0 0-416zm384 64l32 0 0-64-320 0 0 64 288 0zm0 320l32 0 0-64-320 0 0 64 288 0zm64-160l0-64-352 0 0 64 352 0z"],
    "gauge-low": [512, 512, ["tachometer-alt-slow"], "f627", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM127.8 149.3L208 309.7c-10 11.3-16 26.1-16 42.3 0 35.3 28.7 64 64 64s64-28.7 64-64-28.7-64-64-64c-1.7 0-3.4 .1-5.1 .2l-69.5-139-10.8-21.5-42.9 21.5zM96 224a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm320 0a32 32 0 1 0 0 64 32 32 0 1 0 0-64zM368 112a32 32 0 1 0 0 64 32 32 0 1 0 0-64zM256 64a32 32 0 1 0 0 64 32 32 0 1 0 0-64z"],
    "gauge": [512, 512, ["dashboard", "gauge-med", "tachometer-alt-average"], "f624", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM232 96l0 196.7c-23.4 9.5-40 32.5-40 59.3 0 35.3 28.7 64 64 64s64-28.7 64-64c0-26.9-16.6-49.8-40-59.3l0-196.7-48 0zM96 224a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm320 0a32 32 0 1 0 0 64 32 32 0 1 0 0-64zM144 112a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm224 0a32 32 0 1 0 0 64 32 32 0 1 0 0-64z"],
    "signal": [576, 512, [128246, "signal-5", "signal-perfect"], "f012", "M512 512L55 512c-30.4 0-55-24.6-55-55 0-15.9 6.9-31 18.9-41.5L479.6 14.3C490.2 5.1 503.7 0 517.8 0 549.9 0 576 26.1 576 58.2L576 448c0 35.3-28.7 64-64 64z"],
    "share-nodes": [512, 512, ["share-alt"], "f1e0", "M416 192c53 0 96-43 96-96s-43-96-96-96-96 43-96 96c0 4 .2 8 .7 11.9l-158.1 79C145.4 170.2 121.9 160 96 160 43 160 0 203 0 256s43 96 96 96c25.9 0 49.4-10.2 66.6-26.9l158.1 79c-.5 3.9-.7 7.8-.7 11.9 0 53 43 96 96 96s96-43 96-96-43-96-96-96c-25.9 0-49.4 10.2-66.6 26.9l-158.1-79c.5-3.9 .7-7.8 .7-11.9s-.2-8-.7-11.9l158.1-79C366.6 181.8 390.1 192 416 192z"],
    "hard-drive": [512, 512, [128436, "hdd"], "f0a0", "M403.5 .2c27 2.3 49.9 21.5 56.6 48.2l50 199.9c1.3 5.1 1.9 10.3 1.9 15.5L512 448c0 35.3-28.7 64-64 64L64 512c-4.3 0-8.5-.5-12.6-1.3-.7-.1-1.4-.3-2.1-.5-1.3-.3-2.6-.6-3.9-1-.7-.2-1.5-.5-2.2-.8-1.2-.4-2.4-.8-3.6-1.3-.7-.3-1.4-.6-2.1-.9-1.1-.5-2.3-1-3.3-1.6-.8-.4-1.7-.9-2.5-1.4-.9-.5-1.7-1-2.6-1.6-.8-.5-1.5-1-2.2-1.5-1-.7-1.9-1.4-2.8-2.1-.6-.5-1.3-1.1-1.9-1.6-.9-.8-1.8-1.6-2.6-2.4-.6-.5-1.1-1.1-1.7-1.7-.8-.9-1.6-1.8-2.4-2.7-.6-.6-1.1-1.3-1.7-2-.7-.9-1.3-1.7-1.9-2.6-.5-.7-1.1-1.5-1.6-2.2-.6-.9-1.1-1.8-1.7-2.7-.5-.8-1-1.6-1.4-2.5-.5-.9-.9-1.8-1.3-2.7s-.9-1.8-1.3-2.8c-.3-.8-.7-1.7-1-2.6-.4-1-.7-2-1.1-3.1-1.2-3.9-2-7.9-2.4-12L0 448 0 263.9c0-5.2 .6-10.5 1.9-15.5l50-199.9C59 20 84.6 0 114 0L398 0 403.5 .2zM112 336a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm96 0a32 32 0 1 0 0 64 32 32 0 1 0 0-64zM74 224L438 224 398 64 114 64 74 224z"],
    "ellipsis": [512, 512, ["ellipsis-h"], "f141", "M256 192a64 64 0 1 1 0 128 64 64 0 1 1 0-128zM64 192a64 64 0 1 1 0 128 64 64 0 1 1 0-128zm384 0a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"],
    "percent": [448, 512, [62101, 62785, "percentage"], "25", "M352 480a96 96 0 1 1 0-192 96 96 0 1 1 0 192zM438.6 86.6l-384 384-45.2-45.2 384-384 45.2 45.2zM96 224a96 96 0 1 1 0-192 96 96 0 1 1 0 192z"],
    "display": [512, 512, [], "e163", "M448 0c35.3 0 64 28.7 64 64l0 256-.3 6.5C508.4 358.8 481.1 384 448 384l-160 0 0 64 96 0 0 64-256 0 0-64 96 0 0-64-160 0C30.9 384 3.6 358.8 .3 326.5L0 320 0 64C0 28.7 28.7 0 64 0L448 0z"],
    "magnifying-glass": [576, 512, [128269, "search"], "f002", "M256.3 0c123.7 0 224 100.3 224 224 0 50.3-16.6 96.7-44.6 134.1L557.5 480 512.3 525.3 390.4 403.4c-37.4 28-83.8 44.6-134.1 44.6-123.7 0-224-100.3-224-224S132.5 0 256.3 0z"],
    "cloud-moon": [640, 512, [], "f6c3", "M608 254.9l-.7 1.1c-13.6 21.3-31 39.9-51.3 55-9.3-19.5-21.5-37.4-36.1-53 5.5-4.3 10.7-8.9 15.6-14-88.2-30.1-151.6-113.7-151.6-212 0-8.2 .4-16.3 1.3-24.3-42.7 14.6-76.3 48.7-90.3 91.6-27.3-4.8-50.6-3.6-65.8-1.8 19.1-83.9 89-148.5 175.5-159.8 8.9-1.2 18-1.8 27.3-1.8 15.3 0 30.2 1.6 44.5 4.8-12.4 17.8-21.3 38.3-25.6 60.5-1.9 10-3 20.2-3 30.8 0 75.1 51.7 138 121.4 155.3 12.4 3.1 25.3 4.7 38.6 4.7 9.2 0 18.2-.8 27-2.3-5.3 23.5-14.5 45.4-27 65.2zm-500.6 5.8C130.9 201.7 188.6 160 256 160s125.1 41.7 148.6 100.7c61.8 16.2 107.4 72.4 107.4 139.3 0 79.5-64.5 144-144 144l-224 0C64.5 544 0 479.5 0 400 0 333.1 45.6 276.9 107.4 260.7z"],
    "floppy-disk": [512, 512, [128190, 128426, "save"], "f0c7", "M325.5 0c17 0 33.2 6.8 45.2 18.8L493.3 141.2c12 12 18.7 28.3 18.7 45.2L512 448c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64C0 28.7 28.7 0 64 0L325.5 0zM256 272a80 80 0 1 0 0 160 80 80 0 1 0 0-160zM96 64l0 96 224 0 0-96-224 0z"],
    "palette": [512, 512, [127912], "f53f", "M256 0c141.4 0 256 114.6 256 256 0 39.2-8.9 76.4-24.7 109.7L478.6 384 320 384c-17.7 0-32 14.3-32 32l0 96-32 0C114.6 512 0 397.4 0 256S114.6 0 256 0zM128 180a44 44 0 1 0 0 88 44 44 0 1 0 0-88zm256 0a44 44 0 1 0 0 88 44 44 0 1 0 0-88zM256 84a44 44 0 1 0 0 88 44 44 0 1 0 0-88z"],
    "unlock": [512, 512, [128275], "f09c", "M384 64c-35.3 0-64 28.7-64 64l0 64c35.3 0 64 28.7 64 64l0 192c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 256c0-35.3 28.7-64 64-64l192 0 0-64C256 57.3 313.3 0 384 0S512 57.3 512 128l0 128-64 0 0-128c0-35.3-28.7-64-64-64z"],
    "key": [512, 512, [128273], "f084", "M352.5 0c88.4 0 160 71.6 160 160s-71.6 160-160 160c-32.6 0-63-9.8-88.2-26.5l-74.5 74.5 41.4 41.4-45.2 45.2-41.4-41.4-34.8 34.7 41.4 41.4-45.2 45.2-86.6-86.6 199.8-199.8c-16.7-25.3-26.5-55.6-26.5-88.2 0-88.4 71.6-160 160-160z"],
    "skull": [512, 512, [128128], "f54c", "M0 309.5L0 256C0 114.6 114.6 0 256 0S512 114.6 512 256l0 53.5c0 17-6.7 33.3-18.7 45.3L448 400 448 448c0 35.3-28.7 64-64 64l-40 0 0-80-48 0 0 80-80 0 0-80-48 0 0 80-40 0c-35.3 0-64-28.7-64-64l0-48-45.3-45.3C6.7 342.7 0 326.5 0 309.5zM224 240a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zm112 48a48 48 0 1 0 0-96 48 48 0 1 0 0 96z"],
    "gamepad-modern": [576, 512, [127918, 63676, "gamepad-alt"], "e5a2", "M400 480l48 0c70.7 0 128-57.3 128-128l0-128c0-106-86-192-192-192L192 32C86 32 0 118 0 224L0 352c0 70.7 57.3 128 128 128l48 0 64-96 96 0 64 96zm0-344a40 40 0 1 1 0 80 40 40 0 1 1 0-80zm24 136a40 40 0 1 1 80 0 40 40 0 1 1 -80 0zM184 144l0 56 56 0 0 48-56 0 0 56-48 0 0-56-56 0 0-48 56 0 0-56 48 0z"],
    "tree": [512, 512, [127794], "f1bb", "M48.1 448l176 0 0 64 64 0 0-64 176 0c33 0 51.8-37.6 32-64l-69.7-93 7.6-7.6c13.8-13.8 15.6-35.6 4.3-51.5L288.6 22.5c-16-22.3-49.1-22.3-65.1 0L74 231.9c-11.4 15.9-9.6 37.7 4.3 51.5l7.6 7.6-69.7 93c-19.8 26.4-1 64 32 64z"],
    "phone-arrow-up-right": [512, 512, ["phone-arrow-up", "phone-outgoing"], "e224", "M83.1 29.3c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-49.4 49.4c-.8 .8-1.1 2-.8 3.2 14.6 53.4 56.3 95.1 109.7 109.7 1.1 .3 2.3 0 3.2-.8l49.4-49.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9c-45 44.9-109.6 64.7-172 52.8-141.9-27-253.7-138.9-280.8-280.8-11.9-62.4 7.8-127 52.8-172L83.1 29.3zM480.6 4c7.4 0 14.6 2.9 19.8 8.2s8.2 12.4 8.2 19.8l0 156-56 0 0-88.4-112.2 112.2-19.8 19.8-39.6-39.6 19.8-19.8 112.2-112.2-88.4 0 0-56 156 0z"],
    "pen-line": [576, 512, [], "e212", "M389.5 0c67.7 0 122.5 54.8 122.5 122.5 0 32.5-12.9 63.7-35.9 86.6L173.2 512 0 512 0 338.7 302.9 35.9C325.8 12.9 357 0 389.5 0zM576 512l-288 0 0-64 288 0 0 64z"],
    "paintbrush": [576, 512, [128396, "paint-brush"], "f1fc", "M476.1 0c55.2 0 99.9 44.7 99.9 99.9 0 24.8-9.3 48.7-25.8 67l-3.4 3.6-194.8 194.8c0 .9 .1 1.8 .1 2.7 0 79.5-64.5 144-144 144l-208 0 0-64 64 0 0-80c0-79.5 64.5-144 144-144 .9 0 1.8 0 2.7 .1l194.8-194.8 3.6-3.4C427.4 9.3 451.3 0 476.1 0zM208 288c-44.2 0-80 35.8-80 80l0 80 80 0c44.2 0 80-35.8 80-80s-35.8-80-80-80z"],
    "flower": [512, 512, [127804, 10047], "f7ff", "M15.4 204.7c10.5 20.5 25.8 38.1 44.7 51.3-18.9 13.2-34.2 30.9-44.7 51.3-9.9 19.3-15.4 41.1-15.4 64 0 77.7 63 140.7 140.7 140.7 47.1 0 89.6-23.4 115.3-60.1 25.7 36.7 68.2 60.1 115.3 60.1 77.7 0 140.7-63 140.7-140.7 0-22.9-5.5-44.7-15.4-64-10.5-20.5-25.8-38.1-44.7-51.3 18.9-13.2 34.2-30.9 44.7-51.3 9.9-19.3 15.4-41.1 15.4-64 0-77.7-63-140.7-140.7-140.7-47.1 0-89.6 23.4-115.3 60.1-25.7-36.7-68.2-60.1-115.3-60.1-77.7 0-140.7 63-140.7 140.7 0 22.9 5.5 44.7 15.4 64zM256 176a80 80 0 1 1 0 160 80 80 0 1 1 0-160z"],
    "battery-slash": [640, 512, [], "f377", "M621.3 512L576 557.3 18.8 0 64-45.2 621.3 512zm-245-64L64 448c-35.3 0-64-28.7-64-64L0 128c0-15.7 5.6-30.1 15-41.2L376.2 448zM640 352l-64 0 0-192 64 0 0 192zM480 64c35.3 0 64 28.7 64 64L544 344.2 263.8 64 480 64z"],
    "font-case": [640, 512, [], "f866", "M96 416l0-96 160 0 0 96-32 0 0 64 128 0 0-64-32 0 0-240c0-79.5-64.5-144-144-144S32 96.5 32 176l0 240-32 0 0 64 128 0 0-64-32 0zM544 128l-128 0 0 64 128 0c17.7 0 32 14.3 32 32l0 32-96 0c-53 0-96 43-96 96l0 32c0 53 43 96 96 96l64 0c11.2 0 22-1.9 32-5.5l0 5.5 64 0 0-256c0-53-43-96-96-96z"],
    "camera": [512, 512, [62258, "camera-alt"], "f030", "M352 32l64 64 32 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 160c0-35.3 28.7-64 64-64l32 0 64-64 192 0zM256 384a96 96 0 1 0 0-192 96 96 0 1 0 0 192z"],
    "eye": [576, 512, [128065], "f06e", "M288.2 32c135.2 0 241.5 105.6 290.7 224-49.1 118.4-155.4 224-290.7 224S46.6 374.4-2.5 256C46.6 137.6 152.9 32 288.2 32zm0 148a76 76 0 1 0 -.3 152 76 76 0 1 0 .3-152z"],
    "trash": [448, 512, [], "f1f8", "M160 0C124.7 0 96 28.7 96 64l0 32-96 0 0 64 32 0 0 288c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-288 32 0 0-64-96 0 0-32c0-35.3-28.7-64-64-64L160 0zM288 96l-128 0 0-32 128 0 0 32z"],
    "clipboard-check": [448, 512, [], "f46c", "M128 128l192 0 0-96 64 0c35.3 0 64 28.7 64 64l0 352c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l64 0 0 96zm64 190.1l-64-64-33.9 33.9 81 81c9.4 9.4 24.6 9.4 33.9 0l145-145-33.9-33.9-128 128zM224-32c35.3 0 64 28.7 64 64l0 64-128 0 0-64c0-35.3 28.7-64 64-64z"],
    "equals": [448, 512, [62764], "3d", "M448 384l-448 0 0-64 448 0 0 64zm0-192l-448 0 0-64 448 0 0 64z"],
    "expand": [512, 512, [], "f065", "M32 0C14.3 0 0 14.3 0 32l0 128 64 0 0-96 96 0 0-64-128 0zM64 384l0-32-64 0 0 128c0 17.7 14.3 32 32 32l128 0 0-64-96 0 0-64zM384 0l-32 0 0 64 96 0 0 96 64 0 0-128c0-17.7-14.3-32-32-32L384 0zM512 384l0-32-64 0 0 96-96 0 0 64 128 0c17.7 0 32-14.3 32-32l0-96z"],
    "signal-weak": [576, 512, ["signal-1"], "f68c", "M517.8 0C549.9 0 576 26.1 576 58.2L576 448c0 35.3-28.7 64-64 64L55 512c-30.4 0-55-24.6-55-55 0-15.9 6.9-31 18.9-41.5L479.6 14.3C490.2 5.1 503.7 0 517.8 0zM79.1 448L512 448 512 70.9 79.1 448z"],
    "water": [640, 512, [], "f773", "M0 0L640 0c0 70.7-57.3 128-128 128-38.2 0-72.5-16.8-96-43.3-23.5 26.6-57.8 43.3-96 43.3s-72.5-16.8-96-43.3C200.5 111.2 166.2 128 128 128 57.3 128 0 70.7 0 0zM64 192l576 0c0 70.7-57.3 128-128 128-38.2 0-72.5-16.8-96-43.3-23.5 26.6-57.8 43.3-96 43.3s-72.5-16.8-96-43.3C200.5 303.2 166.2 320 128 320 57.3 320 0 262.7 0 192l64 0zm0 192l576 0c0 70.7-57.3 128-128 128-38.2 0-72.5-16.8-96-43.3-23.5 26.6-57.8 43.3-96 43.3s-72.5-16.8-96-43.3C200.5 495.2 166.2 512 128 512 57.3 512 0 454.7 0 384l64 0z"],
    "signal-good": [576, 512, ["signal-3"], "f68e", "M517.8 0C549.9 0 576 26.1 576 58.2L576 448c0 35.3-28.7 64-64 64L55 512c-30.4 0-55-24.6-55-55 0-15.9 6.9-31 18.9-41.5L479.6 14.3C490.2 5.1 503.7 0 517.8 0zM412 158l0 290 100 0 0-377.1-100 87.1z"],
    "stop": [384, 512, [9209], "f04d", "M0 128C0 92.7 28.7 64 64 64l256 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128z"],
    "signal-slash": [640, 512, [], "f695", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zm-181 0L87.2 512c-30.4 0-55-24.6-55-55 0-15.9 6.9-31 18.9-41.5L207.7 279.2 440.5 512zM550 0c32.1 0 58.2 26.1 58.2 58.2l0 350-255.5-255.5 159-138.5C522.4 5.1 536 0 550 0z"],
    "command": [512, 512, [], "e142", "M224 160l0-48C224 50.1 173.9 0 112 0S0 50.1 0 112 50.1 224 112 224l48 0 0 64-48 0C50.1 288 0 338.1 0 400s50.1 112 112 112 112-50.1 112-112l0-48 64 0 0 48c0 61.9 50.1 112 112 112s112-50.1 112-112-50.1-112-112-112l-48 0 0-64 48 0c61.9 0 112-50.1 112-112S461.9 0 400 0 288 50.1 288 112l0 48-64 0zm64 128l-64 0 0-64 64 0 0 64z"],
    "tv-retro": [512, 512, [128250], "f401", "M160-13.3c6.6 6.6 38.6 38.6 96 96 57.4-57.4 89.4-89.4 96-96L397.3 32c-12 12-33.3 33.3-64 64L448 96c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 160c0-35.3 28.7-64 64-64l114.7 0c-30.7-30.7-52-52-64-64L160-13.3zM288 416l160 0 0-256-160 0 0 256zm80-216a40 40 0 1 1 0 80 40 40 0 1 1 0-80zM328 336a40 40 0 1 1 80 0 40 40 0 1 1 -80 0z"],
    "angle-left": [320, 512, [8249], "f104", "M269.7 64l-192 192 192 192-45.3 45.2-214.6-214.6c-12.5-12.5-12.5-32.8 0-45.3L224.5 18.7 269.7 64z"],
    "arrow-right-to-line": [512, 512, [8677, "arrow-to-right"], "f340", "M512 480l-64 0 0-448 64 0 0 448zM342.6 233.4l2.2 2.4c10.2 12.6 9.5 31.1-2.2 42.8l-150.6 150.6-45.2-45.3 96-96-242.8 0 0-64 242.8 0-96-96 45.2-45.2 150.6 150.6z"],
    "radio": [512, 512, [128251], "f8d7", "M456.5 52.7l-30.4 10.1-196.9 65.6 218.8 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64l-384 0c-35.3 0-64-28.7-64-64L0 183.5c0-27.5 17.6-52 43.8-60.7L405.9 2.1 436.2-8 456.5 52.7zM400 304.5a32 32 0 1 0 0-64 32 32 0 1 0 0 64zm32 64a32 32 0 1 0 -64 0 32 32 0 1 0 64 0zm-304-48a64 64 0 1 1 128 0 64 64 0 1 1 -128 0zm176 0a112 112 0 1 0 -224 0 112 112 0 1 0 224 0z"],
    "pencil-line": [576, 512, [], "e74f", "M389.5 0c67.7 0 122.5 54.8 122.5 122.5 0 32.5-12.9 63.7-35.9 86.6L173.2 512 0 512 0 338.7 302.9 35.9C325.8 12.9 357 0 389.5 0zM576 512l-288 0 0-64 288 0 0 64zM389.5 64c-15.5 0-30.4 6.2-41.4 17.1l-33.7 33.7 82.7 82.8 33.7-33.7c11-11 17.1-25.9 17.1-41.4 0-32.3-26.2-58.5-58.5-58.5z"],
    "pen-to-square": [512, 512, ["edit"], "f044", "M345.8-6.6l-208 208-9.4 9.4 0 141.3 141.3 0 9.4-9.4 208-208c39-39 39-102.2 0-141.3s-102.2-39-141.3 0zM216.6 32L64.4 32C29 32 .4 60.7 .4 96l0 320c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-152.2-64 64 0 88.2-320 0 0-320 88.2 0 64-64z"],
    "circle-half-stroke": [512, 512, [9680, "adjust"], "f042", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm32-66.7C378.8 430 448 351.1 448 256S378.8 81.9 288 66.7l0 378.6z"],
    "clock": [512, 512, [128339, "clock-four"], "f017", "M0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zM280 128l0-24-48 0 0 152c0 13.3 10.7 24 24 24l136 0 0-48-112 0 0-104z"],
    "book": [448, 512, [128212], "f02d", "M0 336l0 80c0 53 43 96 96 96l352 0 0-448-64 0 0 384-288 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l224 0 0-384-224 0C43 0 0 43 0 96L0 336z"],
    "magnifying-glass-minus": [576, 512, ["search-minus"], "f010", "M256.3 0c123.7 0 224 100.3 224 224 0 50.3-16.6 96.7-44.6 134.1L557.5 480 512.3 525.3 390.4 403.4c-37.4 28-83.8 44.6-134.1 44.6-123.7 0-224-100.3-224-224S132.5 0 256.3 0zm-96 200l0 48 192 0 0-48-192 0z"],
    "paper-plane": [512, 512, [61913], "f1d8", "M64 2L497.9 232.5c8.7 4.6 14.1 13.7 14.1 23.5s-5.4 18.9-14.1 23.5L64 510 0 544 0 432 69.1 280 248 280 248 232 69.1 232 0 80 0-32 64 2z"],
    "heart": [576, 512, [128153, 128154, 128155, 128156, 128420, 129293, 129294, 129505, 9829, 10084, 61578], "f004", "M289.8 77.8c61.1-61.1 160.2-61.1 221.3 0 61.1 61.1 61.1 160.2 0 221.2L288.4 521.7 65.8 299.1C4.7 238 4.7 138.9 65.8 77.8s160.2-61.1 221.3 0l1.4 1.4 1.4-1.4z"],
    "battery-half": [640, 512, ["battery-3"], "f242", "M480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l416 0zM640 352l-64 0 0-192 64 0 0 192zM128 192l0 128 160 0 0-128-160 0z"],
    "font-awesome": [512, 512, [62501, 62694, "font-awesome-flag", "font-awesome-logo-full"], "f2b4", "M64 0c26.5 0 48 21.5 48 48 0 5.6-1 11-2.8 16l312.2 0c32.3 0 58.6 26.2 58.6 58.6 0 5.9-.9 11.8-2.7 17.5l-2 5.6-40.5 94.4 40.5 94.4 2 5.6c1.8 5.7 2.7 11.6 2.7 17.5 0 32.3-26.2 58.6-58.6 58.6l-325.4 0 0 96-64 0 0-428.3C22.2 74.9 16 62.2 16 48 16 21.5 37.5 0 64 0z"],
    "forward": [576, 512, [9193], "f04e", "M64 64l-32 0 0 384 76.4 0 9.2-8.3 170.5-155 0 163.3 76.4 0 9.2-8.3 176-160C556.2 273.6 560 265 560 256s-3.8-17.6-10.5-23.7l-176-160-9.2-8.3-76.4 0 0 163.3-170.5-155-9.2-8.3-44.4 0z"],
    "triangle": [576, 512, [9650], "f2ec", "M288 32c10.7 0 20.7 5.3 26.6 14.2l256 384c6.5 9.8 7.2 22.4 1.6 32.8S555.8 480 544 480L32 480c-11.8 0-22.7-6.5-28.2-16.9s-4.9-23 1.6-32.8l256-384 2.4-3.2c6-7 14.9-11.1 24.2-11.1z"],
    "lightbulb-slash": [640, 512, [], "f673", "M621.5 512L576.3 557.2 19 0 64.3-45.3 621.5 512zM384.3 455.7l0 56.2-128 0 0-64 120.3 0 7.8 7.8zM344.5 416l-56.3 0c-33.2 0-60.4-25.2-63.7-57.5-55.3-31.9-93.3-90.6-96.1-158.5l216 216zM320.3 0c106 0 192 86 192 192 0 34.6-9.2 67-25.3 95L308.8 108.8c18.1-8.2 38.2-12.8 59.4-12.8 15.2 0 29.9 2.3 43.7 6.7-23.2-23.9-55.7-38.7-91.7-38.7-16.7 0-32.6 3.2-47.2 9L225.2 25.2C253.2 9.2 285.7 0 320.3 0z"],
    "landmark-dome": [512, 512, ["landmark-alt"], "f752", "M0 216.3C0 79.2 111.2-32 248.3-32l15.5 0c137.1 0 248.3 111.2 248.3 248.3 0 19.3-13.8 35.4-32 39l0 128.7-64 0 0-128-64 0 0 128-64 0 0-128-64 0 0 128-64 0 0-128-64 0 0 128-64 0 0-128.8c-18.2-3.6-32-19.7-32-39zM0 448l512 0 0 64-512 0 0-64z"],
    "moon-star": [512, 512, [], "e7c9", "M224 128c0 115.3 87.1 210.3 199.1 222.6 8.2 .9 16.5 1.4 24.9 1.4 16.2 0 32.1-1.7 47.4-5-9.5 25.1-22.9 48.3-39.4 68.9-46.9 58.6-119 96.1-199.9 96.1-141.4 0-256-114.6-256-256 0-116.8 78.3-215.4 185.3-246.1 22.5-6.4 46.2-9.9 70.7-9.9 2.7 0 5.4 0 8.1 .1-2.8 4-5.5 8.2-8.1 12.4-19.4 32.2-32 71.3-32 115.4zM444 32l0 68 68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0z"],
    "strikethrough": [448, 512, [], "f0cc", "M96 352c0 35.3 28.7 64 64 64l136.1 0c30.9 0 55.9-25 55.9-55.9 0-2.7-.2-5.4-.6-8.1l64.3 0c.2 2.7 .3 5.4 .3 8.1 0 66.2-53.7 119.9-119.9 119.9L160 480C89.3 480 32 422.7 32 352l64 0zm295.9-64L0 288 0 224 56.1 224C40.9 203.8 32 178.7 32 151.9 32 85.7 85.7 32 151.9 32L288 32c70.7 0 128 57.3 128 128l-64 0c0-35.3-28.7-64-64-64L151.9 96c-30.9 0-55.9 25-55.9 55.9 0 26.7 18.8 49.6 45 54.8l86.2 17.2 220.8 0 0 64-56.1 0z"],
    "shield-check": [448, 512, [], "f2f7", "M234.1 1.7L404.2 58.3c26.1 8.7 43.7 33.2 43.8 60.7l0 146.3c0 84.8-47.9 162.4-123.8 200.3L224 515.8 123.8 465.7C47.9 427.7 0 350.2 0 265.3L0 119.1c0-27.5 17.6-52 43.8-60.7L213.9 1.7 224-1.8 234.1 1.7zM192 286.1l-48-48-33.9 33.9 65 65c9.4 9.4 24.6 9.4 33.9 0l129-129-33.9-33.9-112 112z"],
    "arrow-down-to-bracket": [448, 512, [], "e094", "M64 320l0 96c0 17.7 14.3 32 32 32l256 0c17.7 0 32-14.3 32-32l0-96 64 0 0 96c0 53-43 96-96 96L96 512c-53 0-96-43-96-96l0-96 64 0zm192-77.3l96-96 45.3 45.3-150.6 150.6-2.4 2.2c-12.6 10.2-31.1 9.5-42.8-2.2L50.8 192 96 146.7 192 242.7 192 0 256 0 256 242.7z"],
    "star-half": [576, 512, [61731], "f089", "M373.2 165.1c1.2 2.3 3.3 3.8 5.8 4.2L562.3 199 431.5 330.7c-1.8 1.8-2.6 4.4-2.2 6.9L457.7 521 292 437.3c-2.3-1.1-5-1.1-7.2 0L119.1 521 147.5 337.6c.4-2.5-.4-5.1-2.2-6.9L14.5 199 197.8 169.3c1.9-.3 3.6-1.3 4.8-2.7l1.1-1.5 84.8-165.1 84.8 165.1zM288.4 372.5c11.1 0 22.3 2.5 32.5 7.7l54.5 27.5-9.3-60.3c-3.5-22.6 3.9-45.6 20.1-61.8l43-43.3-60.2-9.8c-22.6-3.7-42.1-17.8-52.5-38.2l-27.9-54.3 0 232.4z"],
    "arrow-down-to-line": [448, 512, ["arrow-to-bottom"], "f33d", "M448 512l-448 0 0-64 448 0 0 64zM256 242.8l96-96 45.3 45.2-150.6 150.6-2.4 2.2c-12.6 10.2-31.1 9.5-42.8-2.2L50.8 192 96 146.8 192 242.8 192 0 256 0 256 242.8z"],
    "fire": [448, 512, [128293], "f06d", "M224 512c123.7 0 224-100.3 224-224 0-71.7-28.5-140.5-79.2-191.2L336 64 274.3 125.7 160 0 74.9 93.6C26.7 146.6 0 216.4 0 288 0 411.7 100.3 512 224 512zm0-256l59 62.5c13.5 14.3 21 33.1 21 52.7 0 42.4-34.4 76.8-76.8 76.8l-6.5 0c-42.4 0-76.8-34.4-76.8-76.8 0-19.6 7.5-38.5 21-52.7L224 256z"],
    "magnifying-glass-plus": [576, 512, ["search-plus"], "f00e", "M256.3 0c123.7 0 224 100.3 224 224 0 50.3-16.6 96.7-44.6 134.1L557.5 480 512.3 525.3 390.4 403.4c-37.4 28-83.8 44.6-134.1 44.6-123.7 0-224-100.3-224-224S132.5 0 256.3 0zm-24 128l0 72-72 0 0 48 72 0 0 72 48 0 0-72 72 0 0-48-72 0 0-72-48 0z"],
    "rectangle-vertical": [448, 512, ["rectangle-portrait"], "f2fb", "M384 0c35.3 0 64 28.7 64 64l0 384c0 33.1-25.2 60.4-57.5 63.7l-6.5 .3-320 0-6.5-.3C25.2 508.4 0 481.1 0 448L0 64C0 28.7 28.7 0 64 0L384 0z"],
    "burger": [512, 512, ["hamburger"], "f805", "M320 0C426 0 512 86 512 192l-64 0 0 0-384 0 0 0-64 0C0 86 86 0 192 0L320 0zM0 256l512 0 0 64-512 0 0-64zM0 384l512 0c0 70.7-57.3 128-128 128l-256 0C57.3 512 0 454.7 0 384z"],
    "print": [512, 512, [128424, 128438, 9113], "f02f", "M416 128l32 0c35.3 0 64 28.7 64 64l0 160c0 35.3-28.7 64-64 64l-32 0 0 96-320 0 0-96-32 0C30.9 416 3.6 390.8 .3 358.5L0 352 0 192c0-35.3 28.7-64 64-64l32 0 0-128 320 0 0 128zM160 320l0 128 192 0 0-128-192 0zm0-192l192 0 0-64-192 0 0 64z"],
    "users": [640, 512, [], "f0c0", "M480 320c88.4 0 160 71.6 160 160l0 32-64 0 0-32c0-49.4-37.3-90.1-85.3-95.4-11.4-24.2-27-46.1-45.9-64.6l35.3 0zM288 384c11.2 0 22 2 32 5.5-27.3 9.6-48.8 31.2-58.5 58.5l-66.3 0c4.8-23.6 14.8-45.4 28.8-64l64 0zM416 0c70.7 0 128 57.3 128 128S486.7 256 416 256c-15 0-29.4-2.6-42.8-7.4 13.8-17.1 24.8-36.5 32.1-57.6 3.5 .6 7 1 10.7 1 35.3 0 64-28.7 64-64s-28.7-64-64-64c-3.6 0-7.2 .4-10.7 .9-7.3-21.1-18.3-40.6-32.1-57.6 13.4-4.7 27.7-7.3 42.7-7.3zM288 320c88.4 0 160 71.6 160 160l0 32-448 0 0-32c0-88.4 71.6-160 160-160l128 0zm-64-64a128 128 0 1 1 0-256 128 128 0 1 1 0 256z"],
    "alarm-clock": [640, 512, [9200], "f34e", "M319.7 512a256 256 0 1 1 .5-512 256 256 0 1 1 -.5 512zM296.3 256c0 13.3 10.7 24 24 24l136 0 0-48-112 0 0-128-48 0 0 152zM173.5 0L64.3 109.2 19 64 128.3-45.2 173.5 0zm448 64L576.3 109.2 467 0 512.3-45.2 621.5 64z"],
    "database": [448, 512, [], "f1c0", "M448 416c0 19.5-9.2 41-30 52.5-34.9 19.4-102.3 43.5-194 43.5-86 0-150.6-21.2-187.1-39.8L30 468.5C9.2 457 0 435.5 0 416l0-45.9C64.3 394.2 141.7 408 224 408s159.7-13.8 224-37.9l0 45.9zm0-97.7C387.9 343.9 310.2 360 224 360S60.1 343.9 0 318.3L0 210.1C64.3 234.3 141.7 248 224 248s159.7-13.7 224-37.9l0 108.2zM224 0c91.7 0 159.1 24.1 194 43.5 20.7 11.5 30 33 30 52.5l0 62.3C387.9 183.9 310.2 200 224 200S60.1 183.9 0 158.3L0 96C0 76.5 9.2 55 30 43.5l6.9-3.7C73.4 21.2 138 0 224 0z"],
    "newspaper": [576, 512, [128240], "f1ea", "M576 384c0 53-43 96-96 96L96 480c-53 0-96-43-96-96l0-288 64 0 0 288c0 17.7 14.3 32 32 32s32-14.3 32-32l0-352 448 0 0 352zM224 344l256 0 0-48-256 0 0 48zm0-128l256 0 0-48-256 0 0 48z"],
    "location-arrow": [512, 512, [], "f124", "M468.3 2.2c11.8-4.6 25.3-1.8 34.3 7.2s11.8 22.5 7.2 34.3l-176 448-8 20.3-101.8 0 0-224-224 0 0-101.8 20.3-8 448-176z"],
    "rectangle-code": [640, 512, [], "e322", "M544 32c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64l-384 0c-33.1 0-60.4-25.2-63.7-57.5l-.3-6.5 0-128 288 0 0-256 160 0zM135.6 64c-9.1 9.1-30.4 30.5-64 64 33.5 33.5 54.8 54.9 64 64l-39.6 39.6-19.8-19.8-64-64c-10.9-10.9-10.9-28.7 0-39.6l64-64 19.8-19.8 39.6 39.6zM243.8 44.2l64 64c10.9 10.9 10.9 28.7 0 39.6l-64 64-19.8 19.8-39.6-39.6c9.1-9.1 30.4-30.5 64-64-33.5-33.5-54.8-54.9-64-64L224 24.4 243.8 44.2z"],
    "arrow-right-to-bracket": [512, 512, ["sign-in"], "f090", "M416 32c53 0 96 43 96 96l0 256c0 53-43 96-96 96l-96 0 0-64 96 0c17.7 0 32-14.3 32-32l0-256c0-17.7-14.3-32-32-32l-96 0 0-64 96 0zM342.6 233.4l2.2 2.4c10.3 12.6 9.5 31.1-2.2 42.8l-150.6 150.6-45.2-45.2 96-96-242.8 0 0-64 242.8 0-96-96 45.2-45.3 150.6 150.6z"],
    "folder-check": [512, 512, [], "e64e", "M288 96l160 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l160 0 64 64zM224 318.1l-64-64-33.9 33.9 81 81c9.4 9.4 24.6 9.4 33.9 0l145-145-33.9-33.9-128 128z"],
    "video-slash": [640, 512, [], "f4e2", "M621.5 512L576.3 557.2 19 0 64.3-45.3 621.5 512zM405 476.5c-6.5 2.2-13.5 3.5-20.7 3.5l-288 0c-35.3 0-64-28.7-64-64l0-312.3 372.7 372.7zM384.3 32c35.3 0 64 28.7 64 64l0 45.7c69.3-19.8 122.7-35.1 160-45.7l0 312.3-64-64 0-163.4-96 27.4 0 40-216.3-216.2 152.3 0z"],
    "comment": [512, 512, [128489, 61669], "f075", "M256 32c141.4 0 256 100.3 256 224S397.4 480 256 480c-22.8 0-44.9-2.7-65.9-7.6L32 512 46.2 384.3C17.1 347.9 0 303.7 0 256 0 132.3 114.6 32 256 32z"],
    "file-check": [384, 512, [], "f316", "M384 128l0 320c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64C0 28.7 28.7 0 64 0L256 0 384 128zM160 318.1l-48-48-33.9 33.9 65 65c9.4 9.4 24.6 9.4 33.9 0l129-129-33.9-33.9-112 112z"],
    "video": [576, 512, ["video-camera"], "f03d", "M416 416l0-45.7c69.3 19.8 122.7 35.1 160 45.7l0-320c-37.3 10.7-90.7 25.9-160 45.7L416 96c0-35.3-28.7-64-64-64L64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l288 0c35.3 0 64-28.7 64-64zm96-84.8l-96-27.4 0-95.4 96-27.4 0 150.3z"],
    "calendar-plus": [448, 512, [], "f271", "M160 32l128 0 0-64 64 0 0 64 32 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l32 0 0-64 64 0 0 64zm40 128l0 72-72 0 0 48 72 0 0 72 48 0 0-72 72 0 0-48-72 0 0-72-48 0z"],
    "wheelchair-move": [448, 512, ["wheelchair-alt"], "e2ce", "M171 224.4l-9.7 17.9C126.7 306.2 173 384 245.7 384l74.3 0c0 88.4-71.6 160-160 160S0 472.4 0 384 71.6 224 160 224c3.7 0 7.3 .2 11 .4zM255.7 96c42.4 0 69.4 45.3 49.2 82.7L245.7 288 384 288c16.1 0 29.7 12 31.8 28l20 159.8-63.5 7.9c-1.2-9.8-6.7-53.7-16.5-131.7l-110 0c-48.5 0-79.4-51.8-56.3-94.5l52.8-97.5-62.9 0c-6.3 0-12.5 1.9-17.8 5.4l-58.5 39-35.5-53.2 58.5-39C141.9 101.6 160.4 96 179.4 96l76.3 0zM336 96a48 48 0 1 1 0-96 48 48 0 1 1 0 96z"],
    "bold": [384, 512, [], "f032", "M64 224l0 192-64 0 0 64 256 0c70.7 0 128-57.3 128-128 0-46.5-24.8-87.3-62-109.7 18.7-22.3 30-51 30-82.3 0-70.7-57.3-128-128-128L0 32 0 96 64 96 64 224z"],
    "clipboard": [448, 512, [128203], "f328", "M128 128l192 0 0-96 64 0c35.3 0 64 28.7 64 64l0 352c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l64 0 0 96zM224-32c35.3 0 64 28.7 64 64l0 64-128 0 0-64c0-35.3 28.7-64 64-64z"],
    "laptop": [576, 512, [128187], "f109", "M576 424c0 30.9-25.1 56-56 56L56 480c-30.9 0-56-25.1-56-56l0-8 576 0 0 8zM448 32c35.3 0 64 28.7 64 64l0 256-448 0 0-256c0-35.3 28.7-64 64-64l320 0z"],
    "user-xmark": [640, 512, ["user-times"], "f235", "M288 320c88.4 0 160 71.6 160 160l0 32-448 0 0-32c0-88.4 71.6-160 160-160l128 0zM639.7 167.9l-56.1 56.1 56.1 56.1-39.6 39.6-56.1-56.1-56.1 56.1-39.6-39.6 56.1-56.1-56.1-56.1 39.6-39.6 56.1 56.1 56.1-56.1 39.6 39.6zM224 256a128 128 0 1 1 0-256 128 128 0 1 1 0 256z"],
    "joystick": [512, 512, [128377], "f8c5", "M192 64a48 48 0 1 1 0 96 48 48 0 1 1 0-96zm32 155.4c46.3-13.8 80-56.6 80-107.4 0-61.9-50.1-112-112-112S80 50.1 80 112c0 50.7 33.7 93.6 80 107.4l0 68.6-96 0c-35.3 0-64 28.7-64 64l0 96c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-96c0-35.3-28.7-64-64-64l-64 0 0-32-64 0 0 32-96 0 0-68.6z"],
    "battery-three-quarters": [640, 512, ["battery-4"], "f241", "M480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l416 0zM640 352l-64 0 0-192 64 0 0 192zM128 192l0 128 224 0 0-128-224 0z"],
    "thumbs-down": [512, 512, [128078, 61576], "f165", "M160 352l96 160c35.3 0 64-28.7 64-64l0-96 128 0c35.3 0 64-28.7 64-64l0-112-43.4-78.2C446 57.2 403.2 32 356.7 32L0 32 0 352 160 352zm0-64l-96 0 0-192 96 0 0 192z"],
    "utensils": [512, 512, [127860, 61685, "cutlery"], "f2e7", "M64 0l0 128 32 0 0-128 64 0 0 128 32 0 0-128 64 0 0 128c0 59.6-40.8 109.8-96 124l0 260-64 0 0-260C40.8 237.8 0 187.6 0 128L0 0 64 0zM448 10.9C468 3.8 489.6 0 512 0l0 512-64 0 0-160-64 0c-35.3 0-64-28.7-64-64l0-96c0-83.6 53.4-154.7 128-181.1z"],
    "envelope-open": [512, 512, [62135], "f2b6", "M256 43.5L442.8 160.2 256 293.6 69.2 160.2 256 43.5zM256-32L30.1 109.2C11.4 120.9 0 141.4 0 163.5L0 448c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-284.5c0-22.1-11.4-42.6-30.1-54.3L256-32z"],
    "voicemail": [640, 512, [], "f897", "M263.8 320c15.3-22.9 24.2-50.4 24.2-80 0-79.5-64.5-144-144-144S0 160.5 0 240 64.5 384 144 384l352 0c79.5 0 144-64.5 144-144S575.5 96 496 96 352 160.5 352 240c0 29.6 8.9 57.1 24.2 80l-112.5 0z"],
    "microphone": [448, 512, [], "f130", "M128 96l0 128c0 53 43 96 96 96s96-43 96-96l0-128c0-53-43-96-96-96s-96 43-96 96zM64 224l0-32-64 0 0 32C0 336.8 83.4 430.2 192 445.7l0 66.3 64 0 0-66.3C364.6 430.2 448 336.8 448 224l0-32-64 0 0 32c0 88.4-71.6 160-160 160S64 312.4 64 224z"],
    "crown": [512, 512, [128081], "f521", "M512 32c-47.5 31.6-95.5 63.6-144 96L256 32 144 128c-48.5-32.4-96.5-64.4-144-96 3 21.1 21.3 148.9 54.7 383.2 5.1 35.6 38.4 60 73.9 54.1l64.3-10.7c41.8-7 84.5-7 126.3 0l64.3 10.7c35.4 5.9 68.8-18.5 73.9-54.1 33.5-234.3 51.7-362 54.7-383.2z"],
    "arrow-up-wide-short": [640, 512, ["sort-amount-up"], "f161", "M182.9 41.4C170.4 28.9 150.1 28.9 137.6 41.4 61.4 117.6 21.9 157.1 19 160l45.3 45.3c12-12 33.3-33.3 64-64l0 338.7 64 0 0-338.7c30.7 30.7 52 52 64 64L301.5 160c-2.9-2.9-42.4-42.4-118.6-118.6zM576.3 128l32 0 0-64-288 0 0 64 256 0zm-96 320l0-64-160 0 0 64 160 0zm32-160l32 0 0-64-224 0 0 64 192 0z"],
    "sun": [576, 512, [9728], "f185", "M333.3 13.3L368 48 496 48 496 176c21.4 21.4 48.1 48.1 80 80-31.9 31.9-58.6 58.6-80 80l0 128-128 0c-21.4 21.4-48.1 48.1-80 80-31.9-31.9-58.6-58.6-80-80l-128 0 0-128c-21.4-21.4-48.1-48.1-80-80 31.9-31.9 58.6-58.6 80-80l0-128 128 0c21.4-21.4 48.1-48.1 80-80l45.3 45.3zM288 352a96 96 0 1 0 0-192 96 96 0 1 0 0 192z"],
    "image": [512, 512, [], "f03e", "M160 416l288 0 0-32-128-128-160 160zM0 96C0 60.7 28.7 32 64 32l384 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zM144 224a48 48 0 1 0 0-96 48 48 0 1 0 0 96z"],
    "notdef": [448, 512, [], "e1fe", "M384 0c35.3 0 64 28.7 64 64l0 384c0 33.1-25.2 60.4-57.5 63.7l-6.5 .3-320 0-6.5-.3C25.2 508.4 0 481.1 0 448L0 64C0 28.7 28.7 0 64 0L384 0zM101.5 448L346.5 448 224 305.1 101.5 448zM266.1 256L384 393.5 384 118.4 266.1 256zM64 393.5L181.9 256 64 118.5 64 393.5zM224 206.8L346.4 64 101.6 64 224 206.8z"],
    "pencil": [512, 512, [9999, 61504, "pencil-alt"], "f303", "M389.5 0c67.7 0 122.5 54.8 122.5 122.5 0 32.5-12.9 63.7-35.9 86.6L173.2 512 0 512 0 338.7 302.9 35.9C325.8 12.9 357 0 389.5 0zm0 64c-15.5 0-30.4 6.2-41.4 17.1l-33.7 33.7 82.7 82.8 33.7-33.7c11-11 17.1-25.9 17.1-41.4 0-32.3-26.2-58.5-58.5-58.5z"],
    "plane-up": [576, 512, [], "e22d", "M224 0c0-35.3 28.7-64 64-64S352-35.5 352-.1l0 111.7 197.2 140.9c16.8 12 26.8 31.4 26.8 52.1l0 112.1c-7.3-3.1-82-35.1-224-96l0 111.5 64 64 0 48c0 17.7-14.3 32-32 32l-96-32-96 32c-17.7 0-32-14.3-32-32l0-48 64-64 0-111.5C81.9 381.4 7.3 413.4 0 416.5L0 304.5c0-20.7 10-40.1 26.8-52.1L224 111.5 224 0z"],
    "circle-arrow-left": [512, 512, ["arrow-circle-left"], "f0a8", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM143 239c-9.4 9.4-9.4 24.6 0 33.9l112 112 33.9-33.9-71-71 166.1 0 0-48-166.1 0 71-71-33.9-33.9-112 112z"],
    "lightbulb": [384, 512, [128161], "f0eb", "M256 512l-128 0 0-64 128 0 0 64zM192 0c106 0 192 86 192 192 0 71.3-38.8 133.4-96.3 166.5-3.2 32.3-30.5 57.5-63.7 57.5l-64 0C126.8 416 99.6 390.8 96.3 358.5 38.8 325.3 0 263.2 0 192 0 86 86 0 192 0zm0 64c-70.7 0-128 57.3-128 128 0 36 14.8 68.5 38.8 91.8-4.4-13.8-6.8-28.5-6.8-43.8 0-79.5 64.5-144 144-144 15.2 0 29.9 2.3 43.7 6.7-23.3-23.9-55.7-38.7-91.7-38.7z"],
    "circle-arrow-right": [512, 512, ["arrow-circle-right"], "f0a9", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM223 161l71 71-166.1 0 0 48 166.1 0-71 71 33.9 33.9 112-112c9.4-9.4 9.4-24.6 0-33.9L257 127 223 161z"],
    "bed-empty": [640, 512, [128719], "f8f9", "M64 64l0-32-64 0 0 448 64 0 0-64 512 0 0 64 64 0 0-256c0-53-43-96-96-96l-480 0 0-64zm0 128l128 0 0 160-128 0 0-160z"],
    "code": [576, 512, [], "f121", "M356.7 4.9l-4.5 31.7-64 448-4.5 31.7-63.4-9.1 4.5-31.7 64-448 4.5-31.7 63.4 9.1zM189.7 144l-112 112 112 112-45.2 45.2-134.6-134.6c-12.5-12.5-12.5-32.8 0-45.3L144.5 98.8 189.7 144zm377.4 89.4c12.5 12.5 12.5 32.8 0 45.3l-134.6 134.6-45.3-45.2 112-112-112-112 45.3-45.3 134.6 134.6z"],
    "sparkles": [576, 512, [10024], "f890", "M508 420l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68zM316.6 49.7l54.5 108.9c3.1 6.2 8.1 11.2 14.3 14.3 81.2 40.6 136.6 68.3 166.2 83.1-29.6 14.8-85 42.5-166.2 83.1-6.2 3.1-11.2 8.1-14.3 14.3-40.6 81.2-68.3 136.6-83.1 166.2-14.8-29.6-42.5-85-83.1-166.2-3.1-6.2-8.1-11.2-14.3-14.3-81.2-40.6-136.6-68.3-166.2-83.1 29.6-14.8 85-42.5 166.2-83.1 6.2-3.1 11.2-8.1 14.3-14.3 40.6-81.2 68.3-136.6 83.1-166.2l28.6 57.2zM124 36l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"],
    "angle-right": [320, 512, [8250], "f105", "M51.2 448l192-192-192-192 45.2-45.2 214.6 214.6c12.5 12.5 12.5 32.8 0 45.3L96.5 493.3 51.2 448z"],
    "face-meh": [512, 512, [128528, "meh"], "f11a", "M256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM176 176a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM192 328l152 0 0 48-176 0 0-48 24 0z"],
    "map": [576, 512, [128506, 62072], "f279", "M576 380.2c0 24.2-13.7 46.4-35.4 57.3l-142.3 71.2-13.1 6.5-13.5-5.6-179.9-75C75.8 480.9 11.9 506.5 0 511.2L0 149.6C0 123.5 15.9 100 40.2 90.2l139.9-56 10.9-4.3 11.1 3.7 180.8 60.3C500 47.1 564.3 21.4 576 16.7l0 363.5zM220 377l136 56.7 0-281.3-136-45.3 0 270z"],
    "user-plus": [640, 512, [], "f234", "M288 320c88.4 0 160 71.6 160 160l0 32-448 0 0-32c0-88.4 71.6-160 160-160l128 0zM572 196l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68zM224 256a128 128 0 1 1 0-256 128 128 0 1 1 0 256z"],
    "thumbtack": [384, 512, [128204, 128392, "thumb-tack"], "f08d", "M352 64l-32 0 0 86.3 42.5 63.7c14 21 21.5 45.7 21.5 71l0 98.9-160 0 0 128-64 0 0-128-160 0 0-98.9c0-25.3 7.5-50 21.5-71l42.5-63.7 0-86.3-32 0 0-64 320 0 0 64z"],
    "money-bill-wave": [576, 512, [], "f53a", "M288 28.3c96-24.5 192-48.9 288 0l0 403.3c0 23.9-25.6 39.7-48.7 33.4-79.8-21.8-159.6-1.5-239.3 18.9-96 24.5-192 48.9-288 0L0 80.5C0 56.6 25.6 40.8 48.7 47.1 128.4 68.9 208.2 48.6 288 28.3zM288 344a88 88 0 1 0 0-176 88 88 0 1 0 0 176z"],
    "phone-hangup": [576, 512, [], "e225", "M384 320l0-64-28-14c-42.8-21.4-93.2-21.4-136 0l-28 14 0 64c0 35.3-28.7 64-64 64l-64 0c-35.3 0-64-28.7-64-64l0-36.3c0-66.9 34.8-129 91.9-163.8l12.6-7.7c112.7-68.9 254.4-68.9 367.1 0l12.6 7.7c57.1 34.9 91.9 96.9 91.9 163.8l0 36.3c0 35.3-28.7 64-64 64l-64 0c-35.3 0-64-28.7-64-64z"],
    "circle-plus": [512, 512, ["plus-circle"], "f055", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM232 128l0 104-104 0 0 48 104 0 0 104 48 0 0-104 104 0 0-48-104 0 0-104-48 0z"],
    "folder": [512, 512, [128193, 128447, 61716, "folder-blank"], "f07b", "M224 32l64 64 160 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l160 0z"],
    "arrow-up-from-bracket": [448, 512, [], "e09a", "M64 416c0 17.7 14.3 32 32 32l256 0c17.7 0 32-14.3 32-32l0-96 64 0 0 96c0 53-43 96-96 96L96 512c-53 0-96-43-96-96l0-96 64 0 0 96zM203.8 7.2c12.6-10.3 31.1-9.5 42.8 2.2l150.6 150.6-45.3 45.3-96-96 0 242.7-64 0 0-242.7-96 96-45.2-45.3 150.6-150.6 2.4-2.2z"],
    "cloud": [576, 512, [9729], "f0c2", "M288 32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 88.4-71.6 160-160 160l-256 0c-88.4 0-160-71.6-160-160 0-8.6 .7-17 2-25.2 .7-4.2 1.5-8.3 2.5-12.3 13.5-56.2 56.7-100.8 112-116.4 13.8-3.9 28.4-6 43.5-6 40.6 0 77.7 15.1 105.8 40 10.6-12 21.2-24 31.7-36-36.6-32.3-84.9-52-137.6-52-6.8 0-13.5 .3-20.2 1 31.3-48.7 86-81 148.2-81z"],
    "circle": [512, 512, [128308, 128309, 128992, 128993, 128994, 128995, 128996, 9679, 9898, 9899, 11044, 61708, 61915], "f111", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512z"],
    "circle-exclamation": [512, 512, ["exclamation-circle"], "f06a", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-200a40 40 0 1 0 0 80 40 40 0 1 0 0-80zM232 128l0 144 48 0 0-144-48 0z"],
    "backward": [576, 512, [9194], "f04a", "M560 64l-76.4 0-9.2 8.3-170.5 155 0-163.3-76.4 0-9.2 8.3-176 160C35.8 238.4 32 247 32 256s3.8 17.6 10.5 23.7l176 160 9.2 8.3 76.4 0 0-163.3 170.5 155 9.2 8.3 76.4 0 0-384z"],
    "link": [640, 512, [128279, "chain"], "f0c1", "M640 206.2c0 74.5-55.9 135.9-128 144.7l0-64.9c36.6-8.1 64-40.8 64-79.8l0-14.2c0-53-43-96-96-96L352 96c-53 0-96 43-96 96l0 14.2c0 39.1 27.4 71.7 64 79.8l0 64.9c-72.1-8.8-128-70.2-128-144.7l0-14.2c0-88.4 71.6-160 160-160l128 0c88.4 0 160 71.6 160 160l0 14.2zM0 305.8c0-74.5 55.9-135.9 128-144.7l0 64.9c-36.6 8.1-64 40.8-64 79.8L64 320c0 53 43 96 96 96l128 0c53 0 96-43 96-96l0-14.2c0-39.1-27.4-71.7-64-79.8l0-64.9c72.1 8.8 128 70.2 128 144.7l0 14.2c0 88.4-71.6 160-160 160l-128 0C71.6 480 0 408.4 0 320l0-14.2z"],
    "backward-step": [384, 512, ["step-backward"], "f048", "M384 448l-76.4 0-9.2-8.3-176-160C115.8 273.6 112 265 112 256s3.8-17.6 10.5-23.7l176-160 9.2-8.3 76.4 0 0 384zM64 448l-64 0 0-384 64 0 0 384z"],
    "circle-user": [512, 512, [62142, "user-circle"], "f2bd", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-176c-53.2 0-101.8 20-138.6 52.9 34.9 36.4 84.1 59.1 138.6 59.1s103.7-22.7 138.6-59.1C357.8 356 309.2 336 256 336zm0-216a72 72 0 1 0 0 144 72 72 0 1 0 0-144z"],
    "hand": [448, 512, [129306, 9995, "hand-paper"], "f256", "M224 48c0-26.5 21.5-48 48-48s48 21.5 48 48l0 176 32 0 0-112c0-26.5 21.5-48 48-48s48 21.5 48 48l0 240c0 88.4-71.6 160-160 160l-96 0C86 512 0 426 0 320l0-96 64 0 0 96 32 0 0-240c0-26.5 21.5-48 48-48s48 21.5 48 48l0 144 32 0 0-176z"],
    "thumbs-up": [512, 512, [128077, 61575], "f164", "M160 160L256 0c35.3 0 64 28.7 64 64l0 96 128 0c35.3 0 64 28.7 64 64l0 87.1c0 16.3-4.2 32.4-12.1 46.6l-31.3 56.4C446 454.8 403.2 480 356.7 480L0 480 0 160 160 160zm0 64l-96 0 0 192 96 0 0-192z"],
    "building": [448, 512, [127970, 61687], "f1ad", "M0 64C0 28.7 28.7 0 64 0L384 0c35.3 0 64 28.7 64 64l0 384c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64zm96 64l0 96 96 0 0-96-96 0zm256 0l-96 0 0 96 96 0 0-96zM256 288l0 96 96 0 0-96-96 0zm-64 0l-96 0 0 96 96 0 0-96z"],
    "circle-arrow-down": [512, 512, ["arrow-circle-down"], "f0ab", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM232 294.1L161 223 127 257 239 369c9.4 9.4 24.6 9.4 33.9 0l112-112-33.9-33.9-71 71 0-166.1-48 0 0 166.1z"],
    "gear": [512, 512, [9881, "cog"], "f013", "M294.5 0c14.7 0 27.5 10 31.1 24.2l12 48.1c12.7 5.7 24.7 12.6 35.8 20.7l47.8-13.7c14.1-4 29.2 2.1 36.5 14.8l39 67.6c7.3 12.7 5.1 28.8-5.5 39l-35.7 34.5c.7 6.8 1.1 13.7 1.1 20.8 0 7-.4 13.9-1.1 20.7l35.7 34.5c10.5 10.2 12.8 26.3 5.5 39l-39 67.6c-7.3 12.7-22.4 18.8-36.5 14.8l-47.8-13.7c-11.1 8.1-23.1 15-35.8 20.7l-12 48.2C322 502 309.2 512 294.5 512l-78 0c-14.7 0-27.5-10-31-24.2l-12.1-48.1c-12.7-5.7-24.7-12.7-35.9-20.8L89.8 432.6c-14.1 4-29.2-2.1-36.5-14.8l-39-67.6c-7.3-12.7-5.1-28.8 5.5-39l35.6-34.5c-1.4-13.5-1.4-27.9 0-41.5L19.8 200.8c-10.5-10.2-12.8-26.3-5.5-39l39-67.6c7.3-12.7 22.4-18.8 36.5-14.8l47.7 13.7C148.7 85 160.7 78 173.4 72.3l12.1-48.1C189 10 201.8 0 216.5 0l78 0zM256.4 184a72 72 0 1 0 -.9 144 72 72 0 1 0 .9-144z"],
    "circle-question": [512, 512, [62108, "question-circle"], "f059", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm0-184a40 40 0 1 0 0 80 40 40 0 1 0 0-80zm0-208c-48.6 0-88 39.4-88 88l48 0c0-22.1 17.9-40 40-40s40 17.9 40 40-17.9 40-40 40l-32 0 0 48 32 0c48.6 0 88-39.4 88-88s-39.4-88-88-88z"],
    "arrow-rotate-right-10": [512, 512, [], "e837", "M256 64c74 0 138.3 41.9 170.4 103.3 7.6 14.5 22.8 24.7 40.4 24.7 25 0 45.2-20.2 45.2-45.2l0-114.8-64 0 0 54.7C401.1 33.6 332.5 0 256 0 114.6 0 0 114.6 0 256S114.6 512 256 512c102.2 0 190.3-59.9 231.3-146.3l-57.8-27.5C398.7 403.2 332.5 448 256 448 150 448 64 362 64 256S150 64 256 64zM132 168l0 176 56 0 0-176-56 0zm148-4c-28.7 0-52 23.3-52 52l0 80c0 28.7 23.3 52 52 52l48 0c28.7 0 52-23.3 52-52l0-80c0-28.7-23.3-52-52-52l-48 0zm44 128l-40 0 0-72 40 0 0 72z"],
    "file": [384, 512, [128196, 128459, 61462], "f15b", "M384 128l0 320c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64C0 28.7 28.7 0 64 0L256 0 384 128z"],
    "volume-slash": [640, 512, [128263], "f2e2", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM352.3 423.8l0 56.2-53.3 0c-13.8 0-27.3-4.5-38.4-12.8L149.6 384 96.3 384c-35.3 0-64-28.7-64-64l0-128c0-23.9 13.1-44.7 32.5-55.7L352.3 423.8zm64-389.4c108.5 15.5 192 108.8 192 221.7 0 43.5-12.4 84-33.9 118.4l-41-41c12-23.2 18.9-49.5 18.9-77.4 0-81.8-58.5-150-136-164.9l0-56.8zm0 97.7c55.2 14.2 96 64.3 96 124 0 16.7-3.3 32.5-9.1 47.1l-46.9-46.9c0-.1 0-.1 0-.2 0-28.3-16.3-52.7-40-64.4l0-59.5zm-64 20.2l-100.7-100.7 9-6.7C271.6 36.5 285.1 32 298.9 32l53.3 0 0 120.2z"],
    "arrow-up": [512, 512, [8593], "f062", "M448.3 301.3l-160-160 0 338.8-64 0 0-338.8-160 160-45.3-45.3 214.6-214.6c12.5-12.5 32.8-12.5 45.3 0L493.5 256 448.3 301.3z"],
    "rectangle": [512, 512, [9644, "rectangle-landscape"], "f2fa", "M480 448l-448 0 0-384 448 0 0 384zM448 32c35.3 0 64 28.7 64 64l0 320-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-384 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 416 0 96C0 60.7 28.7 32 64 32l384 0zM64 416l384 0 0-320-384 0 0 320z"],
    "shirt": [640, 512, [128085, "t-shirt", "tshirt"], "f553", "M400.1 0c14.3 0 28.5 2.4 42.1 7.1l168.7 58.7 23.8 8.3-2.5 25.1-16 160-3.4 33.6c-16.6-2.5-50.1-7.7-100.5-15.5l0 170.7c0 35.3-28.7 64-64 64l-256 0c-35.3 0-64-28.7-64-64l0-170.7C78 285 44.5 290.2 27.9 292.7l-3.4-33.6-16-160-2.5-25.1 23.8-8.3 168.7-58.7C212 2.4 226.3 0 240.6 0L400.1 0zM248.3 64c0 39.8 32.2 72 72 72s72-32.2 72-72l-144 0z"],
    "suitcase": [512, 512, [129523], "f0f2", "M320 4c33.1 0 60 26.9 60 60l0 32 68 0c35.3 0 64 28.7 64 64l0 288c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 160c0-35.3 28.7-64 64-64l68 0 0-32c0-33.1 26.9-60 60-60L320 4zM136 160l0 288 48 0 0-288-48 0zM328 448l48 0 0-288-48 0 0 288zM192 60c-2.2 0-4 1.8-4 4l0 32 136 0 0-32c0-2.2-1.8-4-4-4L192 60z"],
    "comment-slash": [640, 512, [], "f4b3", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM397.9 469.4c-24.5 6.8-50.6 10.6-77.7 10.6-22.8 0-44.9-2.7-65.9-7.6L96.3 512 110.4 384.3c-29.1-36.3-46.2-80.6-46.2-128.3 0-34.3 8.8-66.7 24.5-95.8L397.9 469.4zM320.3 32c141.4 0 256 100.3 256 224 0 34.3-8.8 66.7-24.5 95.7L242.5 42.5C267 35.7 293.2 32 320.3 32z"],
    "play": [384, 512, [9654], "f04b", "M32 32l-32 0 0 448 54.3 0c12.6 0 25-3.7 35.5-10.7L369.8 282.6c8.9-5.9 14.2-15.9 14.2-26.6s-5.3-20.7-14.2-26.6L89.8 42.7C79.3 35.7 66.9 32 54.3 32L32 32z"],
    "paperclip": [448, 512, [128206], "f0c6", "M0 160C0 71.6 71.6 0 160 0S320 71.6 320 160l0 128c0 53-43 96-96 96s-96-43-96-96l0-128 64 0 0 128c0 17.7 14.3 32 32 32s32-14.3 32-32l0-128c0-53-43-96-96-96s-96 43-96 96l0 128c0 88.4 71.6 160 160 160s160-71.6 160-160l0-128 64 0 0 128c0 123.7-100.3 224-224 224S0 411.7 0 288L0 160z"],
    "wrench": [512, 512, [128295], "f0ad", "M318.4 21.3c8.9-5.9 20.2-7 30.1-2.9 86.6 36.2 147.5 121.7 147.5 221.5 0 85.5-44.8 160.5-112 203l0 69-256 0 0-69c-67.2-42.5-112-117.5-112-203 0-99.8 61-185.3 147.5-221.5 9.9-4.1 21.2-3 30.1 2.9S207.8 37.3 207.8 48l0 144.6 48.1 38.4 48.1-38.4 .2-144.6 .2-4c1.2-9.2 6.2-17.5 14-22.7z"],
    "life-ring": [512, 512, [], "f1cd", "M256 0c60.6 0 116.2 21.1 160.1 56.3L432 40.4 471.6 80 455.7 95.9C490.9 139.8 512 195.4 512 256s-21.1 116.2-56.3 160.1l15.9 15.9-39.6 39.6-15.9-15.9C372.2 490.9 316.6 512 256 512S139.8 490.9 95.9 455.7L80 471.6 40.4 432 56.3 416.1C21.1 372.2 0 316.6 0 256S21.1 139.8 56.3 95.9L40.4 80 80 40.4 95.9 56.3C139.8 21.1 195.4 0 256 0zm96.5 199.1c9.9 16.7 15.5 36.1 15.5 56.9 0 20.8-5.7 40.2-15.5 56.8l57.6 57.6c23.8-32 37.9-71.6 37.9-114.5s-14.1-82.5-37.9-114.5l-57.6 57.6zM101.9 141.5C78.1 173.5 64 213.1 64 256s14.1 82.5 37.9 114.5l57.6-57.6c-9.8-16.7-15.5-36.1-15.5-56.8 0-20.8 5.7-40.2 15.5-56.9l-57.6-57.6zM256 208a48 48 0 1 0 0 96 48 48 0 1 0 0-96z"],
    "calendar": [448, 512, [128197, 128198], "f133", "M160 32l128 0 0-64 64 0 0 64 32 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l32 0 0-64 64 0 0 64zM64 96l0 64 320 0 0-64-320 0z"],
    "italic": [448, 512, [], "f033", "M321 32l46.1 0c.6 0 1.3 0 1.9 0l79 0 0 64-60.2 0-160 320c18.2 0 38.3 0 60.2 0l0 64c-13.4 0-50.6 0-111.5 0-.4 0-.7 0-1.1 0l-46.9 0c-.4 0-.8 0-1.1 0l-46.8 0c-.4 0-.9 0-1.3 0-34.1 0-60.5 0-79.3 0l0-64c22 0 42 0 60.2 0l160-320-60.2 0 0-64 111.1 0c.6 0 1.3 0 1.9 0l46.1 0c.6 0 1.3 0 1.9 0z"],
    "check": [512, 512, [10003, 10004], "f00c", "M493.5 128l-22.6 22.6-256 256c-12.5 12.5-32.8 12.5-45.3 0L41.6 278.6 19 256 64.3 210.7c1.3 1.3 44 44 128 128l233.4-233.4 22.6-22.6 45.3 45.3z"],
    "wifi-slash": [640, 512, [], "f6ac", "M621.5 512L576.3 557.2 19 0 64.3-45.3 621.5 512zM364.4 435.9l-44.1 44.1-86.8-86.8c13.5-16.5 31.6-29.1 52.4-35.8l78.5 78.5zM250.5 322c-18.5 10.2-34.5 24.4-46.8 41.4l-68.4-68.4C148.6 279 164 264.6 181 252.5L250.5 322zM146.7 218.2c-16.6 12.6-31.9 26.9-45.4 42.8l-68-68c13.8-15.6 28.9-30 45.1-43.1l68.4 68.4zM320.3 64C434.4 64 537 113.8 607.3 192.9l-68 68c-44-51.5-105.9-87.3-176.1-97.8L267.6 67.6c17.2-2.4 34.8-3.6 52.7-3.6z"],
    "rocket-launch": [576, 512, [128640], "e027", "M236.8 480.6l-54.1 54.1-45.2-45.2 54.1-54.1 45.2 45.3zm-64-64l-86.1 86.1-45.2-45.2 86.1-86.1 45.2 45.3zM544.1 139c0 47.3-17.4 92.2-48 126.9l0 86.1c0 79.5-64.5 144-144 144l-29.2 0-274.8-274.7 0-29.3c0-79.5 64.5-144 144-144l86 0c34.7-30.6 79.7-48 127-48l139 0 0 139zM315 397.6l34.4 34.4 2.7 0c44.2 0 80-35.8 80-80l0-35.1-117.2 80.7zm-206.2-45l-54.1 54.1-45.2-45.2 54.1-54.1 45.2 45.3zM192.1 112c-44.2 0-80 35.8-80 80l0 2.8 34.4 34.4 80.6-117.2-35 0zm176 16a48 48 0 1 0 0 96 48 48 0 1 0 0-96z"],
    "shield-slash": [640, 512, [], "e24b", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM96.3 167.8l306.7 306.7-82.7 41.3-100.2-50.1C144.2 427.7 96.3 350.2 96.3 265.3l0-97.6zM330.4 1.7L500.5 58.3c26.1 8.7 43.7 33.2 43.8 60.7l0 146.3c0 23.5-3.7 46.5-10.7 68.2L228.8 28.8 310.1 1.7 320.3-1.8 330.4 1.7z"],
    "house": [512, 512, [127968, 63498, 63500, "home", "home-alt", "home-lg-alt"], "f015", "M160 512l-96 0c-35.3 0-64-28.7-64-64L0 192c0-20.1 9.5-39.1 25.6-51.2L256-32 486.4 140.8C502.5 152.9 512 171.9 512 192l0 256c0 35.3-28.7 64-64 64l-288 0zm96-224c-35.3 0-64 28.7-64 64l0 96 128 0 0-96c0-35.3-28.7-64-64-64z"],
    "play-pause": [512, 512, [], "e22f", "M0 64l76.4 0 9.2 8.3 176 160C268.2 238.4 272 247 272 256s-3.8 17.6-10.5 23.7l-176 160-9.2 8.3-76.4 0 0-384zm384 0l0 384-64 0 0-384 64 0zm128 0l0 384-64 0 0-384 64 0z"],
    "sliders": [512, 512, ["sliders-h"], "f1de", "M128 0c17.7 0 32 14.3 32 32l0 192c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-64-96 0 0-64 96 0 0-64c0-17.7 14.3-32 32-32zM288 256c17.7 0 32 14.3 32 32l0 192c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-64-256 0 0-64 256 0 0-64c0-17.7 14.3-32 32-32zm-64-96l0-64 288 0 0 64-288 0zM512 416l-128 0 0-64 128 0 0 64z"],
    "paintbrush-slash": [640, 512, [], "e74e", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM219.3 290.8c-34 9.2-59.1 40.2-59.1 77.2l0 80 80 0c36.9 0 67.9-25.1 77.1-59.1l48.8 48.8C341.7 482 294.5 512 240.3 512l-208 0 0-64 64 0 0-80c0-54.2 30-101.4 74.2-126l48.8 48.8zM508.4 0c55.2 0 99.9 44.7 99.9 99.9 0 26.5-10.5 51.9-29.3 70.6L474.7 274.7 333.5 133.5 437.8 29.2C456.5 10.5 481.9 0 508.4 0z"],
    "face-frown": [512, 512, [9785, "frown"], "f119", "M256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM176 176a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM256 336c-38.5 0-72.1 20.9-90.1 52l-41.5-24c26.2-45.4 75.4-76 131.6-76s105.4 30.6 131.7 76l-41.5 24c-18-31.1-51.6-52-90.1-52z"],
    "phone-plus": [512, 512, [], "f4d2", "M83.1 29.3c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-49.4 49.4c-.8 .8-1.1 2-.8 3.2 14.6 53.4 56.3 95.1 109.7 109.7 1.1 .3 2.3 0 3.2-.8l49.4-49.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9c-45 45-109.6 64.7-172 52.8-141.9-27-253.8-138.9-280.8-280.8-11.9-62.4 7.8-127.1 52.8-172L83.1 29.3zM428.3 84l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"],
    "forward-step": [384, 512, ["step-forward"], "f051", "M0 64l76.4 0 9.2 8.3 176 160C268.2 238.4 272 247 272 256s-3.8 17.6-10.5 23.7l-176 160-9.2 8.3-76.4 0 0-384zm320 0l64 0 0 384-64 0 0-384z"],
    "wand-magic": [576, 512, ["magic"], "f0d0", "M432.3-29.3c2.9 2.9 42.4 42.4 118.6 118.6L573.5 112 550.9 134.6 189.5 496c-25 25-65.5 25-90.5 0L48.3 445.3c-25-25-25-65.5 0-90.5L409.6-6.6 432.3-29.3zm0 90.5l-69.6 69.6 50.7 50.7 69.6-69.6-50.7-50.7z"],
    "sort": [384, 512, ["unsorted"], "f0dc", "M0 288l0 77.3 9.4 9.4 160 160c6 6 14.1 9.4 22.6 9.4s16.6-3.4 22.6-9.4L384 365.3 384 288 0 288zm0-64l384 0 0-77.3-9.4-9.4-160-160c-6-6-14.1-9.4-22.6-9.4s-16.6 3.4-22.6 9.4L9.4 137.4 0 146.7 0 224z"],
    "server": [512, 512, [], "f233", "M512 448c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64l0-160 512 0 0 160zM368 368a32 32 0 1 0 0 64 32 32 0 1 0 0-64zM448 0c35.3 0 64 28.7 64 64l0 160-512 0 0-160C0 28.7 28.7 0 64 0L448 0zM368 80a32 32 0 1 0 0 64 32 32 0 1 0 0-64z"],
    "user": [448, 512, [128100, 62144, 62470, "user-alt", "user-large"], "f007", "M288 320c88.4 0 160 71.6 160 160l0 32-448 0 0-32c0-88.4 71.6-160 160-160l128 0zm-64-64a128 128 0 1 1 0-256 128 128 0 1 1 0 256z"],
    "snowflake": [512, 512, [10052, 10054], "f2dc", "M288 32l0-32-64 0 0 88.4-64-64-39.6 39.6 103.6 103.6 0 56.4-56.4 0-103.6-103.6-39.6 39.6 64 64-88.4 0 0 64 88.4 0c-33.5 33.5-54.9 54.9-64 64L64 391.6c2.5-2.5 37.1-37.1 103.6-103.6l56.4 0 0 56.4C157.5 410.9 122.9 445.5 120.4 448L160 487.6c9.1-9.1 30.5-30.5 64-64l0 88.4 64 0 0-88.4 64 64 39.6-39.6-103.6-103.6 0-56.4 56.4 0 103.6 103.6 39.6-39.6-64-64 88.4 0 0-64-88.4 0c33.5-33.5 54.9-54.9 64-64L448 120.4c-2.5 2.5-37.1 37.1-103.6 103.6l-56.4 0 0-56.4C354.5 101.1 389.1 66.5 391.6 64L352 24.4c-9.1 9.1-30.5 30.5-64 64L288 32z"],
    "skull-crossbones": [512, 512, [128369, 9760], "f714", "M64.5 160l0 25.5c0 14.4 5.7 28.2 15.9 38.4l48.1 48.1 0 16c0 35.3 28.7 64 64 64l128 0c35.3 0 64-28.7 64-64l0-16 48.1-48.1c10.2-10.2 15.9-24 15.9-38.4l0-25.5c0-106-86-192-192-192s-192 86-192 192zM74.6 353.6L44.2 343.5 24 404.2c8.5 2.8 52.2 17.4 131.3 43.8-79.1 26.4-122.8 40.9-131.3 43.8l20.2 60.7 30.4-10.1 181.9-60.6 181.9 60.6 30.4 10.1 20.2-60.7c-8.5-2.8-52.2-17.4-131.3-43.8 79-26.4 122.8-40.9 131.3-43.8l-20.2-60.7-30.4 10.1-181.9 60.6-181.9-60.6zM152.5 160a40 40 0 1 1 80 0 40 40 0 1 1 -80 0zm168-40a40 40 0 1 1 0 80 40 40 0 1 1 0-80z"],
    "ticket": [512, 512, [127903], "f145", "M456 256c0-30.9 25.1-56 56-56l0-104c0-35.3-28.7-64-64-64L64 32C28.7 32 0 60.7 0 96L0 200c30.9 0 56 25.1 56 56S30.9 312 0 312L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-104c-30.9 0-56-25.1-56-56zM256 224a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm32 160a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM256 96a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"],
    "wheelchair": [448, 512, [], "f193", "M208 64a48 48 0 1 0 0-96 48 48 0 1 0 0 96zM0 384c0 88.4 71.6 160 160 160s160-71.6 160-160l-104 0c-48.6 0-88-39.4-88-88l0-68.8C55 242 0 306.6 0 384zM224 169.2L271 228c6.1 7.6 15.3 12 25 12l72 0 0-64-56.6 0-47.2-59c-10.6-13.3-26.7-21-43.7-21L216 96c-30.9 0-56 25.1-56 56l0 136c0 35.3 28.7 64 64 64l131.8 0c9.8 78 15.2 121.9 16.5 131.7l63.5-7.9c-.6-5.1-7.3-58.4-20-159.8-2-16-15.6-28-31.8-28l-160 0 0-118.8z"],
    "volume-off": [384, 512, [], "f026", "M320 480l-53.3 0c-13.8 0-27.3-4.5-38.4-12.8L117.3 384 64 384c-35.3 0-64-28.7-64-64L0 192c0-35.3 28.7-64 64-64l53.3 0 110.9-83.2C239.4 36.5 252.8 32 266.7 32l53.3 0 0 448z"],
    "bookmark": [384, 512, [128278, 61591], "f02e", "M0 512c32-18.7 96-56 192-112 96 56 160 93.3 192 112l0-448c0-35.3-28.7-64-64-64L64 0C28.7 0 0 28.7 0 64L0 512z"],
    "list-ol": [512, 512, ["list-1-2", "list-numeric"], "f0cb", "M36 92l-36 0 0-56 92 0 0 128 36 0 0 56-128 0 0-56 36 0 0-72zm476 36l-320 0 0-64 320 0 0 64zm0 320l-320 0 0-64 320 0 0 64zM480 288l-288 0 0-64 320 0 0 64-32 0zM0 348l0-56 72.3 0c28.5 0 51.7 23.1 51.7 51.7 0 11.7-4 23.1-11.3 32.3l-35.2 44 50.5 0 0 56-124 0 0-53.8 6.1-7.7 53.2-66.5-63.3 0z"],
    "bomb": [640, 512, [128163], "f1e2", "M299.5 64.3c22.1 1.1 43.3 5.4 63.3 12.5 24.1-12.3 54.3-8.4 74.4 11.7L488 139.2c20.3 20.3 24.1 50.7 11.5 74.8 8.1 23.2 12.5 48 12.5 73.9 0 119.8-94.1 217.7-212.5 223.7L288 512C168.2 512 70.3 417.9 64.3 299.5L64 288C64 164.3 164.3 64 288 64l11.5 .3zM288 136c-83.9 0-152 68.1-152 152l48 0c0-57.4 46.6-104 104-104l0-48zM572 4l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"],
    "trash-slash": [640, 512, [], "e2b3", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zm-181 0l-248.2 0c-33.1 0-60.4-25.2-63.7-57.5l-.3-6.5 0-248.2 312.2 312.2zM390.8 .3c32.3 3.3 57.5 30.5 57.5 63.7l0 32 96 0 0 64-32 0 0 152.2-216.2-216.2 88.2 0 0-32-120.2 0-49-49c11.1-9.4 25.5-15 41.2-15l128 0 6.5 .3z"],
    "airplay": [512, 512, [], "e089", "M64 32C28.7 32 0 60.7 0 96L0 352c0 35.3 28.7 64 64 64l28.1 0 1.9-1.9c101-101 155-155 161.9-161.9 6.9 6.9 60.9 60.9 161.9 161.9l1.9 1.9 28.1 0c35.3 0 64-28.7 64-64l0-256c0-35.3-28.7-64-64-64L64 32zM256 320l-128 128 0 64 256 0 0-64-128-128z"],
    "volume-xmark": [576, 512, ["volume-mute", "volume-times"], "f6a9", "M320 480l-53.3 0c-13.8 0-27.3-4.5-38.4-12.8L117.3 384 64 384c-35.3 0-64-28.7-64-64L0 192c0-35.3 28.7-64 64-64l53.3 0 110.9-83.2C239.4 36.5 252.8 32 266.7 32l53.3 0 0 448zM559.7 215.9l-56.1 56.1 56.1 56.1-39.6 39.6-56.1-56.1-56.1 56.1-39.6-39.6 56.1-56.1-56.1-56.1 39.6-39.6 56.1 56.1 56.1-56.1 39.6 39.6z"],
    "gauge-high": [512, 512, [62461, "tachometer-alt", "tachometer-alt-fast"], "f625", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm74.5-362.7L261 288.2c-1.7-.1-3.3-.2-5-.2-35.3 0-64 28.7-64 64s28.7 64 64 64 64-28.7 64-64c0-16.2-6.1-31-16.1-42.3l80.3-160.4-42.9-21.5-10.7 21.5zM96 224a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm320 0a32 32 0 1 0 0 64 32 32 0 1 0 0-64zM144 112a32 32 0 1 0 0 64 32 32 0 1 0 0-64zM256 64a32 32 0 1 0 0 64 32 32 0 1 0 0-64z"],
    "cloud-sun": [640, 512, [9925], "f6c4", "M480 0l96 0 0 96c8.1 8.1 29.4 29.4 64 64-34.6 34.6-55.9 55.9-64 64l0 96-15.9 0c-11.1-26.6-27.6-50.4-48.1-70.1l0-52.4c12.5-12.5 25-25 37.5-37.5-12.5-12.5-25-25-37.5-37.5l0-58.5-58.5 0c-12.5-12.5-25-25-37.5-37.5-12.5 12.5-25 25-37.5 37.5l-58.5 0 0 41.3c-20.3-6-41.8-9.3-64-9.3l0 0 0-96 96 0c8.1-8.1 29.4-29.4 64-64 34.6 34.6 55.9 55.9 64 64zM444.3 198.7c-17.3-26.9-40.2-49.8-67.1-67.1 8.7-11.9 22.8-19.6 38.7-19.6 26.5 0 48 21.5 48 48 0 15.9-7.7 30-19.7 38.7zm-337 62C130.9 201.7 188.6 160 256 160s125.1 41.7 148.6 100.7c61.8 16.2 107.4 72.4 107.4 139.3 0 79.5-64.5 144-144 144l-224 0C64.5 544 0 479.5 0 400 0 333.1 45.6 276.9 107.4 260.7z"],
    "arrow-right": [448, 512, [8594], "f061", "M178.8 448l160-160-338.7 0 0-64 338.7 0-160-160 45.2-45.3 214.6 214.6c12.5 12.5 12.5 32.8 0 45.3L224 493.2 178.8 448z"],
    "file-minus": [384, 512, [], "f318", "M384 128l0 320c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64C0 28.7 28.7 0 64 0L256 0 384 128zM96 264l0 48 192 0 0-48-192 0z"],
    "shredder": [512, 512, [], "f68a", "M192 512l-64 0 0-224 64 0 0 224zm96 0l-64 0 0-224 64 0 0 224zm96 0l-64 0 0-224 64 0 0 224zm32-384l32 0c35.3 0 64 28.7 64 64l0 160c0 35.3-28.7 64-64 64l-32 0 0-160-320 0 0 160-32 0C30.9 416 3.6 390.8 .3 358.5L0 352 0 192c0-35.3 28.7-64 64-64l32 0 0-128 320 0 0 128zm-256 0l192 0 0-64-192 0 0 64z"],
    "battery-bolt": [640, 512, [], "f376", "M336 176L448 199.1 232.9 512 208 336 96 312.9 311.1 0 336 176zM164.9 128l-100.9 0 0 256 102.3 0 9.1 64-111.4 0c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l144.9 0-44 64zM480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64l-144.9 0 44-64 100.9 0 0-256-102.3 0-9.1-64 111.4 0zM640 352l-64 0 0-192 64 0 0 192z"],
    "arrow-rotate-left-10": [512, 512, [], "e836", "M256 64c-74 0-138.3 41.9-170.4 103.3-7.6 14.5-22.8 24.7-40.4 24.7-25 0-45.2-20.2-45.2-45.2L0 32 64 32 64 86.7C110.9 33.6 179.5 0 256 0 397.4 0 512 114.6 512 256S397.4 512 256 512C153.8 512 65.7 452.1 24.7 365.7l57.8-27.5c30.9 64.9 97 109.7 173.5 109.7 106 0 192-86 192-192S362 64 256 64zM132 344l0-176 56 0 0 176-56 0zM280 164l48 0c28.7 0 52 23.3 52 52l0 80c0 28.7-23.3 52-52 52l-48 0c-28.7 0-52-23.3-52-52l0-80c0-28.7 23.3-52 52-52zm44 128l0-72-40 0 0 72 40 0z"],
    "buildings": [576, 512, [], "e0cc", "M0 64C0 28.7 28.7 0 64 0L256 0c35.3 0 64 28.7 64 64l192 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64zM320 272l0 176 192 0 0-320-192 0 0 144zm64-80l64 0 0 64-64 0 0-64zm64 128l0 64-64 0 0-64 64 0zM128 128l0 64 64 0 0-64-64 0zm64 128l-64 0 0 64 64 0 0-64z"],
    "xmark": [384, 512, [128473, 10005, 10006, 10060, 215, "close", "multiply", "remove", "times"], "f00d", "M365.5 128l-128 128 128 128-45.2 45.2-128-128-128 128-45.3-45.2 128-128-128-128 45.3-45.2 128 128 128-128 45.2 45.2z"],
    "lock-open": [384, 512, [], "f3c1", "M128 192l0-64c0-35.3 28.7-64 64-64s64 28.7 64 64l64 0C320 57.3 262.7 0 192 0S64 57.3 64 128l0 64c-35.3 0-64 28.7-64 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-192c0-35.3-28.7-64-64-64l-192 0z"],
    "droplet": [384, 512, [128167, "tint"], "f043", "M38.4 204.8C126.4 87.5 177.6 19.2 192 0 206.4 19.2 257.6 87.5 345.6 204.8 370.5 238 384 278.5 384 320 384 426 298 512 192 512S0 426 0 320c0-41.5 13.5-82 38.4-115.2z"],
    "shop": [576, 512, ["store-alt"], "f54f", "M64 224l-13.9 0c-27.7 0-50.1-22.4-50.1-50.1 0-9.1 2.5-18 7.1-25.8L96 0 480 0 568.9 148.1c4.7 7.8 7.1 16.7 7.1 25.8 0 27.7-22.4 50.1-50.1 50.1l-13.9 0 0 288-64 0 0-288-96 0 0 224c0 35.3-28.7 64-64 64l-160 0c-35.3 0-64-28.7-64-64l0-224zm224 0l-160 0 0 128 160 0 0-128z"],
    "film": [512, 512, [127902, 62368, "film-alt", "film-simple"], "f008", "M380 96l68 0 0 68-68 0 0-68zm0 196l0-72 68 0 0 72-68 0zm0 56l68 0 0 68-68 0 0-68zM64 96l68 0 0 68-68 0 0-68zm0 124l68 0 0 72-68 0 0-72zm0 128l68 0 0 68-68 0 0-68zM64 32C28.7 32 0 60.7 0 96L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-320c0-35.3-28.7-64-64-64L64 32z"],
    "comments": [640, 512, [128490, 61670], "f086", "M98.2 367.4L32 384C37.5 334.4 41.6 297.9 44.2 274.5 16.4 242.5 0 202.9 0 160 0 54 100.3-32 224-32S448 54 448 160 347.7 352 224 352c-16.1 0-31.9-1.5-47-4.2L98.2 367.4zm413-189.3c76.1 30.7 128.7 97 128.7 173.8 0 42.9-16.4 82.5-44.2 114.5 2.6 23.4 6.7 59.9 12.2 109.5-42.1-10.5-90.4-22.6-145-36.2-15.2 2.8-30.9 4.2-47 4.2-97.8 0-180.9-53.7-211.5-128.6 6.4 .4 12.9 .6 19.5 .6 17.5 0 34.6-1.4 51.2-4 25.5 38.3 75 68 140.8 68 12.3 0 24.1-1.1 35.5-3.2l13.6-2.5c1.9 .5 25 6.2 69.1 17.3-1.2-10.4-2.9-25.7-5.1-45.9l18.4-21.2c18.7-21.5 28.5-46.6 28.5-72.5 0-42.3-29.1-86.7-78.9-110.5 7.6-20.1 12.5-41.3 14.2-63.3z"],
    "circle-check": [512, 512, [61533, "check-circle"], "f058", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM224 286.1l-64-64-33.9 33.9 81 81c9.4 9.4 24.6 9.4 33.9 0l145-145-33.9-33.9-128 128z"],
    "moon": [512, 512, [127769, 9214], "f186", "M224 128c0 115.3 87.1 210.3 199.1 222.6 8.2 .9 16.5 1.4 24.9 1.4 16.2 0 32.1-1.7 47.4-5-9.5 25.1-22.9 48.3-39.4 68.9-46.9 58.6-119 96.1-199.9 96.1-141.4 0-256-114.6-256-256 0-116.8 78.3-215.4 185.3-246.1 22.5-6.4 46.2-9.9 70.7-9.9 2.7 0 5.4 0 8.1 .1-2.8 4-5.5 8.2-8.1 12.4-19.4 32.2-32 71.3-32 115.4z"],
    "file-plus": [384, 512, [], "f319", "M384 128l0 320c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64C0 28.7 28.7 0 64 0L256 0 384 128zM168 192l0 72-72 0 0 48 72 0 0 72 48 0 0-72 72 0 0-48-72 0 0-72-48 0z"],
    "closed-captioning": [576, 512, [], "f20a", "M0 96C0 60.7 28.7 32 64 32l448 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zm120 96l0 128c0 17.7 14.3 32 32 32l80 0c17.7 0 32-14.3 32-32l0-40-48 0 0 24-48 0 0-96 48 0 0 24 48 0 0-40c0-17.7-14.3-32-32-32l-80 0c-17.7 0-32 14.3-32 32zm224-32c-17.7 0-32 14.3-32 32l0 128c0 17.7 14.3 32 32 32l80 0c17.7 0 32-14.3 32-32l0-40-48 0 0 24-48 0 0-96 48 0 0 24 48 0 0-40c0-17.7-14.3-32-32-32l-80 0z"],
    "pen": [512, 512, [128394], "f304", "M389.5 0c67.7 0 122.5 54.8 122.5 122.5 0 32.5-12.9 63.7-35.9 86.6L173.2 512 0 512 0 338.7 302.9 35.9C325.8 12.9 357 0 389.5 0z"],
    "plane": [640, 512, [], "f072", "M576 192c35.3 0 64 28.7 64 64s-28.5 64-63.8 64l-111.7 0-140.8 197.2c-12 16.8-31.4 26.8-52.1 26.8l-112.1 0c3.1-7.3 35.1-81.9 96-224l-111.5 0-64 64-48 0c-17.7 0-32-14.3-32-32l32-96-32-96c0-17.7 14.3-32 32-32l48 0 64 64 111.5 0-76.9-179.4-19.1-44.6 112.1 0c20.7 0 40.1 10 52.1 26.8L464.5 192 576 192z"],
    "images": [576, 512, [], "f302", "M128 64c0-35.3 28.7-64 64-64L512 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64l-320 0c-35.3 0-64-28.7-64-64l0-256zM64 160l0 288 384 0 0 64-384 0c-35.3 0-64-28.7-64-64l0-320 64 0 0 32zm216-48a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zM224 320l288 0 0-32-128-128-160 160z"],
    "bag-shopping": [448, 512, ["shopping-bag"], "f290", "M192 64l64 0c17.7 0 32 14.3 32 32l0 32-128 0 0-32c0-17.7 14.3-32 32-32zM96 96l0 32-96 0 0 256c0 70.7 57.3 128 128 128l192 0c70.7 0 128-57.3 128-128l0-256-96 0 0-32c0-53-43-96-96-96L192 0C139 0 96 43 96 96z"],
    "phone-volume": [576, 512, ["volume-control-phone"], "f2a0", "M114.7 29.3c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-49.4 49.4c-.8 .8-1.1 2-.8 3.2 14.6 53.4 56.3 95.1 109.7 109.7 1.1 .3 2.3 0 3.2-.8l49.4-49.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9c-45 44.9-109.6 64.7-172 52.8-141.9-27-253.7-138.9-280.8-280.8-11.9-62.4 7.8-127 52.8-172l26.9-26.9zM352-32c123.7 0 224 100.3 224 224 0 9.4-.7 18.7-1.8 27.8l-55.6-6.9c.8-6.8 1.3-13.8 1.3-20.8 0-92.8-75.2-168-168-168-14.1 0-27.7 1.7-40.8 5L297.7-25.3C315.1-29.7 333.3-32 352-32zm0 96c70.7 0 128 57.3 128 128 0 5.4-.4 10.7-1 15.8l-55.6-6.9c.4-2.9 .6-5.9 .6-8.9 0-39.8-32.2-72-72-72-6 0-11.9 .8-17.5 2.2L321 67.8c9.9-2.5 20.4-3.8 31.1-3.8z"],
    "phone": [512, 512, [128222, 128379], "f095", "M83.1 29.3c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-49.4 49.4c-.8 .8-1.1 2-.8 3.2 14.6 53.4 56.3 95.1 109.7 109.7 1.1 .3 2.3 0 3.2-.8l49.4-49.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9c-45 45-109.6 64.7-172 52.8-141.9-27-253.8-138.9-280.8-280.8-11.9-62.4 7.8-127 52.8-172L83.1 29.3z"],
    "id-card": [576, 512, [62147, "drivers-license"], "f2c2", "M64 0C28.7 0 0 28.7 0 64L0 448C0 465.8 7.3 482 19.1 493.6 30.6 505 46.5 512 64 512l448 0c35.3 0 64-28.7 64-64l0-384c0-35.3-28.7-64-64-64L64 0zM208 136a72 72 0 1 1 0 144 72 72 0 1 1 0-144zM352 401l0 47-288 0 0-47c35.2-39.9 86.7-65 144-65s108.8 25.1 144 65zm32-185l0-48 128 0 0 48-128 0zm128 96l-128 0 0-48 128 0 0 48z"],
    "leaf": [512, 512, [], "f06c", "M462.4 279.9c-6.5 90.5-68.2 164.7-150.9 190.4-20.3 6.3-41.8 9.7-64 9.7-47.9 0-92.2-15.7-128-42.1l-64.8 64.8-45.3-45.3 64.8-64.8c-26.5-35.8-42.1-80.1-42.1-128 0-113 87.3-206.8 200.1-214.9 142.1-10.2 224.8-16.1 247.9-17.7-1.7 23.2-7.6 105.8-17.7 247.9zM177.1 369l128-128-33.9-33.9-128 128 33.9 33.9z"],
    "heart-half": [576, 512, [], "e1ab", "M65.8 77.8c61.1-61.1 160.2-61.1 221.2 0l1.4 1.4 0 442.5-222.6-222.6C4.7 238 4.7 138.9 65.8 77.8z"],
    "universal-access": [512, 512, [], "f29a", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM136 200l0 48 56 0 0 160 48 0 0-68 32 0 0 68 48 0 0-160 56 0 0-48-240 0zM256 88a40 40 0 1 0 0 80 40 40 0 1 0 0-80z"],
    "volume-low": [512, 512, [128264, "volume-down"], "f027", "M352 480l-53.3 0c-13.8 0-27.3-4.5-38.4-12.8L149.3 384 96 384c-35.3 0-64-28.7-64-64l0-128c0-35.3 28.7-64 64-64l53.3 0 110.9-83.2C271.4 36.5 284.8 32 298.7 32l53.3 0 0 448zm64-343.8c53 14.1 92 62.4 92 119.8 0 57.4-39 105.7-92 119.8l0-59.8c21.4-11.4 36-34 36-60 0-26-14.6-48.6-36-60l0-59.8z"],
    "hourglass": [448, 512, [9203, 62032, "hourglass-empty"], "f254", "M33.8 64L0 64 0 0 448 0 448 64 414.2 64c-7.3 57.3-36.6 110.1-82.3 146.6l-56.7 45.4 56.7 45.4c45.7 36.6 75 89.3 82.3 146.6l33.8 0 0 64-448 0 0-64 33.8 0c7.3-57.3 36.6-110.1 82.3-146.6l56.7-45.4-56.7-45.4C70.4 174.1 41.1 121.3 33.8 64zm64.7 0c4.1 23.1 13.3 44.9 26.8 64l197.4 0c13.5-19.1 22.6-40.9 26.8-64l-251 0zM156 351.3c-11.9 9.5-22.2 20.5-30.8 32.7l197.4 0c-8.6-12.1-18.9-23.2-30.8-32.7l-68-54.4-68 54.4z"],
    "fish": [576, 512, [128031], "f578", "M144.1 240c0-132.5 107.5-240 240-240l64 0c53 0 96 43 96 96l0 64c0 132.5-107.5 240-240 240l-48 0 0 34.7c0 33.2-13.2 65.1-36.7 88.6l-11.3 11.3-11.3-11.3-176-176-11.3-11.3 11.3-11.3C44.3 301.2 76.2 288 109.4 288l34.7 0 0-48zm256-56a40 40 0 1 0 0-80 40 40 0 1 0 0 80z"],
    "chart-simple": [512, 512, [], "e473", "M160 80c0-26.5 21.5-48 48-48l64 0c26.5 0 48 21.5 48 48l0 432-160 0 0-432zM0 272c0-26.5 21.5-48 48-48l80 0 0 288-80 0c-26.5 0-48-21.5-48-48L0 272zM464 128c26.5 0 48 21.5 48 48l0 288c0 26.5-21.5 48-48 48l-112 0 0-384 112 0z"],
    "headphones": [512, 512, [127911, 62863, "headphones-alt", "headphones-simple"], "f025", "M256 64C150 64 64 150 64 256l64 0c35.3 0 64 28.7 64 64l0 96c0 35.3-28.7 64-64 64l-64 0c-35.3 0-64-28.7-64-64L0 256C0 114.6 114.6 0 256 0l32 0 0 2C414.3 17.7 512 125.5 512 256l0 160c0 35.3-28.7 64-64 64l-64 0c-35.3 0-64-28.7-64-64l0-96c0-35.3 28.7-64 64-64l64 0c0-106-86-192-192-192z"],
    "bus": [640, 512, [128653], "f207", "M416 0c70.7 0 128 57.3 128 128l0 384-64 0 0-64-320 0 0 64-64 0 0-384C96 57.3 153.3 0 224 0L416 0zM208 296a40 40 0 1 0 0 80 40 40 0 1 0 0-80zm224 0a40 40 0 1 0 0 80 40 40 0 1 0 0-80zM64 288l-64 0 0-128 64 0 0 128zm576 0l-64 0 0-128 64 0 0 128zM224 64c-35.3 0-64 28.7-64 64l0 64 320 0 0-64c0-35.3-28.7-64-64-64L224 64z"],
    "screencast": [512, 512, [], "e23e", "M0 96C0 60.7 28.7 32 64 32l384 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64l-128 0C320 303.3 176.7 160 0 160L0 96zM0 224c141.4 0 256 114.6 256 256l-56 0c0-110.5-89.5-200-200-200l0-56zm0 96c88.4 0 160 71.6 160 160l-56 0c0-57.4-46.6-104-104-104l0-56zm0 96c35.3 0 64 28.7 64 64l-64 0 0-64z"],
    "martini-glass": [512, 512, [127864, "glass-martini-alt"], "f57b", "M32 32C19.4 32 8 39.3 2.9 50.8S-.3 75.6 7.9 85.1l216.1 247 0 116-96 0 0 64 256 0 0-64-96 0 0-116 216.1-247c8.3-9.4 10.2-22.9 5.1-34.3S492.6 32 480 32L32 32zm98.5 96l-28-32 307 0-28 32-251 0z"],
    "link-simple": [576, 512, [], "e1cd", "M160 64C71.6 64 0 135.6 0 224l0 64c0 88.4 71.6 160 160 160l96 0 0-64-96 0c-53 0-96-43-96-96l0-64c0-53 43-96 96-96l96 0 0-64-96 0zM416 448c88.4 0 160-71.6 160-160l0-64c0-88.4-71.6-160-160-160l-96 0 0 64 96 0c53 0 96 43 96 96l0 64c0 53-43 96-96 96l-96 0 0 64 96 0zM192 224l-32 0 0 64 256 0 0-64-224 0z"],
    "rectangle-wide": [576, 512, [], "f2fc", "M518.5 64.3C550.8 67.6 576 94.9 576 128l0 256-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-448 0-6.5-.3C25.2 444.4 0 417.1 0 384L0 128C0 94.9 25.2 67.6 57.5 64.3l6.5-.3 448 0 6.5 .3z"],
    "cloud-arrow-down": [576, 512, [62337, "cloud-download", "cloud-download-alt"], "f0ed", "M288 32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 88.4-71.6 160-160 160l-256 0C71.6 480 0 408.4 0 320 0 246.5 49.6 184.6 117.1 165.8 136 89 205.3 32 288 32zM264 160l0 174.1-72-72-33.9 33.9 113 113c9.4 9.4 24.6 9.4 33.9 0l113-113-33.9-33.9-72 72 0-174.1-48 0z"],
    "angle-down": [512, 512, [8964], "f107", "M448.3 146.8l-192 192-192-192-45.2 45.2 214.6 214.6c12.5 12.5 32.8 12.5 45.3 0L493.5 192 448.3 146.8z"],
    "ghost": [448, 512, [128123], "f6e2", "M342 496.6l-38-32.6-37.8 32.4C254.5 506.5 239.5 512 224 512s-30.5-5.5-42.2-15.6L144 464 106 496.6C94.4 506.5 79.6 512 64.3 512L0 512 0 224C0 100.3 100.3 0 224 0S448 100.3 448 224l0 288-64.3 0c-15.3 0-30-5.5-41.6-15.4zM200 224a40 40 0 1 0 -80 0 40 40 0 1 0 80 0zm88 40a40 40 0 1 0 0-80 40 40 0 1 0 0 80z"],
    "chart-pie": [512, 512, ["pie-chart"], "f200", "M160 89.7c-57.4 33.2-96 95.2-96 166.3 0 106 86 192 192 192 71.1 0 133.1-38.6 166.3-96l71.1 0C455.4 445.8 363.4 512 256 512 114.6 512 0 397.4 0 256 0 148.6 66.2 56.6 160 18.6l0 71.1zM256 0c141.4 0 256 114.6 256 256 0 17.7-14.3 32-32 32l-256 0 0-256 .2-3.3C225.8 12.6 239.4 0 256 0z"],
    "phone-arrow-right": [576, 512, [], "e5be", "M83.1 29.3c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-49.4 49.4c-.8 .8-1.1 2-.8 3.2 14.6 53.4 56.3 95.1 109.7 109.7 1.1 .3 2.3 0 3.2-.8l49.4-49.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9c-45 44.9-109.6 64.7-172 52.8-141.9-27-253.7-138.9-280.8-280.8-11.9-62.4 7.8-127 52.8-172L83.1 29.3zM565.6 76.2l1.8 2c4.1 5 6.3 11.3 6.3 17.8 0 7.4-2.9 14.6-8.2 19.8l-90.5 90.5-19.8 19.8-39.6-39.6c9.4-9.4 30.2-30.2 62.5-62.5l-186.7 0 0-56 186.7 0c-32.3-32.3-53.1-53.1-62.5-62.5L455.3-34.1 565.6 76.2z"],
    "list-music": [640, 512, [], "f8c9", "M192 0c-35.3 0-64 28.7-64 64l0 261.5c-10-3.5-20.8-5.5-32-5.5-53 0-96 43-96 96s43 96 96 96 96-43 96-96l0-224 96 0c35.3 0 64-28.7 64-64l0-64c0-35.3-28.7-64-64-64L192 0zM640 128l0-64-224 0 0 64 224 0zM608 448l32 0 0-64-352 0 0 64 320 0zm32-160l0-64-224 0 0 64 224 0z"],
    "inbox": [512, 512, [], "f01c", "M0 64C0 28.7 28.7 0 64 0L448 0c35.3 0 64 28.7 64 64l0 384c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64zM64 288l96 0 32 64 128 0 32-64 96 0 0-224-384 0 0 224z"],
    "bolt-slash": [640, 512, [], "e0b8", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM364.4 435.9L256.3 544 240.8 342.8c-.3-3.9-3.4-7.1-7.4-7.4l-201.2-15.5 108.1-108.1 224 224zm35.3-266.7c.3 3.9 3.4 7.1 7.4 7.4L608.3 192 500.1 300.1 276.1 76.1 384.3-32 399.7 169.2z"],
    "cloud-snow": [576, 512, [127784], "f742", "M288 480c17.7 0 32 14.3 32 32s-14.3 32-32 32-32-14.3-32-32 14.3-32 32-32zm-96 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm192 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm-96-64a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm0-448c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 77.8-55.5 142.6-129.1 157-6.9-12.4-17.4-22.5-30-29 23.2-11.9 39.1-36.1 39.1-64 0-39.8-32.2-72-72-72-38.5 0-69.9 30.2-71.8 68.2-7.6-2.7-15.7-4.2-24.2-4.2s-16.6 1.5-24.2 4.2c-2-38-33.3-68.2-71.8-68.2-39.8 0-72 32.2-72 72 0 27.9 15.9 52 39.1 64-12.6 6.5-23.1 16.6-30 29-73.6-14.4-129.1-79.2-129.1-157 0-8.6 .7-17 2-25.2 .7-4.2 1.5-8.3 2.5-12.3 13.5-56.2 56.7-100.8 112-116.4 13.8-3.9 28.4-6 43.5-6 40.6 0 77.7 15.1 105.8 40 10.6-12 21.2-24 31.7-36-36.6-32.3-84.9-52-137.6-52-6.8 0-13.5 .3-20.2 1 31.3-48.7 86-81 148.2-81zM192 352a32 32 0 1 1 0-64 32 32 0 1 1 0 64zm192 0a32 32 0 1 1 0-64 32 32 0 1 1 0 64z"],
    "credit-card": [512, 512, [128179, 62083, "credit-card-alt"], "f09d", "M0 96l0 64 512 0 0-64c0-35.3-28.7-64-64-64L64 32C28.7 32 0 60.7 0 96zM0 224L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-192-512 0z"],
    "wand-magic-sparkles": [576, 512, ["magic-wand-sparkles"], "e2ca", "M508 420l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68zm65.3-308l-384 384c-25 25-65.5 25-90.5 0L48 445.3c-25-25-25-65.5 0-90.5L432-29.2 573.3 112zM362.5 130.8l50.8 50.8 69.6-69.6-50.8-50.8-69.6 69.6zM124 36l68 0 0 56-68 0 0 68-56 0 0-68-68 0 0-56 68 0 0-68 56 0 0 68z"],
    "bell-slash": [640, 512, [128277, 61943], "f1f6", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM384.3 455.8l0 56.2-128 0 0-64 120.2 0 7.8 7.8zM344.5 416l-268 0 83.8-167.6 0-16.7 184.2 184.2zM320.3 0c88.4 0 160 71.6 160 160l0 120.2-251.5-251.5C254.7 10.6 286.2 0 320.3 0z"],
    "folders": [576, 512, [], "f660", "M384 64l128 0c35.3 0 64 28.7 64 64l0 192c0 35.3-28.7 64-64 64l-320 0c-35.3 0-64-28.7-64-64l0-256c0-35.3 28.7-64 64-64l128 0 64 64zM64 128l0 320 416 0 0 64-416 0c-35.3 0-64-28.7-64-64l0-320 64 0z"],
    "tv": [512, 512, [63717, "television", "tv-alt"], "f26c", "M448 512l-384 0 0-64 384 0 0 64zM448 0c35.3 0 64 28.7 64 64l0 256-.3 6.5C508.4 358.8 481.1 384 448 384L64 384C30.9 384 3.6 358.8 .3 326.5L0 320 0 64C0 28.7 28.7 0 64 0L448 0z"],
    "star": [576, 512, [11088, 61446], "f005", "M373.2 165.1c1.2 2.3 3.3 3.8 5.8 4.2L562.3 199 431.5 330.7c-1.8 1.8-2.6 4.4-2.2 6.9L457.7 521 292 437.3c-2.3-1.1-5-1.1-7.2 0L119.1 521 147.5 337.6c.4-2.5-.4-5.1-2.2-6.9L14.5 199 197.8 169.3c2.5-.4 4.7-2 5.8-4.2L288.4 0 373.2 165.1z"],
    "flag": [448, 512, [127988, 61725], "f024", "M64 32l114.8 0c27.2 0 53.3 10.1 73.3 28.2l7.9 7.5c18.7 16.9 42.7 26.9 67.9 28.1l5.4 .1 50.7 0c35.3 0 64 28.7 64 64l0 192c0 35.3-28.7 64-64 64l-114.7 0-5.4-.1c-25.2-1.2-49.2-11.2-67.9-28.1l-7.9-7.5c-18.7-16.9-42.7-26.9-67.9-28.1l-5.4-.1-50.8 0 0 160-64 0 0-512 64 0 0 32z"],
    "arrow-right-from-line": [512, 512, [8614, "arrow-from-left"], "f343", "M64 480l-64 0 0-448 64 0 0 448zM502.6 233.4l2.2 2.4c10.2 12.6 9.5 31.1-2.2 42.8l-150.6 150.6-45.3-45.3 96-96-242.7 0 0-64 242.7 0-96-96 45.3-45.2 150.6 150.6z"],
    "store": [576, 512, [], "f54e", "M320 224l64 0 0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-32zm-64 0l0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-32 64 0zM64 256l0-32 64 0 0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32zm160 96c24.6 0 47-9.2 64-24.4 17 15.2 39.4 24.4 64 24.4s47-9.2 64-24.4c17 15.2 39.4 24.4 64 24.4l0 96-384 0 0-96c24.6 0 47-9.2 64-24.4 17 15.2 39.4 24.4 64 24.4zm320-24.4c19.6-17.6 32-43.1 32-71.6l0-96-96-160-384 0-96 160 0 96c0 28.4 12.4 54 32 71.6L32 448c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-120.4zM448 224l64 0 0 32c0 17.7-14.3 32-32 32s-32-14.3-32-32l0-32z"],
    "mug-saucer": [576, 512, ["coffee"], "f0f4", "M96 32l-32 0 0 224c0 70.7 57.3 128 128 128l128 0c70.7 0 128-57.3 128-128l16 0c61.9 0 112-50.1 112-112S525.9 32 464 32L96 32zM448 96l16 0c26.5 0 48 21.5 48 48s-21.5 48-48 48l-16 0 0-96zM416 512c53 0 96-43 96-96l-64 0c0 17.7-14.3 32-32 32L96 448c-17.7 0-32-14.3-32-32L0 416c0 53 43 96 96 96l320 0z"],
    "lock": [384, 512, [128274], "f023", "M128 128c0-35.3 28.7-64 64-64s64 28.7 64 64l0 64-128 0 0-64zm-64 0l0 64c-35.3 0-64 28.7-64 64L0 448c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-192c0-35.3-28.7-64-64-64l0-64C320 57.3 262.7 0 192 0S64 57.3 64 128z"],
    "folder-plus": [512, 512, [], "f65e", "M288 96l160 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l160 0 64 64zm-56 96l0 72-72 0 0 48 72 0 0 72 48 0 0-72 72 0 0-48-72 0 0-72-48 0z"],
    "anchor": [512, 512, [9875], "f13d", "M256 0c53 0 96 43 96 96 0 41.8-26.7 77.2-64 90.4l0 261.6 32 0c70.7 0 128-57.3 128-128l-64 0 0-64 128 0 0 64c0 106-86 192-192 192l-128 0C86 512 0 426 0 320l0-64 128 0 0 64-64 0c0 70.7 57.3 128 128 128l32 0 0-261.6c-37.3-13.2-64-48.6-64-90.4 0-53 43-96 96-96z"],
    "user-minus": [640, 512, [], "f503", "M288 320c88.4 0 160 71.6 160 160l0 32-448 0 0-32c0-88.4 71.6-160 160-160l128 0zm-64-64a128 128 0 1 1 0-256 128 128 0 1 1 0 256zm416-4l-192 0 0-56 192 0 0 56z"],
    "scissors": [512, 512, [9984, 9986, 9988, "cut"], "f0c4", "M112 0c61.9 0 112 50.1 112 112 0 17.5-4 34.1-11.2 48.9l68.2 53.9 163.3-127.9 25.2-19.8 39.5 50.4-25.2 19.8-271.5 212.8c7.5 15.1 11.8 32 11.8 50 0 61.9-50.1 112-112 112S0 461.9 0 400 50.1 288 112 288c20.5 0 39.7 5.5 56.2 15.2l61-47.8-59.8-47.2C152.6 218.2 133 224 112 224 50.1 224 0 173.9 0 112S50.1 0 112 0zM483.8 374.9l25.1 19.8-39.7 50.2-25.1-19.8-111-87.6 51.7-40.8 99 78.2z"],
    "bug": [448, 512, [], "f188", "M378.6 17.8L337.6 79.3c13.8 13.9 25.1 30.4 33.1 48.7l77.3 0 0 64-64 0 0 64 64 0 0 64-64 0 0 32c0 11-1.1 21.7-3.2 32l67.2 0 0 64-96 0c-29.2 38.9-75.7 64-128 64s-98.8-25.1-128-64l-96 0 0-64 67.2 0c-2.1-10.3-3.2-21-3.2-32l0-32-64 0 0-64 64 0 0-64-64 0 0-64 77.3 0c8-18.3 19.2-34.7 33.1-48.7l-41-61.6 53.2-35.5 41 61.5C182.3 36.2 202.6 32 224 32s41.7 4.2 60.3 11.8l41.1-61.5 53.2 35.5zM160 168l0 48 128 0 0-48-128 0z"],
    "arrow-right-from-bracket": [512, 512, ["sign-out"], "f08b", "M192 96L96 96c-17.7 0-32 14.3-32 32l0 256c0 17.7 14.3 32 32 32l96 0 0 64-96 0c-53 0-96-43-96-96L0 128C0 75 43 32 96 32l96 0 0 64zM502.6 233.4l2.2 2.4c10.2 12.6 9.5 31.1-2.2 42.8l-150.6 150.6-45.2-45.3 96-96-242.8 0 0-64 242.8 0-96-96 45.2-45.2 150.6 150.6z"],
    "arrow-right-arrow-left": [448, 512, [8644, "exchange"], "f0ec", "M9.4 406.6C85.6 482.9 125.1 522.4 128 525.3L173.3 480c-12-12-33.3-33.3-64-64l338.7 0 0-64-338.7 0c30.7-30.7 52-52 64-64L128 242.7c-2.9 2.9-42.4 42.4-118.6 118.6-6 6-9.4 14.1-9.4 22.6s3.4 16.6 9.4 22.6zm429.3-256c12.5-12.5 12.5-32.8 0-45.3-76.2-76.2-115.8-115.8-118.6-118.6L274.7 32c12 12 33.3 33.3 64 64L0 96 0 160 338.7 160c-30.7 30.7-52 52-64 64L320 269.2c2.9-2.9 42.4-42.4 118.6-118.6z"],
    "arrow-up-from-line": [448, 512, [8613, "arrow-from-bottom"], "f342", "M448 512l-448 0 0-64 448 0 0 64zM203.8 7.2c12.6-10.3 31.1-9.5 42.8 2.2l150.6 150.6-45.3 45.3-96-96 0 242.7-64 0 0-242.7-96 96-45.2-45.3 150.6-150.6 2.4-2.2z"],
    "battery-full": [640, 512, [128267, "battery", "battery-5"], "f240", "M480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l416 0zM640 352l-64 0 0-192 64 0 0 192zM128 192l0 128 288 0 0-128-288 0z"],
    "font": [512, 512, [], "f031", "M128 416l0-96 256 0 0 96-64 0 0 64 192 0 0-64-64 0 0-192c0-106-86-192-192-192S64 118 64 224l0 192-64 0 0 64 192 0 0-64-64 0z"],
    "language": [576, 512, [], "f1ab", "M192 32l0-32-64 0 0 64-128 0 0 64 242.3 0-.5 1.2c-14.7 40.3-37.1 76.9-65.7 107.8-25.8-21.9-48.6-47.5-67.7-76.1l-1.8-2.7-53.3 35.5 1.8 2.7c20.7 31.1 45.2 59 72.6 83.4-13.7 9.8-28.2 18.6-43.5 26.3-24 12-45.1 22.5-63.2 31.6l28.6 57.2c18.1-9 39.2-19.6 63.2-31.6 24.2-12.1 47-26.7 67.8-43.3 37.5 24.2 78.8 42.5 122.4 54.2-28.3 66.1-44.7 104.3-49.1 114.6L312.8 514c7.9-18.4 17.3-40.4 28.3-66l149.8 0c11 25.6 20.4 47.6 28.3 66l58.8-25.2-12.6-29.4-120-280c-5-11.8-16.6-19.4-29.4-19.4s-24.4 7.6-29.4 19.4l-58 135.2c-35.4-8.5-69-22.1-100-40.2 31.7-35.8 56.7-77.5 73.3-123.3l8.4-23.1 41.6 0 0-64-160 0 0-32z"],
    "shield-halved": [448, 512, ["shield-alt"], "f3ed", "M234.1 1.7L404.2 58.3c26.1 8.7 43.7 33.2 43.8 60.7l0 146.3c0 84.8-47.9 162.4-123.8 200.3L224 515.8 123.8 465.7C47.9 427.7 0 350.2 0 265.3L0 119.1c0-27.5 17.6-52 43.8-60.7L213.9 1.7 224-1.8 234.1 1.7zM224 444.2l71.6-35.8c54.2-27.1 88.4-82.5 88.4-143.1l0-146.3-160-53.3 0 378.5z"],
    "person-biking": [576, 512, [128692, "biking"], "f84a", "M416 48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM112 512a112 112 0 1 0 0-224 112 112 0 1 0 0 224zm352 0a112 112 0 1 0 0-224 112 112 0 1 0 0 224zM242.2 219l49.8-49.8 74.2 49.4c5.3 3.5 11.4 5.4 17.8 5.4l64 0 0-64-54.3 0-77-51.3c-19-12.7-44.4-10.2-60.6 6l-72.9 72.9c-21.4 21.4-17.9 57.1 7.3 73.9l65.5 43.7 0 110.9 64 0 0-128c0-10.7-5.3-20.7-14.2-26.6L242.2 219z"],
    "phone-xmark": [512, 512, [], "e227", "M83.1 29.3c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-49.4 49.4c-.8 .8-1.1 2-.8 3.2 14.6 53.4 56.3 95.1 109.7 109.7 1.1 .3 2.3 0 3.2-.8l49.4-49.4c25-25 65.5-25 90.5 0l53.5 53.5c25 25 25 65.5 0 90.5l-26.9 26.9c-45 45-109.6 64.7-172 52.8-141.9-27-253.8-138.9-280.8-280.8-11.9-62.4 7.8-127.1 52.8-172L83.1 29.3zM496 55.9l-56.1 56.1 56.1 56.1-39.6 39.6-56.1-56.1-56.1 56.1-39.6-39.6 56.1-56.1-56.1-56.1 39.6-39.6 56.1 56.1 56.1-56.1 39.6 39.6z"],
    "globe": [512, 512, [127760], "f0ac", "M342.1 280c-2.6 68.8-16 128.8-35 171.5-10.6 23.8-22 40.2-32.2 49.9-9.8 9.3-16.2 10.6-19.3 10.6l-.4 0c-3.1-.1-9.6-1.4-19.3-10.6-10.2-9.7-21.6-26-32.2-49.9-19-42.7-32.4-102.7-34.9-171.5l173.2 0zm169.1 0c-9.6 102.8-79.9 187.9-174.7 219.1 30.1-51 50.5-129.6 53.6-219.1l121.1 0zm-390.4 0C123.9 369.1 144 447.4 173.9 498.3 80.2 466.5 11 382 1.5 280l119.3 0zM173.9 13.6c-29.9 51-50 129.3-53.1 218.4L1.5 232C11 130 80.2 45.5 173.9 13.6zM255.6 0c3.1 0 9.6 1.3 19.3 10.7 10.2 9.7 21.6 26 32.2 49.9 19 42.7 32.4 102.7 35 171.5l-173.2 0c2.6-68.8 16-128.8 34.9-171.5 10.6-23.8 22-40.2 32.2-49.9 9.7-9.2 16.1-10.6 19.3-10.7 .1 0 .3 0 .4 0zm80.9 12.8C431.3 44.1 501.6 129.2 511.2 232l-121.1 0C387 142.4 366.6 63.8 336.5 12.8z"],
    "folder-minus": [512, 512, [], "f65d", "M288 96l160 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l160 0 64 64zM160 264l0 48 192 0 0-48-192 0z"],
    "poop": [512, 512, [], "f619", "M176 96l8 0 8.5-6.8c20.2-16.1 33-39.7 35.6-65.4L230.4 .4c3.2-.3 6.4-.4 9.6-.4 56.8 0 103.7 42.2 111 97 54.8 7.3 97 54.2 97 111 0 21-5.8 40.6-15.8 57.4 46.8 19 79.8 65 79.8 118.6 0 70.7-57.3 128-128 128l-256 0c-70.7 0-128-57.3-128-128 0-53.6 33-99.6 79.8-118.6 14.9-6.1 31.2-9.4 48.2-9.4l48 0 0-48-48 0c-22.3 0-43.7 4.2-63.4 11.8-.4-3.9-.6-7.8-.6-11.8 0-61.9 50.1-112 112-112z"],
    "speaker": [448, 512, [], "f8df", "M384 0c35.3 0 64 28.7 64 64l0 384c0 35.3-28.7 64-64 64L64 512c-35.3 0-64-28.7-64-64L0 64C0 28.7 28.7 0 64 0L384 0zM224 240a80 80 0 1 1 0 160 80 80 0 1 1 0-160zm128 80a128 128 0 1 0 -256 0 128 128 0 1 0 256 0zM256 96a32 32 0 1 0 -64 0 32 32 0 1 0 64 0z"],
    "battery-quarter": [640, 512, ["battery-2"], "f243", "M480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l416 0zM640 352l-64 0 0-192 64 0 0 192zM128 192l0 128 96 0 0-128-96 0z"],
    "diamond": [576, 512, [9830], "f219", "M288-16c10.2 0 20.1 4.1 27.3 11.3L548.7 228.7c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L315.3 516.7c-7.2 7.2-17.1 11.3-27.3 11.3s-20.1-4.1-27.3-11.3L27.3 283.3C20.1 276.1 16 266.2 16 256s4.1-20.1 11.3-27.3L260.7-4.7C267.9-11.9 277.8-16 288-16z"],
    "computer-classic": [512, 512, [], "f8b1", "M448 0c35.3 0 64 28.7 64 64l0 332.6c0 12.6-3.7 25-10.7 35.5L467 483.5c-11.9 17.8-31.9 28.5-53.3 28.5L98.2 512c-21.4 0-41.4-10.7-53.2-28.5L10.8 432.1C3.7 421.6 0 409.3 0 396.6L0 64C0 28.7 28.7 0 64 0L448 0zM288 408l128 0 0-48-128 0 0 48zM96 96l0 192 320 0 0-192-320 0z"],
    "grid-round": [512, 512, [], "e5da", "M112 512a112 112 0 1 1 0-224 112 112 0 1 1 0 224zm288 0a112 112 0 1 1 0-224 112 112 0 1 1 0 224zM112 224a112 112 0 1 1 0-224 112 112 0 1 1 0 224zm288 0a112 112 0 1 1 0-224 112 112 0 1 1 0 224z"],
    "arrow-left": [448, 512, [8592], "f060", "M269.3 64l-160 160 338.8 0 0 64-338.8 0 160 160-45.3 45.3-214.6-214.6c-12.5-12.5-12.5-32.8 0-45.3L224 18.8 269.3 64z"],
    "paw": [512, 512, [], "f1b0", "M176 96a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm-.4 83.4L65.3 299.7c-21.4 23.4-33.3 53.9-33.3 85.6 0 70 57.7 126.7 127.7 126.7 21 0 41.8-5.9 59.6-17l36.8-23 36.8 23c17.8 11.1 38.6 17 59.6 17 70 0 127.7-56.7 127.7-126.7 0-31.7-11.9-62.3-33.3-85.6L336.4 179.4C315.8 156.8 286.6 144 256 144s-59.8 12.8-80.4 35.4zM96 176a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM336 96a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm176 80a48 48 0 1 0 -96 0 48 48 0 1 0 96 0z"],
    "bed": [640, 512, [128716], "f236", "M64 64l0-32-64 0 0 448 64 0 0-96 512 0 0 96 64 0 0-288c0-53-43-96-96-96L352 96c-17.7 0-32 14.3-32 32l0 192-256 0 0-256zM288 192a96 96 0 1 0 -192 0 96 96 0 1 0 192 0z"],
    "heart-slash": [640, 512, [], "e78e", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM385.2 456.7l-65 65-222.6-222.6C52.8 254.2 40.9 189 61.8 133.3L385.2 456.7zM331.3 68.9c61.5-52 153.6-49 211.5 8.9 61.1 61.1 61.1 160.2 0 221.2l-21.9 21.9-220.8-220.8 31.2-31.2z"],
    "fill": [576, 512, [], "f575", "M518.9 367.2l38.4 51.2c9.9 13.2 15.2 29.2 15.2 45.6 0 42-34 76-76 76-42 0-76-34-76-76 0-16.4 5.3-32.4 15.2-45.6 28.3-37.7 48.5-64.7 60.8-81.1l22.4 29.8zM455.1 249.4c6 6 9.4 14.1 9.4 22.6s-3.4 16.6-9.4 22.6L268.4 481.4c-37.5 37.5-98.3 37.5-135.8 0L31.1 379.9c-37.5-37.5-37.5-98.3 0-135.8l164.1-164.1-64-64 45.3-45.2 278.6 278.6zM105.7 260L375.2 260 240.5 125.2 105.7 260z"],
    "landmark": [512, 512, [127963], "f66f", "M256-36.9l15.9 9.1 220 125.7c12.5 7.1 20.2 20.4 20.2 34.7l0 19.4c0 19.4-13.7 35.5-32 39.2l0 192.8-64 0 0-192-64 0 0 192-64 0 0-192-64 0 0 192-64 0 0-192-64 0 0 192-64 0 0-192 0 0 0-.8C13.8 187.5 0 171.4 0 152l0-19.4C0 118.3 7.7 105 20.2 97.9l220-125.7 15.9-9.1zM0 448l512 0 0 64-512 0 0-64z"],
    "music": [512, 512, [127925], "f001", "M395.8 15.7C437.2 1.9 480 32.7 480 76.4L480 384c0 53-43 96-96 96s-96-43-96-96 43-96 96-96c11.2 0 22 1.9 32 5.5l0-89.1-224 74.7 0 136.9c0 53-43 96-96 96s-96-43-96-96 43-96 96-96c11.2 0 22 1.9 32 5.5l0-174.4c0-27.5 17.6-52 43.8-60.7l224-74.7z"],
    "files": [512, 512, [], "e178", "M352-32L192-32c-35.3 0-64 28.7-64 64l0 320c0 35.3 28.7 64 64 64l224 0c35.3 0 64-28.7 64-64L480 96 352-32zM64 96L0 96 0 480c0 35.3 28.7 64 64 64l288 0 0-64-288 0 0-384z"],
    "underline": [448, 512, [], "f0cd", "M0 544l448 0 0-64-448 0 0 64zM352 32L32 32 32 224c0 106 86 192 192 192s192-86 192-192l0-192-64 0z"],
    "plus": [448, 512, [10133, 61543, "add"], "2b", "M256 224l192 0 0 64-192 0 0 192-64 0 0-192-192 0 0-64 192 0 0-192 64 0 0 192z"],
    "bell-ring": [576, 512, [], "e62c", "M352 512l-128 0 0-64 128 0 0 64zM288 0c88.4 0 160 71.6 160 160l0 88.4 83.8 167.6-487.6 0 83.8-167.6 0-88.4C128 71.6 199.6 0 288 0zM120 11.8C85.1 51.3 64 103.2 64 160l0 32-64 0 0-32C0 87 27.2 20.2 72-30.5l48 42.4zM504-30.5C548.8 20.2 576 87 576 160l0 32-64 0 0-32c0-56.8-21.1-108.7-56-148.2l48-42.4z"],
    "copy": [512, 512, [], "f0c5", "M64 448l320 0 0 64-320 0c-35.3 0-64-28.7-64-64l0-320 64 0 0 320zM448 0c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64l-256 0c-35.3 0-64-28.7-64-64l0-256c0-35.3 28.7-64 64-64L448 0z"],
    "box": [512, 512, [128230], "f466", "M128 0l-16 0-9.6 12.8-89.6 119.5C4.5 143.3 0 156.8 0 170.7L0 448c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-277.3c0-13.8-4.5-27.3-12.8-38.4L409.6 12.8 400 0 128 0zM93 132l51-68 84 0 0 68-135 0zm191 0l0-68 84 0 51 68-135 0z"],
    "arrow-rotate-right": [512, 512, [8635, "arrow-right-rotate", "arrow-rotate-forward", "redo"], "f01e", "M399.1 128C363.9 88.7 312.8 64 256 64 150 64 64 150 64 256s86 192 192 192c76.5 0 142.7-44.8 173.5-109.7l57.8 27.5C446.3 452.1 358.2 512 256 512 114.6 512 0 397.4 0 256S114.6 0 256 0c76.5 0 145.1 33.5 192 86.7l0-86.7 64 0 0 160c0 17.7-14.3 32-32 32l-160 0 0-64 79.1 0z"],
    "arrow-down-wide-short": [640, 512, ["sort-amount-asc", "sort-amount-down"], "f160", "M182.9 470.6c-12.5 12.5-32.8 12.5-45.3 0-76.2-76.2-115.8-115.8-118.6-118.6l45.3-45.3c12 12 33.3 33.3 64 64l0-338.7 64 0 0 338.7c30.7-30.7 52-52 64-64L301.5 352c-2.9 2.9-42.4 42.4-118.6 118.6zM576.3 128l-256 0 0-64 288 0 0 64-32 0zm-96 320l-160 0 0-64 160 0 0 64zm32-160l-192 0 0-64 224 0 0 64-32 0z"],
    "compress": [512, 512, [], "f066", "M160 32l0-32-64 0 0 96-96 0 0 64 128 0c17.7 0 32-14.3 32-32l0-96zM32 352l-32 0 0 64 96 0 0 96 64 0 0-128c0-17.7-14.3-32-32-32l-96 0zM416 32l0-32-64 0 0 128c0 17.7 14.3 32 32 32l128 0 0-64-96 0 0-64zM384 352c-17.7 0-32 14.3-32 32l0 128 64 0 0-96 96 0 0-64-128 0z"],
    "circle-dollar": [512, 512, ["dollar-circle", "usd-circle"], "f2e8", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM232 136l-12 0c-37.5 0-68 30.4-68 68 0 32.4 22.9 60.3 54.6 66.6L296 288.5c9.3 1.9 16 10.1 16 19.6 0 11-8.9 20-20 20l-116 0 0 48 56 0 0 40 48 0 0-40 12 0c37.5 0 68-30.4 68-68 0-32.4-22.9-60.3-54.6-66.6L216 223.5c-9.3-1.9-16-10.1-16-19.6 0-11 8.9-20 20-20l116 0 0-48-56 0 0-40-48 0 0 40z"],
    "cloud-bolt": [576, 512, [127785, "thunderstorm"], "f76c", "M341.1 274.4L269.7 356 368 356c11 0 21 6.5 25.5 16.5s2.7 21.8-4.6 30.1l-128 144-41.9-37.2 86.6-97.4-97.7 0c-11 0-21-6.4-25.5-16.4s-2.8-21.7 4.4-30l112-128 42.1 36.9zM288-32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 82.7-62.7 150.6-143.1 159.1 9-18.8 9.6-41 .8-60.6-11.6-25.9-37.3-42.5-65.7-42.5l-3.5 0 41-47.8-109.3-93.7c-23 26.9-70.7 82.5-142.8 166.7-18.3 21.4-22.5 51.4-10.8 76.9 .2 .3 .3 .7 .5 1-80.4-8.4-143.1-76.4-143.1-159.1 0-8.6 .7-17 2-25.2 .7-4.2 1.5-8.3 2.5-12.3 13.5-56.2 56.7-100.8 112-116.4 13.8-3.9 28.4-6 43.5-6 40.6 0 77.7 15.1 105.8 40 10.6-12 21.2-24 31.7-36-36.6-32.3-84.9-52-137.6-52-6.8 0-13.5 .3-20.2 1 31.3-48.7 86-81 148.2-81z"],
    "eye-slash": [640, 512, [], "f070", "M621.5 512L576.3 557.2 19 0 64.3-45.3 621.5 512zM396.8 468.3C372.5 475.8 347 480 320.3 480 185 480 78.7 374.4 29.6 256 43.9 221.5 63.1 188 86.5 158L396.8 468.3zM320.3 32c135.2 0 241.5 105.6 290.7 224-14.3 34.5-33.6 67.9-56.9 98L243.7 43.7C267.9 36.1 293.5 32 320.3 32z"],
    "mug-hot": [576, 512, [9749], "f7b6", "M100-32l56 0 0 21.5c0 9.5 3.8 18.7 10.5 25.5l26.5 26.5C210.3 58.7 220 82.1 220 106.5l0 21.5-56 0 0-21.5c0-9.5-3.8-18.7-10.5-25.5L126.9 54.5C109.7 37.3 100 13.9 100-10.5L100-32zM64 192l400 0c61.9 0 112 50.1 112 112S525.9 416 464 416l-20 0c-14.2 55.2-64.3 96-124 96l-128 0c-70.7 0-128-57.3-128-128l0-192zM448 352l16 0c26.5 0 48-21.5 48-48s-21.5-48-48-48l-16 0 0 96zM228-10.5l0-21.5 56 0 0 21.5c0 9.5 3.8 18.7 10.5 25.5l26.5 26.5C338.3 58.7 348 82.1 348 106.5l0 21.5-56 0 0-21.5c0-9.5-3.8-18.7-10.5-25.5L254.9 54.5C237.7 37.3 228 13.9 228-10.5z"],
    "bolt": [576, 512, [9889, "zap"], "f0e7", "M84 326.5L0 320C10.9 309.1 108.4 211.6 292.4 27.6L352-32c3.9 50.5 9 117.6 15.5 201.2 .3 3.9 3.4 7.1 7.4 7.4 83.6 6.4 150.6 11.6 201.2 15.5-10.9 10.9-108.4 108.4-292.4 292.4L224 544c-3.9-50.5-9-117.6-15.5-201.2-.3-3.9-3.4-7.1-7.4-7.4L84 326.5z"],
    "aperture": [512, 512, [], "e2df", "M0 256a256 256 0 1 1 512 0 256 256 0 1 1 -512 0zm434.1-71.9c-7-17.4-16.6-33.6-28.1-48l-94.3 0c-.3 0-.6 0-.9 0l-68.8 0 40.6-70.2c-8.7-1.2-17.5-1.8-26.5-1.8-9.9 0-19.6 .8-29.1 2.2L145 208 104.5 138C93.2 152.6 83.8 168.8 77 186.3l46.9 81.2c.2 .3 .4 .6 .5 .9L158.8 328 78 328c7 17.4 16.6 33.6 28.1 48l163.5 0-40.5 70.2c8.8 1.2 17.8 1.9 26.9 1.9 9.7 0 19.3-.7 28.6-2.1l47.3-81.8 .1-.3 34.5-59.8 40.6 70.3c11.4-14.5 20.7-30.7 27.6-48.2l-47.1-81.6c-.2-.4-.4-.7-.6-1l-34.3-59.4 81.3 0zm-136.7 0l41.5 71.9-41.5 71.9-83.1 0-41.6-72 41.5-71.9 83.1 0z"],
    "signal-fair": [576, 512, ["signal-2"], "f68d", "M517.8 0C549.9 0 576 26.1 576 58.2L576 448c0 35.3-28.7 64-64 64L55 512c-30.4 0-55-24.6-55-55 0-15.9 6.9-31 18.9-41.5L479.6 14.3C490.2 5.1 503.7 0 517.8 0zM252 297.3l0 150.7 260 0 0-377.1-260 226.4z"],
    "arrow-rotate-left": [512, 512, [8634, "arrow-left-rotate", "arrow-rotate-back", "arrow-rotate-backward", "undo"], "f0e2", "M32 192c-17.7 0-32-14.3-32-32L0 0 64 0 64 86.7C110.9 33.5 179.5 0 256 0 397.4 0 512 114.6 512 256S397.4 512 256 512C153.8 512 65.7 452.1 24.7 365.7l57.8-27.5c30.9 64.9 97 109.7 173.5 109.7 106 0 192-86 192-192S362 64 256 64c-56.8 0-107.9 24.7-143.1 64l79.1 0 0 64-160 0z"],
    "wifi": [576, 512, ["wifi-3", "wifi-strong"], "f1eb", "M201.3 393.2l86.8 86.8 86.8-86.8c-20.5-25.1-51.8-41.2-86.8-41.2s-66.3 16.1-86.8 41.2zm-29.8-29.8c26.2-36 68.6-59.4 116.6-59.4s90.4 23.4 116.6 59.4L473 295c-44-53.2-110.5-87-185-87s-140.9 33.9-185 87l68.4 68.4zM69 261c52.8-61.8 131.3-101 219-101s166.2 39.2 219 101l68-68C504.8 113.8 402.2 64 288.1 64S71.3 113.8 1 192.9l68 68z"],
    "circle-arrow-up": [512, 512, ["arrow-circle-up"], "f0aa", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zm17-369c-9.4-9.4-24.6-9.4-33.9 0l-112 112 33.9 33.9 71-71 0 166.1 48 0 0-166.1 71 71 33.9-33.9-112-112z"],
    "volume": [576, 512, [128265, "volume-medium"], "f6a8", "M320 480l-53.3 0c-13.8 0-27.3-4.5-38.4-12.8L117.3 384 64 384c-35.3 0-64-28.7-64-64L0 192c0-35.3 28.7-64 64-64l53.3 0 110.9-83.2C239.4 36.5 252.8 32 266.7 32l53.3 0 0 448zM384 34.3c108.5 15.5 192 108.8 192 221.7 0 112.8-83.5 206.2-192 221.7l0-56.8c77.5-14.9 136-83.1 136-164.9 0-81.8-58.5-150-136-164.9l0-56.8zm0 97.7c55.2 14.2 96 64.3 96 124 0 59.6-40.8 109.8-96 124l0-59.6c23.7-11.8 40-36.2 40-64.4 0-28.3-16.3-52.7-40-64.4l0-59.5z"],
    "tag": [512, 512, [127991], "f02b", "M454 0L230 0 19.2 210.7c-25 25-25 65.5 0 90.5L216.7 498.7c25 25 65.5 25 90.5 0L518 288 518 64c0-35.3-28.7-64-64-64zM368.5 104a40 40 0 1 1 0 80 40 40 0 1 1 0-80z"],
    "compact-disc": [512, 512, [128191, 128192, 128440], "f51f", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM362.4 291c-4.9 14.8-12.7 28.2-22.8 39.5l44.9 68.1c29.6-26.6 50.8-62.3 59.3-102.7L362.4 291zM256 192a64 64 0 1 0 0 128 64 64 0 1 0 0-128zM127.5 113.3C97.9 140 76.7 175.7 68.2 216.1l81.4 4.9c4.9-14.8 12.7-28.2 22.8-39.5l-44.9-68.1z"],
    "phone-slash": [640, 512, [], "f3dd", "M621.5 0L64.3 557.3 19 512 576.3-45.2 621.5 0zM445.3 266.6c17.3-.8 35 5.4 48.2 18.6L547 338.7c25 25 25 65.5 0 90.5l-26.9 26.9c-45 45-109.6 64.7-172 52.8-37.9-7.2-73.6-20.6-106.2-38.8L445.3 266.6zM147 29.2c25-25 65.5-25 90.5 0L291 82.7c13.2 13.2 19.4 30.8 18.6 48.2L106.2 334.3c-18.3-32.6-31.6-68.3-38.8-106.2-11.9-62.4 7.8-127.1 52.8-172L147 29.2z"],
    "grid-2": [512, 512, [], "e196", "M224 512L64 512c-35.3 0-64-28.7-64-64l0-160 224 0 0 224zm288-64c0 35.3-28.7 64-64 64l-160 0 0-224 224 0 0 160zM224 224L0 224 0 64C0 28.7 28.7 0 64 0l160 0 0 224zM448 0c35.3 0 64 28.7 64 64l0 160-224 0 0-224 160 0z"],
    "arrow-up-right-from-square": [512, 512, ["external-link"], "f08e", "M320 0l-32 0 0 64 114.7 0-201.4 201.4-22.6 22.6 45.3 45.3 22.6-22.6 201.4-201.4 0 114.7 64 0 0-192c0-17.7-14.3-32-32-32L320 0zM64 64C28.7 64 0 92.7 0 128L0 448c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-128-64 0 0 128-320 0 0-320 128 0 0-64-128 0z"],
    "rectangle-tall": [384, 512, [], "e791", "M326.5-31.7C358.8-28.4 384-1.1 384 32l0 448-.3 6.5c-3.1 30.1-27 54.1-57.1 57.1l-6.5 .3-256 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1L0 480 0 32C0-3.3 28.7-32 64-32l256 0 6.5 .3z"],
    "compass": [512, 512, [129517], "f14e", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM232.5 179.9c-27 4.5-48.1 25.7-52.6 52.6L160 352 279.5 332.1c27-4.5 48.1-25.7 52.6-52.6L352 160 232.5 179.9z"],
    "pen-nib": [512, 512, [10001], "f5ad", "M307 32c25-25 65.5-25 90.5 0l82.8 82.8c25 25 25 65.5 0 90.5l-48 48 0 8.5c0 56-22.3 109.8-61.9 149.4-33.2 33.2-76.6 54.4-123.2 60.2L56.6 495.2 229.1 322.7c3.6 .8 7.3 1.2 11.2 1.3 28.7 0 52-23.3 52-52s-23.3-52-52-52-52 23.3-52 52c0 3.8 .4 7.5 1.2 11.1L17 455.5 40.8 265.1c5.8-46.6 27-90 60.2-123.2 39.6-39.6 93.4-61.9 149.4-61.9l8.5 0 48-48z"],
    "square": [448, 512, [9632, 9723, 9724, 61590], "f0c8", "M384 32c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l320 0z"],
    "angle-up": [512, 512, [8963], "f106", "M448.3 365.3l-192-192-192 192-45.2-45.3 214.6-214.6c12.5-12.5 32.8-12.5 45.3 0L493.5 320 448.3 365.3z"],
    "face-smile": [512, 512, [128578, "smile"], "f118", "M256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zm0-152c38.5 0 72.1-20.9 90.1-52l41.5 24c-26.2 45.4-75.4 76-131.7 76s-105.4-30.6-131.6-76l41.5-24c18 31.1 51.6 52 90.1 52zM144 208a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zm192-32a32 32 0 1 1 0 64 32 32 0 1 1 0-64z"],
    "cloud-showers": [576, 512, [], "f73f", "M316 324l0 216-56 0 0-216 56 0zM220 508l-56 0 0-216 56 0 0 216zm192 0l-56 0 0-216 56 0 0 216zM288-32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 77.4-55 142-128 156.8l0-156.8-128 0 0 32-64 0 0-32-128 0 0 156.8c-73-14.8-128-79.4-128-156.8 0-8.6 .7-17 2-25.2 .7-4.2 1.5-8.3 2.5-12.3 13.5-56.2 56.7-100.8 112-116.4 13.8-3.9 28.4-6 43.5-6 40.6 0 77.7 15.1 105.8 40 10.6-12 21.2-24 31.7-36-36.6-32.3-84.9-52-137.6-52-6.8 0-13.5 .3-20.2 1 31.3-48.7 86-81 148.2-81z"],
    "umbrella": [512, 512, [], "f0e9", "M2.6 219.6C20.3 95.4 127 0 256.1 0S491.8 95.4 509.5 219.6c5.7 39.8-27.5 68.4-61.4 68.4l-160 0 0 128c0 53-43 96-96 96s-96-43-96-96l0-32 64 0 0 32c0 17.7 14.3 32 32 32s32-14.3 32-32l0-128-160 0C30.2 288-3 259.4 2.6 219.6z"],
    "briefcase": [512, 512, [128188], "f0b1", "M192 60l128 0c2.2 0 4 1.8 4 4l0 32-136 0 0-32c0-2.2 1.8-4 4-4zm-60 4l0 32-68 0C28.7 96 0 124.7 0 160l0 60 512 0 0-60c0-35.3-28.7-64-64-64l-68 0 0-32c0-33.1-26.9-60-60-60L192 4c-33.1 0-60 26.9-60 60zM512 260L0 260 0 448c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-188z"],
    "microchip": [576, 512, [], "f2db", "M256 32l64 0 0-64 64 0 0 64 64 0c35.3 0 64 28.7 64 64l0 64 64 0 0 64-64 0 0 64 64 0 0 64-64 0 0 64c0 35.3-28.7 64-64 64l-64 0 0 64-64 0 0-64-64 0 0 64-64 0 0-64-64 0-6.5-.3c-30.1-3.1-54.1-27-57.1-57.1l-.3-6.5 0-64-64 0 0-64 64 0 0-64-64 0 0-64 64 0 0-64 .3-6.5c3.1-30.1 27-54.1 57.1-57.1l6.5-.3 64 0 0-64 64 0 0 64zM128 96l0 320 320 0 0-320-320 0zm272 48l0 224-224 0 0-224 224 0z"],
    "pause": [256, 512, [9208], "f04c", "M64 64l-64 0 0 384 64 0 0-384zm192 0l-64 0 0 384 64 0 0-384z"],
    "arrow-down": [512, 512, [8595], "f063", "M448.3 210.8l-160 160 0-338.7-64 0 0 338.7-160-160-45.3 45.2 214.6 214.6c12.5 12.5 32.8 12.5 45.3 0L493.5 256 448.3 210.8z"],
    "location-dot": [384, 512, ["map-marker-alt"], "f3c5", "M192 0c106 0 192 86 192 192 0 41.5-13.5 82-38.4 115.2L192 512 38.4 307.2C13.5 274 0 233.5 0 192 0 86 86 0 192 0zm0 136a56 56 0 1 0 0 112 56 56 0 1 0 0-112z"],
    "bars": [512, 512, ["navicon"], "f0c9", "M512 128l-512 0 0-64 512 0 0 64zm0 320l-512 0 0-64 512 0 0 64zM480 288l-480 0 0-64 512 0 0 64-32 0z"],
    "battery-empty": [640, 512, ["battery-0"], "f244", "M480 64c35.3 0 64 28.7 64 64l0 256c0 35.3-28.7 64-64 64L64 448c-35.3 0-64-28.7-64-64L0 128C0 92.7 28.7 64 64 64l416 0zM640 352l-64 0 0-192 64 0 0 192z"],
    "keyboard": [576, 512, [9000], "f11c", "M512 32c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96C0 60.7 28.7 32 64 32l448 0zM160 376l256 0 0-48-256 0 0 48zm-48-88l64 0 0-64-64 0 0 64zm96 0l64 0 0-64-64 0 0 64zm96 0l64 0 0-64-64 0 0 64zm96 0l64 0 0-64-64 0 0 64zM112 192l64 0 0-64-64 0 0 64zm96 0l64 0 0-64-64 0 0 64zm96 0l64 0 0-64-64 0 0 64zm96-64l0 64 64 0 0-64-64 0z"],
    "stopwatch": [512, 512, [9201], "f2f2", "M192.4-32l160 0 0 64-192 0 0-64 32 0zm288 320c0 123.7-100.3 224-224 224s-224-100.3-224-224 100.3-224 224-224c64.6 0 122.8 27.3 163.7 71.1 17.7-11.8 35.4-23.6 53.2-35.5l35.5 53.3c-17.9 12-35.3 23.5-52.1 34.7 15.2 30.2 23.7 64.3 23.7 100.4zm-200-96l0-24-48 0 0 120c0 13.3 10.7 24 24 24s24-10.7 24-24l0-96z"],
    "train": [512, 512, [128646], "f238", "M352.3 0c70.7 0 128 57.3 128 128l0 224c0 40.1-18.5 75.9-47.4 99.4l60.6 60.6-45.2 45.3-78.5-78.5c-5.7 .8-11.6 1.3-17.5 1.3l-192 0-6.6-.2c-3.7-.2-7.4-.6-11-1.1L64.2 557.3 19 512 79.6 451.4C50.7 427.9 32.2 392.1 32.2 352l0-224c0-70.7 57.3-128 128-128l192 0zm-208 296a40 40 0 1 0 0 80 40 40 0 1 0 0-80zm224 0a40 40 0 1 0 0 80 40 40 0 1 0 0-80zM160.2 64c-35.3 0-64 28.7-64 64l0 96 320 0 0-96c0-35.3-28.7-64-64-64l-192 0z"],
    "train-subway": [512, 512, ["subway"], "f239", "M352.3 0c70.7 0 128 57.3 128 128l0 224c0 40.1-18.5 75.9-47.4 99.4l60.6 60.6-45.2 45.3-78.5-78.5c-5.7 .8-11.6 1.3-17.5 1.3l-192 0-6.6-.2c-3.7-.2-7.4-.6-11-1.1L64.2 557.3 19 512 79.6 451.4C52.3 429.2 34.3 396 32.4 358.6l-.2-6.6 0-224c0-70.7 57.3-128 128-128l192 0zm-208 296a40 40 0 1 0 0 80 40 40 0 1 0 0-80zm224 0a40 40 0 1 0 0 80 40 40 0 1 0 0-80zM160.2 64c-35.3 0-64 28.7-64 64l0 96 132 0 0-160-68 0zm124 160l132 0 0-96c0-35.3-28.7-64-64-64l-68 0 0 160z"],
    "cloud-drizzle": [576, 512, [], "f738", "M316 540l-56 0 0-88 56 0 0 88zm-96-32l-56 0 0-88 56 0 0 88zm192 0l-56 0 0-88 56 0 0 88zM288-32c82.7 0 151.9 57 170.8 133.8 67.6 18.7 117.2 80.6 117.2 154.2 0 77.4-55 142-128 156.8l0-156.8-128 0 0 32-64 0 0-32-128 0 0 156.8c-73-14.8-128-79.4-128-156.8 0-8.6 .7-17 2-25.2 .7-4.2 1.5-8.3 2.5-12.3 13.5-56.2 56.7-100.8 112-116.4 13.8-3.9 28.4-6 43.5-6 40.6 0 77.7 15.1 105.8 40 10.6-12 21.2-24 31.7-36-36.6-32.3-84.9-52-137.6-52-6.8 0-13.5 .3-20.2 1 31.3-48.7 86-81 148.2-81zm28 356l0 88-56 0 0-88 56 0zm-96 56l-56 0 0-88 56 0 0 88zm192-88l0 88-56 0 0-88 56 0z"],
    "ship": [640, 512, [128674], "f21a", "M64 384c0 35.3 28.7 64 64 64s64-28.7 64-64l64 0c0 35.3 28.7 64 64 64s64-28.7 64-64l64 0c0 35.3 28.7 64 64 64s64-28.7 64-64l64 0c0 70.7-57.3 128-128 128-38.2 0-72.5-16.8-96-43.4-23.5 26.6-57.8 43.4-96 43.4s-72.5-16.8-96-43.4C200.5 495.2 166.2 512 128 512 57.3 512 0 454.7 0 384l64 0zM448 0c35.3 0 64 28.7 64 64l0 125.8c19.5 11.3 32 32.2 32 55.4l0 20.8c0 18.7-3.3 36.9-9.4 54L500 320c-5.5 11.8-12.7 22.7-21.5 32.3l-134.6-32.3 0-185.9 104 33.5 0-103.6-256 0 0 103.6 104-33.5 0 185.9-134.6 32.3c-8.8-9.6-16-20.5-21.5-32.3l-34.6 0c-6.1-17.1-9.4-35.3-9.4-54l0-20.8c0-23.2 12.5-44.1 32-55.4L128 64c0-35.3 28.7-64 64-64L448 0z"],
    "arrows-rotate": [512, 512, [128472, "refresh", "sync"], "f021", "M256 64c56.8 0 107.9 24.7 143.1 64l-79.1 0 0 64 160 0c17.7 0 32-14.3 32-32l0-160-64 0 0 86.7C401.1 33.5 332.5 0 256 0 114.6 0 0 114.6 0 256l64 0C64 150 150 64 256 64zm0 384c-56.8 0-107.9-24.7-143.1-64l79.1 0 0-64-160 0c-17.7 0-32 14.3-32 32l0 160 64 0 0-86.7c46.9 53.1 115.5 86.7 192 86.7 141.4 0 256-114.6 256-256l-64 0c0 106-86 192-192 192z"],
    "quotes": [512, 512, [], "e234", "M0 160C0 89.3 57.3 32 128 32l32 0 0 64-32 0c-35.3 0-64 28.7-64 64l0 64 96 0c35.3 0 64 28.7 64 64l0 96c0 35.3-28.7 64-64 64l-96 0c-35.3 0-64-28.7-64-64L0 160zm352 64l96 0c35.3 0 64 28.7 64 64l0 96c0 35.3-28.7 64-64 64l-96 0c-35.3 0-64-28.7-64-64l0-224c0-70.7 57.3-128 128-128l32 0 0 64-32 0c-35.3 0-64 28.7-64 64l0 64z"],
    "book-open": [576, 512, [128214, 128366], "f518", "M320 496.8c48.7-30.8 117.5-45.2 193.3-48.2 34-1.3 62.7-28.9 62.7-64.6l0-352-32 0c-76.7 0-157.6 9.8-224 40.3l0 424.5zM256 72.3C189.6 41.8 108.7 32 32 32L0 32 0 384c0 35.7 28.7 63.3 62.7 64.6 75.8 3 144.5 17.5 193.3 48.2l0-424.5z"],
    "box-archive": [512, 512, ["archive"], "f187", "M448 64l0 64-384 0 0-64 384 0zM0 128c0 23.7 12.9 44.4 32 55.4L32 448c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-264.6c19.1-11.1 32-31.7 32-55.4l0-64c0-35.3-28.7-64-64-64L64 0C28.7 0 0 28.7 0 64l0 64zM352 264l0 48-192 0 0-48 192 0z"],
    "list-ul": [512, 512, ["list-dots"], "f0ca", "M48 144a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm432-16l32 0 0-64-352 0 0 64 320 0zm0 320l32 0 0-64-352 0 0 64 320 0zm32-160l0-64-352 0 0 64 352 0zM96 256a48 48 0 1 0 -96 0 48 48 0 1 0 96 0zM48 464a48 48 0 1 0 0-96 48 48 0 1 0 0 96z"],
    "money-bill": [576, 512, [], "f0d6", "M0 96C0 60.7 28.7 32 64 32l448 0c35.3 0 64 28.7 64 64l0 320c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64L0 96zM288 344a88 88 0 1 0 0-176 88 88 0 1 0 0 176z"],
    "arrow-pointer": [512, 512, ["mouse-pointer"], "f245", "M59 17.8L483.3 167.1c17.4 6.1 29 22.5 29 41 0 18.1-11.2 34.3-28.2 40.7l-171 64.1-64.1 171c-6.4 16.9-22.6 28.2-40.7 28.2-18.4 0-34.9-11.6-41-29L18.2 58.6-4-4.3 59 17.8z"],
    "cake-candles": [512, 512, [127874, "birthday-cake", "cake"], "f1fd", "M96-32L60.7 9.2C52.5 18.8 48 30.9 48 43.4L48 48c0 14.2 6.2 27 16 35.8L64 160c-35.3 0-64 28.7-64 64l0 38.1 47 47C64.3 326.3 87.6 336 112 336s47.7-9.7 65-26.9l7.4-7.4c19-19 44.7-29.7 71.6-29.7s52.6 10.7 71.6 29.7l7.4 7.4c17.2 17.2 40.6 26.9 65 26.9s47.7-9.7 65-26.9l47-47 0-38.1c0-35.3-28.7-64-64-64l0-76.2c9.8-8.8 16-21.6 16-35.8l0-4.6c0-12.5-4.5-24.7-12.7-34.2L416-32 380.7 9.2C372.5 18.8 368 30.9 368 43.4l0 4.6c0 14.2 6.2 27 16 35.8l0 76.2-96 0 0-76.2c9.8-8.8 16-21.6 16-35.8l0-4.6c0-12.5-4.5-24.7-12.7-34.2L256-32 220.7 9.2C212.5 18.8 208 30.9 208 43.4l0 4.6c0 14.2 6.2 27 16 35.8l0 76.2-96 0 0-76.2c9.8-8.8 16-21.6 16-35.8l0-4.6c0-12.5-4.5-24.7-12.7-34.2L96-32zM512 329.9L498.9 343c-26.2 26.2-61.8 41-98.9 41s-72.7-14.7-98.9-41l-7.4-7.4c-10-10-23.5-15.6-37.7-15.6s-27.7 5.6-37.7 15.6l-7.4 7.4c-26.2 26.2-61.8 41-98.9 41s-72.7-14.7-98.9-41L0 329.9 0 448c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-118.1z"],
    "bug-slash": [640, 512, [], "e490", "M621.5 512L576.3 557.3 19 0 64.3-45.2 621.5 512zM411.7 483.2c-25.9 18.1-57.4 28.8-91.5 28.8-52.3 0-98.8-25.1-128-64l-96 0 0-64 67.2 0c-2.1-10.3-3.2-21-3.2-32l0-32-64 0 0-64 64 0 0-24.2 251.5 251.5zM474.9 17.8L433.8 79.3c13.8 13.9 25.1 30.4 33.1 48.7l77.3 0 0 64-64 0 0 64 64 0 0 64-24.2 0-271.2-271.2c21.5-10.7 45.8-16.8 71.4-16.8 21.3 0 41.7 4.2 60.3 11.8l41.1-61.5 53.2 35.5z"],
    "circle-info": [512, 512, ["info-circle"], "f05a", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM200 232l0 48 32 0 0 56-32 0 0 48 112 0 0-48-32 0 0-104-80 0zm56-112a40 40 0 1 0 0 80 40 40 0 1 0 0-80z"],
    "feather": [512, 512, [129718], "f52d", "M200 278.1l-57 57 33.9 33.9 57-57 247.8 0c-7.4 11.6-16.1 22.4-25.9 32.2L352 448 109.3 448 54.6 502.6 9.4 457.4 64 402.7 64 160 167.8 56.2c9.9-9.9 20.7-18.5 32.2-25.9l0 247.8zM248 8.2C265.8 2.8 284.5 0 303.5 0L320 0C426 0 512 86 512 192l0 16.5c0 19-2.8 37.7-8.2 55.5l-221.9 0 87-87-33.9-33.9-87 87 0-221.9z"],
    "phone-arrow-down-left": [512, 512, ["phone-arrow-down", "phone-incoming"], "e223", "M83 29.3c25-25 65.5-25 90.5 0L227 82.7c25 25 25 65.5 0 90.5l-49.4 49.4c-.8 .8-1.1 2-.8 3.2 14.6 53.4 56.3 95.1 109.7 109.7 1.1 .3 2.3 0 3.2-.8L339 285.3c25-25 65.5-25 90.5 0L483 338.7c25 25 25 65.5 0 90.5l-26.9 26.9c-45 45-109.6 64.7-172 52.8-141.9-27-253.8-138.9-280.8-280.8-11.9-62.4 7.8-127 52.8-172L83 29.3zM519.5 32l-19.8 19.8-112.2 112.2 88.4 0 0 56-156 0c-7.4 0-14.6-2.9-19.8-8.2S292 199.4 292 192l0-156 56 0 0 88.4 112.2-112.2 19.8-19.8 39.6 39.6z"],
    "wind": [512, 512, [], "f72e", "M192 0l0 64 32 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-224 0 0 64 224 0c53 0 96-43 96-96S277 0 224 0L192 0zm64 512l32 0c53 0 96-43 96-96s-43-96-96-96l-288 0 0 64 288 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-32 0 0 64zM416 96l-32 0 0 64 32 0c17.7 0 32 14.3 32 32s-14.3 32-32 32l-416 0 0 64 416 0c53 0 96-43 96-96s-43-96-96-96z"],
    "layer-group": [576, 512, [], "f5fd", "M555.4 414.3l-28.6 14.3-209.7 104.8c-18 9-39.2 9-57.2 0l-209.7-104.8-28.6-14.3 28.6-57.2 28.6 14.3 209.7 104.8 238.3-119.2 28.6 57.2zm0-128L317.1 405.5c-18 9-39.2 9-57.2 0l-238.3-119.2 28.6-57.2 238.3 119.2 238.3-119.2 28.6 57.2zM259.8-21.5c18-9 39.2-9 57.2 0l227.4 113.7 0 71.6-227.4 113.7c-18 9-39.2 9-57.2 0L32.5 163.8 32.5 92.2 259.8-21.5z"],
    "shield": [448, 512, [128737, "shield-blank"], "f132", "M234.1 1.6L404.2 58.3C430.4 67 448 91.5 448 119l0 146.3c0 84.8-47.9 162.4-123.8 200.3L224 515.8 123.8 465.7C47.9 427.7 0 350.2 0 265.3L0 119C0 91.5 17.6 67 43.8 58.3L213.9 1.6 224-1.7 234.1 1.6z"],
    "face-laugh": [512, 512, ["laugh"], "f599", "M256 512a256 256 0 1 0 0-512 256 256 0 1 0 0 512zM176 176a32 32 0 1 1 0 64 32 32 0 1 1 0-64zm128 32a32 32 0 1 1 64 0 32 32 0 1 1 -64 0zM256 416c-54.1 0-102.7-28.1-128-69.8l0-26.2 256 0 0 26.2C358.7 387.9 310.1 416 256 416z"],
    "cart-shopping": [640, 512, [128722, "shopping-cart"], "f07a", "M32 0L0 0 0 64 69.8 64 118.3 306.8c9 44.9 48.4 77.2 94.1 77.2L430 384c44.1 0 82.5-30 93.1-72.7l41.9-167.8C575.2 103.1 544.7 64 503 64L135 64c-5.5-27.6-9.8-48.9-12.8-64L32 0zM208 512a48 48 0 1 0 0-96 48 48 0 1 0 0 96zm272-48a48 48 0 1 0 -96 0 48 48 0 1 0 96 0z"],
    "arrow-up-arrow-down": [576, 512, ["sort-up-down"], "e099", "M438.9 470.6C515.1 394.4 554.7 354.9 557.5 352l-45.3-45.3c-12 12-33.3 33.3-64 64l0-338.7-64 0 0 338.7-64-64-45.3 45.3c2.9 2.9 42.4 42.4 118.6 118.6 6 6 14.1 9.4 22.6 9.4s16.6-3.4 22.6-9.4zM182.9 41.4C170.4 28.9 150.1 28.9 137.6 41.4 61.4 117.6 21.9 157.1 19 160l45.3 45.3c12-12 33.3-33.3 64-64l0 338.7 64 0 0-338.7c30.7 30.7 52 52 64 64L301.5 160c-2.9-2.9-42.4-42.4-118.6-118.6z"]
  };

  bunker(function () {
    defineIcons('faufsb', icons);
  });

}());
