/*!
 * Font Awesome Pro 7.3.0 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license (Commercial License)
 * Copyright 2026 Fonticons, Inc.
 */
(function () {
  'use strict';

  var _WINDOW = {};
  var _DOCUMENT = {};
  try {
    if (typeof window !== 'undefined') _WINDOW = window;
    if (typeof document !== 'undefined') _DOCUMENT = document;
  } catch (e) {} // eslint-disable-line no-empty

  var _ref = _WINDOW.navigator || {},
    _ref$userAgent = _ref.userAgent,
    userAgent = _ref$userAgent === void 0 ? '' : _ref$userAgent;
  var WINDOW = _WINDOW;
  var DOCUMENT = _DOCUMENT;
  var IS_BROWSER = !!WINDOW.document;
  var IS_DOM = !!DOCUMENT.documentElement && !!DOCUMENT.head && typeof DOCUMENT.addEventListener === 'function' && typeof DOCUMENT.createElement === 'function';
  var IS_IE = ~userAgent.indexOf('MSIE') || ~userAgent.indexOf('Trident/');

  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _arrayWithoutHoles(r) {
    if (Array.isArray(r)) return _arrayLikeToArray(r);
  }
  function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[r] = t, e;
  }
  function _iterableToArray(r) {
    if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
  }
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function (r) {
        return Object.getOwnPropertyDescriptor(e, r).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
        _defineProperty(e, r, t[r]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
        Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
      });
    }
    return e;
  }
  function _toConsumableArray(r) {
    return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }

  var _cl;
  var rl = {
      classic: {
        fa: "solid",
        fas: "solid",
        "fa-solid": "solid",
        far: "regular",
        "fa-regular": "regular",
        fal: "light",
        "fa-light": "light",
        fat: "thin",
        "fa-thin": "thin",
        fab: "brands",
        "fa-brands": "brands"
      },
      duotone: {
        fa: "solid",
        fad: "solid",
        "fa-solid": "solid",
        "fa-duotone": "solid",
        fadr: "regular",
        "fa-regular": "regular",
        fadl: "light",
        "fa-light": "light",
        fadt: "thin",
        "fa-thin": "thin"
      },
      sharp: {
        fa: "solid",
        fass: "solid",
        "fa-solid": "solid",
        fasr: "regular",
        "fa-regular": "regular",
        fasl: "light",
        "fa-light": "light",
        fast: "thin",
        "fa-thin": "thin"
      },
      "sharp-duotone": {
        fa: "solid",
        fasds: "solid",
        "fa-solid": "solid",
        fasdr: "regular",
        "fa-regular": "regular",
        fasdl: "light",
        "fa-light": "light",
        fasdt: "thin",
        "fa-thin": "thin"
      },
      slab: {
        "fa-regular": "regular",
        faslr: "regular"
      },
      "slab-press": {
        "fa-regular": "regular",
        faslpr: "regular"
      },
      "slab-duo": {
        "fa-regular": "regular",
        fasldr: "regular"
      },
      "slab-press-duo": {
        "fa-regular": "regular",
        faslpdr: "regular"
      },
      thumbprint: {
        "fa-light": "light",
        fatl: "light"
      },
      vellum: {
        "fa-solid": "solid",
        favs: "solid"
      },
      pixel: {
        "fa-regular": "regular",
        fapr: "regular"
      },
      mosaic: {
        "fa-solid": "solid",
        fams: "solid"
      },
      whiteboard: {
        "fa-semibold": "semibold",
        fawsb: "semibold"
      },
      notdog: {
        "fa-solid": "solid",
        fans: "solid"
      },
      "notdog-duo": {
        "fa-solid": "solid",
        fands: "solid"
      },
      etch: {
        "fa-solid": "solid",
        faes: "solid"
      },
      graphite: {
        "fa-thin": "thin",
        fagt: "thin"
      },
      jelly: {
        "fa-regular": "regular",
        fajr: "regular"
      },
      "jelly-fill": {
        "fa-regular": "regular",
        fajfr: "regular"
      },
      "jelly-duo": {
        "fa-regular": "regular",
        fajdr: "regular"
      },
      chisel: {
        "fa-regular": "regular",
        facr: "regular"
      },
      utility: {
        "fa-semibold": "semibold",
        fausb: "semibold"
      },
      "utility-duo": {
        "fa-semibold": "semibold",
        faudsb: "semibold"
      },
      "utility-fill": {
        "fa-semibold": "semibold",
        faufsb: "semibold"
      }
    };
  var u = "classic",
    l = "duotone",
    h = "sharp",
    t = "sharp-duotone",
    g = "chisel",
    n = "etch",
    m = "graphite",
    p = "jelly",
    s = "jelly-duo",
    y = "jelly-fill",
    w = "mosaic",
    x = "notdog",
    e = "notdog-duo",
    b = "pixel",
    c = "slab",
    o = "slab-duo",
    I = "slab-press",
    a = "slab-press-duo",
    r = "thumbprint",
    v = "utility",
    i = "utility-duo",
    F = "utility-fill",
    d = "vellum",
    S = "whiteboard",
    A = "Classic",
    P = "Duotone",
    j = "Sharp",
    B = "Sharp Duotone",
    N = "Chisel",
    D = "Etch",
    k = "Graphite",
    T = "Jelly",
    C = "Jelly Duo",
    W = "Jelly Fill",
    R = "Mosaic",
    K = "Notdog",
    L = "Notdog Duo",
    U = "Pixel",
    J = "Slab",
    _ = "Slab Duo",
    M = "Slab Press",
    E = "Slab Press Duo",
    G = "Thumbprint",
    V = "Utility",
    z = "Utility Duo",
    O = "Utility Fill",
    Y = "Vellum",
    q = "Whiteboard",
    cl = (_cl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, u, A), l, P), h, j), t, B), g, N), n, D), m, k), p, T), s, C), y, W), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, w, R), x, K), e, L), b, U), c, J), o, _), I, M), a, E), r, G), v, V), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, i, z), F, O), d, Y), S, q));
  var Al = {
      classic: {
        900: "fas",
        400: "far",
        normal: "far",
        300: "fal",
        100: "fat"
      },
      duotone: {
        900: "fad",
        400: "fadr",
        300: "fadl",
        100: "fadt"
      },
      sharp: {
        900: "fass",
        400: "fasr",
        300: "fasl",
        100: "fast"
      },
      "sharp-duotone": {
        900: "fasds",
        400: "fasdr",
        300: "fasdl",
        100: "fasdt"
      },
      slab: {
        400: "faslr"
      },
      "slab-press": {
        400: "faslpr"
      },
      "slab-duo": {
        400: "fasldr"
      },
      "slab-press-duo": {
        400: "faslpdr"
      },
      vellum: {
        900: "favs"
      },
      mosaic: {
        900: "fams"
      },
      pixel: {
        400: "fapr"
      },
      whiteboard: {
        600: "fawsb"
      },
      thumbprint: {
        300: "fatl"
      },
      notdog: {
        900: "fans"
      },
      "notdog-duo": {
        900: "fands"
      },
      etch: {
        900: "faes"
      },
      graphite: {
        100: "fagt"
      },
      chisel: {
        400: "facr"
      },
      jelly: {
        400: "fajr"
      },
      "jelly-fill": {
        400: "fajfr"
      },
      "jelly-duo": {
        400: "fajdr"
      },
      utility: {
        600: "fausb"
      },
      "utility-duo": {
        600: "faudsb"
      },
      "utility-fill": {
        600: "faufsb"
      }
    };
  var $l = {
      chisel: {
        regular: "facr"
      },
      classic: {
        brands: "fab",
        light: "fal",
        regular: "far",
        solid: "fas",
        thin: "fat"
      },
      duotone: {
        light: "fadl",
        regular: "fadr",
        solid: "fad",
        thin: "fadt"
      },
      etch: {
        solid: "faes"
      },
      graphite: {
        thin: "fagt"
      },
      jelly: {
        regular: "fajr"
      },
      "jelly-duo": {
        regular: "fajdr"
      },
      "jelly-fill": {
        regular: "fajfr"
      },
      mosaic: {
        solid: "fams"
      },
      notdog: {
        solid: "fans"
      },
      "notdog-duo": {
        solid: "fands"
      },
      pixel: {
        regular: "fapr"
      },
      sharp: {
        light: "fasl",
        regular: "fasr",
        solid: "fass",
        thin: "fast"
      },
      "sharp-duotone": {
        light: "fasdl",
        regular: "fasdr",
        solid: "fasds",
        thin: "fasdt"
      },
      slab: {
        regular: "faslr"
      },
      "slab-duo": {
        regular: "fasldr"
      },
      "slab-press": {
        regular: "faslpr"
      },
      "slab-press-duo": {
        regular: "faslpdr"
      },
      thumbprint: {
        light: "fatl"
      },
      utility: {
        semibold: "fausb"
      },
      "utility-duo": {
        semibold: "faudsb"
      },
      "utility-fill": {
        semibold: "faufsb"
      },
      vellum: {
        solid: "favs"
      },
      whiteboard: {
        semibold: "fawsb"
      }
    };
  var rt = {
      kit: {
        fak: "kit",
        "fa-kit": "kit"
      },
      "kit-duotone": {
        fakd: "kit-duotone",
        "fa-kit-duotone": "kit-duotone"
      }
    },
    it = ["kit"];
  var H = "kit",
    f = "kit-duotone",
    Q = "Kit",
    X = "Kit Duotone",
    ht = _defineProperty(_defineProperty({}, H, Q), f, X);
  var mt = {
    kit: {
      "fa-kit": "fak"
    },
    "kit-duotone": {
      "fa-kit-duotone": "fakd"
    }
  };
  var It = {
      kit: {
        fak: "fa-kit"
      },
      "kit-duotone": {
        fakd: "fa-kit-duotone"
      }
    };
  var St = {
      kit: {
        kit: "fak"
      },
      "kit-duotone": {
        "kit-duotone": "fakd"
      }
    };

  var _jl;
  var l$1 = {
      GROUP: "duotone-group",
      SWAP_OPACITY: "swap-opacity",
      PRIMARY: "primary",
      SECONDARY: "secondary"
    };
  var g$1 = "classic",
    a$1 = "duotone",
    m$1 = "sharp",
    t$1 = "sharp-duotone",
    p$1 = "chisel",
    y$1 = "etch",
    b$1 = "graphite",
    w$1 = "jelly",
    e$1 = "jelly-duo",
    x$1 = "jelly-fill",
    c$1 = "mosaic",
    I$1 = "notdog",
    o$1 = "notdog-duo",
    v$1 = "pixel",
    F$1 = "slab",
    r$1 = "slab-duo",
    S$1 = "slab-press",
    i$1 = "slab-press-duo",
    d$1 = "thumbprint",
    A$1 = "utility",
    f$1 = "utility-duo",
    P$1 = "utility-fill",
    u$1 = "vellum",
    j$1 = "whiteboard",
    B$1 = "Classic",
    N$1 = "Duotone",
    D$1 = "Sharp",
    k$1 = "Sharp Duotone",
    C$1 = "Chisel",
    T$1 = "Etch",
    L$1 = "Graphite",
    W$1 = "Jelly",
    R$1 = "Jelly Duo",
    K$1 = "Jelly Fill",
    U$1 = "Mosaic",
    J$1 = "Notdog",
    _$1 = "Notdog Duo",
    M$1 = "Pixel",
    E$1 = "Slab",
    G$1 = "Slab Duo",
    O$1 = "Slab Press",
    V$1 = "Slab Press Duo",
    z$1 = "Thumbprint",
    Y$1 = "Utility",
    $$1 = "Utility Duo",
    q$1 = "Utility Fill",
    H$1 = "Vellum",
    Q$1 = "Whiteboard",
    jl$1 = (_jl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, g$1, B$1), a$1, N$1), m$1, D$1), t$1, k$1), p$1, C$1), y$1, T$1), b$1, L$1), w$1, W$1), e$1, R$1), x$1, K$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, c$1, U$1), I$1, J$1), o$1, _$1), v$1, M$1), F$1, E$1), r$1, G$1), S$1, O$1), i$1, V$1), d$1, z$1), A$1, Y$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, f$1, $$1), P$1, q$1), u$1, H$1), j$1, Q$1));
  var X$1 = "kit",
    h$1 = "kit-duotone",
    Z$1 = "Kit",
    ll$1 = "Kit Duotone",
    ws = _defineProperty(_defineProperty({}, X$1, Z$1), h$1, ll$1);
  var ra = {
      classic: {
        "fa-brands": "fab",
        "fa-duotone": "fad",
        "fa-light": "fal",
        "fa-regular": "far",
        "fa-solid": "fas",
        "fa-thin": "fat"
      },
      duotone: {
        "fa-regular": "fadr",
        "fa-light": "fadl",
        "fa-thin": "fadt"
      },
      sharp: {
        "fa-solid": "fass",
        "fa-regular": "fasr",
        "fa-light": "fasl",
        "fa-thin": "fast"
      },
      "sharp-duotone": {
        "fa-solid": "fasds",
        "fa-regular": "fasdr",
        "fa-light": "fasdl",
        "fa-thin": "fasdt"
      },
      slab: {
        "fa-regular": "faslr"
      },
      "slab-press": {
        "fa-regular": "faslpr"
      },
      "slab-duo": {
        "fa-regular": "fasldr"
      },
      "slab-press-duo": {
        "fa-regular": "faslpdr"
      },
      pixel: {
        "fa-regular": "fapr"
      },
      mosaic: {
        "fa-solid": "fams"
      },
      vellum: {
        "fa-solid": "favs"
      },
      whiteboard: {
        "fa-semibold": "fawsb"
      },
      thumbprint: {
        "fa-light": "fatl"
      },
      notdog: {
        "fa-solid": "fans"
      },
      "notdog-duo": {
        "fa-solid": "fands"
      },
      etch: {
        "fa-solid": "faes"
      },
      graphite: {
        "fa-thin": "fagt"
      },
      jelly: {
        "fa-regular": "fajr"
      },
      "jelly-fill": {
        "fa-regular": "fajfr"
      },
      "jelly-duo": {
        "fa-regular": "fajdr"
      },
      chisel: {
        "fa-regular": "facr"
      },
      utility: {
        "fa-semibold": "fausb"
      },
      "utility-duo": {
        "fa-semibold": "faudsb"
      },
      "utility-fill": {
        "fa-semibold": "faufsb"
      }
    },
    al$1 = {
      classic: ["fas", "far", "fal", "fat", "fad"],
      duotone: ["fadr", "fadl", "fadt"],
      sharp: ["fass", "fasr", "fasl", "fast"],
      "sharp-duotone": ["fasds", "fasdr", "fasdl", "fasdt"],
      slab: ["faslr"],
      "slab-press": ["faslpr"],
      "slab-duo": ["fasldr"],
      "slab-press-duo": ["faslpdr"],
      pixel: ["fapr"],
      mosaic: ["fams"],
      vellum: ["favs"],
      whiteboard: ["fawsb"],
      thumbprint: ["fatl"],
      notdog: ["fans"],
      "notdog-duo": ["fands"],
      etch: ["faes"],
      graphite: ["fagt"],
      jelly: ["fajr"],
      "jelly-fill": ["fajfr"],
      "jelly-duo": ["fajdr"],
      chisel: ["facr"],
      utility: ["fausb"],
      "utility-duo": ["faudsb"],
      "utility-fill": ["faufsb"]
    },
    da = {
      classic: {
        fab: "fa-brands",
        fad: "fa-duotone",
        fal: "fa-light",
        far: "fa-regular",
        fas: "fa-solid",
        fat: "fa-thin"
      },
      duotone: {
        fadr: "fa-regular",
        fadl: "fa-light",
        fadt: "fa-thin"
      },
      sharp: {
        fass: "fa-solid",
        fasr: "fa-regular",
        fasl: "fa-light",
        fast: "fa-thin"
      },
      "sharp-duotone": {
        fasds: "fa-solid",
        fasdr: "fa-regular",
        fasdl: "fa-light",
        fasdt: "fa-thin"
      },
      slab: {
        faslr: "fa-regular"
      },
      "slab-press": {
        faslpr: "fa-regular"
      },
      "slab-duo": {
        fasldr: "fa-regular"
      },
      "slab-press-duo": {
        faslpdr: "fa-regular"
      },
      pixel: {
        fapr: "fa-regular"
      },
      mosaic: {
        fams: "fa-solid"
      },
      vellum: {
        favs: "fa-solid"
      },
      whiteboard: {
        fawsb: "fa-semibold"
      },
      thumbprint: {
        fatl: "fa-light"
      },
      notdog: {
        fans: "fa-solid"
      },
      "notdog-duo": {
        fands: "fa-solid"
      },
      etch: {
        faes: "fa-solid"
      },
      graphite: {
        fagt: "fa-thin"
      },
      jelly: {
        fajr: "fa-regular"
      },
      "jelly-fill": {
        fajfr: "fa-regular"
      },
      "jelly-duo": {
        fajdr: "fa-regular"
      },
      chisel: {
        facr: "fa-regular"
      },
      utility: {
        fausb: "fa-semibold"
      },
      "utility-duo": {
        faudsb: "fa-semibold"
      },
      "utility-fill": {
        faufsb: "fa-semibold"
      }
    },
    el$1 = ["solid", "regular", "light", "thin", "duotone", "brands", "semibold"],
    sl$1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    ol$1 = sl$1.concat([11, 12, 13, 14, 15, 16, 17, 18, 19, 20]),
    rl$1 = ["aw", "fw", "pull-left", "pull-right"],
    ga = [].concat(_toConsumableArray(Object.keys(al$1)), el$1, rl$1, ["2xs", "xs", "sm", "lg", "xl", "2xl", "beat", "beat-fade", "border", "bounce", "buzz", "canvas-square", "canvas-roomy", "fade", "flip-360", "flip-both", "flip-horizontal", "flip-vertical", "flip", "float", "inverse", "jello", "layers", "layers-bottom-left", "layers-bottom-right", "layers-counter", "layers-text", "layers-top-left", "layers-top-right", "li", "pull-end", "pull-start", "pulse", "rotate-180", "rotate-270", "rotate-90", "rotate-by", "shake", "spin-pulse", "spin-reverse", "spin", "spin-snap", "spin-snap-4", "spin-snap-8", "stack-1x", "stack-2x", "stack", "swing", "ul", "wag", "width-auto", "width-fixed", l$1.GROUP, l$1.SWAP_OPACITY, l$1.PRIMARY, l$1.SECONDARY]).concat(sl$1.map(function (s) {
      return "".concat(s, "x");
    })).concat(ol$1.map(function (s) {
      return "w-".concat(s);
    }));

  var NAMESPACE_IDENTIFIER = '___FONT_AWESOME___';
  var PRODUCTION = function () {
    try {
      return "production" === 'production';
    } catch (e$$1) {
      return false;
    }
  }();
  function familyProxy(obj) {
    // Defaults to the classic family if family is not available
    return new Proxy(obj, {
      get: function get(target, prop) {
        return prop in target ? target[prop] : target[u];
      }
    });
  }
  var _PREFIX_TO_STYLE = _objectSpread2({}, rl);

  // We changed FACSSClassesToStyleId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _PREFIX_TO_STYLE below, so we are manually adding
  // {'fa-duotone': 'duotone'}
  _PREFIX_TO_STYLE[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    'fa-duotone': 'duotone'
  }), rl[u]), rt['kit']), rt['kit-duotone']);
  var PREFIX_TO_STYLE = familyProxy(_PREFIX_TO_STYLE);
  var _STYLE_TO_PREFIX = _objectSpread2({}, $l);

  // We changed FAStyleIdToShortPrefixId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _STYLE_TO_PREFIX below, so we are manually adding {duotone: 'fad'}
  _STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    duotone: 'fad'
  }), _STYLE_TO_PREFIX[u]), St['kit']), St['kit-duotone']);
  var STYLE_TO_PREFIX = familyProxy(_STYLE_TO_PREFIX);
  var _PREFIX_TO_LONG_STYLE = _objectSpread2({}, da);
  _PREFIX_TO_LONG_STYLE[u] = _objectSpread2(_objectSpread2({}, _PREFIX_TO_LONG_STYLE[u]), It['kit']);
  var PREFIX_TO_LONG_STYLE = familyProxy(_PREFIX_TO_LONG_STYLE);
  var _LONG_STYLE_TO_PREFIX = _objectSpread2({}, ra);
  _LONG_STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2({}, _LONG_STYLE_TO_PREFIX[u]), mt['kit']);
  var LONG_STYLE_TO_PREFIX = familyProxy(_LONG_STYLE_TO_PREFIX);
  var _FONT_WEIGHT_TO_PREFIX = _objectSpread2({}, Al);
  var FONT_WEIGHT_TO_PREFIX = familyProxy(_FONT_WEIGHT_TO_PREFIX);
  var RESERVED_CLASSES = [].concat(_toConsumableArray(it), _toConsumableArray(ga));

  function bunker(fn) {
    try {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      fn.apply(void 0, args);
    } catch (e) {
      if (!PRODUCTION) {
        throw e;
      }
    }
  }

  var w$2 = WINDOW || {};
  if (!w$2[NAMESPACE_IDENTIFIER]) w$2[NAMESPACE_IDENTIFIER] = {};
  if (!w$2[NAMESPACE_IDENTIFIER].styles) w$2[NAMESPACE_IDENTIFIER].styles = {};
  if (!w$2[NAMESPACE_IDENTIFIER].hooks) w$2[NAMESPACE_IDENTIFIER].hooks = {};
  if (!w$2[NAMESPACE_IDENTIFIER].shims) w$2[NAMESPACE_IDENTIFIER].shims = [];
  var namespace = w$2[NAMESPACE_IDENTIFIER];

  function normalizeIcons(icons) {
    return Object.keys(icons).reduce(function (acc, iconName) {
      var icon = icons[iconName];
      var expanded = !!icon.icon;
      if (expanded) {
        acc[icon.iconName] = icon.icon;
      } else {
        acc[iconName] = icon;
      }
      return acc;
    }, {});
  }
  function defineIcons(prefix, icons) {
    var params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var _params$skipHooks = params.skipHooks,
      skipHooks = _params$skipHooks === void 0 ? false : _params$skipHooks;
    var normalized = normalizeIcons(icons);
    if (typeof namespace.hooks.addPack === 'function' && !skipHooks) {
      namespace.hooks.addPack(prefix, normalizeIcons(icons));
    } else {
      namespace.styles[prefix] = _objectSpread2(_objectSpread2({}, namespace.styles[prefix] || {}), normalized);
    }

    /**
     * Font Awesome 4 used the prefix of `fa` for all icons. With the introduction
     * of new styles we needed to differentiate between them. Prefix `fa` is now an alias
     * for `fas` so we'll ease the upgrade process for our users by automatically defining
     * this as well.
     */
    if (prefix === 'fas') {
      defineIcons('fa', icons);
    }
  }

  var icons = {
    "question": [352, 512, [10067, 10068, 61736], "3f", "M176 0C78.8 0 0 78.8 0 176l128 0c0-26.5 21.5-48 48-48s48 21.5 48 48-21.5 48-48 48l-48 0 0 128 48 0c97.2 0 176-78.8 176-176S273.2 0 176 0zm0 272c53 0 96-43 96-96l32 0c0 70.7-57.3 128-128 128l0-32zm0 112c-35.3 0-64 28.7-64 64s28.7 64 64 64 64-28.7 64-64-28.7-64-64-64z"],
    "minus": [448, 512, [8211, 8722, 10134, "subtract"], "f068", "M0 192l0 128 448 0 0-128-448 0zm48 80l0-32 176 0 0 32-176 0z"],
    "microphone-slash": [512, 512, [], "f131", "M256.3 0c-46.3 0-86 28.1-103.1 68.1l43.9 43.9 171.1 0c0-61.9-50.1-112-112-112zM44.1 4.2l-39.6 39.6 464 464 39.6-39.6-464-464zM229.2 144L362.1 276.9c4-11.6 6.2-24 6.2-36.9l0-96-139.1 0zm203.1 0a32 32 0 1 0 0 64 32 32 0 1 0 0-64zM63.9 148.5c-9.4 5.6-15.6 15.8-15.6 27.5 0 17.7 14.3 32 32 32 11.7 0 21.9-6.3 27.5-15.6L63.9 148.5zm80.4 80.4l0 11.1c0 61.9 50.1 112 112 112 3.6 0 7.1-.2 10.6-.5L144.3 228.9zM48.3 240c0 93.3 61.4 172.3 146.1 198.6-20.8 17.6-34.1 43.9-34.1 73.4l192 0c0-29.4-13.2-55.8-34.1-73.4 8.9-2.8 17.5-6.1 25.9-10l-49.7-49.7c-12.1 3.3-24.9 5.1-38.1 5.1-79.5 0-144-64.5-144-144l-64 0zm352 0c0 22-4.9 42.8-13.7 61.4l47.2 47.2c19.4-31.6 30.6-68.8 30.6-108.6l-64 0z"],
    "car": [512, 512, [128664, "automobile"], "f1b9", "M0 64l0 64 48 0 0 48 128 0 0 32-128 0 0 48 128 0 0 32-176 0 0 112 40.4 0c-.3 2.6-.4 5.3-.4 8 0 39.8 32.2 72 72 72s72-32.2 72-72c0-2.7-.1-5.4-.4-8l144.9 0c-.3 2.6-.4 5.3-.4 8 0 39.8 32.2 72 72 72s72-32.2 72-72c0-2.7-.1-5.4-.4-8l40.4 0 0-112-85.6 0-16.4-139.2C404.3 100.4 363.3 64 314.6 64L0 64zm224 64l0-16 90.6 0c24.3 0 44.8 18.2 47.7 42.4l15.7 133.6-154 0 0-160zM136 408a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm288 0a24 24 0 1 1 -48 0 24 24 0 1 1 48 0z"],
    "filter": [448, 512, [], "f0b0", "M0 32l0 48 448 0 0-48-448 0zm0 80l0 32 160 160 0 144 128 64 0-208 160-160 0-32-448 0z"],
    "envelope": [512, 512, [128386, 9993, 61443], "f0e0", "M0 64l0 384 512 0 0-384-512 0zM256 320L48 112 464 112 256 320z"],
    "at": [512, 512, [61946], "40", "M256 0C114.6 0 0 114.6 0 256l0 16C0 395.7 100.3 496 224 496l112 0 0-64-112 0c-88.4 0-160-71.6-160-160l0-16C64 150 150 64 256 64l10.7 0C366.8 64 448 145.2 448 245.3l0 10.7c0 35.3-28.7 64-64 64l-16.7 0-54.9-208-109.1 0-61.6 272 65.6 0 10.9-48 87.1 0 12.7 48 66 0c70.7 0 128-57.3 128-128l0-10.7C512 109.8 402.2 0 266.7 0L256 0zM232.7 272l25.7-113.6 30 113.6-55.8 0zM416 416l-48 48 48 48 48-48-48-48z"],
    "truck": [512, 512, [128666, 9951], "f0d1", "M0 32l0 144 288 0 0 32-288 0 0 48 288 0 0 32-288 0 0 112 40.4 0c-.3 2.6-.4 5.3-.4 8 0 39.8 32.2 72 72 72s72-32.2 72-72c0-2.7-.1-5.4-.4-8l144.9 0c-.3 2.6-.4 5.3-.4 8 0 39.8 32.2 72 72 72s72-32.2 72-72c0-2.7-.1-5.4-.4-8l40.4 0 0-112-32 0 0-112 32 0 0-64-176 0 0-16c0-35.3-28.7-64-64-64L0 32zM368 288l0-112 64 0 0 112-64 0zM136 408a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm288 0a24 24 0 1 1 -48 0 24 24 0 1 1 48 0z"],
    "bell": [448, 512, [128276, 61602], "f0f3", "M224 0c-22.1 0-40 17.9-40 40 0 2.8 .3 5.6 .8 8.2-67.4 3.7-120.8 59.5-120.8 127.8l0 112 56 0 0-104 32 0 0 104 232 0 0-112c0-68.3-53.5-124.1-120.8-127.8 .6-2.6 .8-5.4 .8-8.2 0-22.1-17.9-40-40-40zM64 320c-35.3 0-64 28.7-64 64l0 32 448 0 0-32c0-35.3-28.7-64-64-64L64 320zm160 96l-48 48 48 48 48-48-48-48z"],
    "mobile": [416, 512, [128241, "mobile-android", "mobile-phone"], "f3ce", "M32 0l0 80-32 0 0 80 32 0 0 32-32 0 0 80 32 0 0 192c0 26.5 21.5 48 48 48l256 0c26.5 0 48-21.5 48-48l0-304 32 0 0-80-32 0 0-80-352 0zM80 80l0-32 256 0 0 336-256 0 0-304zm32 0l0 272 192 0 0-272-192 0zm16 384l0-32 160 0 0 32-160 0z"],
    "trophy": [512, 512, [127942], "f091", "M112 32l0 32C50.1 64 0 114.1 0 176S50.1 288 112 288l.9 0c6.8 61.3 52.1 111 111.1 124.4l0 51.6-48 0c-26.5 0-48 21.5-48 48l256 0c0-26.5-21.5-48-48-48l-48 0 0-51.6C347.1 399 392.3 349.3 399.1 288l.9 0c61.9 0 112-50.1 112-112S461.9 64 400 64l0-32-288 0zM48 176c0-35.3 28.7-64 64-64l288 0c35.3 0 64 28.7 64 64s-28.7 64-64 64l0-96-288 0 0 96c-35.3 0-64-28.7-64-64zm144 80l64-64 64 64-64 64-64-64z"],
    "gift": [512, 512, [127873], "f06b", "M192 16c-48.6 0-88 39.4-88 88 0 14.4 3.5 28 9.6 40l-113.6 0 0 64 512 0 0-64-113.6 0c6.1-12 9.6-25.6 9.6-40 0-48.6-39.4-88-88-88-25.2 0-48 10.6-64 27.6-16-17-38.8-27.6-64-27.6zm-40 88c0-22.1 17.9-40 40-40s40 17.9 40 40l0 40-40 0c-22.1 0-40-17.9-40-40zm128 0c0-22.1 17.9-40 40-40s40 17.9 40 40-17.9 40-40 40l-40 0 0-40zM32 240l0 176c0 35.3 28.7 64 64 64l104 0 0-240-8 0c-26.5 0-48 21.5-48 48l-32 0c0-18 6-34.6 16-48l-96 0zm200 0l0 240 48 0 0-240-48 0zm80 0l0 240 104 0c35.3 0 64-28.7 64-64l0-176-96 0c10 13.4 16 30 16 48l-32 0c0-26.5-21.5-48-48-48l-8 0z"],
    "gauge": [512, 512, ["dashboard", "gauge-med", "tachometer-alt-average"], "f624", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM240 210.7l0-146.7 32 0 0 146.7c18.6 6.6 32 24.4 32 45.3 0 26.5-21.5 48-48 48s-48-21.5-48-48c0-20.9 13.4-38.7 32-45.3zm-85.8-56.6a32 32 0 1 1 -45.3-45.3 32 32 0 1 1 45.3 45.3zm248.9 0a32 32 0 1 1 -45.3-45.3 32 32 0 1 1 45.3 45.3zM112 256a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm352 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM256 464c-80.2 0-149.9-45.4-184.6-112l369.1 0C405.9 418.6 336.2 464 256 464z"],
    "share-nodes": [512, 512, ["share-alt"], "f1e0", "M384 0c-61.9 0-112 50.1-112 112 0 7.5 .7 14.9 2.2 21.9l-82.3 43.6C171.6 156.8 143.3 144 112 144 50.1 144 0 194.1 0 256S50.1 368 112 368c31.3 0 59.6-12.8 79.9-33.5l82.3 43.6c-1.4 7.1-2.2 14.4-2.2 21.9 0 61.9 50.1 112 112 112s112-50.1 112-112-50.1-112-112-112c-31.3 0-59.6 12.8-79.9 33.5l-82.3-43.6c4-19.9 1.5-36.2 0-43.9l82.3-43.6c20.3 20.7 48.6 33.5 79.9 33.5 61.9 0 112-50.1 112-112S445.9 0 384 0zM328 112l56-56 56 56-56 56-56-56zM56 256l56-56 56 56-56 56-56-56zM328 400l56-56 56 56-56 56-56-56z"],
    "percent": [448, 512, [62101, 62785, "percentage"], "25", "M347 42.7l-336 336 90.5 90.5 336-336-90.5-90.5zM96.3 48a80 80 0 1 0 0 160 80 80 0 1 0 0-160zM212.9 244.7l136-136 22.6 22.6-136 136-136 136-22.6-22.6 136-136zM352.3 304a80 80 0 1 0 0 160 80 80 0 1 0 0-160z"],
    "magnifying-glass": [512, 512, [128269, "search"], "f002", "M192 0C86 0 0 86 0 192S86 384 192 384c44.4 0 85.2-15 117.7-40.3l25.3 25.3-28.3 28.3 96 96c25 25 65.5 25 90.5 0s25-65.5 0-90.5l-96-96-28.3 28.3-25.3-25.3C369 277.2 384 236.4 384 192 384 86 298 0 192 0zM336 192a144 144 0 1 1 -288 0 144 144 0 1 1 288 0zM192 80C130.1 80 80 130.1 80 192s50.1 112 112 112c35 0 66.3-16.1 86.8-41.2L208 192 278.8 121.2C258.3 96.1 227 80 192 80z"],
    "palette": [512, 512, [127912], "f53f", "M240 16C107.5 16 0 123.5 0 256l0 16 .5 0C8.7 405.9 120 512 256 512l48 0c26.5 0 48-21.5 48-48s-21.5-48-48-48-48-21.5-48-48 21.5-48 48-48l144 0c35.3 0 64-28.7 64-64l0-48c0-106-86-192-192-192l-80 0zm16 120a56 56 0 1 1 -112 0 56 56 0 1 1 112 0zm144-8a48 48 0 1 1 -96 0 48 48 0 1 1 96 0zM52.7 227.3l22.6-22.6 28.7 28.7 28.7-28.7 22.6 22.6-28.7 28.7 28.7 28.7-22.6 22.6-28.7-28.7-28.7 28.7-22.6-22.6 28.7-28.7-28.7-28.7zM176 376a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z"],
    "key": [512, 512, [128273], "f084", "M336 0c-97.2 0-176 78.8-176 176 0 17 2.4 33.5 6.9 49.1l-166.9 166.9 0 120 144 0 0-96 96 0 0-92.5c27.6 18 60.6 28.5 96 28.5 97.2 0 176-78.8 176-176S433.2 0 336 0zM256 176l80-80 80 80-80 80-80-80z"],
    "skull": [512, 512, [128128], "f54c", "M256 0c141.4 0 256 114.6 256 256 0 73.2-30.7 139.2-80 185.9l0 70.1-64 0 0-48-32 0 0 48-64 0 0-48-32 0 0 48-64 0 0-48-32 0 0 48-64 0 0-70.1C30.7 395.2 0 329.2 0 256 0 114.6 114.6 0 256 0zM168 206.1l-50.9-50.9-34 34 50.9 50.9-50.9 50.9 34 34 50.9-50.9 50.9 50.9 34-34-50.9-50.9 50.9-50.9-34-34-50.9 50.9zM368 176a64 64 0 1 0 0 128 64 64 0 1 0 0-128z"],
    "tree": [448, 512, [127794], "f1bb", "M224 0l-128 128 0 32 64 0-112 112 0 32 80 0-128 128 0 32 192 0 0 48 64 0 0-48 192 0 0-32-128-128 80 0 0-32-112-112 64 0 0-32-128-128zM192 128l0-48 32 0 0 48-32 0zm48 144l0-48 32 0 0 48-32 0zM176 416l0-48 32 0 0 48-32 0z"],
    "flower": [416, 512, [127804, 10047], "f7ff", "M128 0c-53 0-96 43-96 96 0 33.4 17 62.8 42.9 80-25.9 17.2-42.9 46.6-42.9 80 0 53 43 96 96 96 17.5 0 33.9-4.7 48-12.8l0 172.8 64 0 0-172.8c14.1 8.2 30.5 12.8 48 12.8 53 0 96-43 96-96 0-33.4-17-62.8-42.9-80 25.9-17.2 42.9-46.6 42.9-80 0-53-43-96-96-96-33.4 0-62.8 17-80 42.9-17.2-25.9-46.6-42.9-80-42.9zm0 176l80-80 80 80-80 80-80-80zM0 368l0 16c0 70.7 57.3 128 128 128l16 0 0-16c0-70.7-57.3-128-128-128L0 368zM272 496l0 16 16 0c70.7 0 128-57.3 128-128l0-16-16 0c-70.7 0-128 57.3-128 128z"],
    "camera": [512, 512, [62258, "camera-alt"], "f030", "M288 0L224 0c-35.3 0-64 28.7-64 64l0 32-32 0 0-32-96 0 0 32-32 0 0 96 512 0 0-96-160 0 0-32c0-35.3-28.7-64-64-64zM204.7 67.3l22.6-22.6 28.7 28.7 28.7-28.7 22.6 22.6-28.7 28.7 28.7 28.7-22.6 22.6-28.7-28.7-28.7 28.7-22.6-22.6 28.7-28.7-28.7-28.7zM0 224L0 400c0 44.2 35.8 80 80 80l352 0c44.2 0 80-35.8 80-80l0-176-177.6 0c20.7 20.3 33.6 48.7 33.6 80 0 61.9-50.1 112-112 112S144 365.9 144 304c0-31.3 12.9-59.7 33.6-80L0 224zm256 0a80 80 0 1 0 0 160 80 80 0 1 0 0-160z"],
    "eye": [512, 512, [128065], "f06e", "M228 4l0 61.9c-15.1 2-29.6 5.6-43.4 10.5l-30.4-52.6-48.5 28 14 24.2 14.5 25.1c-14 8.9-27.1 19-39.1 29.7l-19.1-11.1-24.2-14-28 48.5 24.2 14 7.1 4.1C28.5 204.4 9.9 236.1 0 256 26.7 309.3 115.2 448 256 448S485.3 309.3 512 256c-9.9-19.9-28.5-51.6-55.1-83.6l7.1-4.1 24.2-14-28-48.5-24.2 14-19.1 11.1c-12-10.7-25.1-20.8-39.1-29.7l14.5-25.1 14-24.2-48.5-28-30.4 52.6c-13.8-4.9-28.2-8.5-43.4-10.5L284 4 228 4zM400 256a144 144 0 1 1 -288 0 144 144 0 1 1 288 0zM256 144c-61.9 0-112 50.1-112 112s50.1 112 112 112c35 0 66.3-16.1 86.8-41.2L272 256 342.8 185.2C322.3 160.1 291 144 256 144z"],
    "trash": [384, 512, [], "f1f8", "M192 0C130.1 0 80 50.1 80 112l-80 0 0 48 384 0 0-48-80 0C304 50.1 253.9 0 192 0zM128 112c0-35.3 28.7-64 64-64s64 28.7 64 64l-128 0zM32 192l0 256c0 35.3 28.7 64 64 64l192 0c35.3 0 64-28.7 64-64l0-256-48 0-64 64-64-64-56 0 0 264-32 0 0-264-56 0z"],
    "equals": [448, 512, [62764], "3d", "M0 96l0 128 448 0 0-128-448 0zm48 80l0-32 176 0 0 32-176 0zM0 288l0 128 448 0 0-128-448 0zm48 80l0-32 176 0 0 32-176 0z"],
    "phone-rotary": [512, 512, [9742], "f8d3", "M87.1 64C49.3 97.4 21.5 141.7 8.5 192l119.9 0 0-48 256 0 0 48 119.9 0c-13-50.3-40.8-94.6-78.6-128L87.1 64zm73.3 112l0 48-32 0c-44.2 0-80 35.8-80 80l0 96 112 0 0-16c0-53 43-96 96-96s96 43 96 96l0 16 112 0 0-96c0-44.2-35.8-80-80-80l-32 0 0-48-48 0 0 48-96 0 0-48-48 0zm96 144l-56 56 56 56 56-56-56-56zM48.4 432l0 48 416 0 0-48-416 0z"],
    "expand": [448, 512, [], "f065", "M0 32l0 160 16 16 57.4-57.4 72 72 45.3-45.3-72-72 57.4-57.4-16-16-160 0zm288 0l-16 16 57.4 57.4-72 72 45.3 45.3 72-72 57.4 57.4 16-16 0-160-160 0zM145.4 289.4l-72 72-57.4-57.4-16 16 0 160 160 0 16-16-57.4-57.4 72-72-45.3-45.3zm157.3 0l-45.3 45.3 72 72-57.4 57.4 16 16 160 0 0-160-16-16-57.4 57.4-72-72z"],
    "stop": [352, 512, [9209], "f04d", "M0 80l352 0 0 352-352 0 0-352z"],
    "tv-retro": [512, 512, [128250], "f401", "M193-1L159 33 222.1 96 48 96C21.5 96 0 117.5 0 144L0 432c0 26.5 21.5 48 48 48l416 0c26.5 0 48-21.5 48-48l0-288c0-26.5-21.5-48-48-48L289.9 96 353 33 319-1 256 62.1 193-1zM48 176l0-32 304 0 0 288-304 0 0-256zm344 32l40-40 40 40-40 40-40-40zM80 176l0 224 240 0 0-224-240 0zM464 320a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z"],
    "angle-left": [224, 512, [8249], "f104", "M176 80l-176 176 176 176 32 0 0-352-32 0z"],
    "circle-half-stroke": [512, 512, [9680, "adjust"], "f042", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM464 256a208 208 0 1 1 -416 0 208 208 0 1 1 416 0zM256 80C158.8 80 80 158.8 80 256s78.8 176 176 176l0-352z"],
    "clock": [512, 512, [128339, "clock-four"], "f017", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM240 64l0-16 16 0c114.9 0 208 93.1 208 208S370.9 464 256 464 48 370.9 48 256c0-57.4 23.3-109.5 60.9-147.1l11.3-11.3 22.6 22.6-11.3 11.3c-28.3 28.3-47 66.2-50.8 108.5l31.3 0 0 32-31.3 0c7.6 84.4 74.8 151.7 159.3 159.3l0-31.3 32 0 0 31.3c84.4-7.6 151.7-74.8 159.3-159.3l-31.3 0 0-32 31.3 0C423.7 155.6 356.4 88.3 272 80.7l0 31.3-32 0 0-48zM148.7 171.3l22.6-22.6 76.4 76.4c2.6-.7 5.4-1.1 8.3-1.1 17.7 0 32 14.3 32 32s-14.3 32-32 32-32-14.3-32-32c0-2.9 .4-5.6 1.1-8.3l-76.4-76.4z"],
    "book": [416, 512, [128212], "f02d", "M64 0C28.7 0 0 28.7 0 64L0 448c0 35.3 28.7 64 64 64l352 0 0-48-352 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l352 0 0-432-352 0zm64 128l0-32 192 0 0 32-192 0zm16 144l80-80 80 80-80 80-80-80z"],
    "paper-plane": [512, 512, [61913], "f1d8", "M480 32L0 160 96 256 96 440.8 180.2 412.7 234.6 394.6 352 512 480 32zM367.7 120l36.4-12.1-10.8 32.3-217.3 187.2 0 40.7-32 10.7 0-66 5.6-4.8 218.1-187.8z"],
    "heart": [512, 512, [128153, 128154, 128155, 128156, 128420, 129293, 129294, 129505, 9829, 10084, 61578], "f004", "M42.2 74.2c-56.2 56.2-56.2 147.4 0 203.6L222.1 457.7 256 491.6 469.8 277.8c56.2-56.2 56.2-147.4 0-203.6-7-7-14.6-13.2-22.6-18.4-55.9-36.9-131.8-30.8-181 18.4 0 0 0 0 0 0L256 84.4 245.8 74.2c0 0 0 0 0 0-56.2-56.2-147.4-56.2-203.6 0zm33.9 33.9c37.5-37.5 98.3-37.5 135.8 0l10.2 10.2 33.9 33.9 33.9-33.9 10.2-10.2c37.5-37.5 98.3-37.5 135.8 0l-22.6 22.6c-25-25-65.5-25-90.5 0l-10.2 10.2-56.6 56.6-56.6-56.6-10.2-10.2c-25-25-65.5-25-90.5 0s-25 65.5 0 90.5L278.6 401.1 256 423.8 76.1 243.9c-37.5-37.5-37.5-98.3 0-135.8z"],
    "battery-half": [512, 512, ["battery-3"], "f242", "M432 416l-432 0 0-320 432 0 0 320zM208 368l176 0 0-224-176 0 0 224zm304-48l-48 0 0-128 48 0 0 128z"],
    "font-awesome": [512, 512, [62501, 62694, "font-awesome-flag", "font-awesome-logo-full"], "f2b4", "M72 0c26.5 0 48 21.5 48 48 0 12.3-4.7 23.5-12.3 32l404.3 0-80 160 80 160-416 0 0 112-48 0 0-422.5C33.7 81.2 24 65.8 24 48 24 21.5 45.5 0 72 0zM96 352l32 0 0-224-32 0 0 224z"],
    "clone": [512, 512, [], "f24d", "M176 0l0 336 336 0 0-336-336 0zm88 168l80-80 80 80-80 80-80-80zM0 176l0 336 336 0 0-144-64 0 0 80-208 0 0-208 80 0 0-64-144 0z"],
    "forward": [448, 512, [9193], "f04e", "M224 256l-176 176-32 0 0-352 32 0 176 176zM272 80l176 176-176 176-32 0 0-352 32 0z"],
    "triangle": [512, 512, [9650], "f2ec", "M256 16l-256 464 512 0-210.3-381.2 0 0-45.7-82.8zM81.3 432L256 115.4 274.3 148.5 117.8 432 81.3 432z"],
    "star-half": [544, 512, [61731], "f089", "M272 0l-99.4 145.6-168.6 49.9 107.2 139.9-4.8 176.5 165.6-59.2 0-310.9-33.3 48.8-16.1 23.5-27.3 8.1-57.1 16.9 36.5 47.6 17.2 22.5-.8 28.3-1.6 59.3-33.3 46 2.9-106.2 .5-17-10.3-13.5-64.8-84.5 101.7-30.1 16.4-4.9 9.6-14.1 59.7-87.5 0-85.2z"],
    "arrow-down-to-line": [384, 512, ["arrow-to-bottom"], "f33d", "M56 424l32 0 0-72 296 0 0 64c0 35.3-28.7 64-64 64L64 480c-35.3 0-64-28.7-64-64l0-64 56 0 0 72zM224 144l112 0 0 32-144 144-144-144 0-32 112 0 0-112 64 0 0 112z"],
    "fire": [448, 512, [128293], "f06d", "M288 0L184 176 104 80 28.7 209.3C9.9 241.6 0 278.3 0 315.7 0 424.1 87.9 512 196.3 512l57.7 0c107.1 0 194-86.9 194-194 0-38.8-10.8-76.9-31.3-109.9L288 0zM225.3 200.4l63.6-107.7 71.7 115.9-22.5 24.5-48.6-78.6-36.7 62.1-57.7 97.7-72.6-87.1-6.9-8.3-17.8 30.6c-11.7 20.1-17.9 42.9-17.9 66.1 0 23.9 7.2 46.2 19.6 64.7l-23 23c-18-24.6-28.7-54.9-28.7-87.7 0-28.9 7.7-57.3 22.2-82.3l40.8-70 36.1 43.4 43.6 52.3 34.6-58.6z"],
    "rectangle-vertical": [384, 512, ["rectangle-portrait"], "f2fb", "M384 512L0 512 0 0 384 0 384 512zM48 48l0 416 32 0 0-384 256 0 0-32-288 0z"],
    "print": [512, 512, [128424, 128438, 9113], "f02f", "M64 0l0 208 48 0 0-160 288 0 0 160 48 0 0-208-384 0zM0 240L0 400c0 26.5 21.5 48 48 48l16 0 0 64 384 0 0-64 16 0c26.5 0 48-21.5 48-48l0-160-512 0zm216 64l40-40 40 40-40 40-40-40zM112 464l0-96 288 0 0 96-288 0zm32-64l0 32 128 0 0-32-128 0zm160 0l0 32 64 0 0-32-64 0z"],
    "users": [512, 512, [], "f0c0", "M368 48c-17.7 0-32 14.3-32 32l0 16-32 0 0 40c0 39.8 32.2 72 72 72s72-32.2 72-72l0-88-80 0zM128 192c-17.7 0-32 14.3-32 32l0 16-32 0 0 40c0 39.8 32.2 72 72 72s72-32.2 72-72l0-88-80 0zm192 32c-44.2 0-80 35.8-80 80l0 16 272 0 0-16c0-44.2-35.8-80-80-80l0 56-56-56-56 56 0-56zM80 368c-44.2 0-80 35.8-80 80l0 16 272 0 0-16c0-44.2-35.8-80-80-80l0 56-56-56-56 56 0-56z"],
    "alarm-clock": [512, 512, [9200], "f34e", "M80 0C35.8 0 0 35.8 0 80 0 102.1 9 122.1 23.4 136.6L136.6 23.4C122.1 9 102.1 0 80 0zM432 0c-22.1 0-42.1 9-56.6 23.4L488.6 136.6C503 122.1 512 102.1 512 80 512 35.8 476.2 0 432 0zM256 32C132.3 32 32 132.3 32 256l0 224 448 0 0-224C480 132.3 379.7 32 256 32zM432 256a176 176 0 1 1 -352 0 176 176 0 1 1 352 0zM256 112a144 144 0 1 0 0 288 144 144 0 1 0 0-288zm0 121.4l68.7-68.7 22.6 22.6-91.3 91.3-75.3-75.3 22.6-22.6 52.7 52.7z"],
    "database": [384, 512, [], "f1c0", "M0 16l0 48 384 0 0-48-384 0zM0 96l0 48c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-48-296 0 0 56-32 0 0-56-56 0zM0 240l0 48c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-48-296 0 0 56-32 0 0-56-56 0zM0 384l0 48c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-48-296 0 0 56-32 0 0-56-56 0z"],
    "newspaper": [512, 512, [128240], "f1ea", "M80 48l0 352c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-272-48 0 0 272c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-352-432 0zm64 176l0-112 144 0 0 112-144 0zm192-80l0-32 112 0 0 32-112 0zm0 80l0-32 112 0 0 32-112 0zM144 304l0-32 304 0 0 32-304 0zm0 80l0-32 304 0 0 32-304 0z"],
    "location-arrow": [512, 512, [], "f124", "M496 16L0 224 192 320 288 512 496 16zM115 227.8L406.4 105.6 227.8 284.2 115 227.8z"],
    "arrow-right-to-bracket": [512, 512, ["sign-in"], "f090", "M400 32l0 64 48 0 0 320-48 0 0 64 112 0 0-448-112 0zM240 112l0 112-112 0 0 64 112 0 0 112 32 0 144-144-144-144-32 0zM48 208l-48 48 48 48 48-48-48-48z"],
    "video-slash": [512, 512, [], "f4e2", "M43.8 4.2l-39.6 39.6 464 464 39.6-39.6-464-464zM180.9 96l48 48 123.1 0 0-48-171.1 0zM480 96l-128 128 0-48-91.1 0 240 240 11.1 0 0-320-32 0zM16 100.9l0 43.1 43.1 0-43.1-43.1zM16 176l0 192c0 26.5 21.5 48 48 48l240 0c7.9 0 15.3-1.9 21.9-5.3L91.2 176 16 176z"],
    "comment": [512, 512, [128489, 61669], "f075", "M256 0C114.6 0 0 100.3 0 224 0 280.8 24.2 332.7 64 372.2L64 512 176.5 437c25 7.1 51.7 11 79.5 11 141.4 0 256-100.3 256-224S397.4 0 256 0zm0 368c102.4 0 176-69.3 176-144l32 0c0 97.2-93.1 176-208 176l0-32z"],
    "video": [512, 512, ["video-camera"], "f03d", "M16 96l0 48 336 0 0-48-336 0zm464 0l-128 128 0-48-336 0 0 192c0 26.5 21.5 48 48 48l240 0c26.5 0 48-21.5 48-48l0-80 128 128 32 0 0-320-32 0zM136 272l56-56 56 56-56 56-56-56z"],
    "user-hair-long": [448, 512, [], "e45b", "M176 0C123 0 80 43 80 96l0 64c-17.7 0-32 14.3-32 32l0 16c0 17.7 14.3 32 32 32 0 26.5-21.5 48-48 48l0 64c36.1 0 68.2-17.1 88.7-43.6 26.2 26.9 62.8 43.6 103.3 43.6s77.1-16.7 103.3-43.6C347.8 334.9 379.9 352 416 352l0-64c-26.5 0-48-21.5-48-48 17.7 0 32-14.3 32-32l0-16c0-17.7-14.3-32-32-32l0-80c0-26.5-21.5-48-48-48-17.4 0-32.7 9.3-41.1 23.2-15.3-32.6-48.5-55.2-86.9-55.2L176 0zM144 152c0-13.3 10.7-24 24-24s24 10.7 24 24l0 24-48 0 0-24zm112 0c0-13.3 10.7-24 24-24s24 10.7 24 24l0 24-48 0 0-24zM224 304c-35.3 0-64-28.7-64-64l128 0c0 35.3-28.7 64-64 64zM0 496l448 0c0-70.7-57.3-128-128-128l-16 0c0 44.2-35.8 80-80 80s-80-35.8-80-80l-16 0C57.3 368 0 425.3 0 496z"],
    "clipboard": [384, 512, [128203], "f328", "M184 0c-37.1 0-67.6 28-71.6 64L0 64 0 400 384 400 384 64 271.6 64c-4-36-34.5-64-71.6-64L184 0zM160 80c0-17.7 14.3-32 32-32s32 14.3 32 32l0 32 48 0c26.5 0 48 21.5 48 48L64 160c0-26.5 21.5-48 48-48l48 0 0-32zM0 432l0 64 384 0 0-64-384 0z"],
    "laptop": [512, 512, [128187], "f109", "M32 32l0 336 448 0 0-336-448 0zM80 320l0-240 352 0 0 240-352 0zm32-208l0 176 288 0 0-176-288 0zM0 400l0 32c0 26.5 21.5 48 48 48l416 0c26.5 0 48-21.5 48-48l0-32-192 0c0 17.7-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32L0 400z"],
    "battery-three-quarters": [512, 512, ["battery-4"], "f241", "M432 416l-432 0 0-320 432 0 0 320zM288 368l96 0 0-224-96 0 0 224zm224-48l-48 0 0-128 48 0 0 128z"],
    "thumbs-down": [512, 512, [128078, 61576], "f165", "M0 144l0 48 64 0 0 32-64 0 0 176 64 0c26.5 0 48-21.5 48-48l0-208-112 0zm144 0l0 200 24 0c30.9 0 56 25.1 56 56l0 112 32 0c26.5 0 48-21.5 48-48l0-56 152 0c22.1 0 40-17.9 40-40 0-10.2-3.8-19.4-10-26.5 15.2-5.7 26-20.3 26-37.5s-10.8-31.8-26-37.5c6.2-7.1 10-16.3 10-26.5 0-22.1-17.9-40-40-40l-3.3 0c2.1-4.9 3.3-10.3 3.3-16 0-22.1-17.9-40-40-40l-272 0z"],
    "utensils": [384, 512, [127860, 61685, "cutlery"], "f2e7", "M368 0c-53 0-96 43-96 96l0 224 96 0 0-320zM0 64L0 192c0 35.3 28.7 64 64 64l8 0 0 256 64 0 0-256 8 0c35.3 0 64-28.7 64-64l0-128-48 0 0 112-32 0 0-112-48 0 0 112-32 0 0-112-48 0zM304 352l0 160 64 0 0-160-64 0z"],
    "microphone": [416, 512, [], "f130", "M208 0C146.1 0 96 50.1 96 112l224 0C320 50.1 269.9 0 208 0zM32 144a32 32 0 1 0 0 64 32 32 0 1 0 0-64zm64 0l0 96c0 61.9 50.1 112 112 112s112-50.1 112-112l0-96-136 0 0 104-32 0 0-104-56 0zm288 0a32 32 0 1 0 0 64 32 32 0 1 0 0-64zM0 240c0 93.3 61.4 172.3 146.1 198.6-20.8 17.6-34.1 43.9-34.1 73.4l192 0c0-29.4-13.2-55.8-34.1-73.4 84.6-26.4 146.1-105.3 146.1-198.6l-64 0c0 79.5-64.5 144-144 144S64 319.5 64 240L0 240z"],
    "crown": [512, 512, [128081], "f521", "M256 16c-30.9 0-56 25.1-56 56 0 22.3 13.1 41.6 32 50.6l0 5.4c0 41.1-33.3 74.4-74.4 74.4-13.2 0-21.4-.7-28.5-3-5.8-1.9-12.2-5.3-20.3-12.7 2.1-5.8 3.2-12.1 3.2-18.7 0-30.9-25.1-56-56-56s-56 25.1-56 56 25.1 56 56 56c6.6 0 12.9-1.1 18.7-3.2 8.2 8.8 13.1 16.5 16.2 23.7 3.5 8.1 5.1 16.8 5.1 27.5l0 112 320.1 0 0-112c0-10.7 1.6-19.4 5.1-27.5 3.1-7.2 8-14.9 16.2-23.7 5.9 2.1 12.2 3.2 18.7 3.2 30.9 0 56-25.1 56-56s-25.1-56-56-56-56 25.1-56 56c0 6.6 1.1 12.8 3.2 18.7-8.1 7.4-14.5 10.8-20.3 12.7-7.1 2.3-15.3 3-28.5 3-41.1 0-74.4-33.3-74.4-74.4l0-5.4c18.9-9 32-28.3 32-50.6 0-30.9-25.1-56-56-56zM200 288l56-56 56 56-56 56-56-56zM96 416l0 64 320 0 0-64-320 0z"],
    "arrow-up-wide-short": [512, 512, ["sort-amount-up"], "f161", "M128 0l-128 128 0 16 96 0 0 224 64 0 0-224 96 0 0-16-128-128zm80 192l0 64 304 0 0-64-304 0zm0 112l0 64 208 0 0-64-208 0zm-80 96l-48 48 48 48 48-48-48-48zm80 16l0 64 112 0 0-64-112 0z"],
    "sun": [512, 512, [9728], "f185", "M232 0l0 49.4c7.9-.9 15.9-1.4 24-1.4s16.1 .5 24 1.4L280 0 232 0zM148.8 22.3l-41.6 24 24.7 42.8c12.8-9.5 26.7-17.6 41.5-24L148.8 22.3zm214.4 0L338.5 65c14.8 6.4 28.8 14.5 41.5 24l24.7-42.8-41.6-24zM256 80a176 176 0 1 0 0 352 176 176 0 1 0 0-352zM46.3 107.2l-24 41.6 42.7 24.7c6.4-14.8 14.5-28.8 24-41.5L46.3 107.2zm419.4 0l-42.8 24.7c9.5 12.8 17.6 26.7 24 41.5l42.7-24.7-24-41.6zM128 256c0-70.7 57.3-128 128-128l0 32c-53 0-96 43-96 96l-32 0zM0 232l0 48 49.4 0c-1.3-11.2-2.3-28 0-48L0 232zm462.6 0c1.3 11.5 2.3 28.2 0 48l49.4 0 0-48-49.4 0zM65 338.5l-42.7 24.7 24 41.6 42.8-24.7c-9.5-12.8-17.6-26.7-24-41.5zm382 0c-6.4 14.8-14.5 28.8-24 41.5l42.8 24.7 24-41.6-42.7-24.7zM131.9 422.9l-24.7 42.8 41.6 24 24.7-42.7c-14.8-6.4-28.8-14.5-41.5-24zm248.2 0c-12.8 9.5-26.7 17.6-41.5 24l24.7 42.7 41.6-24-24.7-42.8zM232 462.6l0 49.4 48 0 0-49.4c-7.9 .9-15.9 1.4-24 1.4s-16.1-.5-24-1.4z"],
    "image": [512, 512, [], "f03e", "M0 48l0 416 512 0 0-416-512 0zM48 416l0-320 416 0 0 320-416 0zM80 128l0 256 80-80 48 48 96-96 128 128 0-256-352 0zm152 80a40 40 0 1 1 -80 0 40 40 0 1 1 80 0z"],
    "notdef": [384, 512, [], "e1fe", "M384 512L0 512 0 0 384 0 384 512zM48 48L48 74.8 172.6 256 48 437.2 48 464 68.4 464 192 284.2 315.6 464 336 464 336 437.2 211.4 256 336 74.8 336 48 315.6 48 192 227.8 68.4 48 48 48z"],
    "pencil": [480, 512, [9999, 61504, "pencil-alt"], "f303", "M408 16l-48.7 48.7 72 72 48.7-48.7-72-72zM336.7 87.3l-265.4 265.4 72 72 265.4-265.4-72-72zm-288 288l-8.7 8.7-24 96 96-24 8.7-8.7-72-72z"],
    "lightbulb": [352, 512, [128161], "f0eb", "M176 16C78.8 16 0 94.8 0 192 0 266.6 46.4 330.4 112 356l0 44 128 0 0-44c65.6-25.6 112-89.4 112-164 0-97.2-78.8-176-176-176zM48 192c0-70.7 57.3-128 128-128l0 32c-53 0-96 43-96 96l-32 0zm64 240l0 48 32 0 0 32 64 0 0-32 32 0 0-48-128 0z"],
    "code": [512, 512, [], "f121", "M265.4 32l-84 448 65.1 0 84-448-65.1 0zM128 112L45.3 194.7 0 240 45.3 285.3 128 368 173.3 322.7 90.5 240 173.3 157.3 128 112zm256 32l-45.3 45.3 82.7 82.7-82.7 82.7 45.3 45.3 82.7-82.7 45.3-45.3-45.3-45.3-82.7-82.7z"],
    "address-card": [512, 512, [62140, "contact-card", "vcard"], "f2bb", "M0 64l0 384 96 0 0-64 64 0 0 64 192 0 0-64 64 0 0 64 96 0 0-384-512 0zM48 320l0-208 176 0 0 208-32 0c0-17.7-14.3-32-32-32l-48 0c-17.7 0-32 14.3-32 32l-32 0zM272 160l0-32 192 0 0 32-192 0zM144 144c-17.7 0-32 14.3-32 32l-32 0 0 40c0 30.9 25.1 56 56 56s56-25.1 56-56l0-72-48 0zm128 88l0-32 192 0 0 32-192 0zm0 72l0-32 192 0 0 32-192 0z"],
    "angle-right": [224, 512, [8250], "f105", "M16 80l0 352 32 0 176-176-176-176-32 0z"],
    "face-meh": [512, 512, [128528, "meh"], "f11a", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM168 192l-48-48 64 0c26.5 0 48 21.5 48 48s-21.5 48-48 48l-64 0 48-48zm160 0l-48-48 64 0c26.5 0 48 21.5 48 48s-21.5 48-48 48l-64 0 48-48zM128 368l0-32 256 0 0 32-256 0z"],
    "map": [512, 512, [128506, 62072], "f279", "M128 32l-128 64 0 384 128-64 128 64 128-64 128 64 0-384-128-64-128 64-128-64zm0 330.3l0-276.7 80 40 0 276.7-80-40zm256 0l0-276.7 80 40 0 276.7-80-40z"],
    "thumbtack": [384, 512, [128204, 128392, "thumb-tack"], "f08d", "M48 0l0 64 288 0 0-64-288 0zM80 96l0 144c-44.2 0-80 35.8-80 80l0 16 160 0 0 144 32 32 32-32 0-144 160 0 0-16c0-44.2-35.8-80-80-80l0-144-136 0 0 144-32 0 0-144-56 0z"],
    "money-bill-wave": [512, 512, [], "f53a", "M0 80l0 352 512 0 0-352-512 0zM128 256c0-70.7 57.3-128 128-128s128 57.3 128 128c0 48.4-26.9 90.6-66.6 112.3-6.5-18.8-24.4-32.3-45.4-32.3l-32 0c-21 0-38.9 13.5-45.4 32.3-39.7-21.7-66.6-63.9-66.6-112.3zm336-96a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM256 176c-17.7 0-32 14.3-32 32l-32 0 0 48c0 35.3 28.7 64 64 64s64-28.7 64-64l0-80-64 0zM112 352a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z"],
    "folder": [512, 512, [128193, 128447, 61716, "folder-blank"], "f07b", "M0 32L0 416c0 35.3 28.7 64 64 64l384 0c35.3 0 64-28.7 64-64l0-304-432 0 0 304c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-336 208 0 0-48-256 0z"],
    "arrow-up-from-bracket": [448, 512, [], "e09a", "M224 0l-144 144 0 32 112 0 0 112 64 0 0-112 112 0 0-32-144-144zm0 320l-48 48 48 48 48-48-48-48zM0 400l0 112 448 0 0-112-64 0 0 48-320 0 0-48-64 0z"],
    "cloud": [512, 512, [9729], "f0c2", "M192 32C121.3 32 64 89.3 64 160 64 184.9 71.1 208.1 83.3 227.7 35.4 240.4 0 284 0 336 0 397.9 50.1 448 112 448l288 0c61.9 0 112-50.1 112-112 0-48.5-30.8-89.8-73.9-105.4 6.3-11.5 9.9-24.6 9.9-38.6 0-44.2-35.8-80-80-80-19.6 0-37.5 7-51.4 18.7-13.3-56.6-64-98.7-124.6-98.7zM152 90.7c38.3-22.1 87.2-9 109.3 29.3l-27.7 16c-13.3-23-42.6-30.8-65.6-17.6S137.2 161 150.4 184l-27.7 16c-22.1-38.3-9-87.2 29.3-109.3zm88 93.9c30.6-17.7 69.8-7.2 87.4 23.4l-27.7 16c-8.8-15.3-28.4-20.5-43.7-11.7s-20.5 28.4-11.7 43.7l-27.7 16c-17.7-30.6-7.2-69.8 23.4-87.4zm-160 96c30.6-17.7 69.8-7.2 87.4 23.4l-27.7 16c-8.8-15.3-28.4-20.5-43.7-11.7S75.4 336.7 84.3 352L56.6 368c-17.7-30.6-7.2-69.8 23.4-87.4z"],
    "circle": [512, 512, [128308, 128309, 128992, 128993, 128994, 128995, 128996, 9679, 9898, 9899, 11044, 61708, 61915], "f111", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM48 256c0-114.9 93.1-208 208-208 57.4 0 109.4 23.3 147.1 60.9l-22.6 22.6C348.6 99.7 304.6 80 256 80 158.8 80 80 158.8 80 256 80 304.6 99.7 348.6 131.5 380.5l-22.6 22.6C71.3 365.4 48 313.4 48 256z"],
    "envelope-heart": [512, 512, [], "e8af", "M0 64l0 384 512 0 0-384-512 0zM256 320L48 112 464 112 256 320zM201.4 161.4c-12.5 12.5-12.5 32.8 0 45.3l54.6 54.6 54.6-54.6c12.5-12.5 12.5-32.8 0-45.3s-32.8-12.5-45.3 0l-9.4 9.4-9.4-9.4c-12.5-12.5-32.8-12.5-45.3 0z"],
    "backward": [448, 512, [9194], "f04a", "M224 256l176 176 32 0 0-352-32 0-176 176zM0 256l176 176 32 0 0-352-32 0-176 176z"],
    "link": [480, 512, [128279, "chain"], "f0c1", "M234.2 58.2l-80 80c-5.4 5.4-10.4 11.2-14.7 17.2-6 4.4-11.8 9.3-17.3 14.8l-80 80c-56.2 56.2-56.2 147.4 0 203.6s147.4 56.2 203.6 0l40.4-40.4c-9.8 1.7-19.9 2.6-30.2 2.6-19 0-37.2-3-54.3-8.5l-1.1 1.1c-31.2 31.2-81.9 31.2-113.1 0s-31.2-81.9 0-113.1l27.3-27.3s0 0 0 0l52.7-52.7c5.6-5.6 11.7-10.1 18.3-13.7 0 0 0 0 0 0 30.4-16.5 69.2-12 94.8 13.7 12.7 12.7 20.3 28.7 22.6 45.3L354 209.9c-6.9-14.4-16.2-27.8-28.1-39.7-20.9-20.9-46.7-34.1-73.7-39.4l27.3-27.3c31.2-31.2 81.9-31.2 113.1 0s31.2 81.9 0 113.1l-80 80c-31.2 31.2-81.9 31.2-113.1 0-12.7-12.7-20.3-28.7-22.6-45.2L126 302.1c6.9 14.4 16.2 27.8 28.1 39.7 56.2 56.2 147.4 56.2 203.6 0l80-80c56.2-56.2 56.2-147.4 0-203.6s-147.4-56.2-203.6 0z"],
    "backward-step": [320, 512, ["step-backward"], "f048", "M0 80l0 352 64 0 0-352-64 0zm288 0l-176 176 176 176 32 0 0-352-32 0z"],
    "circle-user": [512, 512, [62142, "user-circle"], "f2bd", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM48 256C48 141.1 141.1 48 256 48s208 93.1 208 208c0 66.6-31.3 126-80.1 164-1.8-36.9-28.6-67.3-63.9-74.4l0 62.4-64-64-64 64 0-62.4C156.7 352.8 129.9 383.1 128.1 420 79.3 382 48 322.6 48 256zM272 120c-17.7 0-32 14.3-32 32l0 8-32 0 0-24-48 0 0 72c-8.8 0-16 7.2-16 16l0 32c0 8.8 7.2 16 16 16 1.8 0 3.5-.3 5.2-.9 12.9 37.7 48.7 64.9 90.8 64.9s77.9-27.1 90.8-64.9c1.6 .6 3.4 .9 5.2 .9 8.8 0 16-7.2 16-16l0-32c0-8.8-7.2-16-16-16l0-88-80 0zm-64 96c0-8.8 7.2-16 16-16s16 7.2 16 16l0 16-32 0 0-16zm64 0c0-8.8 7.2-16 16-16s16 7.2 16 16l0 16-32 0 0-16zm-16 88c-17.7 0-32-14.3-32-32l64 0c0 17.7-14.3 32-32 32z"],
    "hand": [512, 512, [129306, 9995, "hand-paper"], "f256", "M253.2 .2C235.6 2 222.9 17.7 224.7 35.3l20.6 199-33.2-5-44.4-181c-4.2-17.2-21.5-27.7-38.7-23.4s-27.7 21.5-23.4 38.7l69.5 283c3.9 15.9-15.7 26.7-27.1 14.9L55.7 266c-11.5-12.2-30.7-13.4-43.7-2.6-13.6 11.3-15.4 31.5-4.1 45.1L110.3 431.4C152.9 482.5 215.9 512 282.4 512l62.1 0 0-.2c84.6-4.2 152-74.1 152-159.8l0-224c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 134.4-32-4.8 0-193.6c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 184-25.9-3.9-22.3-215.4C286.5 11.1 270.8-1.6 253.2 .2z"],
    "thumbs-up": [512, 512, [128077, 61575], "f164", "M224 32l0 120c0 30.9-25.1 56-56 56l-24 0 0 200 272 0c22.1 0 40-17.9 40-40 0-5.7-1.2-11.1-3.3-16l3.3 0c22.1 0 40-17.9 40-40 0-10.2-3.8-19.4-10-26.5 15.2-5.7 26-20.3 26-37.5s-10.8-31.8-26-37.5c6.2-7.1 10-16.3 10-26.5 0-22.1-17.9-40-40-40l-152 0 0-64c0-26.5-21.5-48-48-48l-32 0zM0 208l0 48 64 0 0 32-64 0 0 176 64 0c26.5 0 48-21.5 48-48l0-208-112 0z"],
    "building": [448, 512, [127970, 61687], "f1ad", "M160 0l0 64-64 0 0 448 96 0 0-48c0-17.7 14.3-32 32-32s32 14.3 32 32l0 48 96 0 0-448-64 0 0-64-128 0zM144 168l0-56 56 0 0 56-56 0zm104 0l0-56 56 0 0 56-56 0zM0 144l0 368 64 0 0-368-64 0zm384 0l0 368 64 0 0-368-64 0zM144 272l0-56 56 0 0 56-56 0zm104 0l0-56 56 0 0 56-56 0zM144 376l0-56 56 0 0 56-56 0zm104 0l0-56 56 0 0 56-56 0z"],
    "gear": [480, 512, [9881, "cog"], "f013", "M192 16l0 54c-17.6 4.5-34.3 11.5-49.5 20.5l-38.2-38.2-67.9 67.9 38.2 38.2c-9 15.3-16 31.9-20.5 49.5l-54 0 0 96 54 0c4.5 17.6 11.5 34.3 20.5 49.5l-38.2 38.2 67.9 67.9 38.2-38.2c15.3 9 31.9 16 49.5 20.5l0 54 96 0 0-54c17.6-4.5 34.3-11.5 49.5-20.5l38.2 38.2 67.9-67.9-38.2-38.2c9-15.3 16-31.9 20.5-49.5l54 0 0-96-54 0c-4.5-17.6-11.5-34.3-20.5-49.5l38.2-38.2-67.9-67.9-38.2 38.2c-15.3-9-31.9-16-49.5-20.5l0-54-96 0zM160 256l80-80 80 80-80 80-80-80z"],
    "circle-question": [512, 512, [62108, "question-circle"], "f059", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM464 256a208 208 0 1 1 -416 0 208 208 0 1 1 416 0zM256 80a176 176 0 1 0 0 352 176 176 0 1 0 0-352zM192 184c0-35.3 28.7-64 64-64s64 28.7 64 64l0 3.4c0 18.2-9.1 35.3-24.3 45.4l-9.5 6.3C277.3 245 272 255 272 265.7l0 14.3-32 0 0-14.3c0-21.4 10.7-41.4 28.5-53.3l9.5-6.3c6.3-4.2 10-11.2 10-18.7l0-3.4c0-17.7-14.3-32-32-32s-32 14.3-32 32l0 8-32 0 0-8zm24 168l40-40 40 40-40 40-40-40z"],
    "file": [384, 512, [128196, 128459, 61462], "f15b", "M0 0L0 512 384 512 384 176 208 0 0 0zM192 192L192 51.9 332.1 192 192 192zM56 304l80-80 80 80-80 80-80-80zM232 408c0-22.1 17.9-40 40-40s40 17.9 40 40-17.9 40-40 40-40-17.9-40-40z"],
    "volume-slash": [512, 512, [128263], "f2e2", "M43.8 4.2l-39.6 39.6 464 464 39.6-39.6-464-464zM272 48L202.4 117.6 320 235.1 320 48 272 48zm189.6 66.4l-34.2 34.2c22.9 29.7 36.6 67 36.6 107.4 0 35.1-10.3 67.8-27.9 95.2l34.6 34.6c26.1-36.6 41.4-81.4 41.4-129.8 0-53.7-18.9-103-50.4-141.6zM77 161.9c-43.9 8.8-77 47.6-77 94.1 0 53 43 96 96 96l64 0 112 112 48 0 0-59.1-243-243zm327.5 9.6L370 206c8.9 14.6 14 31.7 14 50 0 12.8-2.5 25-7 36.1l35.8 35.8c12.2-21.2 19.2-45.7 19.2-71.9 0-31.6-10.2-60.8-27.4-84.6z"],
    "arrow-up": [320, 512, [8593], "f062", "M160 32l-160 160 0 32 128 0 0 160 64 0 0-160 128 0 0-32-160-160zm0 384l-48 48 48 48 48-48-48-48z"],
    "rectangle": [512, 512, [9644, "rectangle-landscape"], "f2fa", "M512 448l-512 0 0-384 512 0 0 384zM48 112l0 288 32 0 0-256 384 0 0-32-416 0z"],
    "grid": [448, 512, ["grid-3"], "e195", "M0 32l0 128 128 0 0-128-128 0zm160 0l0 128 128 0 0-128-128 0zm160 0l0 128 128 0 0-128-128 0zM224 176l-80 80 80 80 80-80-80-80zM0 192l0 128 128 0 0-128-128 0zm320 0l0 128 128 0 0-128-128 0zM0 352l0 128 128 0 0-128-128 0zm160 0l0 128 128 0 0-128-128 0zm160 0l0 128 128 0 0-128-128 0z"],
    "shirt": [512, 512, [128085, "t-shirt", "tshirt"], "f553", "M112 48C50.1 48 0 98.1 0 160l0 32 96 0 0 208 320 0 0-208 96 0 0-32c0-61.9-50.1-112-112-112l-80 0c0 35.3-28.7 64-64 64s-64-28.7-64-64l-80 0zm80 192l64-64 64 64-64 64-64-64zM96 432l0 48 320 0 0-48-320 0z"],
    "suitcase": [512, 512, [129523], "f0f2", "M256 0C185.3 0 128 57.3 128 128l-128 0 0 48 512 0 0-48-128 0C384 57.3 326.7 0 256 0zM176 128c0-44.2 35.8-80 80-80s80 35.8 80 80l-160 0zM0 208l0 192 512 0 0-192-512 0zM0 432l0 48 512 0 0-48-512 0z"],
    "play": [448, 512, [9654], "f04b", "M80 64l0 384 32 0 336-192-336-192-32 0z"],
    "paperclip": [512, 512, [128206], "f0c6", "M311.8 0c-34 0-66.6 13.5-90.6 37.5L51.5 207.2C18.5 240.2 0 285 0 331.6L0 336c0 97.2 78.8 176 176 176l4.4 0c46.7 0 91.4-18.5 124.5-51.5l149.8-149.8-45.3-45.3-149.8 149.8c-21 21-49.5 32.8-79.2 32.8l-4.4 0c-61.9 0-112-50.1-112-112l0-4.4c0-29.7 11.8-58.2 32.8-79.2L266.5 82.8c12-12 28.4-18.8 45.4-18.8 35.4 0 64.2 28.7 64.2 64.2l0 2.8c0 17.8-7.1 34.8-19.6 47.4L187.5 347.3c-3 3-7.1 4.7-11.4 4.7-8.7 0-16.1-7.2-16.1-16.3 0-4.3 1.7-8.5 4.6-11.5l150.3-153.9-45.8-44.7-150.3 153.9c-14.7 15-22.8 35.3-22.8 56.2 0 44.1 35.7 80.3 80.1 80.3 21.2 0 41.6-8.4 56.6-23.5L401.6 223.6C426.2 199.1 440 165.7 440 131l0-2.8C440 57.4 382.6 0 311.8 0zM448 208l0 64 64 0 0-64-64 0z"],
    "wrench": [480, 512, [128295], "f0ad", "M344 16c-75.1 0-136 60.9-136 136 0 16.9 3.1 33.1 8.7 48.1L16.4 400.4c-21.9 21.9-21.9 57.3 0 79.2s57.3 21.9 79.2 0L295.9 279.3c14.9 5.6 31.1 8.7 48.1 8.7 75.1 0 136-60.9 136-136 0-23-5.7-44.7-15.8-63.6L356.3 196.3 299.7 139.7 407.6 31.8C388.7 21.7 367 16 344 16zM44.7 428.7l56-56 22.6 22.6-56 56-22.6-22.6z"],
    "life-ring": [480, 512, [], "f1cd", "M96 16c-53 0-96 43-96 96 0 26.9 11.1 51.3 29 68.7-8.4 23.5-13 48.9-13 75.3s4.6 51.8 13 75.3c-17.9 17.4-29 41.8-29 68.7 0 53 43 96 96 96 26.9 0 51.3-11.1 68.7-29 23.5 8.4 48.9 13 75.3 13s51.8-4.6 75.3-13c17.4 17.9 41.8 29 68.7 29 53 0 96-43 96-96 0-26.9-11.1-51.3-29-68.7 8.4-23.5 13-48.9 13-75.3s-4.6-51.8-13-75.3c17.9-17.4 29-41.8 29-68.7 0-53-43-96-96-96-26.9 0-51.3 11.1-68.7 29-23.5-8.4-48.9-13-75.3-13s-51.8 4.6-75.3 13C147.3 27.1 122.9 16 96 16zM48 112c0-26.5 21.5-48 48-48 7.5 0 14.6 1.7 20.9 4.8-25.5 16.8-47.4 38.7-64.1 64.1-3.1-6.3-4.8-13.4-4.8-20.9zM363.1 68.8c6.3-3.1 13.4-4.8 20.9-4.8 26.5 0 48 21.5 48 48 0 7.5-1.7 14.6-4.8 20.9-16.8-25.5-38.7-47.4-64.1-64.1zM64 256c0-97.2 78.8-176 176-176l0 32c-79.5 0-144 64.5-144 144l-32 0zm256 0a80 80 0 1 1 -160 0 80 80 0 1 1 160 0zM240 400c79.5 0 144-64.5 144-144l32 0c0 97.2-78.8 176-176 176l0-32zM48 400c0-7.5 1.7-14.6 4.8-20.9 16.8 25.5 38.7 47.4 64.1 64.1-6.3 3.1-13.4 4.8-20.9 4.8-26.5 0-48-21.5-48-48zm315.1 43.2c25.5-16.8 47.4-38.7 64.1-64.1 3.1 6.3 4.8 13.4 4.8 20.9 0 26.5-21.5 48-48 48-7.5 0-14.6-1.7-20.9-4.8z"],
    "calendar": [480, 512, [128197, 128198], "f133", "M80 0l0 32-32 0C21.5 32 0 53.5 0 80l0 400 480 0 0-400c0-26.5-21.5-48-48-48l-32 0 0-32-48 0 0 32-224 0 0-32-48 0zm40 112a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm288 0a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zM176 240l64-64 64 64-64 64-64-64zM48 288l0-96 96 0 0 96-96 0zm288 0l0-96 96 0 0 96-96 0zm-3.3 67.3l22.6-22.6 28.7 28.7 28.7-28.7 22.6 22.6-28.7 28.7 28.7 28.7-22.6 22.6-28.7-28.7-28.7 28.7-22.6-22.6 28.7-28.7-28.7-28.7zM144 384a48 48 0 1 1 -96 0 48 48 0 1 1 96 0zm48 48l0-96 96 0 0 96-96 0z"],
    "check": [512, 512, [10003, 10004], "f00c", "M419 50.7l-226.7 226.7-98.7-98.7-90.5 90.5 144 144 45.3 45.3 45.3-45.3 272-272-90.5-90.5zM172.9 364.7l248-248 22.6 22.6-248 248-22.6-22.6z"],
    "house": [448, 512, [127968, 63498, 63500, "home", "home-alt", "home-lg-alt"], "f015", "M224 32l-224 160 0 32 48 0 0 256 112 0 0-128c0-35.3 28.7-64 64-64s64 28.7 64 64l0 128 112 0 0-256 48 0 0-32-224-160zM176 184l48-48 48 48-48 48-48-48z"],
    "play-pause": [448, 512, [], "e22f", "M0 80L0 432 32 432 208 256 32 80 0 80zm272 0l0 352 64 0 0-352-64 0zm112 0l0 352 64 0 0-352-64 0z"],
    "sliders": [448, 512, ["sliders-h"], "f1de", "M176 16c-34.3 0-63.6 21.6-75 52l-101 0 0 56 101 0c11.4 30.4 40.6 52 75 52s63.6-21.6 75-52l197 0 0-56-197 0c-11.4-30.4-40.6-52-75-52zM136 96l40-40 40 40-40 40-40-40zm184 80c-34.3 0-63.6 21.6-75 52l-245 0 0 56 245 0c11.4 30.4 40.6 52 75 52s63.6-21.6 75-52l53 0 0-56-53 0c-11.4-30.4-40.6-52-75-52zm-40 80l40-40 40 40-40 40-40-40zM128 336c-34.3 0-63.6 21.6-75 52l-53 0 0 56 53 0c11.4 30.4 40.6 52 75 52s63.6-21.6 75-52l245 0 0-56-245 0c-11.4-30.4-40.6-52-75-52zM88 416l40-40 40 40-40 40-40-40z"],
    "face-frown": [512, 512, [9785, "frown"], "f119", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM128 192c0-26.5 21.5-48 48-48s48 21.5 48 48l0 64-48-48-48 48 0-64zm160 0c0-26.5 21.5-48 48-48s48 21.5 48 48l0 64-48-48-48 48 0-64zM131.1 380c29.3-36.6 74.4-60 124.9-60s95.6 23.4 124.9 60l-25 20c-23.5-29.3-59.5-48-100-48s-76.5 18.8-100 48l-25-20z"],
    "forward-step": [320, 512, ["step-forward"], "f051", "M208 256L32 432 0 432 0 80 32 80 208 256zM320 432l-64 0 0-352 64 0 0 352z"],
    "sort": [352, 512, ["unsorted"], "f0dc", "M176 32l-176 176 0 32 352 0 0-32-176-176zM0 304l0 32 176 176 176-176 0-32-352 0z"],
    "user": [448, 512, [128100, 62144, 62470, "user-alt", "user-large"], "f007", "M224 0c-26.5 0-48 21.5-48 48l0 16-32 0 0-32-64 0 0 112c-17.7 0-32 14.3-32 32l0 32c0 17.7 14.3 32 32 32 1.2 0 2.4-.1 3.5-.2 14.5 64.2 71.9 112.2 140.5 112.2s126-48 140.5-112.2c1.2 .1 2.3 .2 3.5 .2 17.7 0 32-14.3 32-32l0-32c0-17.7-14.3-32-32-32L368 0 224 0zM144 152c0-13.3 10.7-24 24-24s24 10.7 24 24l0 24-48 0 0-24zm112 0c0-13.3 10.7-24 24-24s24 10.7 24 24l0 24-48 0 0-24zM224 304c-35.3 0-64-28.7-64-64l128 0c0 35.3-28.7 64-64 64zM0 496l448 0c0-70.7-57.3-128-128-128l0 96-96-96-96 96 0-96C57.3 368 0 425.3 0 496z"],
    "signal-bars": [480, 512, ["signal-alt", "signal-alt-4", "signal-bars-strong"], "f690", "M392 80l0 384 80 0 0-384-80 0zM264 176l0 288 80 0 0-288-80 0zM136 272l0 192 80 0 0-192-80 0zM8 368l0 96 80 0 0-96-80 0z"],
    "snowflake": [512, 512, [10052, 10054], "f2dc", "M256.2 0c-8.1 0-16.1 .4-24 1.1l0 70.9-46.6-62.1c-16.1 4.6-31.6 10.8-46.3 18.3l92.9 123.8 0 62.4-54.1-31.2-60.8-142.3c-13.9 8.9-26.9 19.3-39 30.9l30.5 71.4-61.4-35.4c-4.6 6.5-8.9 13.2-13 20.2s-7.7 14.1-11 21.3l61.4 35.4-77.1 9.3c-4.1 16.3-6.5 32.8-7.3 49.2l153.7-18.5 54.1 31.2-54.1 31.2-153.7-18.5c.8 16.5 3.2 32.9 7.3 49.2l77.1 9.3-61.4 35.4c3.3 7.2 7 14.3 11 21.3s8.4 13.8 13 20.2l61.4-35.4-30.5 71.4c12.1 11.7 25.1 22 39 30.9l60.8-142.3 54.1-31.2 0 62.4-92.9 123.8c14.7 7.5 30.1 13.7 46.3 18.3l46.6-62.1 0 70.9c7.9 .7 15.9 1.1 24 1.1s16.1-.4 24-1.1l0-70.9 46.6 62.1c16.1-4.6 31.6-10.8 46.3-18.3l-92.9-123.8 0-62.4 54.1 31.2 60.8 142.3c13.9-8.9 26.9-19.2 39-30.9l-30.5-71.4 61.4 35.4c4.6-6.5 8.9-13.2 13-20.2s7.7-14.1 11-21.3l-61.4-35.4 77.1-9.3c4.1-16.3 6.5-32.8 7.3-49.2l-153.7 18.5-54.1-31.2 54.1-31.2 153.7 18.5c-.8-16.5-3.2-32.9-7.3-49.2l-77.1-9.3 61.4-35.4c-3.3-7.2-7-14.3-11-21.3s-8.4-13.8-13-20.2l-61.4 35.4 30.5-71.4c-12.1-11.7-25.1-22-39-30.9l-60.8 142.3-54.1 31.2 0-62.4 92.9-123.8C358.5 20.6 343 14.5 326.8 9.9l-46.6 62.1 0-70.9c-7.9-.7-15.9-1.1-24-1.1z"],
    "skull-crossbones": [512, 512, [128369, 9760], "f714", "M256 0c-79.5 0-144 64.5-144 144 0 34.3 12 65.8 32 90.5l0 53.5 48 0 0-32 32 0 0 32 64 0 0-32 32 0 0 32 48 0 0-53.5c20-24.7 32-56.2 32-90.5 0-79.5-64.5-144-144-144zM156.7 115.3l22.6-22.6 28.7 28.7 28.7-28.7 22.6 22.6-28.7 28.7 28.7 28.7-22.6 22.6-28.7-28.7-28.7 28.7-22.6-22.6 28.7-28.7-28.7-28.7zM352 160a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm81 66.3c-20.5 8.3-30.4 31.6-22.1 52.1 .5 1.3 1.1 2.5 1.7 3.6L115.5 402c-.4-1.3-.8-2.5-1.3-3.8-8.3-20.5-31.6-30.4-52.1-22.1S31.8 407.8 40 428.2c4.9 12.1 15.1 20.5 26.8 23.7-6.3 10.4-7.7 23.5-2.8 35.7 8.3 20.5 31.6 30.4 52.1 22.1s30.4-31.6 22.1-52.1c-.5-1.3-1.1-2.5-1.7-3.6L433.6 334c.4 1.3 .8 2.5 1.3 3.8 8.3 20.5 31.6 30.4 52.1 22.1s30.4-31.6 22.1-52.1c-4.9-12.1-15.1-20.6-26.8-23.7 6.3-10.4 7.7-23.5 2.8-35.7-8.3-20.5-31.6-30.4-52.1-22.1zM26.9 248.4c-4.9 12.1-3.4 25.3 2.8 35.7-11.7 3.1-21.9 11.5-26.8 23.7-8.3 20.5 1.6 43.8 22.1 52.1s43.8-1.6 52.1-22.1c.5-1.3 .9-2.5 1.3-3.8L149.2 362.6 224 332.4 99.4 282c.6-1.2 1.2-2.4 1.7-3.6 8.3-20.5-1.6-43.8-22.1-52.1s-43.8 1.6-52.1 22.1zM397.8 398.3c-.5 1.3-.9 2.5-1.3 3.8l-33.7-13.6-74.7 30.2 87.5 35.3c-.6 1.2-1.2 2.4-1.7 3.6-8.3 20.5 1.6 43.8 22.1 52.1s43.8-1.6 52.1-22.1c4.9-12.1 3.4-25.3-2.8-35.7 11.7-3.1 21.9-11.5 26.8-23.7 8.3-20.5-1.6-43.8-22.1-52.1s-43.8 1.6-52.1 22.1z"],
    "ticket": [512, 512, [127903], "f145", "M0 64l0 48 512 0 0-48-512 0zm0 80l0 48c35.3 0 64 28.7 64 64S35.3 320 0 320l0 48 512 0 0-48c-35.3 0-64-28.7-64-64s28.7-64 64-64l0-48-512 0zM176 256l80-80 80 80-80 80-80-80zM0 400l0 48 512 0 0-48-512 0z"],
    "wheelchair": [480, 512, [], "f193", "M336 0c-17.7 0-32 14.3-32 32l-32 0 0 48c0 35.3 28.7 64 64 64s64-28.7 64-64l0-80-64 0zM32 128l0 48 32 0 0 60c-38.7 27.5-64 72.8-64 124 0 83.9 68.1 152 152 152 64.2 0 119.1-39.8 141.4-96l58.6 0 0-48-96.3 0c-4.1 53.7-49 96-103.7 96-57.4 0-104-46.6-104-104 0-43.3 26.4-80.4 64-96l0-136-80 0zm112 67.5l0 60.5 48 0 0-64c0-8.8 7.2-16 16-16s16 7.2 16 16l0 91.5c0 27.5 21.1 50 48 52.3l0 .2 111.5 0c16.1 0 27.6 15.5 23 30.9l-23.3 77.6c-7.7 25.7 11.5 51.5 38.3 51.5l42.5 0 0-48-31.7 0 20.2-67.3c13.9-46.2-20.7-92.7-69-92.7l-54.3 0 11.7-61.7c6.3-32.9-13.9-65.1-46.2-73.8l-70-18.9C184 122.8 144 153.4 144 195.5zM152 304a56 56 0 1 0 0 112 56 56 0 1 0 0-112z"],
    "bookmark": [384, 512, [128278, 61591], "f02e", "M0 0L0 56 384 56 384 0 0 0zM0 88L0 512 192 400 384 512 384 88 0 88zM256 224a64 64 0 1 1 -128 0 64 64 0 1 1 128 0z"],
    "bomb": [512, 512, [128163], "f1e2", "M122.5 0c-53.9 0-89 56.7-64.9 105l.9 1.8 42.9-21.5-.9-1.8c-8.2-16.3 3.7-35.5 21.9-35.5 6.9 0 13.5 2.9 18.2 8l18.2 20c34.3 37.7 95.6 30.4 120-14.4l3-5.5c2.7-5 8-8.2 13.8-8.2 4.2 0 8.2 1.7 11.1 4.6l19.4 19.4 33.9 0 0-33.9-19.4-19.4C328.6 6.7 312.4 0 295.6 0 272.2 0 250.8 12.7 239.6 33.2l-3 5.5c-8.6 15.8-30.2 18.4-42.3 5.1l-18.2-20C162.4 8.6 143 0 122.5 0zM392 32l0 72-72 0 0 48 72 0 0 72 48 0 0-72 72 0 0-48-72 0 0-72-48 0zM153.2 99.4l-114.5 57.2 15 30.1C20.5 221.2 0 268.2 0 320 0 426 86 512 192 512s192-86 192-192-86-192-192-192c-8 0-15.9 .5-23.7 1.5l-15-30.1zM48 320c0-79.5 64.5-144 144-144l0 32c-61.9 0-112 50.1-112 112l-32 0z"],
    "arrow-right": [480, 512, [8594], "f061", "M288 96l0 128-160 0 0 64 160 0 0 128 32 0 160-160-160-160-32 0zM48 208l-48 48 48 48 48-48-48-48z"],
    "battery-bolt": [512, 512, [], "f376", "M0 96l0 320 208 0 0-128-112 0 128-192-224 0zm224 0l0 128 112 0-128 192 224 0 0-320-208 0zm240 96l0 128 48 0 0-128-48 0z"],
    "buildings": [512, 512, [], "e0cc", "M64 32l0 64-64 0 0 384 112 0 0-48c0-17.7 14.3-32 32-32s32 14.3 32 32l0 48 112 0 0-384-64 0 0-64-160 0zm352 96c-26.5 0-48 21.5-48 48l-48 0 0 304 64 0 0-48c0-17.7 14.3-32 32-32s32 14.3 32 32l0 48 64 0 0-304-48 0c0-26.5-21.5-48-48-48zM48 216l0-72 72 0 0 72-72 0zm120 0l0-72 72 0 0 72-72 0zm208 56l40-40 40 40-40 40-40-40zM48 336l0-72 72 0 0 72-72 0zm120 0l0-72 72 0 0 72-72 0z"],
    "xmark": [448, 512, [128473, 10005, 10006, 10060, 215, "close", "multiply", "remove", "times"], "f00d", "M353.3 36.4L224.2 165.5 95 36.4 4.5 126.9 133.6 256 4.5 385.1 95 475.6 224.2 346.5 353.3 475.6 443.8 385.1 314.7 256 443.8 126.9 353.3 36.4zM212.8 244.7L353.3 104.2 375.9 126.9 235.5 267.3 95 407.8 72.4 385.1 212.8 244.7z"],
    "lock-open": [576, 512, [], "f3c1", "M464 0C402.1 0 352 50.1 352 112l0 80-256 0 0 48 384 0 0-48-80 0 0-80c0-35.3 28.7-64 64-64s64 28.7 64 64l0 80 48 0 0-80C576 50.1 525.9 0 464 0zM96 272l0 160 384 0 0-160-384 0zm0 192c0 26.5 21.5 48 48 48l288 0c26.5 0 48-21.5 48-48L96 464z"],
    "droplet": [384, 512, [128167, "tint"], "f043", "M192 0L37.5 208C13.2 240.9 0 280.7 0 321.6 0 426.7 86.8 512 192 512s192-85.3 192-190.4c0-40.9-13.2-80.7-37.5-113.5L192 0zM80 256l64-64 64 64-64 64-64-64zM192 432c61.9 0 112-50.1 112-112l32 0c0 79.5-64.5 144-144 144l0-32z"],
    "shop": [512, 512, ["store-alt"], "f54f", "M112 32l-112 112 0 32 512 0 0-32-112-112-288 0zM48 208l0 224c-26.5 0-48 21.5-48 48l96 0 0-160c0-35.3 28.7-64 64-64s64 28.7 64 64l0 160 288 0c0-26.5-21.5-48-48-48l0-224-416 0zM272 384l0-112 144 0 0 112-144 0z"],
    "film": [512, 512, [127902, 62368, "film-alt", "film-simple"], "f008", "M0 48l0 416 64 0 0-72 32 0 0 72 320 0 0-72 32 0 0 72 64 0 0-416-64 0 0 72-32 0 0-72-320 0 0 72-32 0 0-72-64 0zM144 232l0-136 224 0-136 136-88 0zm-80 0l0-64 32 0 0 64-32 0zm352 0l0-64 32 0 0 64-32 0zM64 344l0-64 32 0 0 64-32 0zm80 72l0-136 224 0-136 136-88 0zm272-72l0-64 32 0 0 64-32 0z"],
    "comments": [512, 512, [128490, 61670], "f086", "M192 0C86 0 0 71.6 0 160 0 192.7 11.8 223.1 32 248.5l0 119.5 89-59.3c22 7.3 45.9 11.3 71 11.3 106 0 192-71.6 192-160S298 0 192 0zm0 240c69.8 0 112-42.8 112-80l32 0c0 61.9-64.5 112-144 112l0-32zm217.9-34.7c-24.1 87.2-116.6 146.7-217.9 146.7-10.5 0-20.9-.6-31.2-1.9 8.7 72.9 83.8 129.9 175.2 129.9 26.9 0 52.5-5 75.3-13.8l68.7 45.8 0-93.2c20.2-23.4 32-52 32-82.8 0-57.9-41.8-107.9-102.1-130.7zm-2.6 173C424.4 365.5 432 350.2 432 336l32 0c0 53-57.3 96-128 96l0-32c29.1 0 54.2-8.9 71.3-21.7z"],
    "moon": [480, 512, [127769, 9214], "f186", "M240 16C107.5 16 0 123.5 0 256S107.5 496 240 496 480 388.5 480 256l-42.6 0c-22.3 56.2-77.2 96-141.4 96-83.9 0-152-68.1-152-152 0-64.2 39.8-119.1 96-141.4L240 16zM192 442C124.5 424.6 71.4 371.5 54 304l33.3 0C103 353.8 142.2 393 192 408.7l0 33.3z"],
    "plane": [512, 512, [], "f072", "M439.4 16c-15 0-29.4 6-40 16.6l-207.4 207.4-65.3 112-94.7 0-32 32 79 26.3-26.3 26.3 22.6 22.6 26.3-26.3 26.3 79 32-32 0-94.7 112-65.3 96 192 48-48-9-85.1 25.9-25.9c9.4-9.4 9.4-24.6 0-33.9-8.9-8.9-23-9.3-32.4-1.4l-12-114.2 90.9-90.9C490 102 496 87.6 496 72.6 496 41.3 470.7 16 439.4 16zM159 79l-25.9 25.9-85.1-9-48 48 161.8 80.9 105.8-105.8-73.2-7.7c7.9-9.4 7.4-23.5-1.4-32.4-9.4-9.4-24.6-9.4-33.9 0z"],
    "images": [512, 512, [], "f302", "M80 48l0 336 432 0 0-336-432 0zm48 288l0-240 336 0 0 240-336 0zM0 112l0 352 448 0 0-48-400 0 0-304-48 0zm160 16l0 176 56-56 40 40 80-80 96 96 0-176-272 0zm112 56a24 24 0 1 1 -48 0 24 24 0 1 1 48 0z"],
    "bag-shopping": [384, 512, ["shopping-bag"], "f290", "M192 0C121.3 0 64 57.3 64 128l-64 0 0 48 384 0 0-48-64 0C320 57.3 262.7 0 192 0zM112 128c0-44.2 35.8-80 80-80s80 35.8 80 80l-160 0zM0 208L0 480c0 17.7 14.3 32 32 32l320 0c17.7 0 32-14.3 32-32l0-272-384 0z"],
    "phone": [512, 512, [128222, 128379], "f095", "M407.7 .4L276.1 132 308.8 164.7 438.4 35.1c-9.3-12.4-19.6-24-30.7-34.7zm48.8 61.8l-125.1 125.1 36.7 36.7-144 144-36.7-36.7-125.1 125.1c29.2 17.2 61.6 29.3 96.2 35.3 47.3-7.8 92.5-26.4 131.9-54.6 56.7-40.5 106.3-90.1 146.8-146.8 28.2-39.4 46.7-84.6 54.6-131.9-6-34.6-18.2-67.1-35.3-96.2zM132.1 276L.5 407.6c10.7 11.1 22.3 21.4 34.7 30.7L164.8 308.7 132.1 276z"],
    "leaf": [480, 512, [], "f06c", "M16 32l0 272c0 106 86 192 192 192l16 0c40.2 0 78.2-9.2 112-25.7l0-55.9c0-25.5-10.1-49.9-28.1-67.9l-44.3-44.3c-15.6 11.1-34.6 17.6-55.1 17.7l-1.1 0c-34.5-.2-64.7-18.6-81.4-46l23.6-23.6c10 22.2 32.4 37.7 58.3 37.7 11.9 0 23-3.2 32.5-8.9L64 102.6 64 80 86.6 80 199.1 192.5c5.6-9.5 8.9-20.6 8.9-32.5 0-17.7-7.2-33.7-18.7-45.3l22.6-22.6c17.4 17.4 28.1 41.4 28.1 67.9 0 20.7-6.6 39.9-17.8 55.6L322.7 316.1c8.4-12.6 13.3-27.8 13.3-44.1 0-22.1-9-42.1-23.4-56.6l22.6-22.6c20.3 20.3 32.8 48.3 32.8 79.2 0 25.8-8.7 49.6-23.4 68.6 15.1 21.5 23.4 47.2 23.4 73.8l0 81.6 0 0 0 16 48 0 0-102.7c39.8-45.1 64-104.4 64-169.3l0-16c0-106-86-192-192-192L16 32z"],
    "universal-access": [512, 512, [], "f29a", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM48 256C48 141.1 141.1 48 256 48s208 93.1 208 208c0 92.5-60.4 171-144 198l0-170.1c0-6.4 2.5-12.5 7-17l57.9-57.9 0 0c.4-.4 .8-.8 1.1-1.1l28.4-28.4c-7.2-14.8-16.4-28.5-27.2-40.7l-35.1 35.1c-53.1 53.1-139.2 53.1-192.3 0l-35.1-35.1c-10.9 12.2-20.1 25.8-27.2 40.7l28.4 28.4c.4 .4 .8 .8 1.1 1.1l0 0 57.9 57.9c4.5 4.5 7 10.6 7 17L192 454C108.4 427 48 348.5 48 256zM256 88c-17.7 0-32 14.3-32 32l-16 0 0 24c0 26.5 21.5 48 48 48s48-21.5 48-48l0-56-48 0zM240 463.4l0-111.4 32 0 0 111.4c-5.3 .4-10.6 .6-16 .6s-10.7-.2-16-.6z"],
    "hourglass": [384, 512, [9203, 62032, "hourglass-empty"], "f254", "M0 0L0 48 384 48 384 0 0 0zM32 80l0 11c0 33.9 13.5 66.5 37.5 90.5l47.2 47.2c7.2 7.2 11.3 17.1 11.3 27.3s-4.1 20.1-11.3 27.3L69.5 330.5C45.5 354.5 32 387.1 32 421l0 11 64 0c0-53 43-96 96-96s96 43 96 96l64 0 0-11c0-33.9-13.5-66.5-37.5-90.5l-47.2-47.2c-7.2-7.2-11.3-17.1-11.3-27.3s4.1-20.1 11.3-27.3l47.2-47.2c24-24 37.5-56.6 37.5-90.5l0-11-320 0zM216 256a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zM0 464l0 48 384 0 0-48-384 0z"],
    "fish": [512, 512, [128031], "f578", "M272 0L160 0c0 53 43 96 96 96l6.6 0c-47.2 21.7-83.2 63.7-96.7 114.7L120 131.3 0 131.3 0 192c35.3 0 64 28.7 64 64S35.3 320 0 320l0 60.7 120 0 45.9-79.5C178 346.9 208 385.3 248 408.5l0 15.5c0 22.1-17.9 40-40 40l-32 0 0 48 32 0c47.5 0 86.1-37.6 87.9-84.6 12.9 3 26.3 4.6 40.1 4.6 19.6 0 38.4-3.2 56-9.1l0 1.1c0 22.1-17.9 40-40 40l-32 0 0 48 32 0c48.6 0 88-39.4 88-88l0-26c43.7-32 72-83.7 72-142 0-86.6-62.5-158.6-144.9-173.3-6.5-46.7-46.6-82.7-95.1-82.7zm80 216a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm112 0a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zM384 352c-35.3 0-64-28.7-64-64l128 0c0 35.3-28.7 64-64 64z"],
    "chart-simple": [480, 512, [], "e473", "M0 48l0 400 480 0 0-48-432 0 0-352-48 0zM224 80l0 288 112 0 0-288-112 0zm144 80l0 208 112 0 0-208-112 0zM80 208l0 160 112 0 0-160-112 0z"],
    "list": [512, 512, ["list-squares"], "f03a", "M64 72l-56 56 56 56 56-56-56-56zm96 24l0 64 320 0 0-64-320 0zM64 208a48 48 0 1 0 0 96 48 48 0 1 0 0-96zm96 16l0 64 320 0 0-64-320 0zM64 328l-56 56 56 56 56-56-56-56zm96 24l0 64 320 0 0-64-320 0z"],
    "headphones": [512, 512, [127911, 62863, "headphones-alt", "headphones-simple"], "f025", "M256 0C141.1 0 48 93.1 48 208l64 0c0-79.5 64.5-144 144-144s144 64.5 144 144l64 0C464 93.1 370.9 0 256 0zM0 240l0 48 112 0 0 32-112 0 0 176 112 0c26.5 0 48-21.5 48-48l0-160c0-26.5-21.5-48-48-48L0 240zm400 0c-26.5 0-48 21.5-48 48l0 160c0 26.5 21.5 48 48 48l112 0 0-176-112 0 0-32 112 0 0-48-112 0zM112 416a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm352 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z"],
    "bus": [512, 512, [128653], "f207", "M176 0l0 48 96 0c8.8 0 16 7.2 16 16s-7.2 16-16 16l-272 0 0 64 160 0 0 32-160 0 0 48 160 0 0 32-160 0 0 144 40.4 0c-.3 2.6-.4 5.3-.4 8 0 39.8 32.2 72 72 72s72-32.2 72-72c0-2.7-.1-5.4-.4-8l144.9 0c-.3 2.6-.4 5.3-.4 8 0 39.8 32.2 72 72 72s72-32.2 72-72c0-2.7-.1-5.4-.4-8l40.4 0 0-96-32 0 0-160 32 0 0-32c0-17.7-14.3-32-32-32L334 80c1.3-5.1 2-10.5 2-16 0-35.3-28.7-64-64-64L176 0zm32 256l0-112 112 0 0 112-112 0zm160 48l0-160 64 0 0 160-64 0zM136 408a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm288 0a24 24 0 1 1 -48 0 24 24 0 1 1 48 0z"],
    "quote-left": [448, 512, [8220, "quote-left-alt"], "f10d", "M96 80C43 80 0 123 0 176l0 256 192 0 0-224-96 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64 0 0-64-64 0zm256 0c-53 0-96 43-96 96l0 256 192 0 0-224-96 0c-17.7 0-32-14.3-32-32s14.3-32 32-32l64 0 0-64-64 0z"],
    "martini-glass": [416, 512, [127864, "glass-martini-alt"], "f57b", "M383.5-1l-97 97 67.9 0 63-63-33.9-33.9zM.5 128l0 32 184 184 0 120-104 0 0 48 256 0 0-48-104 0 0-120 184-184 0-32-416 0zm148.7 67.3l22.6-22.6 28.7 28.7 28.7-28.7 22.6 22.6-28.7 28.7 28.7 28.7-22.6 22.6-28.7-28.7-28.7 28.7-22.6-22.6 28.7-28.7-28.7-28.7z"],
    "rectangle-wide": [640, 512, [], "f2fc", "M640 432l-640 0 0-352 640 0 0 352zM48 128l0 256 32 0 0-224 512 0 0-32-544 0z"],
    "angle-down": [352, 512, [8964], "f107", "M0 160l0 32 176 176 176-176 0-32-352 0z"],
    "chart-pie": [480, 512, ["pie-chart"], "f200", "M256 16l0 224 224 0C480 116.3 379.7 16 256 16zM224 48C100.3 48 0 148.3 0 272S100.3 496 224 496 448 395.7 448 272l-144 0-80 80-80-80 80-80 0-144z"],
    "inbox": [448, 512, [], "f01c", "M0 32l0 336 160 0 0-64-96 0 0-208 320 0 0 208-96 0 0 64 160 0 0-336-448 0zM0 400l0 16c0 35.3 28.7 64 64 64l320 0c35.3 0 64-28.7 64-64l0-16-160 0c0 17.7-14.3 32-32 32l-64 0c-17.7 0-32-14.3-32-32L0 400z"],
    "credit-card": [512, 512, [128179, 62083, "credit-card-alt"], "f09d", "M48 80C21.5 80 0 101.5 0 128l0 32 512 0 0-32c0-26.5-21.5-48-48-48L48 80zM0 192L0 384c0 26.5 21.5 48 48 48l416 0c26.5 0 48-21.5 48-48l0-192-512 0zM48 336l48-48 48 48-48 48-48-48zm128 0l48-48 48 48-48 48-48-48z"],
    "wand-magic-sparkles": [512, 512, ["magic-wand-sparkles"], "e2ca", "M144 0L112.3 80.3 32 112 112.3 143.7 144 224 175.7 143.7 256 112 175.7 80.3 144 0zM419.7 35.7L359 96.4 415.6 153 476.3 92.3 419.7 35.7zM336.4 119L35.7 419.7 92.3 476.3 393 175.6 336.4 119zM400 256L368.3 336.3 288 368 368.3 399.7 400 480 431.7 399.7 512 368 431.7 336.3 400 256z"],
    "folders": [512, 512, [], "f660", "M80 0l0 320c0 35.3 28.7 64 64 64l304 0c35.3 0 64-28.7 64-64l0-240-352 0 0 240c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-272 208 0 0-48-256 0zM0 112L0 432c0 35.3 28.7 64 64 64l304 0c35.3 0 64-28.7 64-64l0-16-288 0c-24.6 0-47-9.2-64-24.4L80 432c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-111.9 0-.1 0-208-48 0z"],
    "star": [544, 512, [11088, 61446], "f005", "M272 0L172.6 145.6 4 195.6 111.2 335.5 106.4 512 272 452.8 437.6 512 432.8 335.5 540 195.6 371.4 145.6 272 0zM212.3 172.7l59.7-87.5 59.7 87.5 9.6 14.1 .2 .1-19.9 27.5-.3-.1-16.1-23.5-33.3-48.8-33.3 48.8-16.1 23.5-27.3 8.1-57.1 16.9 36.5 47.6 17.2 22.5-.8 28.3-1.6 59.3-33.3 46 2.9-106.2 .5-17-10.3-13.5-64.8-84.5 101.7-30.1 16.4-4.9 9.6-14.1z"],
    "flag": [512, 512, [127988, 61725], "f024", "M72 0c-26.5 0-48 21.5-48 48 0 17.8 9.7 33.3 24 41.6l0 422.4 48 0 0-112 416 0-80-160 80-160-404.2 0c7.6-8.5 12.2-19.7 12.2-32 0-26.5-21.5-48-48-48zM96 352l0-224 32 0 0 224-32 0z"],
    "triangle-exclamation": [512, 512, [9888, "exclamation-triangle", "warning"], "f071", "M256 16L0 480 512 480 256 16zM240 312l0-152 32 0 0 152-32 0zm-24 72l40-40 40 40-40 40-40-40z"],
    "lock": [384, 512, [128274], "f023", "M192 0C130.1 0 80 50.1 80 112l0 80-80 0 0 48 384 0 0-48-80 0 0-80C304 50.1 253.9 0 192 0zM128 112c0-35.3 28.7-64 64-64s64 28.7 64 64l0 80-128 0 0-80zM0 272l0 160 384 0 0-160-384 0zM0 464c0 26.5 21.5 48 48 48l288 0c26.5 0 48-21.5 48-48L0 464z"],
    "anchor": [448, 512, [9875], "f13d", "M224 0c-53 0-96 43-96 96 0 41.8 26.7 77.4 64 90.5l0 37.5-64 0 0 48 64 0 0 181c-39.8-7.7-74.6-29.4-99-59.8L128 288 0 288C0 411.7 100.3 512 224 512S448 411.7 448 288l-128 0 35 105.1c-24.4 30.4-59.2 52.1-99 59.8l0-181 64 0 0-48-64 0 0-37.5c37.3-13.2 64-48.7 64-90.5 0-53-43-96-96-96zM168 96l56-56 56 56-56 56-56-56z"],
    "scissors": [512, 512, [9984, 9986, 9988, "cut"], "f0c4", "M272 0c-35.3 0-64 28.7-64 64l0 160-41.6 0c-14.6-28.5-44.2-48-78.4-48-48.6 0-88 39.4-88 88s39.4 88 88 88c34.2 0 63.8-19.5 78.4-48l41.6 0 0 41.6c-28.5 14.6-48 44.2-48 78.4 0 48.6 39.4 88 88 88s88-39.4 88-88c0-34.2-19.5-63.8-48-78.4L288 0 272 0zM72 248l0-32 32 0 0 32 32 0 0 32-32 0 0 32-32 0 0-32-32 0 0-32 32 0zm248-24l0 80 128 0c35.3 0 64-28.7 64-64l0-16-192 0zM200 424l48-48 48 48-48 48-48-48z"],
    "bug": [480, 512, [], "f188", "M104 0l-56 56 56 56 28.9-28.9 10.9 2.2C162.5 89 176 105.4 176 124.5l0 4.2C77.4 136.8 0 219.3 0 320 0 426 86 512 192 512l32 0 0-387.5c0-41.9-29.6-78.1-70.7-86.3L139.4 35.4 104 0zM376 0l-35.4 35.4-13.9 2.8C285.6 46.4 256 82.5 256 124.5l0 387.5 32 0c106 0 192-86 192-192 0-100.7-77.4-183.2-176-191.3l0-4.2c0-19.1 13.5-35.5 32.2-39.2l10.9-2.2 28.9 28.9 56-56-56-56zM176 240a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm192 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM112 320a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm320 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zM176 400a32 32 0 1 1 -64 0 32 32 0 1 1 64 0zm192 0a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z"],
    "arrow-right-from-bracket": [512, 512, ["sign-out"], "f08b", "M0 32l0 448 112 0 0-64-48 0 0-320 48 0 0-64-112 0zm336 80l0 112-112 0 0 64 112 0 0 112 32 0 144-144-144-144-32 0zM144 208l-48 48 48 48 48-48-48-48z"],
    "arrow-right-arrow-left": [512, 512, [8644, "exchange"], "f0ec", "M144 0l-144 144 144 144 32 0 0-112 192 0 0-64-192 0 0-112-32 0zM448 96l-48 48 48 48 48-48-48-48zM336 224l0 112-192 0 0 64 192 0 0 112 32 0 144-144-144-144-32 0zM64 320l-48 48 48 48 48-48-48-48z"],
    "arrow-up-from-line": [384, 512, [8613, "arrow-from-bottom"], "f342", "M192 32l-144 144 0 32 112 0 0 112 64 0 0-112 112 0 0-32-144-144zM0 352l0 64c0 35.3 28.7 64 64 64l256 0c35.3 0 64-28.7 64-64l0-64-296 0 0 72-32 0 0-72-56 0z"],
    "battery-full": [512, 512, [128267, "battery", "battery-5"], "f240", "M432 416l-432 0 0-320 432 0 0 320zm80-96l-48 0 0-128 48 0 0 128z"],
    "font": [448, 512, [], "f031", "M160 32l-160 448 112 0 32-96 160 0 32 96 112 0-160-448-128 0zm-3.3 171.3l22.6-22.6 44.7 44.7 44.7-44.7 22.6 22.6-44.7 44.7 44.7 44.7-22.6 22.6-44.7-44.7-44.7 44.7-22.6-22.6 44.7-44.7-44.7-44.7z"],
    "language": [512, 512, [], "f1ab", "M0 64l0 384 512 0 0-384-512 0zM256 400l0-288 208 0 0 288-208 0zm88-256l0 32-56 0 0 32 111 0c-3.8 31.9-18.8 59.6-39 79.5-13.1-12.9-24-29.1-31.1-47.5l-33.7 0c7.8 25.7 21.6 48.7 39.1 67-14.8 8.3-30.7 13-46.3 13l0 32c25.4 0 50.2-8.5 72-23.2 21.8 14.7 46.6 23.2 72 23.2l0-32c-15.6 0-31.5-4.6-46.3-13 27.9-29.2 46.3-70.1 46.3-115l0-16-56 0 0-32-32 0zM49.2 352l53.3-192 51 0 53.3 192-33.2 0-8.9-32-73.5 0-8.9 32-33.2 0zM128 187.8L100.2 288 155.8 288 128 187.8z"],
    "person-biking": [512, 512, [128692, "biking"], "f84a", "M336 0c-17.7 0-32 14.3-32 32l-32 0 0 48c0 35.3 28.7 64 64 64s64-28.7 64-64l0-80-64 0zM175.2 143.2L145.9 210c-14.3 32.7 5.3 70.3 40.3 77.4l1 .2c1.6 .3 3.1 .5 4.7 .5l61.4 0-27.7 74c-9.8 26.2 9.5 54 37.5 54l43.7 0c10.8 45.9 52 80 101.2 80 57.4 0 104-46.6 104-104S465.4 288 408 288c-49.2 0-90.4 34.1-101.2 80l-32.2 0 31.8-84.8c7.8-20.9-7.6-43.2-30-43.2l-49.8 0 23.8-63.5 81.5 69.8c7.2 6.2 16.5 9.6 26 9.6l50.1 0 0-48-47.1 0-105.3-90.2c-2.8-2.4-6.2-4.2-9.8-5.1l-5.8-1.4c-26.5-6.6-53.9 6.8-64.9 31.9zM104 288a104 104 0 1 0 0 208 104 104 0 1 0 0-208zM48 392c0-30.9 25.1-56 56-56l0 32c-13.3 0-24 10.7-24 24s10.7 24 24 24 24-10.7 24-24l32 0c0 30.9-25.1 56-56 56s-56-25.1-56-56zm360-24l0-32c30.9 0 56 25.1 56 56s-25.1 56-56 56-56-25.1-56-56l32 0c0 13.3 10.7 24 24 24s24-10.7 24-24-10.7-24-24-24z"],
    "globe": [512, 512, [127760], "f0ac", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM464 256a208 208 0 1 1 -416 0 208 208 0 1 1 416 0zM256 80c-6.5 0-22.5 7.1-38.8 42.3-13.5 29.3-23.1 70.5-24.9 117.7l127.4 0c-1.8-47.2-11.4-88.4-24.9-117.7-16.3-35.3-32.3-42.3-38.8-42.3zm-57.6 9.7C134.3 111.9 87 170 80.7 240l79.6 0c2.2-61.4 16.6-115.4 38.1-150.3zm115.3 0c21.4 34.9 35.9 88.9 38.1 150.3l79.6 0C425 170 377.7 111.9 313.6 89.7zM80.7 272c6.3 70 53.6 128.1 117.6 150.3-21.4-34.9-35.9-88.9-38.1-150.3l-79.6 0zm111.6 0c1.8 47.2 11.4 88.4 24.9 117.7 16.3 35.3 32.3 42.3 38.8 42.3s22.5-7.1 38.8-42.3c13.5-29.3 23.1-70.5 24.9-117.7l-127.4 0zm159.4 0c-2.2 61.4-16.6 115.4-38.1 150.3 64.1-22.2 111.3-80.4 117.6-150.3l-79.6 0z"],
    "battery-quarter": [512, 512, ["battery-2"], "f243", "M432 416l-432 0 0-320 432 0 0 320zM128 368l256 0 0-224-256 0 0 224zm384-48l-48 0 0-128 48 0 0 128z"],
    "arrow-left": [480, 512, [8592], "f060", "M160 96l-160 160 160 160 32 0 0-128 160 0 0-64-160 0 0-128-32 0zM432 208l-48 48 48 48 48-48-48-48z"],
    "paw": [512, 512, [], "f1b0", "M168 16a72 72 0 1 0 0 144 72 72 0 1 0 0-144zm176 0a72 72 0 1 0 0 144 72 72 0 1 0 0-144zM0 224a64 64 0 1 0 128 0 64 64 0 1 0 -128 0zm448-64a64 64 0 1 0 0 128 64 64 0 1 0 0-128zm-192 8.2l-67.9 67.9-88 88c-37.5 37.5-37.5 98.3 0 135.8s98.3 37.5 135.8 0l20.1-20.1 20.1 20.1c37.5 37.5 98.3 37.5 135.8 0s37.5-98.3 0-135.8l-88-88-67.9-67.9zM204.7 307.3l22.6-22.6 28.7 28.7 28.7-28.7 22.6 22.6-28.7 28.7 28.7 28.7-22.6 22.6-28.7-28.7-28.7 28.7-22.6-22.6 28.7-28.7-28.7-28.7z"],
    "bed": [512, 512, [128716], "f236", "M40 64l-40 40 40 40 40-40-40-40zM16 160l0 272 48 0 0-32c0-8.8 7.2-16 16-16l352 0c8.8 0 16 7.2 16 16l0 32 48 0 0-112-432 0 0-160-48 0zm128 0c-26.5 0-48 21.5-48 48l0 80 96 0 0-80c0-26.5-21.5-48-48-48zm128 16c-26.5 0-48 21.5-48 48l0 64 272 0 0-64c0-26.5-21.5-48-48-48l-176 0z"],
    "landmark": [512, 512, [127963], "f66f", "M256 32l-256 128 0 48 64 0 0 144-32 0 0 48 448 0 0-48-32 0 0-144 64 0 0-48-256-128zM216 136l40-40 40 40-40 40-40-40zM112 352l0-144 64 0 0 144-64 0zm112 0l0-144 64 0 0 144-64 0zm112 0l0-144 64 0 0 144-64 0zM0 432l0 48 512 0 0-48-512 0z"],
    "music": [512, 512, [127925], "f001", "M160 32l0 48 320 0 0-48-320 0zm0 80l0 160.3C143.8 262 124.6 256 104 256 46.6 256 0 302.6 0 360s46.6 104 104 104 104-46.6 104-104l0-168 224 0 0 128.3c-16.2-10.3-35.4-16.3-56-16.3-57.4 0-104 46.6-104 104s46.6 104 104 104 104-46.6 104-104l0-296-320 0z"],
    "files": [416, 512, [], "e178", "M80 0l0 432 336 0 0-288-144-144-192 0zM248 168l0-120 4.1 0 115.9 115.9 0 4.1-120 0zM0 80l0 432 336 0 0-48-288 0 0-384-48 0zM144 264l56-56 56 56-56 56-56-56zm200 80a32 32 0 1 1 -64 0 32 32 0 1 1 64 0z"],
    "plus": [448, 512, [10133, 61543, "add"], "2b", "M144 32l0 144-144 0 0 160 144 0 0 144 160 0 0-144 144 0 0-160-144 0 0-144-160 0zm64 208l0-160 32 0 0 192-192 0 0-32 160 0z"],
    "box": [448, 512, [128230], "f466", "M64 48l-64 128 0 32 208 0 0-160-144 0zm176 0l0 160 208 0 0-32-64-128-144 0zM0 240l0 224 448 0 0-224-448 0zM288 416l0-64 112 0 0 64-112 0z"],
    "arrow-rotate-right": [512, 512, [8635, "arrow-right-rotate", "arrow-rotate-forward", "redo"], "f01e", "M336 64l0 112-176 0C89.3 176 32 233.3 32 304S89.3 432 160 432l8 0 0-64-8 0c-35.3 0-64-28.7-64-64s28.7-64 64-64l176 0 0 112 32 0 144-144-144-144-32 0zM256 344l-56 56 56 56 56-56-56-56z"],
    "arrow-down-wide-short": [512, 512, ["sort-amount-asc", "sort-amount-down"], "f160", "M128 16l-48 48 48 48 48-48-48-48zm80 16l0 64 304 0 0-64-304 0zM96 144l0 224-96 0 0 16 128 128 128-128 0-16-96 0 0-224-64 0zm112 0l0 64 208 0 0-64-208 0zm0 112l0 64 112 0 0-64-112 0z"],
    "compress": [480, 512, [], "f066", "M46.8 17.4l-45.3 45.3 72 72-57.4 57.4 16 16 160 0 0-160-16-16-57.4 57.4-72-72zm386.7 0l-72 72-57.4-57.4-16 16 0 160 160 0 16-16-57.4-57.4 72-72-45.3-45.3zM32.1 304l-16 16 57.4 57.4-72 72 45.3 45.3 72-72 57.4 57.4 16-16 0-160-160 0zm256 0l0 160 16 16 57.4-57.4 72 72 45.3-45.3-72-72 57.4-57.4-16-16-160 0z"],
    "eye-slash": [512, 512, [], "f070", "M228 4l0 61.9c-21.4 2.9-41.5 8.9-60.1 17.2l38 38c15.6-5.8 32.5-9 50.2-9 79.5 0 144 64.5 144 144 0 17.6-3.2 34.5-9 50.2l50.7 50.7c34.9-37.4 58.6-77.4 70.3-100.9-9.9-19.9-28.5-51.6-55.1-83.6l7.1-4.1 24.2-14-28-48.5-24.2 14-19.1 11.1c-12-10.7-25.1-20.8-39.1-29.7l14.5-25.1 14-24.2-48.5-28-30.4 52.6c-13.8-4.9-28.2-8.5-43.4-10.5L284 4 228 4zM43.8 4.2l-39.6 39.6 464 464 39.6-39.6-464-464zM256 144c-8.4 0-16.6 .9-24.5 2.7l74.9 74.9 36.4-36.4C322.3 160.1 291 144 256 144zM70.3 155.1c-34.9 37.4-58.6 77.4-70.3 100.9 26.7 53.3 115.2 192 256 192 32.1 0 61.6-7.2 88.1-19l-38-38c-15.6 5.8-32.5 9-50.2 9-79.5 0-144-64.5-144-144 0-17.6 3.2-34.5 9-50.2L70.3 155.1zm76.4 76.4c-1.8 7.9-2.7 16.1-2.7 24.5 0 61.9 50.1 112 112 112 8.4 0 16.6-.9 24.5-2.7L146.7 231.5z"],
    "mug-hot": [512, 512, [9749], "f7b6", "M160 0C89.3 0 32 57.3 32 128l56 0c0-44.2 35.8-80 80-80l24 0c26.5 0 48-21.5 48-48L160 0zM272 0c0 44.2-35.8 80-80 80l-24 0c-26.5 0-48 21.5-48 48l80 0c70.7 0 128-57.3 128-128L272 0zM32 160l0 48 352 0c44.2 0 80 35.8 80 80s-35.8 80-80 80l0-128-264 0 0 216-32 0 0-216-56 0 0 208c0 35.3 28.7 64 64 64l224 0c35.3 0 64-28.7 64-64l0-32c70.7 0 128-57.3 128-128S454.7 160 384 160L32 160z"],
    "bolt": [512, 512, [9889, "zap"], "f0e7", "M512 0L120.5 97.9 427.7 405.1 512 384 320 192 512 0zM84.3 106.9L0 128 192 320 0 512 391.5 414.1 84.3 106.9z"],
    "arrow-rotate-left": [512, 512, [8634, "arrow-left-rotate", "arrow-rotate-back", "arrow-rotate-backward", "undo"], "f0e2", "M144 64l-144 144 144 144 32 0 0-112 176 0c35.3 0 64 28.7 64 64s-28.7 64-64 64l-8 0 0 64 8 0c70.7 0 128-57.3 128-128S422.7 176 352 176l-176 0 0-112-32 0zM256 344l-56 56 56 56 56-56-56-56z"],
    "wifi": [512, 512, ["wifi-3", "wifi-strong"], "f1eb", "M256.2 80C155.4 80 65.1 124.3 3.5 194.5l64.2 48.2C114.5 191.9 181.6 160 256.2 160s141.6 31.9 188.4 82.7l64.2-48.2C447.2 124.3 356.9 80 256.2 80zm0 128c-58.8 0-111.9 24.4-149.8 63.7l64.8 48.6c22.6-20.1 52.4-32.3 85-32.3s62.4 12.2 85 32.3l64.8-48.6C368.1 232.4 315 208 256.2 208zm0 112l-64 64 64 64 64-64-64-64z"],
    "volume": [512, 512, [128265, "volume-medium"], "f6a8", "M272 48l-112 112-64 0c-53 0-96 43-96 96s43 96 96 96l64 0 112 112 48 0 0-416-48 0zm189.6 66.4l-34.2 34.2c22.9 29.7 36.6 67 36.6 107.4s-13.6 77.7-36.6 107.4l34.2 34.2C493.1 359 512 309.7 512 256s-18.9-103-50.4-141.6zm-57 57L370 206c8.9 14.6 14 31.7 14 50s-5.1 35.4-14 50l34.6 34.6c17.3-23.7 27.4-53 27.4-84.6s-10.2-60.8-27.4-84.6z"],
    "tag": [512, 512, [127991], "f02b", "M32 32L32 256 228.7 452.7 452.7 228.7 256 32 32 32zM192 144a48 48 0 1 1 -96 0 48 48 0 1 1 96 0zM475.3 251.3l-224 224 36.7 36.7 224-224-36.7-36.7z"],
    "compact-disc": [512, 512, [128191, 128192, 128440], "f51f", "M256 512a256 256 0 1 1 0-512 256 256 0 1 1 0 512zM416 256c0 88.4-71.6 160-160 160l0 32c106 0 192-86 192-192l-32 0zm-224 0l64 64 64-64-64-64-64 64zM256 64C150 64 64 150 64 256l32 0c0-88.4 71.6-160 160-160l0-32z"],
    "phone-slash": [512, 512, [], "f3dd", "M407.7 .4L276.1 132 308.8 164.7 438.4 35.1c-9.3-12.4-19.6-24-30.7-34.7zM43.9 4.2l-39.6 39.6 464 464 39.6-39.6-464-464zm412.6 58l-125.1 125.1 36.7 36.7-29.6 29.6 71.8 71.8c9.4-11.4 18.4-23 26.9-35 28.2-39.4 46.7-84.6 54.6-131.9-6-34.6-18.2-67.1-35.3-96.2zM132.1 276L.5 407.6c10.7 11.1 22.3 21.4 34.7 30.7L164.8 308.7 132.1 276zm55.3 55.3L62.3 456.4c29.2 17.2 61.6 29.3 96.2 35.3 47.3-7.8 92.5-26.4 131.9-54.6 12-8.6 23.7-17.6 35-26.9l-71.8-71.8-29.6 29.6-36.7-36.7z"],
    "arrow-up-right-from-square": [512, 512, ["external-link"], "f08e", "M336 16l0 112-96 0c-53 0-96 43-96 96l0 32 64 0 0-32c0-17.7 14.3-32 32-32l96 0 0 112 32 0 144-144-144-144-32 0zM32 32l0 448 448 0 0-160-64 0 0 96-320 0 0-320 96 0 0-64-160 0zM176 288l-48 48 48 48 48-48-48-48z"],
    "rectangle-tall": [352, 512, [], "e791", "M352 576l-352 0 0-640 352 0 0 640zM48-16l0 544 32 0 0-512 224 0 0-32-256 0z"],
    "compass": [512, 512, [129517], "f14e", "M72 0C32.2 0 0 32.2 0 72 0 97 12.7 119 32 131.9 11.6 168.7 0 211 0 256 0 397.4 114.6 512 256 512S512 397.4 512 256 397.4 0 256 0C211 0 168.7 11.6 131.9 32 119 12.7 97 0 72 0zM96 72a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zM240 96l0-48 32 0 0 48-32 0zm-57.5 86.5l220.6-73.5-73.5 220.6-220.6 73.5 73.5-220.6zM233 199l-33.9 33.9 23 23-23 23 33.9 33.9 23-23 23 23 33.9-33.9-23-23 23-23-33.9-33.9-23 23-23-23zM48 272l0-32 48 0 0 32-48 0zm368 0l0-32 48 0 0 32-48 0zM240 464l0-48 32 0 0 48-32 0z"],
    "square": [448, 512, [9632, 9723, 9724, 61590], "f0c8", "M0 32l0 448 448 0 0-448-448 0zM48 96l0-16 352 0 0 32-320 0 0 320-32 0 0-336z"],
    "face-grin": [512, 512, [128512, "grin"], "f580", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM132.7 131.3l22.6-22.6 56 56 11.3 11.3-11.3 11.3-56 56-22.6-22.6 44.7-44.7-44.7-44.7zm168 33.4l56-56 22.6 22.6-44.7 44.7 44.7 44.7-22.6 22.6-67.3-67.3 11.3-11.3zM256 432c-79.5 0-144-64.5-144-144l288 0c0 79.5-64.5 144-144 144z"],
    "angle-up": [352, 512, [8963], "f106", "M176 144l-176 176 0 32 352 0 0-32-176-176z"],
    "face-smile": [512, 512, [128578, "smile"], "f118", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM120 192c0-26.5 21.5-48 48-48l64 0-48 48 48 48-64 0c-26.5 0-48-21.5-48-48zm160 0c0-26.5 21.5-48 48-48l64 0-48 48 48 48-64 0c-26.5 0-48-21.5-48-48zM107.4 315.4l29.7-11.9C156 350.7 202.1 384 256 384s100-33.3 118.9-80.4l29.7 11.9C381 374.4 323.4 416 256 416S131 374.4 107.4 315.4z"],
    "umbrella": [480, 512, [], "f0e9", "M208 0l0 34.1C90.6 49.8 0 150.3 0 272l208 0 0 160c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-16-64 0 0 16c0 44.2 35.8 80 80 80s80-35.8 80-80l0-160 208 0c0-121.7-90.6-222.2-208-237.9L272 0 208 0zM68.2 186.1C99.8 123.2 164.8 80 240 80l0 32c-62.6 0-116.9 36-143.1 88.4L68.2 186.1z"],
    "pause": [256, 512, [9208], "f04c", "M0 80l0 352 96 0 0-352-96 0zm160 0l0 352 96 0 0-352-96 0z"],
    "desktop": [512, 512, [128421, 61704, "desktop-alt"], "f390", "M0 16l0 384 160 0 0 48-48 0c-26.5 0-48 21.5-48 48l0 16 384 0 0-16c0-26.5-21.5-48-48-48l-48 0 0-48 160 0 0-384-512 0zM48 96l0-32 416 0 0 288-416 0 0-256zm32 0l0 224 352 0 0-224-352 0zM216 432l40-40 40 40-40 40-40-40z"],
    "arrow-down": [320, 512, [8595], "f063", "M160 16l-48 48 48 48 48-48-48-48zM128 144l0 160-128 0 0 32 160 160 160-160 0-32-128 0 0-160-64 0z"],
    "location-dot": [384, 512, ["map-marker-alt"], "f3c5", "M192 0C86 0 0 86 0 192l0 6.4c0 42.5 14.1 83.9 40.2 117.5L192 512 343.8 315.9c26-33.6 40.2-75 40.2-117.5l0-6.4C384 86 298 0 192 0zM336 192a144 144 0 1 1 -288 0 144 144 0 1 1 288 0zM192 80a112 112 0 1 0 0 224 112 112 0 1 0 0-224z"],
    "bars": [448, 512, ["navicon"], "f0c9", "M0 96l0 64 448 0 0-64-448 0zM0 224l0 64 448 0 0-64-448 0zM0 352l0 64 448 0 0-64-448 0z"],
    "battery-empty": [512, 512, ["battery-0"], "f244", "M432 416l-432 0 0-320 432 0 0 320zM48 368l336 0 0-224-336 0 0 224zm464-48l-48 0 0-128 48 0 0 128z"],
    "stopwatch": [480, 512, [9201], "f2f2", "M160.1 0c0 16.6 8.4 31.2 21.2 39.8-19.5 5.3-38 13.2-55 23.2L87.7 24.4 8.5 103.6 47.1 142.2c-19.7 33.3-31 72.2-31 113.8 0 123.7 100.3 224 224 224s224-100.3 224-224c0-41.5-11.3-80.4-31-113.8l38.6-38.6-79.2-79.2-38.6 38.6c-17-10-35.5-17.9-55-23.2 12.8-8.6 21.2-23.2 21.2-39.8l-160 0zM415.9 256a175.9 175.9 0 1 1 -351.8 0 175.9 175.9 0 1 1 351.8 0zM240.1 112a144 144 0 1 0 -.2 288 144 144 0 1 0 .2-288zm-16 160l0-112 32 0 0 112-32 0z"],
    "train": [512, 512, [128646], "f238", "M72 40C58.7 40 48 50.7 48 64l-48 0 0 64 48 0 0 32-48 0 0 128 400 0 0 32-400 0 0 80 112.4 0c-.3 2.6-.4 5.3-.4 8 0 39.8 32.2 72 72 72 18.4 0 35.3-6.9 48-18.3 12.7 11.4 29.6 18.3 48 18.3s35.3-6.9 48-18.3c12.7 11.4 29.6 18.3 48 18.3 39.8 0 72-32.2 72-72 0-2.7-.1-5.4-.4-8l64.4 0 0-144c0-53-43-96-96-96l-16 0 0-32c0-35.3-28.7-64-64-64l-96 0c0-13.3-10.7-24-24-24s-24 10.7-24 24L96 64c0-13.3-10.7-24-24-24zM96 160l0-32 96 0 0 32-96 0zm144 0l0-32 96 0 0 32-96 0zM208 408a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm96 0a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm96 0a24 24 0 1 1 -48 0 24 24 0 1 1 48 0z"],
    "gamepad": [512, 512, [], "f11b", "M80 48l0 32-16 0C28.7 80 0 108.7 0 144L0 400c0 35.3 28.7 64 64 64s64-28.7 64-64l256 0c0 35.3 28.7 64 64 64s64-28.7 64-64l0-256c0-35.3-28.7-64-64-64l-16 0 0-32-128 0 0 32-96 0 0-32-128 0zm48 176l0-64 32 0 0 64 64 0 0 32-64 0 0 64-32 0 0-64-64 0 0-32 64 0zm160 16l80-80 80 80-80 80-80-80zm80-32a32 32 0 1 0 0 64 32 32 0 1 0 0-64z"],
    "ship": [512, 512, [128674], "f21a", "M160 32l0 48 48 0 0 32-112 0 0 144 224 0 0 32-320 0 0 192 48 0 0-32 32 0 0 32 272 0c88.4 0 160-71.6 160-160l0-64-64 0-80-144-80 0-40-80-88 0zm32 152a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm80 0a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm80 0a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm16 232c-44.2 0-80-35.8-80-80l32 0c0 26.5 21.5 48 48 48s48-21.5 48-48l32 0c0 44.2-35.8 80-80 80z"],
    "arrows-rotate": [448, 512, [128472, "refresh", "sync"], "f021", "M224 32C100.3 32 0 132.3 0 256l64 0c0-88.4 71.6-160 160-160 44.2 0 84.2 17.9 113.1 46.9l-65.1 65.1 16 16 160 0 0-160-16-16-49.6 49.6C341.9 57.1 285.9 32 224 32zM383.2 272c-8 80.9-76.2 144-159.2 144-40.1 0-76.8-14.8-104.9-39.1l56.9-56.9-16-16-160 0 0 160 16 16 57.8-57.8c39.7 35.9 92.4 57.8 150.2 57.8 118.3 0 215.2-91.8 223.4-208l-64.2 0z"],
    "book-open": [512, 512, [128214, 128366], "f518", "M0 32l0 320 200 0c14.8 0 28.6 4.5 40 12.1L240 112c0-44.2-35.8-80-80-80L0 32zm352 0c-44.2 0-80 35.8-80 80l0 252.1c11.4-7.7 25.2-12.1 40-12.1l200 0 0-320-160 0zM0 384l0 48 192 0 0 16c0 35.3 28.7 64 64 64s64-28.7 64-64l0-16 192 0 0-48-200 0c-22.1 0-40 17.9-40 40l0 24c0 8.8-7.2 16-16 16s-16-7.2-16-16l0-24c0-22.1-17.9-40-40-40L0 384z"],
    "box-archive": [480, 512, ["archive"], "f187", "M0 48l0 80 480 0 0-80-480 0zM32 160l0 304 416 0 0-304-416 0zM240 288c-44.2 0-80-35.8-80-80l32 0c0 26.5 21.5 48 48 48s48-21.5 48-48l32 0c0 44.2-35.8 80-80 80z"],
    "glass-citrus": [512, 512, [], "f869", "M408 0c-54.7 0-99.6 42.3-103.7 96l56.4 0c3.8-22.7 23.6-40 47.3-40 26.5 0 48 21.5 48 48 0 23.8-17.3 43.5-40 47.3l0 56.4c53.7-4.1 96-49 96-103.7 0-57.4-46.6-104-104-104zM64 128l0 48 320 0 0-48-320 0zm0 80l0 224c0 35.3 28.7 64 64 64l192 0c35.3 0 64-28.7 64-64l0-224-232 0 0 232-32 0 0-232-56 0z"],
    "cake-candles": [480, 512, [127874, "birthday-cake", "cake"], "f1fd", "M136 0L112.1 35.9c-5.3 7.9-8.1 17.1-8.1 26.6l0 1.5c0 17.7 14.3 32 32 32s32-14.3 32-32l0-1.5c0-9.5-2.8-18.7-8.1-26.6L136 0zM240 0L216.1 35.9c-5.3 7.9-8.1 17.1-8.1 26.6l0 1.5c0 17.7 14.3 32 32 32s32-14.3 32-32l0-1.5c0-9.5-2.8-18.7-8.1-26.6L240 0zM344 0L320.1 35.9c-5.3 7.9-8.1 17.1-8.1 26.6l0 1.5c0 17.7 14.3 32 32 32s32-14.3 32-32l0-1.5c0-9.5-2.8-18.7-8.1-26.6L344 0zM112 112l0 96 48 0 0-96-48 0zm104 0l0 96 48 0 0-96-48 0zm104 0l0 96 48 0 0-96-48 0zM32 240l0 192 416 0 0-192-336 0 0 128-32 0 0-128-48 0zM0 464l0 48 480 0 0-48-480 0z"],
    "circle-info": [512, 512, ["info-circle"], "f05a", "M256 0a256 256 0 1 0 0 512 256 256 0 1 0 0-512zM464 256a208 208 0 1 1 -416 0 208 208 0 1 1 416 0zM256 80a176 176 0 1 0 0 352 176 176 0 1 0 0-352zm-40 80l40-40 40 40-40 40-40-40zm24 224l0-152 32 0 0 152-32 0z"],
    "layer-group": [512, 512, [], "f5fd", "M256 0L0 128 256 256 512 128 256 0zM92.2 209.9L53.7 229.2 0 256 53.7 282.8 256 384 458.3 282.8 512 256 458.3 229.2 419.8 209.9 366.1 236.7 404.7 256 256 330.3 107.3 256 145.9 236.7 92.2 209.9zm0 128L53.7 357.2 0 384 53.7 410.8 256 512 458.3 410.8 512 384 458.3 357.2 419.8 337.9 366.1 364.7 404.7 384 256 458.3 107.3 384 145.9 364.7 92.2 337.9z"],
    "shield": [448, 512, [128737, "shield-blank"], "f132", "M0 32l0 48 448 0 0-48-448 0zm0 80L0 222C0 331.1 61.6 430.8 159.2 479.6L224 512 288.8 479.6C386.4 430.8 448 331.1 448 222l0-110-448 0zM144 256l80-80 80 80-80 80-80-80z"],
    "cart-shopping": [512, 512, [128722, "shopping-cart"], "f07a", "M0 48l0 48 24 0c13.3 0 24 10.7 24 24l0 56 192 0 0 32-192 0 0 48 128 0 0 32-128 0 0 64c0 35.3 28.7 64 64 64l304 0 0-48-304 0c-8.8 0-16-7.2-16-16s7.2-16 16-16l304 0c35.3 0 64-28.7 64-64l0-144-384 0 0-8c0-39.8-32.2-72-72-72L0 48zM136 432a40 40 0 1 0 0 80 40 40 0 1 0 0-80zm240 0a40 40 0 1 0 0 80 40 40 0 1 0 0-80z"]
  };

  bunker(function () {
    defineIcons('fams', icons);
  });

}());
