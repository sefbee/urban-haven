/*!
 * Font Awesome Pro 7.3.0 by @fontawesome - https://fontawesome.com
 * License - https://fontawesome.com/license (Commercial License)
 * Copyright 2026 Fonticons, Inc.
 */
(function () {
  'use strict';

  var _WINDOW = {};
  var _DOCUMENT = {};
  try {
    if (typeof window !== 'undefined') _WINDOW = window;
    if (typeof document !== 'undefined') _DOCUMENT = document;
  } catch (e) {} // eslint-disable-line no-empty

  var _ref = _WINDOW.navigator || {},
    _ref$userAgent = _ref.userAgent,
    userAgent = _ref$userAgent === void 0 ? '' : _ref$userAgent;
  var WINDOW = _WINDOW;
  var DOCUMENT = _DOCUMENT;
  var IS_BROWSER = !!WINDOW.document;
  var IS_DOM = !!DOCUMENT.documentElement && !!DOCUMENT.head && typeof DOCUMENT.addEventListener === 'function' && typeof DOCUMENT.createElement === 'function';
  var IS_IE = ~userAgent.indexOf('MSIE') || ~userAgent.indexOf('Trident/');

  function _arrayLikeToArray(r, a) {
    (null == a || a > r.length) && (a = r.length);
    for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
    return n;
  }
  function _arrayWithoutHoles(r) {
    if (Array.isArray(r)) return _arrayLikeToArray(r);
  }
  function _defineProperty(e, r, t) {
    return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
      value: t,
      enumerable: !0,
      configurable: !0,
      writable: !0
    }) : e[r] = t, e;
  }
  function _iterableToArray(r) {
    if ("undefined" != typeof Symbol && null != r[Symbol.iterator] || null != r["@@iterator"]) return Array.from(r);
  }
  function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
  }
  function ownKeys(e, r) {
    var t = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
      var o = Object.getOwnPropertySymbols(e);
      r && (o = o.filter(function (r) {
        return Object.getOwnPropertyDescriptor(e, r).enumerable;
      })), t.push.apply(t, o);
    }
    return t;
  }
  function _objectSpread2(e) {
    for (var r = 1; r < arguments.length; r++) {
      var t = null != arguments[r] ? arguments[r] : {};
      r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
        _defineProperty(e, r, t[r]);
      }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
        Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
      });
    }
    return e;
  }
  function _toConsumableArray(r) {
    return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
  }
  function _toPrimitive(t, r) {
    if ("object" != typeof t || !t) return t;
    var e = t[Symbol.toPrimitive];
    if (void 0 !== e) {
      var i = e.call(t, r || "default");
      if ("object" != typeof i) return i;
      throw new TypeError("@@toPrimitive must return a primitive value.");
    }
    return ("string" === r ? String : Number)(t);
  }
  function _toPropertyKey(t) {
    var i = _toPrimitive(t, "string");
    return "symbol" == typeof i ? i : i + "";
  }
  function _unsupportedIterableToArray(r, a) {
    if (r) {
      if ("string" == typeof r) return _arrayLikeToArray(r, a);
      var t = {}.toString.call(r).slice(8, -1);
      return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
    }
  }

  var _cl;
  var rl = {
      classic: {
        fa: "solid",
        fas: "solid",
        "fa-solid": "solid",
        far: "regular",
        "fa-regular": "regular",
        fal: "light",
        "fa-light": "light",
        fat: "thin",
        "fa-thin": "thin",
        fab: "brands",
        "fa-brands": "brands"
      },
      duotone: {
        fa: "solid",
        fad: "solid",
        "fa-solid": "solid",
        "fa-duotone": "solid",
        fadr: "regular",
        "fa-regular": "regular",
        fadl: "light",
        "fa-light": "light",
        fadt: "thin",
        "fa-thin": "thin"
      },
      sharp: {
        fa: "solid",
        fass: "solid",
        "fa-solid": "solid",
        fasr: "regular",
        "fa-regular": "regular",
        fasl: "light",
        "fa-light": "light",
        fast: "thin",
        "fa-thin": "thin"
      },
      "sharp-duotone": {
        fa: "solid",
        fasds: "solid",
        "fa-solid": "solid",
        fasdr: "regular",
        "fa-regular": "regular",
        fasdl: "light",
        "fa-light": "light",
        fasdt: "thin",
        "fa-thin": "thin"
      },
      slab: {
        "fa-regular": "regular",
        faslr: "regular"
      },
      "slab-press": {
        "fa-regular": "regular",
        faslpr: "regular"
      },
      "slab-duo": {
        "fa-regular": "regular",
        fasldr: "regular"
      },
      "slab-press-duo": {
        "fa-regular": "regular",
        faslpdr: "regular"
      },
      thumbprint: {
        "fa-light": "light",
        fatl: "light"
      },
      vellum: {
        "fa-solid": "solid",
        favs: "solid"
      },
      pixel: {
        "fa-regular": "regular",
        fapr: "regular"
      },
      mosaic: {
        "fa-solid": "solid",
        fams: "solid"
      },
      whiteboard: {
        "fa-semibold": "semibold",
        fawsb: "semibold"
      },
      notdog: {
        "fa-solid": "solid",
        fans: "solid"
      },
      "notdog-duo": {
        "fa-solid": "solid",
        fands: "solid"
      },
      etch: {
        "fa-solid": "solid",
        faes: "solid"
      },
      graphite: {
        "fa-thin": "thin",
        fagt: "thin"
      },
      jelly: {
        "fa-regular": "regular",
        fajr: "regular"
      },
      "jelly-fill": {
        "fa-regular": "regular",
        fajfr: "regular"
      },
      "jelly-duo": {
        "fa-regular": "regular",
        fajdr: "regular"
      },
      chisel: {
        "fa-regular": "regular",
        facr: "regular"
      },
      utility: {
        "fa-semibold": "semibold",
        fausb: "semibold"
      },
      "utility-duo": {
        "fa-semibold": "semibold",
        faudsb: "semibold"
      },
      "utility-fill": {
        "fa-semibold": "semibold",
        faufsb: "semibold"
      }
    };
  var u = "classic",
    l = "duotone",
    h = "sharp",
    t = "sharp-duotone",
    g = "chisel",
    n = "etch",
    m = "graphite",
    p = "jelly",
    s = "jelly-duo",
    y = "jelly-fill",
    w = "mosaic",
    x = "notdog",
    e = "notdog-duo",
    b = "pixel",
    c = "slab",
    o = "slab-duo",
    I = "slab-press",
    a = "slab-press-duo",
    r = "thumbprint",
    v = "utility",
    i = "utility-duo",
    F = "utility-fill",
    d = "vellum",
    S = "whiteboard",
    A = "Classic",
    P = "Duotone",
    j = "Sharp",
    B = "Sharp Duotone",
    N = "Chisel",
    D = "Etch",
    k = "Graphite",
    T = "Jelly",
    C = "Jelly Duo",
    W = "Jelly Fill",
    R = "Mosaic",
    K = "Notdog",
    L = "Notdog Duo",
    U = "Pixel",
    J = "Slab",
    _ = "Slab Duo",
    M = "Slab Press",
    E = "Slab Press Duo",
    G = "Thumbprint",
    V = "Utility",
    z = "Utility Duo",
    O = "Utility Fill",
    Y = "Vellum",
    q = "Whiteboard",
    cl = (_cl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, u, A), l, P), h, j), t, B), g, N), n, D), m, k), p, T), s, C), y, W), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, w, R), x, K), e, L), b, U), c, J), o, _), I, M), a, E), r, G), v, V), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_cl, i, z), F, O), d, Y), S, q));
  var Al = {
      classic: {
        900: "fas",
        400: "far",
        normal: "far",
        300: "fal",
        100: "fat"
      },
      duotone: {
        900: "fad",
        400: "fadr",
        300: "fadl",
        100: "fadt"
      },
      sharp: {
        900: "fass",
        400: "fasr",
        300: "fasl",
        100: "fast"
      },
      "sharp-duotone": {
        900: "fasds",
        400: "fasdr",
        300: "fasdl",
        100: "fasdt"
      },
      slab: {
        400: "faslr"
      },
      "slab-press": {
        400: "faslpr"
      },
      "slab-duo": {
        400: "fasldr"
      },
      "slab-press-duo": {
        400: "faslpdr"
      },
      vellum: {
        900: "favs"
      },
      mosaic: {
        900: "fams"
      },
      pixel: {
        400: "fapr"
      },
      whiteboard: {
        600: "fawsb"
      },
      thumbprint: {
        300: "fatl"
      },
      notdog: {
        900: "fans"
      },
      "notdog-duo": {
        900: "fands"
      },
      etch: {
        900: "faes"
      },
      graphite: {
        100: "fagt"
      },
      chisel: {
        400: "facr"
      },
      jelly: {
        400: "fajr"
      },
      "jelly-fill": {
        400: "fajfr"
      },
      "jelly-duo": {
        400: "fajdr"
      },
      utility: {
        600: "fausb"
      },
      "utility-duo": {
        600: "faudsb"
      },
      "utility-fill": {
        600: "faufsb"
      }
    };
  var $l = {
      chisel: {
        regular: "facr"
      },
      classic: {
        brands: "fab",
        light: "fal",
        regular: "far",
        solid: "fas",
        thin: "fat"
      },
      duotone: {
        light: "fadl",
        regular: "fadr",
        solid: "fad",
        thin: "fadt"
      },
      etch: {
        solid: "faes"
      },
      graphite: {
        thin: "fagt"
      },
      jelly: {
        regular: "fajr"
      },
      "jelly-duo": {
        regular: "fajdr"
      },
      "jelly-fill": {
        regular: "fajfr"
      },
      mosaic: {
        solid: "fams"
      },
      notdog: {
        solid: "fans"
      },
      "notdog-duo": {
        solid: "fands"
      },
      pixel: {
        regular: "fapr"
      },
      sharp: {
        light: "fasl",
        regular: "fasr",
        solid: "fass",
        thin: "fast"
      },
      "sharp-duotone": {
        light: "fasdl",
        regular: "fasdr",
        solid: "fasds",
        thin: "fasdt"
      },
      slab: {
        regular: "faslr"
      },
      "slab-duo": {
        regular: "fasldr"
      },
      "slab-press": {
        regular: "faslpr"
      },
      "slab-press-duo": {
        regular: "faslpdr"
      },
      thumbprint: {
        light: "fatl"
      },
      utility: {
        semibold: "fausb"
      },
      "utility-duo": {
        semibold: "faudsb"
      },
      "utility-fill": {
        semibold: "faufsb"
      },
      vellum: {
        solid: "favs"
      },
      whiteboard: {
        semibold: "fawsb"
      }
    };
  var rt = {
      kit: {
        fak: "kit",
        "fa-kit": "kit"
      },
      "kit-duotone": {
        fakd: "kit-duotone",
        "fa-kit-duotone": "kit-duotone"
      }
    },
    it = ["kit"];
  var H = "kit",
    f = "kit-duotone",
    Q = "Kit",
    X = "Kit Duotone",
    ht = _defineProperty(_defineProperty({}, H, Q), f, X);
  var mt = {
    kit: {
      "fa-kit": "fak"
    },
    "kit-duotone": {
      "fa-kit-duotone": "fakd"
    }
  };
  var It = {
      kit: {
        fak: "fa-kit"
      },
      "kit-duotone": {
        fakd: "fa-kit-duotone"
      }
    };
  var St = {
      kit: {
        kit: "fak"
      },
      "kit-duotone": {
        "kit-duotone": "fakd"
      }
    };

  var _jl;
  var l$1 = {
      GROUP: "duotone-group",
      SWAP_OPACITY: "swap-opacity",
      PRIMARY: "primary",
      SECONDARY: "secondary"
    };
  var g$1 = "classic",
    a$1 = "duotone",
    m$1 = "sharp",
    t$1 = "sharp-duotone",
    p$1 = "chisel",
    y$1 = "etch",
    b$1 = "graphite",
    w$1 = "jelly",
    e$1 = "jelly-duo",
    x$1 = "jelly-fill",
    c$1 = "mosaic",
    I$1 = "notdog",
    o$1 = "notdog-duo",
    v$1 = "pixel",
    F$1 = "slab",
    r$1 = "slab-duo",
    S$1 = "slab-press",
    i$1 = "slab-press-duo",
    d$1 = "thumbprint",
    A$1 = "utility",
    f$1 = "utility-duo",
    P$1 = "utility-fill",
    u$1 = "vellum",
    j$1 = "whiteboard",
    B$1 = "Classic",
    N$1 = "Duotone",
    D$1 = "Sharp",
    k$1 = "Sharp Duotone",
    C$1 = "Chisel",
    T$1 = "Etch",
    L$1 = "Graphite",
    W$1 = "Jelly",
    R$1 = "Jelly Duo",
    K$1 = "Jelly Fill",
    U$1 = "Mosaic",
    J$1 = "Notdog",
    _$1 = "Notdog Duo",
    M$1 = "Pixel",
    E$1 = "Slab",
    G$1 = "Slab Duo",
    O$1 = "Slab Press",
    V$1 = "Slab Press Duo",
    z$1 = "Thumbprint",
    Y$1 = "Utility",
    $$1 = "Utility Duo",
    q$1 = "Utility Fill",
    H$1 = "Vellum",
    Q$1 = "Whiteboard",
    jl$1 = (_jl = {}, _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, g$1, B$1), a$1, N$1), m$1, D$1), t$1, k$1), p$1, C$1), y$1, T$1), b$1, L$1), w$1, W$1), e$1, R$1), x$1, K$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, c$1, U$1), I$1, J$1), o$1, _$1), v$1, M$1), F$1, E$1), r$1, G$1), S$1, O$1), i$1, V$1), d$1, z$1), A$1, Y$1), _defineProperty(_defineProperty(_defineProperty(_defineProperty(_jl, f$1, $$1), P$1, q$1), u$1, H$1), j$1, Q$1));
  var X$1 = "kit",
    h$1 = "kit-duotone",
    Z$1 = "Kit",
    ll$1 = "Kit Duotone",
    ws = _defineProperty(_defineProperty({}, X$1, Z$1), h$1, ll$1);
  var ra = {
      classic: {
        "fa-brands": "fab",
        "fa-duotone": "fad",
        "fa-light": "fal",
        "fa-regular": "far",
        "fa-solid": "fas",
        "fa-thin": "fat"
      },
      duotone: {
        "fa-regular": "fadr",
        "fa-light": "fadl",
        "fa-thin": "fadt"
      },
      sharp: {
        "fa-solid": "fass",
        "fa-regular": "fasr",
        "fa-light": "fasl",
        "fa-thin": "fast"
      },
      "sharp-duotone": {
        "fa-solid": "fasds",
        "fa-regular": "fasdr",
        "fa-light": "fasdl",
        "fa-thin": "fasdt"
      },
      slab: {
        "fa-regular": "faslr"
      },
      "slab-press": {
        "fa-regular": "faslpr"
      },
      "slab-duo": {
        "fa-regular": "fasldr"
      },
      "slab-press-duo": {
        "fa-regular": "faslpdr"
      },
      pixel: {
        "fa-regular": "fapr"
      },
      mosaic: {
        "fa-solid": "fams"
      },
      vellum: {
        "fa-solid": "favs"
      },
      whiteboard: {
        "fa-semibold": "fawsb"
      },
      thumbprint: {
        "fa-light": "fatl"
      },
      notdog: {
        "fa-solid": "fans"
      },
      "notdog-duo": {
        "fa-solid": "fands"
      },
      etch: {
        "fa-solid": "faes"
      },
      graphite: {
        "fa-thin": "fagt"
      },
      jelly: {
        "fa-regular": "fajr"
      },
      "jelly-fill": {
        "fa-regular": "fajfr"
      },
      "jelly-duo": {
        "fa-regular": "fajdr"
      },
      chisel: {
        "fa-regular": "facr"
      },
      utility: {
        "fa-semibold": "fausb"
      },
      "utility-duo": {
        "fa-semibold": "faudsb"
      },
      "utility-fill": {
        "fa-semibold": "faufsb"
      }
    },
    al$1 = {
      classic: ["fas", "far", "fal", "fat", "fad"],
      duotone: ["fadr", "fadl", "fadt"],
      sharp: ["fass", "fasr", "fasl", "fast"],
      "sharp-duotone": ["fasds", "fasdr", "fasdl", "fasdt"],
      slab: ["faslr"],
      "slab-press": ["faslpr"],
      "slab-duo": ["fasldr"],
      "slab-press-duo": ["faslpdr"],
      pixel: ["fapr"],
      mosaic: ["fams"],
      vellum: ["favs"],
      whiteboard: ["fawsb"],
      thumbprint: ["fatl"],
      notdog: ["fans"],
      "notdog-duo": ["fands"],
      etch: ["faes"],
      graphite: ["fagt"],
      jelly: ["fajr"],
      "jelly-fill": ["fajfr"],
      "jelly-duo": ["fajdr"],
      chisel: ["facr"],
      utility: ["fausb"],
      "utility-duo": ["faudsb"],
      "utility-fill": ["faufsb"]
    },
    da = {
      classic: {
        fab: "fa-brands",
        fad: "fa-duotone",
        fal: "fa-light",
        far: "fa-regular",
        fas: "fa-solid",
        fat: "fa-thin"
      },
      duotone: {
        fadr: "fa-regular",
        fadl: "fa-light",
        fadt: "fa-thin"
      },
      sharp: {
        fass: "fa-solid",
        fasr: "fa-regular",
        fasl: "fa-light",
        fast: "fa-thin"
      },
      "sharp-duotone": {
        fasds: "fa-solid",
        fasdr: "fa-regular",
        fasdl: "fa-light",
        fasdt: "fa-thin"
      },
      slab: {
        faslr: "fa-regular"
      },
      "slab-press": {
        faslpr: "fa-regular"
      },
      "slab-duo": {
        fasldr: "fa-regular"
      },
      "slab-press-duo": {
        faslpdr: "fa-regular"
      },
      pixel: {
        fapr: "fa-regular"
      },
      mosaic: {
        fams: "fa-solid"
      },
      vellum: {
        favs: "fa-solid"
      },
      whiteboard: {
        fawsb: "fa-semibold"
      },
      thumbprint: {
        fatl: "fa-light"
      },
      notdog: {
        fans: "fa-solid"
      },
      "notdog-duo": {
        fands: "fa-solid"
      },
      etch: {
        faes: "fa-solid"
      },
      graphite: {
        fagt: "fa-thin"
      },
      jelly: {
        fajr: "fa-regular"
      },
      "jelly-fill": {
        fajfr: "fa-regular"
      },
      "jelly-duo": {
        fajdr: "fa-regular"
      },
      chisel: {
        facr: "fa-regular"
      },
      utility: {
        fausb: "fa-semibold"
      },
      "utility-duo": {
        faudsb: "fa-semibold"
      },
      "utility-fill": {
        faufsb: "fa-semibold"
      }
    },
    el$1 = ["solid", "regular", "light", "thin", "duotone", "brands", "semibold"],
    sl$1 = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
    ol$1 = sl$1.concat([11, 12, 13, 14, 15, 16, 17, 18, 19, 20]),
    rl$1 = ["aw", "fw", "pull-left", "pull-right"],
    ga = [].concat(_toConsumableArray(Object.keys(al$1)), el$1, rl$1, ["2xs", "xs", "sm", "lg", "xl", "2xl", "beat", "beat-fade", "border", "bounce", "buzz", "canvas-square", "canvas-roomy", "fade", "flip-360", "flip-both", "flip-horizontal", "flip-vertical", "flip", "float", "inverse", "jello", "layers", "layers-bottom-left", "layers-bottom-right", "layers-counter", "layers-text", "layers-top-left", "layers-top-right", "li", "pull-end", "pull-start", "pulse", "rotate-180", "rotate-270", "rotate-90", "rotate-by", "shake", "spin-pulse", "spin-reverse", "spin", "spin-snap", "spin-snap-4", "spin-snap-8", "stack-1x", "stack-2x", "stack", "swing", "ul", "wag", "width-auto", "width-fixed", l$1.GROUP, l$1.SWAP_OPACITY, l$1.PRIMARY, l$1.SECONDARY]).concat(sl$1.map(function (s) {
      return "".concat(s, "x");
    })).concat(ol$1.map(function (s) {
      return "w-".concat(s);
    }));

  var NAMESPACE_IDENTIFIER = '___FONT_AWESOME___';
  var PRODUCTION = function () {
    try {
      return "production" === 'production';
    } catch (e$$1) {
      return false;
    }
  }();
  function familyProxy(obj) {
    // Defaults to the classic family if family is not available
    return new Proxy(obj, {
      get: function get(target, prop) {
        return prop in target ? target[prop] : target[u];
      }
    });
  }
  var _PREFIX_TO_STYLE = _objectSpread2({}, rl);

  // We changed FACSSClassesToStyleId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _PREFIX_TO_STYLE below, so we are manually adding
  // {'fa-duotone': 'duotone'}
  _PREFIX_TO_STYLE[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    'fa-duotone': 'duotone'
  }), rl[u]), rt['kit']), rt['kit-duotone']);
  var PREFIX_TO_STYLE = familyProxy(_PREFIX_TO_STYLE);
  var _STYLE_TO_PREFIX = _objectSpread2({}, $l);

  // We changed FAStyleIdToShortPrefixId in the icons repo to be canonical and as such, "classic" family does not have any
  // duotone styles.  But we do still need duotone in _STYLE_TO_PREFIX below, so we are manually adding {duotone: 'fad'}
  _STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2(_objectSpread2(_objectSpread2({}, {
    duotone: 'fad'
  }), _STYLE_TO_PREFIX[u]), St['kit']), St['kit-duotone']);
  var STYLE_TO_PREFIX = familyProxy(_STYLE_TO_PREFIX);
  var _PREFIX_TO_LONG_STYLE = _objectSpread2({}, da);
  _PREFIX_TO_LONG_STYLE[u] = _objectSpread2(_objectSpread2({}, _PREFIX_TO_LONG_STYLE[u]), It['kit']);
  var PREFIX_TO_LONG_STYLE = familyProxy(_PREFIX_TO_LONG_STYLE);
  var _LONG_STYLE_TO_PREFIX = _objectSpread2({}, ra);
  _LONG_STYLE_TO_PREFIX[u] = _objectSpread2(_objectSpread2({}, _LONG_STYLE_TO_PREFIX[u]), mt['kit']);
  var LONG_STYLE_TO_PREFIX = familyProxy(_LONG_STYLE_TO_PREFIX);
  var _FONT_WEIGHT_TO_PREFIX = _objectSpread2({}, Al);
  var FONT_WEIGHT_TO_PREFIX = familyProxy(_FONT_WEIGHT_TO_PREFIX);
  var RESERVED_CLASSES = [].concat(_toConsumableArray(it), _toConsumableArray(ga));

  function bunker(fn) {
    try {
      for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }
      fn.apply(void 0, args);
    } catch (e) {
      if (!PRODUCTION) {
        throw e;
      }
    }
  }

  var w$2 = WINDOW || {};
  if (!w$2[NAMESPACE_IDENTIFIER]) w$2[NAMESPACE_IDENTIFIER] = {};
  if (!w$2[NAMESPACE_IDENTIFIER].styles) w$2[NAMESPACE_IDENTIFIER].styles = {};
  if (!w$2[NAMESPACE_IDENTIFIER].hooks) w$2[NAMESPACE_IDENTIFIER].hooks = {};
  if (!w$2[NAMESPACE_IDENTIFIER].shims) w$2[NAMESPACE_IDENTIFIER].shims = [];
  var namespace = w$2[NAMESPACE_IDENTIFIER];

  function normalizeIcons(icons) {
    return Object.keys(icons).reduce(function (acc, iconName) {
      var icon = icons[iconName];
      var expanded = !!icon.icon;
      if (expanded) {
        acc[icon.iconName] = icon.icon;
      } else {
        acc[iconName] = icon;
      }
      return acc;
    }, {});
  }
  function defineIcons(prefix, icons) {
    var params = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var _params$skipHooks = params.skipHooks,
      skipHooks = _params$skipHooks === void 0 ? false : _params$skipHooks;
    var normalized = normalizeIcons(icons);
    if (typeof namespace.hooks.addPack === 'function' && !skipHooks) {
      namespace.hooks.addPack(prefix, normalizeIcons(icons));
    } else {
      namespace.styles[prefix] = _objectSpread2(_objectSpread2({}, namespace.styles[prefix] || {}), normalized);
    }

    /**
     * Font Awesome 4 used the prefix of `fa` for all icons. With the introduction
     * of new styles we needed to differentiate between them. Prefix `fa` is now an alias
     * for `fas` so we'll ease the upgrade process for our users by automatically defining
     * this as well.
     */
    if (prefix === 'fas') {
      defineIcons('fa', icons);
    }
  }

  var icons = {
    "question": [432, 576, [10067, 10068, 61736], "3f", ["M216 0C103.9 0 0 79.3 0 192l0 24c0 13.3 10.7 24 24 24l48 0c13.3 0 24-10.7 24-24l0-24c0-46.3 46.5-96 120-96s120 49.7 120 96-46.5 96-120 96l-24 0c-13.3 0-24 10.7-24 24l0 84.9c14.1-8.2 30.5-12.9 48-12.9s33.9 4.7 48 12.9l0-17.8C356.1 360.2 432 288.4 432 192 432 79.3 328.1 0 216 0zM168 396.9c-28.7 16.6-48 47.6-48 83.1 0 53 43 96 96 96s96-43 96-96c0-35.5-19.3-66.5-48-83.1l0 59.1c0 26.5-21.5 48-48 48s-48-21.5-48-48l0-59.1z", "M216 384c-17.5 0-33.9 4.7-48 12.9l0 59.1c0 26.5 21.5 48 48 48s48-21.5 48-48l0-59.1c-14.1-8.2-30.5-12.9-48-12.9z"]],
    "minus": [528, 576, [8211, 8722, 10134, "subtract"], "f068", ["M19.2 216C8.6 216 0 224.6 0 235.2L0 340.8C0 351.4 8.6 360 19.2 360l340.8 0 0-144-340.8 0z", "M360 216l0 144 148.8 0c10.6 0 19.2-8.6 19.2-19.2l0-105.6c0-10.6-8.6-19.2-19.2-19.2L360 216z"]],
    "microphone-slash": [480, 576, [], "f131", ["M240.4 0c-66.3 0-120 53.7-120 120l0 168 88.8 0 150.2-183.5c.7 5.1 1 10.2 1 15.5l0 58.9-89.3 109.1 89.3 0 0 48-128.4 0-83.1 101.6c-11.2-13.2-19.6-28.8-24.3-46l45.5-55.6-49.7 0 0 24c0 10.9 1.5 21.5 4.2 31.6L89.9 434.2c-11-22.3-17.5-47.5-17.5-74.2l0-24 48 0 0-48-96 0 0 72c0 41.8 12.2 80.9 32.9 114L5.9 536.9c-8.4 10.3-6.9 25.4 3.4 33.8 4.6 3.6 9.8 5.5 15.1 5.5 7 0 13.9-2.9 18.5-8.9l44.6-54.7c39.1 39.1 93.1 63.4 152.6 63.4 119 0 216-97 216-216l0-72-95.8 0 0-109.1 114.5-139.8c8.4-10.3 7-25.4-3.4-33.8l0 .3c-10.3-8.4-25.4-7-33.8 3.4l-78.3 95.6C351.8 45.6 301.5 0 240.4 0zm120 360l0-24 48 0 0 24c0 92.6-75.4 168-168 168-48 0-91.4-20.4-122.2-52.8L149 437.6c22 25.9 54.8 42.4 91.5 42.4 66.3 0 120-53.7 120-120z", "M359.4 104.5c.7 5.1 1 10.2 1 15.5l0 58.9-89.3 109.1 89.3 0 0 48-128.4 0-83.1 101.6c-11.2-13.2-19.6-28.8-24.3-46l45.5-55.6-49.7 0 0-48 88.8 0 150.2-183.5z"]],
    "square-pen": [576, 576, ["pen-square", "pencil-square"], "f14b", ["M459.8 20.2L336 144 403.7 144c15.6 0 28.3 12.6 28.3 28.3q0 0 0 .1l0 67.7 123.8-123.8c26.4-26.4 26.4-69.6 0-96s-69.6-26.4-96 0zM28.3 144C12.7 144 0 156.7 0 172.3L0 547.7C0 563.3 12.7 576 28.3 576l375.4 0c15.6 0 28.3-12.7 28.3-28.3l0-307.7-120 120-144 48 48-144 120-120-307.7 0z", "M336 144l-120 120-48 144 144-48 120-120 0-67.7c0-15.6-12.7-28.3-28.3-28.3L336 144z"]],
    "car": [576, 576, [128664, "automobile"], "f1b9", ["M121.2 120c-28.6 0-53.2 20.2-58.9 48.2L36 300 24 316C8.4 336.8 0 362 0 388l0 68c0 13.3 10.7 24 24 24l24.9 0c-.6-3.9-.9-7.9-.9-12 0-46.4 37.6-84 84-84s84 37.6 84 84c0 4.1-.3 8.1-.9 12l145.7 0c-.6-3.9-.9-7.9-.9-12 0-46.4 37.6-84 84-84s84 37.6 84 84c0 4.1-.3 8.1-.9 12l27.3 0c11.9 0 21.6-9.7 21.6-21.6l0-20.4c0-96.1-77.9-174-174-174l-126 0c-6.6 0-12-5.4-12-12l0-72c0-6.6 5.4-12 12-12l98 0-1.4-4.8C365.1 137.6 341.7 120 315 120l-193.8 0zm-15 57.8c1.1-5.7 6-9.8 11.8-9.8l86 0c6.6 0 12 5.4 12 12l0 72c0 6.6-5.4 12-12 12l-99.5 0c-7.5 0-13.2-6.8-11.8-14.2l13.5-72zM374 168l28 96 37.7 0c8.1 0 13.9-7.9 11.4-15.6l-22.5-72c-1.6-5-6.2-8.4-11.4-8.4L374 168zM48.9 480c5.8 40.7 40.8 72 83.1 72s77.3-31.3 83.1-72L48.9 480zm312 0c5.8 40.7 40.8 72 83.1 72s77.3-31.3 83.1-72l-166.3 0z", "M132 384c46.4 0 84 37.6 84 84 0 4.1-.3 8.1-.9 12L48.9 480c-.6-3.9-.9-7.9-.9-12 0-46.4 37.6-84 84-84zm312 0c46.4 0 84 37.6 84 84 0 4.1-.3 8.1-.9 12l-166.3 0c-.6-3.9-.9-7.9-.9-12 0-46.4 37.6-84 84-84zM204 168c6.6 0 12 5.4 12 12l0 72c0 6.6-5.4 12-12 12l-99.5 0c-7.5 0-13.2-6.8-11.8-14.2l13.5-72c1.1-5.7 6-9.8 11.8-9.8l86 0zm198 96l-126 0c-6.6 0-12-5.4-12-12l0-72c0-6.6 5.4-12 12-12l98 0 28 96z"]],
    "filter": [480, 576, [], "f0b0", ["M240.5 0c-132.5 0-240 37.6-240 84 0 17.9 16 34.4 43.1 48 43.4-21.7 115.4-36 196.9-36 81.5 0 153.5 14.3 196.9 36 27.2-13.6 43.1-30.2 43.1-48 0-46.4-107.5-84-240-84zM43.6 132c-27.2 13.6-43.1 30.1-43.1 48 0 9.4 4.5 18.2 12.5 26.6l155.8 153.4 0 168 144 48 0-216 155.8-153.4c7.9-8.4 12.5-17.3 12.5-26.6l-.5 0c0-17.8-16-34.4-43.1-48-43.4 21.7-115.4 36-196.9 36-81.5 0-153.5-14.2-196.9-36z", "M240.5 96c81.5 0 153.5 14.3 196.9 36-43.4 21.7-115.4 36-196.9 36-81.5 0-153.5-14.2-196.9-36 43.4-21.7 115.4-36 196.9-36z"]],
    "envelope": [576, 576, [128386, 9993, 61443], "f0e0", ["M288 0L9.1 221.3c-2.4 1.9-4.6 4.3-6 7.2-6.5 11.5-2.2 26.2 9.4 32.6l48.9 26.9-38.8 0C10.1 288 0 298.1 0 310.6L0 553.4C0 565.9 10.1 576 22.6 576l530.9 0c12.5 0 22.6-10.1 22.6-22.6l0-242.9c0-12.5-10.1-22.6-22.6-22.6l-38.4 0-176.9 97.2 177.8 97.7c11.5 6.5 15.8 21.1 9.4 32.6-4.3 7.9-12.7 12.5-21.1 12.5-3.8 0-7.9-1-11.5-2.9L288.2 412.8 83.8 525.1c-3.6 1.9-7.7 2.9-11.5 2.9-8.6 0-16.8-4.6-21.1-12.5-6.5-11.8-2.2-26.2 9.4-32.6l177.8-97.7-176.9-97.2 453.7 0 48.9-26.9c11.5-6.5 15.8-20.9 9.4-32.6l-.2 0c-1.7-2.9-3.6-5.3-6-7.2L288 0z", "M515.1 288L338.2 385.2 516 482.9c11.5 6.5 15.8 21.1 9.4 32.6-4.3 7.9-12.7 12.5-21.1 12.5-3.8 0-7.9-1-11.5-2.9L288.2 412.8 83.8 525.1c-3.6 1.9-7.7 2.9-11.5 2.9-8.6 0-16.8-4.6-21.1-12.5-6.5-11.8-2.2-26.2 9.4-32.6l177.8-97.7-176.9-97.2 453.7 0z"]],
    "cloud-arrow-up": [576, 576, [62338, "cloud-upload", "cloud-upload-alt"], "f0ee", ["M228 0c-86.2 0-156 69.8-156 156 0 13.2 1.7 25.7 4.8 37.9-43.7 8.9-76.8 47.8-76.8 94.1 0 52.8 43.2 96 96 96l168 0 0-134.2-55 55c-9.4 9.4-24.5 9.4-33.8 0s-9.4-24.5 0-33.8l96-96c9.4-9.3 24.5-9.3 33.8 0l96 96c9.4 9.4 9.4 24.5 0 33.8-4.8 4.6-10.8 7-17 7s-12.2-2.2-17-7l-55-55 0 134.2-48 0 0 168c0 13.2 10.8 24 24 24s24-10.8 24-24l0-168 168 0c52.8 0 96-43.2 96-96 0-45.1-31.4-82.8-73.4-93.1 1-4.8 1.4-9.8 1.4-14.9 0-46.3-37.7-84-84-84-16.1 0-30.7 4.8-43.4 12.5-20.2-62.9-79-108.5-148.6-108.5z", "M271.2 174.9c9.4-9.3 24.5-9.3 33.8 0l96 96c9.4 9.4 9.4 24.5 0 33.8-4.8 4.6-10.8 7-17 7s-12.2-2.2-17-7l-55-55 0 134.2-48 0 0-134.2-55 55c-9.4 9.4-24.5 9.4-33.8 0s-9.4-24.5 0-33.8l96-96z"]],
    "at": [528, 576, [61946], "40", ["M264 24C118.2 24 0 142.2 0 288S118.2 552 264 552c121.6 0 223.9-82.2 254.6-194.1 .1-.2 .1-.4 .2-.6l0 0c6-22.1 9.3-45.3 9.3-69.3 0-145.8-118.2-264-264-264zM72 288C72 182 158 96 264 96s192 86 192 192c0 17.5-2.4 34.4-6.7 50.4-4.4 16-20.8 25.4-36.8 21.1-17.3-4.7-27-22.8-23-37.5l-.1 0c3.3-10.9 5.6-22.3 6.6-34l0 0c6.8-79.9-47-144-119.5-144l0 0c-72.7 0-137.7 64.3-144.4 144-6.8 79.9 47 144 119.5 144l0 0c33.4 0 65-13.6 90.3-35.9 13.4 15.5 31.3 27.3 51.8 32.9 .2 .1 .4 .1 .6 .1-34.2 31.6-79.9 50.9-130.1 50.9-106 0-192-86-192-192zm131.7 6.1c4-47.3 42.1-78 72.7-78.1 24.2 0 51.5 21.6 47.8 65.9-4 47.3-42.1 78-72.7 78-24.2 0-51.5-21.6-47.7-65.9zm138 102c-21.3-24.7-31.1-58.9-21.8-93L389.3 322c-9 29.2-25.9 54.9-47.6 74.1zm52.4 33c26.1-24.1 45.5-55.4 55.1-90.7l69.5 18.9c-14.7 54.1-70.4 86.2-124.6 71.8z", "M518.7 357.4c-14.7 54.1-70.4 86.2-124.6 71.8 26.1-24.1 45.5-55.4 55.1-90.7l69.5 18.9zM389.3 322c-9 29.2-25.9 54.9-47.6 74.1-21.3-24.7-31.1-58.9-21.8-93L389.3 322z"]],
    "truck": [576, 576, [128666, 9951], "f0d1", ["M24 0C10.7 0 0 10.7 0 24L0 456c0 13.3 10.7 24 24 24l24.9 0c-.6-3.9-.9-7.9-.9-12 0-46.4 37.6-84 84-84s84 37.6 84 84c0 4.1-.3 8.1-.9 12l145.7 0c-.6-3.9-.9-7.9-.9-12 0-46.4 37.6-84 84-84s84 37.6 84 84c0 4.1-.3 8.1-.9 12l24.9 0c13.3 0 24-10.7 24-24l0-102.9c0-21.7-11.7-41.7-30.6-52.3L480 264 384 264c-13.3 0-24-10.7-24-24l0-72c0-13.3 10.7-24 24-24l96 0 0-12c0-33.1-26.9-60-60-60l-84 0 0-48c0-13.3-10.7-24-24-24L24 0zM480 144l0 120 24 0c13.3 0 24-10.7 24-24l0-72c0-13.3-10.7-24-24-24l-24 0zM48.9 480c5.8 40.7 40.8 72 83.1 72s77.3-31.3 83.1-72L48.9 480zm312 0c5.8 40.7 40.8 72 83.1 72s77.3-31.3 83.1-72l-166.3 0z", "M132 384c46.4 0 84 37.6 84 84 0 4.1-.3 8.1-.9 12L48.9 480c-.6-3.9-.9-7.9-.9-12 0-46.4 37.6-84 84-84zm312 0c46.4 0 84 37.6 84 84 0 4.1-.3 8.1-.9 12l-166.3 0c-.6-3.9-.9-7.9-.9-12 0-46.4 37.6-84 84-84zm36-120l-96 0c-13.3 0-24-10.7-24-24l0-72c0-13.3 10.7-24 24-24l96 0 0 120z"]],
    "bell": [576, 576, [128276, 61602], "f0f3", ["M72 216l0 156c0 18.7-14.1 34-32.3 35.8l-7.4 .4C14.1 410.1 0 425.4 0 444 0 463.9 16.1 480 36 480l228 0t0 0 0 0c0-53 43-96 96-96s96 43 96 96l84 0c19.9 0 36-16.1 36-36 0-18.7-14.1-34-32.3-35.8l-7.4-.4C518.1 406 504 390.7 504 372l0-149.5C504 115 428.4 19.2 322.1 2.7 188.4-18.2 72 86 72 216zM264 480c0 53 43 96 96 96s96-43 96-96l-192 0z", "M360 384c53 0 96 43 96 96l-192 0c0-53 43-96 96-96z"]],
    "mobile": [432, 576, [128241, "mobile-android", "mobile-phone"], "f3ce", ["M120 0C80.2 0 48 32.2 48 72l0 24 48 0 0 96-48 0 0 48 48 0 0 96-48 0 0 48 48 0 0 96-48 0 0 24c0 39.8 32.2 72 72 72l240 0c39.8 0 72-32.2 72-72l0-432c0-39.8-32.2-72-72-72L120 0zM0 96l0 96 48 0 0-96-48 0zm144 96l0-96 96 0 0 96-96 0zm144 0l0-96 96 0 0 96-96 0zM0 240l0 96 48 0 0-96-48 0zm144 96l0-96 96 0 0 96-96 0zm144 0l0-96 96 0 0 96-96 0zM0 384l0 96 48 0 0-96-48 0zm144 96l0-96 96 0 0 96-96 0z", "M48 96l0 96 48 0 0-96-48 0zm96 0l0 96 96 0 0-96-96 0zm144 0l0 96 96 0 0-96-96 0zM48 240l0 96 48 0 0-96-48 0zm96 0l0 96 96 0 0-96-96 0zm144 0l0 96 96 0 0-96-96 0zM48 384l0 96 48 0 0-96-48 0zm96 0l0 96 96 0 0-96-96 0z"]],
    "cherries": [576, 576, [], "e0ec", ["M432 23.8c-96.2 0-172.3 28.3-226.3 83.8-58.5 60.3-79.3 140.5-85.6 204.8-66.6 3.7-114.6 39-119.6 107.7-6 82.6 59 156 131.8 156S268.8 504.5 264 420c-3.4-60.1-41.5-94.6-95.7-104.8-2.6 24.6-2.8 45.9-2.4 60.4 .5 13.2-10.1 24.2-23.3 24.7-13.4 .5-24.2-10.1-24.7-23.3-.5-17.9-.2-40.1 2.2-64.7 3.9-.2 7.9-.3 11.9-.3l.2 0c12.6 0 24.7 1.1 36 3.2 5.8-53.9 23.2-123.9 72-174.1 39.1-40.3 93.6-63.1 162.5-68.2-8.6 49.1-22.5 150-12.8 246.8-44 14-73.6 47.2-77.6 100.2-6 82.6 59 156 131.7 156s136.6-71.5 131.8-156c-4.1-72.7-59-108-131.8-108-2.2 0-4.3 0-6.4 .1-11.6-123.3 17.5-257.4 18-259.3 1.4-7-.2-14.4-4.8-20.2-4.6-5.5-11.5-8.9-18.7-8.9zm-42.1 296c14.5-4.6 30.5-7.2 47.7-7.7 2 21.3 5.2 42.4 10 62.3 3.1 13-4.8 25.9-17.8 29-1.9 .5-3.8 .7-5.8 .7l0 .2c-10.8 0-20.6-7.4-23.3-18.5-5.2-21.4-8.7-43.6-10.9-66.1z", "M437.6 312.1c2 21.3 5.2 42.4 10 62.3 3.1 13-4.8 25.9-17.8 29-1.9 .5-3.8 .7-5.8 .7l0 .2c-10.8 0-20.6-7.4-23.3-18.5-5.2-21.4-8.7-43.6-10.9-66.1 14.5-4.6 30.5-7.2 47.7-7.7zM132.2 312c12.6 0 24.7 1.1 36 3.2-2.6 24.6-2.8 45.9-2.4 60.4 .5 13.2-10.1 24.2-23.3 24.7-13.4 .5-24.2-10.1-24.7-23.3-.5-17.9-.2-40.1 2.2-64.7 3.9-.2 7.9-.3 11.9-.3l.2 0z"]],
    "trophy": [576, 576, [127942], "f091", ["M96 0l5 48-101 0 32.2 193.2c8.6 51.8 51.8 90.2 103.7 94.1 14.7 46.6 44 83.9 83.5 104.1l-17.7 88.6-39.4 0C139 528 120 547 120 570.2l0 5.8 336 0 0-5.8c0-23.3-19-42.2-42.2-42.2l-39.4 0-17.8-88.9c39.2-20.3 68.4-57.5 83-103.9 51.8-3.6 95-42 103.7-94.1L575.5 48 475 48 480 0 96 0zM79.7 233.5L56.9 96 106.3 96 126.2 285.4C102.5 278.6 84 259 79.7 233.5zM450 285.4l19.9-189.4 49.4 0-22.8 137.5c-4.3 25.4-22.8 45.1-46.6 51.8zm-230.7 154l15.9-79.4 105.6 0 15.8 79.1c-20.4 10.5-43.6 16.5-68.9 16.9-25.1-.3-48.1-6.2-68.4-16.6z", "M340.8 360l15.8 79.1c-20.4 10.5-43.6 16.5-68.9 16.9-25.1-.3-48.1-6.2-68.4-16.6l15.9-79.4 105.6 0z"]],
    "signal-bars-fair": [528, 576, ["signal-alt-2"], "f692", ["M144 192c-13.3 0-24 10.7-24 24l0 72 24 0c13.3 0 24 10.7 24 24l0 240c0 12.4-9.4 22.7-21.5 23.9l-2.5 .1 120 0c13.3 0 24-10.7 24-24l0-336c0-13.3-10.7-24-24-24l-120 0zM24 288c-13.3 0-24 10.7-24 24L0 552c0 13.3 10.7 24 24 24l120 0c-13.3 0-24-10.7-24-24l0-264-96 0z", "M120 288l0 264c0 13.3 10.7 24 24 24l2.5-.1c12.1-1.2 21.5-11.5 21.5-23.9l0-240c0-13.3-10.7-24-24-24l-24 0z"]],
    "gift": [576, 576, [127873], "f06b", ["M168 0L96 96 240 144 336 144 480 96 408 0 288 117.6 168 0zM0 144l0 144 48 0 0 240 192 0 0-384-240 0zm336 0l0 384 192 0 0-240 48 0 0-144-240 0zM240 528l0 48 96 0 0-48-96 0z", "M240 144l0 384 96 0 0-384-96 0z"]],
    "gauge": [576, 576, ["dashboard", "gauge-med", "tachometer-alt-average"], "f624", ["M288 48C128.9 48 0 176.9 0 336l320.3 0-24.1 49c-2.6-.2-5.5-.7-8.4-.7-39.8 0-72 32.2-72 72s32.2 72 72 72 72-32.2 72-72c0-19.4-7.9-37.2-20.4-50.2l34.5-70.1-53.6 0 62.7-127.2c5.8-12 20.4-16.8 32.2-11l-.2 .3c12 5.8 16.8 20.4 11 32.2L373.9 336 576 336C576 176.9 447.1 48 288 48z", "M383 208.8c5.8-12 20.4-16.8 32.2-11l-.2 .3c12 5.8 16.8 20.4 11 32.2L373.9 336 320.3 336 383 208.8z"]],
    "share-nodes": [528, 576, ["share-alt"], "f1e0", ["M432 0c-53 0-96 43-96 96 0 8.8 1.2 17.3 3.4 25.4L164.8 221c-17.4-17.9-41.8-29-68.8-29-53 0-96 43-96 96s43 96 96 96c27 0 51.3-11.1 68.7-29l174.6 99.8c-2.2 8-3.4 16.5-3.4 25.2 0 53 43 96 96 96s96-43 96-96-43-96-96-96c-27 0-51.3 11.1-68.7 29L188.7 313.2c-4.3 16-12.7 30.3-23.9 41.8L84 308.9c-7.4-4.3-12-12.2-12-20.9s4.6-16.5 12-20.9l80.8-46.1c11.2 11.5 19.5 25.8 23.8 41.7 0 0 0 0 0 0L363.3 163c17.4 17.9 41.8 29 68.7 29 53 0 96-43 96-96S485 0 432 0zM420.2 75.4c11.5-6.7 26.2-2.6 32.6 8.9 6.7 11.5 2.6 26.1-8.9 32.6L363.3 163c-11.2-11.5-19.5-25.7-23.8-41.6l80.8-46.1zM189.2 264.8c1.8 7.4 2.8 15.2 2.8 23.1 0 7.8-.9 15.3-2.7 22.5 1.9-7.1 2.9-14.6 2.9-22.5 0-8.1-1.1-15.8-3.1-23.2zM339.4 454.8c4.3-16 12.7-30.3 23.9-41.8l80.7 46.1 0 .2c11.5 6.5 15.4 21.1 8.9 32.6-4.6 7.7-12.5 12-20.9 12-4.1 0-8.2-1-12-3.1l-80.6-46.1z", "M444 459.1l0 .2c11.5 6.5 15.4 21.1 8.9 32.6-4.6 7.7-12.5 12-20.9 12-4.1 0-8.2-1-12-3.1l-80.6-46.1c4.3-16 12.7-30.3 23.9-41.8L444 459.1zM164.8 221.1c11.2 11.5 19.5 25.8 23.8 41.7 .2 .6 .3 1.2 .5 1.7 1.9 7.5 2.9 15.4 2.9 23.5 0 26.1-10.4 49.7-27.3 67L84 308.9c-7.4-4.3-12-12.2-12-20.9s4.6-16.5 12-20.9l80.8-46.1zM420.2 75.4c11.5-6.7 26.2-2.6 32.6 8.9 6.7 11.5 2.6 26.1-8.9 32.6L363.3 163c-11.2-11.5-19.5-25.7-23.8-41.6l80.8-46.1z"]],
    "percent": [576, 576, [62101, 62785, "percentage"], "25", ["M156 0C69.8 0 0 69.8 0 156S69.8 312 156 312c8.5 0 16.9-.7 25.1-2L294.2 83.7C268.2 34 216.1 0 156 0zM354 0c-11 0-21.1 6.2-25.9 16.1L294.2 83.7c11.3 21.6 17.8 46.2 17.8 72.3 0 77.6-56.7 142-130.9 154L57.1 557.8C53 566.2 59 576 68.4 576l81.8 0c11 0 21.1-6.2 25.9-16.1l99.4-199c-7.5 18.2-11.6 38.1-11.6 59 0 86.2 69.8 156 156 156s156-69.8 156-156-69.8-156-156-156c-57 0-106.8 30.5-134 76.1L446.9 18.2C451 9.8 445 0 435.6 0L354 0z", "M294.2 83.7c11.3 21.6 17.8 46.2 17.8 72.3 0 77.6-56.7 142-130.9 154L294.2 83.7z"]],
    "magnifying-glass": [576, 576, [128269, "search"], "f002", ["M228 0C102 0 0 102 0 228S102 456 228 456c50 0 96.2-16.1 133.8-43.3l-52-52c20.6-12.7 38.2-30.2 50.9-50.9l52 52C439.9 324.2 456 278 456 228 456 102 354 0 228 0zM384 228a156 156 0 1 1 -312 0 156 156 0 1 1 312 0zm28.7 133.8c-14.2 19.5-31.4 36.7-50.9 50.9L514.6 565.4c7 7 16.3 10.6 25.4 10.6s18.5-3.6 25.4-10.6c14.2-14.2 14.2-37 0-50.9L412.7 361.8z", "M360.7 309.8c-12.7 20.6-30.2 38.2-50.9 50.9l52 52c19.5-14.2 36.7-31.4 50.9-50.9l-52-52z"]],
    "lips": [576, 576, [128068, 128482], "f600", ["M192 84c-91 0-122.1 124.8-159.5 177.3 2.3-1.5 5.2-2.3 8.6-2.3 39.6 0 68.1 9.7 97.8 20.6-21.6 15.1-41.4 26.9-62.1 26.9-22 0-38.3-3.2-50.2-7.3 15 66.7 107.2 192.8 261.6 192.8 154.5 0 246.4-126.2 261.2-192.8 19.2-6.5 26.5-15 26.5-15-9.7 0-18.3-5.7-26.4-15.1-1.4-3.4-3.4-6-6.1-7.7-37.4-52.5-68.6-177.3-159.5-177.3-33.8 0-71 25.2-96 53.8-25-28.3-62.4-53.8-96-53.8zM138.9 279.6c38.6-26.9 83.1-64.3 149.1-64.3 63.3 0 106.8 34.5 144.3 61 25.2-9.5 54.5-17.3 102.4-17.3l.2 0c3.4 0 6.2 .8 8.6 2.3 2 2.8 4 5.4 6.1 7.7 2.8 7.1 2.7 17.5-.1 30.1-11.9 4-28.3 7.3-50.3 7.3-22.2 0-43.3-13.5-66.9-30.2-39.4 14.8-69 33.8-144.3 33.8-69.8 0-110.5-16.3-149.1-30.5zM32.5 261.3c-2.7 1.7-4.7 4.3-6 7.7 2-2.3 4-4.9 6-7.7zm-6 7.7c-8.2 9.5-16.7 15.2-26.4 15.2 0 0 7.4 8.5 26.6 15-2.8-12.6-3-23.1-.2-30.2z", "M41 259c39.6 0 68.1 9.7 97.8 20.6-21.6 15.1-41.4 26.9-62.1 26.9-22 0-38.3-3.2-50.2-7.3-2.8-12.6-3-23.1-.2-30.2 2-2.3 4-4.9 6-7.7 2.3-1.5 5.2-2.3 8.6-2.3zM535 259c3.4 0 6.2 .8 8.6 2.3 2 2.8 4 5.4 6.1 7.7 2.8 7.1 2.7 17.5-.1 30.1-11.9 4-28.3 7.3-50.3 7.3-22.2 0-43.3-13.5-66.9-30.2 25.2-9.5 54.5-17.3 102.4-17.3l.2 0z"]],
    "butterfly": [576, 576, [], "e811", ["M156 48C69.8 48 0 117.8 0 204l0 .2c0 62.6 37 116.4 90.2 141.4-11.5 18.2-18.2 39.6-18.2 62.6 0 66.2 53.8 120 120 120 39.4 0 74.1-19.3 96-48.5 21.9 29.2 56.6 48.5 96 48.5 66.2 0 120-53.8 120-120 0-23-6.7-44.4-18.2-62.6 53.3-25 90.2-78.7 90.2-141.4l0-.2c0-86.2-69.8-156-156-156-55.4 0-104.2 29-131.8 73-.1 .1-.2 .2-.2 .4-.1-.1-.2-.3-.2-.4-27.6-43.9-76.3-73-131.8-73zM287.3 478.8c-90.6-189.5-18.6-326.2 .7-357.4 19.3 31.2 91.3 167.9 .7 357.4-.2 .3-.5 .6-.7 .9-.2-.3-.5-.6-.7-.9z", "M288 121.4c19.3 31.2 91.3 167.9 .7 357.4-.2 .3-.5 .6-.7 .9-.2-.3-.5-.6-.7-.9-90.6-189.5-18.6-326.2 .7-357.4z"]],
    "palette": [576, 576, [127912], "f53f", ["M49.1 72.5c-38.2 34.1-36.5 95 2.4 128.6l25.3 21.8c39.9 34.3 39.9 96.2 0 130.5L51.4 375c-39.4 33.8-40.3 95.2-1.2 129.5 50.4 44.4 116.5 71.5 188.6 71.5 150.4 0 273.7-116.5 285.5-264.6 29.2-4.1 51.7-29.1 51.7-59.3 0-33.1-26.9-60-60-60-2.5 0-4.9 .2-7.3 .5-9.6-26.7-23-51.7-39.6-74.2 6.8-9.7 10.9-21.5 10.9-34.3 0-33.1-26.9-60-60-60-15 0-28.7 5.6-39.3 14.7-40.6-23.7-87.3-37.8-136.6-38.7-75-1.4-143.2 26.4-195 72.4zM360 84.1c0-18.1 8-34.3 20.7-45.3 34.6 20.2 64.7 47.4 88.5 79.6-10.9 15.5-28.8 25.7-49.2 25.7-33.1 0-60-26.9-60-60zm24 168a60 60 0 1 1 -120 0 60 60 0 1 1 120 0zm72 0c0-30.7 23-55.9 52.7-59.5 9.5 26.6 15.3 55 16.4 84.4 .4 11.7 .2 23.2-.7 34.5-2.7 .4-5.5 .7-8.3 .7-33.1 0-60-26.9-60-60zM262.7 419.8a59.7 59.7 0 1 1 -119.4 0 59.7 59.7 0 1 1 119.4 0z", "M324 312.1a60 60 0 1 1 0-120 60 60 0 1 1 0 120zM508.7 192.5c9.5 26.6 15.3 55 16.4 84.4 .4 11.7 .2 23.2-.7 34.5-2.7 .4-5.5 .7-8.3 .7-33.1 0-60-26.9-60-60 0-30.7 23-55.9 52.7-59.5zM380.7 38.8c34.6 20.2 64.7 47.4 88.5 79.6-10.9 15.5-28.8 25.7-49.2 25.7-33.1 0-60-26.9-60-60 0-18.1 8-34.3 20.7-45.3z"]],
    "key": [576, 576, [128273], "f084", ["M372 0c-112.6 0-204 91.4-204 204 0 18.3 2.4 36.1 7 53l77-77 144 144-77 77c16.9 4.6 34.7 7 53 7 112.6 0 204-91.4 204-204S484.6 0 372 0zM480 144a48 48 0 1 1 -96 0 48 48 0 1 1 96 0zM175 257l-175 175 0 144 144 0 0-72 72 0 0-72 72 0 31-31s0 0 0 0c-64.5-17.3-116.4-65.5-138.9-127.7q-.1-.3-.2-.6t-.2-.6q-.1-.2-.1-.4-.1-.3-.2-.6-.1-.4-.3-.7-.1-.2-.1-.4-.1-.2-.2-.5-.1-.3-.2-.6-.1-.3-.2-.6-.1-.4-.2-.7-.1-.4-.3-.8-.1-.2-.1-.4-.1-.2-.1-.5-.1-.3-.2-.5-.1-.3-.2-.5-.1-.3-.2-.6-.1-.3-.2-.6-.1-.3-.2-.6-.1-.3-.2-.7-.1-.4-.2-.7-.1-.4-.2-.8-.1-.4-.2-.8-.1-.2-.1-.4t-.1-.4-.1-.5-.1-.5-.1-.5-.1-.5z", "M252 180l-77 77c18.8 70 74 125.2 144 144l77-77-144-144z"]],
    "skull": [576, 576, [128128], "f54c", ["M216 24C123.2 24 48 99.2 48 192l-24 0c-13.3 0-24 10.7-24 24l0 24c0 39.8 32.2 72 72 72l7.2 0c11.2 15.7 25 29.3 40.8 40.3L120 516c0 19.9 16.1 36 36 36l240 0c19.9 0 36-16.1 36-36l0-109.8c81.4-11.6 144-81.6 144-166.2l0-48c0-92.8-75.2-168-168-168L216 24zM48 192l96 0c13.3 0 24 10.7 24 24l0 24c0 39.8-32.2 72-72 72l-16.7 0C59.6 284.5 48 250.9 48 214.5L48 192zm240 24c0-13.3 10.7-24 24-24l120 0c13.3 0 24 10.7 24 24l0 24c0 39.8-32.2 72-72 72l-24 0c-39.8 0-72-32.2-72-72l0-24zm-60 96c19.9 0 36 16.1 36 36l0 48c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-48c0-19.9 16.1-36 36-36z", "M228 312c19.9 0 36 16.1 36 36l0 48c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-48c0-19.9 16.1-36 36-36zM432 192c13.3 0 24 10.7 24 24l0 24c0 39.8-32.2 72-72 72l-24 0c-39.8 0-72-32.2-72-72l0-24c0-13.3 10.7-24 24-24l120 0zm-288 0c13.3 0 24 10.7 24 24l0 24c0 39.8-32.2 72-72 72l-16.7 0C59.6 284.5 48 250.9 48 214.5l0-22.5 96 0z"]],
    "tree": [480, 576, [127794], "f1bb", ["M240 0c-79.4 0-144 64.6-144 144 0 2.9 .2 5.5 .5 8.4-55.9 19.7-96.5 73.2-96.5 135.6 0 79.2 64.8 144 144 144l72.2 0 0 120.2c0 13.2 10.8 24 24 24s24-10.8 24-24l0-120.2-48 0 0-85.9-89-89c-9.4-9.4-9.4-24.5 0-33.8s24.5-9.4 33.8 0l54.9 55 0-86.2c0-13.2 10.8-24 24-24l.3 .2c13.2 0 24 10.8 24 24l0 239.8 71.8 0c79.2 0 144-64.8 144-144 0-62.4-40.6-115.9-96.5-135.6 0-2.6 .5-5.5 .5-8.4 0-79.4-64.6-144-144-144z", "M240.2 168.2c13.2 0 24 10.8 24 24l0 239.8-48 0 0-85.9-89-89c-9.4-9.4-9.4-24.5 0-33.8s24.5-9.4 33.8 0l54.9 55 0-86.2c0-13.2 10.8-24 24-24l.3 .2z"]],
    "flower": [480, 576, [127804, 10047], "f7ff", ["M123.6 13.9C85.5 36 67 78.5 73.2 119.5 34.6 134.6 7 171.8 7 216s27.6 81.3 66.2 96.5c-6.2 41 12.2 83.5 50.4 105.6 29.5 17.1 63.7 17.7 92.6 5.2l0 128.7c0 13.2 10.8 24 24 24s24-10.8 24-24l0-128.7c29 12.5 63.2 11.9 92.6-5.2 38.2-22.1 56.6-64.6 50.4-105.6 38.6-15.1 66.2-52.6 66.2-96.5s-27.6-81.4-66.2-96.5c6.2-41-12.2-83.5-50.4-105.6S272.7-2.9 240.3 23C207.9-2.9 161.8-8.1 123.6 13.9zM312.3 216a72 72 0 1 1 -144 0 72 72 0 1 1 144 0zm-96 144c0-13.2 10.8-24 24-24s24 10.8 24 24l0 63.3c-8.5-3.7-16.6-8.4-24-14.3-7.4 5.9-15.5 10.6-24 14.3l0-63.3z", "M240.3 336c13.2 0 24 10.8 24 24l0 63.3c-8.5-3.7-16.6-8.4-24-14.3-7.4 5.9-15.5 10.6-24 14.3l0-63.3c0-13.2 10.8-24 24-24zm0-48a72 72 0 1 1 0-144 72 72 0 1 1 0 144z"]],
    "camera": [576, 576, [62258, "camera-alt"], "f030", ["M204.5 72c-7.7 0-15.1 3.8-19.4 10.3L144 144 27.4 144C12.2 144 0 156.2 0 171.4l0 281c0 15.1 12.2 27.4 27.4 27.4l122.6 0c-18.9-27.2-30-60.2-30-95.8 0-92.8 75.2-168 168-168s168 75.2 168 168c0 35.6-11.1 68.6-30 95.8l122.4 0c15.1 0 27.4-12.3 27.4-27.4l0-281c0-15.1-12.3-27.4-27.4-27.4L432 144 391 82.3C386.6 75.8 379.4 72 371.5 72L204.5 72zM150 479.8c30.3 43.6 80.8 72.2 138 72.2s107.7-28.6 138-72.2l-276 0z", "M288 216c92.8 0 168 75.2 168 168 0 35.6-11.1 68.6-30 95.8l-276 0c-18.9-27.2-30-60.2-30-95.8 0-92.8 75.2-168 168-168z"]],
    "eye": [576, 576, [128065], "f06e", ["M284.7 143.1c2.1 7.9 3.3 16.3 3.3 24.9-57.2 0-105 40-117 93.6-26.9-6.2-49.7-24-62.8-47.6-10.2-18.3-37.6-30.6-51.4-14.9-40.1 45.2-56.5 88.4-56.7 89 0 0 72 192 288 192S576 288 576 288c-41.4-110.4-150.5-181.2-264.8-190.7-20.8-1.7-31.8 25.7-26.4 45.9zM192 264c53 0 96-43 96-96 66.3 0 120 53.7 120 120s-53.7 120-120 120-120-53.7-120-120c0-9.1 1-17.9 2.9-26.4 6.8 1.6 13.8 2.4 21.1 2.4z", "M288 168c66.3 0 120 53.7 120 120s-53.7 120-120 120-120-53.7-120-120c0-9.1 1-17.9 2.9-26.4 6.8 1.6 13.8 2.4 21.1 2.4 53 0 96-43 96-96z"]],
    "apple-whole": [576, 576, [127822, 127823, "apple-alt"], "f5d1", ["M432.1 0C354.8 0 288.6 49.8 261.5 120.2l-107.6 0c-92.4 5-162 87.9-153.1 213.6S93.4 581 186.1 575.8c20.2-1.2 38.9-8.2 56.2-19.7 26.6-18 65-18 91.9 0 17 11.5 36 18.5 56.2 19.7 92.4 5.3 176.4-116.2 185.3-241.9 8.6-121.8-56.2-203.3-144.4-212.9-31.8 56.9-91 95.1-158.7 95.1-7.7 0-15.1-.7-22.5-1.7-.7-7.7-1.5-15.4-1.5-23.3 0-25 4.7-48.9 13.1-70.8l160.9 0c2.9 .2 5.8 .4 8.7 .7 15.8-28.2 24.9-61 24.9-96 0-7.9-.7-15.6-1.5-23.3-7.4-1-14.9-1.7-22.5-1.7z", "M422.4 120.2c2.9 .2 5.8 .4 8.7 .7-31.8 56.9-91 95.1-158.7 95.1-7.7 0-15.1-.7-22.5-1.7-.7-7.7-1.5-15.4-1.5-23.3 0-25 4.7-48.9 13.1-70.8l160.9 0z"]],
    "trash": [528, 576, [], "f1f8", ["M201.1 0c-18.2 0-33.4 14.9-33.4 33.4l0 14.6-133.9 0C15.1 48 0 63.1 0 81.8l0 110.2 48 0 0-72 432 0 0 72 48 0 0-110.2C528 63.1 512.9 48 494.2 48L360 48 360 33.4C360 15.1 345.1 0 326.6 0L201.1 0zM48 192l0 350.2C48 560.9 63.1 576 81.8 576l364.3 0c18.7 0 33.8-15.1 33.8-33.8l0-350.2-72 0 0 312-48 0 0-312-72 0 0 312-48 0 0-312-72 0 0 312-48 0 0-312-72 0z", "M48 120l0 72 72 0 0 312 48 0 0-312 72 0 0 312 48 0 0-312 72 0 0 312 48 0 0-312 72 0 0-72-432 0z"]],
    "equals": [528, 576, [62764], "3d", ["M19.2 120C8.6 120 0 128.6 0 139.2L0 244.8C0 255.4 8.6 264 19.2 264l340.8 0 0-144-340.8 0zm0 192C8.6 312 0 320.6 0 331.2L0 436.8C0 447.4 8.6 456 19.2 456l340.8 0 0-144-340.8 0z", "M360 120l0 144 148.8 0c10.6 0 19.2-8.6 19.2-19.2l0-105.6c0-10.6-8.6-19.2-19.2-19.2L360 120zm0 192l0 144 148.8 0c10.6 0 19.2-8.6 19.2-19.2l0-105.6c0-10.6-8.6-19.2-19.2-19.2L360 312z"]],
    "expand": [576, 576, [], "f065", ["M0 0l0 216 72 0 0-144 144 0 0-72-216 0zM360 0l0 72 144 0 0-72-144 0zM504 72l0 144 72 0 0-144-72 0zM0 360l0 144 72 0 0-144-72 0zM72 504l0 72 144 0 0-72-144 0z", "M504 0l0 72 72 0 0-72-72 0zm0 360l0 144-144 0 0 72 216 0 0-216-72 0zM0 504l0 72 72 0 0-72-72 0z"]],
    "stop": [576, 576, [9209], "f04d", ["M312 24c-82 0-155.2 37.4-203.7 96l227.7 0 0 336-227.7 0c48.4 58.6 121.7 96 203.7 96 145.8 0 264-118.2 264-264S457.8 24 312 24zM0 120l0 336 108.3 0q-.2-.3-.5-.6t-.5-.6q-.2-.2-.3-.4-.2-.3-.4-.5-.3-.3-.5-.7-.2-.2-.3-.4-.2-.2-.3-.4-.2-.2-.4-.5-.2-.3-.5-.6-.3-.3-.5-.7-.3-.4-.6-.7-.2-.2-.3-.4-.2-.2-.3-.4-.2-.2-.3-.5-.2-.2-.4-.5-.2-.3-.4-.5-.2-.3-.4-.5-.2-.3-.4-.6-.2-.3-.5-.6-.2-.3-.5-.7-.3-.4-.5-.7-.3-.4-.6-.8-.1-.2-.3-.4t-.3-.4-.3-.4-.3-.4-.3-.4-.3-.5-.3-.5-.3-.5-.4-.5-.4-.5q-.2-.3-.4-.5-.2-.3-.4-.6-.2-.3-.4-.6-.2-.3-.4-.6-.2-.3-.4-.6-.2-.3-.4-.6-.2-.3-.4-.6-.2-.3-.4-.7-.2-.3-.5-.7-.2-.4-.5-.7-.2-.4-.5-.7-.2-.4-.5-.8-.3-.4-.5-.8-.3-.4-.5-.8-.1-.2-.3-.4t-.3-.4-.3-.4-.3-.4-.3-.4-.3-.4-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.4-.6-.4-.6-.4-.7-.4-.7-.4-.7-.4-.7-.4-.7-.4-.7-.4-.7-.4-.7-.4-.7-.4-.8-.4-.8-.4-.8-.4-.8-.4-.8-.4-.8-.4-.8-.4-.8-.4-.9-.4-.9-.4-.9-.4-.9-.4-.9q-.1-.2-.2-.5t-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-1-.2-1-.2-1-.2-1-.2-1-.2-1-.2-1-.2-1-.1-1-.1-1-.1-1-.1-1-.1-1-.1-1.1-.1-1.1-.1-1.1q0-.3-.1-.5t-.1-.5-.1-.5-.1-.5-.1-.5-.1-.5-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.6 0-.7 0-.7 0-.7q0-.5 0-.9t0-.9q0-.3 0-.6 0-.4 0-.8 0-.5 0-1.1 0-.3 0-.6 0-.3 0-.7 0-.4 0-.8 0-.5 0-.9 0-.5 0-1 0-.3 0-.6 0-.3 0-.6 0-.3 0-.6 0-.3 0-.7 0-.4 0-.7 0-.4 0-.8 0-.4 0-.8 0-.4 0-.9 0-.5 .1-.9 0-.5 .1-1 0-.5 .1-1.1 0-.3 0-.5t0-.6 0-.6 0-.6 0-.6q0-.3 0-.6 0-.3 .1-.7 0-.3 .1-.7 0-.4 .1-.7 0-.4 .1-.7 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.9 0-.4 .1-.9 0-.5 .1-.9 .1-.5 .1-.9 .1-.5 .1-1 .1-.5 .1-1 .1-.5 .1-1 .1-.5 .1-1.1 0-.3 .1-.5t.1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.8 .1-.8 .1-.8 .2-.8 .2-.8 .2-.8 .2-.8 .2-.8 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-1 .2-1 .2-1 .2-1 .3-1q.1-.3 .1-.5t.1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .2-.5 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .4-.8 .4-.8 .4-.8 .4-.8 .4-.8 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9q.1-.2 .2-.5t.2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.6 .5-.7 .5-.7 .5-.7L0 120z", "M108.3 120C70.6 165.6 48 224.2 48 288s22.6 122.4 60.3 168l227.7 0 0-336-227.7 0z"]],
    "tv-retro": [576, 576, [128250], "f401", ["M72 0l0 72 504 0 0-72-504 0zM0 72l0 408 240 0 0 48-72 0c-26.4 0-48 21.6-48 48l336 0c0-26.4-21.6-48-48-48l-72 0 0-48 240 0 0-72-504 0 0-336-72 0z", "M72 72l0 336 504 0 0-336-504 0z"]],
    "angle-left": [432, 576, [8249], "f104", ["M273.6 2.6L0 287.9 273.6 573.3c5.3 5.5 14.4 1.7 14.4-6.2l0-183.1 4.9-.1c50.7-2.6 91.1-44.5 91.1-95.9s-40.3-93.3-91.1-95.9l-4.9-.1 0 192c-53 0-96-43-96-96s43-96 96-96t0 0 0 0L288 8.8c0-7.9-9.1-11.8-14.4-6.2z", "M192 288c0 53 43 96 96 96l0-192c-53 0-96 43-96 96z"]],
    "acorn": [528, 576, [], "f6ae", ["M240.3 0l0 72-93.6 0C49.2 72 4.1 131 .5 263.3 .5 269.8 2.7 276 7.2 280.6s10.8 7.2 17.3 7.2l23.8 0 0-37.2c0-19 15.4-34.6 34.6-34.6l362.9 0c19 0 34.6 15.4 34.6 34.6l0 37.2 23.8 0c6.5 0 12.7-2.6 17.3-7.2s7-11.1 6.7-17.3C524.4 131 479.3 72 381.9 72l-93.6 0 0-72-48 0zM48.3 287.8l0 104.9c0 77.3 86.9 145.2 216 183.1 129.1-37.9 216-105.8 216-183.1l0-104.9-432 0z", "M445.7 216c19 0 34.6 15.4 34.6 34.6l0 37.2-432 0 0-37.2c0-19 15.4-34.6 34.6-34.6l362.9 0z"]],
    "envelope-dot": [576, 576, ["envelope-badge"], "e16f", ["M396 24c-59.8 0-108 48.2-108 108 0 12.6 2.2 24.7 6.1 36L22.6 168C10.1 168 0 178.1 0 190.6L0 529.4C0 541.9 10.1 552 22.6 552l530.9 0c12.5 0 22.6-10.1 22.6-22.6l0-338.9c0-12.5-10.1-22.6-22.6-22.6l-55.6 0c-14.8 42-54.7 72-101.9 72s-87.1-30-101.9-72l203.7 0c4-11.3 6.1-23.4 6.1-36 0-59.8-48.2-108-108-108zM51.1 228.5c6.5-11.5 21.1-15.8 32.6-9.4l432 240-.3 .2c11.5 6.5 15.9 21.1 9.4 32.6-4.6 7.7-12.7 12.2-21.1 12.2-3.8 0-7.9-1-11.5-3.1L288 387.6 83.8 501.1c-3.6 2.2-7.7 3.1-11.5 3.1-8.6 0-16.8-4.3-21.1-12.2-6.5-11.5-2.2-26.2 9.4-32.6l178.3-99.1-178.3-99.1C49 254.6 44.6 240 51.1 228.5z", "M51.1 228.5c6.5-11.5 21.1-15.8 32.6-9.4l432 240-.3 .2c11.5 6.5 15.9 21.1 9.4 32.6-4.6 7.7-12.7 12.2-21.1 12.2-3.8 0-7.9-1-11.5-3.1L288 387.6 83.8 501.1c-3.6 2.2-7.7 3.1-11.5 3.1-8.6 0-16.8-4.3-21.1-12.2-6.5-11.5-2.2-26.2 9.4-32.6l178.3-99.1-178.3-99.1C49 254.6 44.6 240 51.1 228.5zM497.9 168c-14.8 42-54.7 72-101.9 72s-87.1-30-101.9-72l203.7 0z"]],
    "circle-half-stroke": [576, 576, [9680, "adjust"], "f042", ["M288 0l0 47.8 12.3 .3c126.5 6.4 227.7 111.6 227.7 239.7 0 132.2-107.7 240-240 240t0 0 0 0 0 0l0 47.8q0 0 0 0t0 0 0 0c159.1 0 288-128.9 288-288 0-156.6-124.9-283.5-280.6-287.4L288 0zM274.5 .3C121.6 7.4 0 133.4 0 288 0 447.1 128.9 576 288 576l0-.5-13.2-.3c-30.8-1.4-60.3-7.9-87.8-18.2l16.8-44.9c23.1 8.6 47.5 14.1 73.1 15.3l11.1 .3 0-480q0 0 0 0t0 0c-29.7 0-58.1 5.8-84.2 15.6L187 18.5C214.4 8.2 243.8 1.8 274.5 .3z", "M203.8 512.2c23.1 8.6 47.5 14.1 73.1 15.3l11.1 .3 0 47.8-13.2-.3c-30.8-1.4-60.3-7.9-87.8-18.2l16.8-44.9zM288 47.8c-29.8 0-58.1 5.7-84.2 15.6L187 18.5c27.4-10.3 56.9-16.7 87.5-18.2 4.5-.2 9-.3 13.5-.3l0 47.8z"]],
    "clock": [576, 576, [128339, "clock-four"], "f017", ["M288 0c-13.2 0-24 10.8-24 24l0 25.2c7.9-.8 15.9-1.2 24-1.2s16.1 .4 24 1.2L312 24c0-13.2-10.8-24-24-24zM264 49.2C150.6 60.5 60.5 150.6 49.2 264L96 264c13.2 0 24 10.8 24 24s-10.8 24-24 24l-46.8 0C60.5 425.4 150.6 515.5 264 526.8l0-46.8c0-13.2 10.8-24 24-24s24 10.8 24 24l0 46.8c47.5-4.7 90.8-23.3 126.1-51.6L272.2 330c-5-4.3-7.9-10.6-8.2-17.3 0-6.7 2.4-13 7-17.8L391 175c9.4-9.4 24.5-9.4 33.8 0s9.4 24.5 0 33.8L323 310.6 472.5 441.4c29.8-35.8 49.4-80.4 54.3-129.4L480 312c-13.2 0-24-10.8-24-24s10.8-24 24-24l46.8 0C515.5 150.6 425.4 60.5 312 49.2L312 96c0 13.2-10.8 24-24 24s-24-10.8-24-24l0-46.8zM24 264c-13.2 0-24 10.8-24 24s10.8 24 24 24l25.2 0c-1.6-16-1.6-32 0-48L24 264zm502.8 0c1.6 16 1.6 32 0 48l25.2 0c13.2 0 24-10.8 24-24s-10.8-24-24-24l-25.2 0zM472.5 441.4c-10.3 12.4-21.9 23.7-34.5 33.8L464.2 498c4.6 4.1 10.3 6 15.8 6l0-.2c6.7 0 13.2-2.6 18-8.2 8.9-9.8 7.9-25.2-2.2-33.8l-23.3-20.4zM264 526.8l0 25.2c0 13.2 10.8 24 24 24s24-10.8 24-24l0-25.2c-7.9 .8-15.9 1.2-24 1.2s-16.1-.4-24-1.2z", "M288 456c13.2 0 24 10.8 24 24l0 46.8c-7.9 .8-15.9 1.2-24 1.2s-16.1-.4-24-1.2l0-46.8c0-13.2 10.8-24 24-24zM391 175c9.4-9.4 24.5-9.4 33.8 0s9.4 24.5 0 33.8L323 310.6 472.5 441.4c-10.3 12.4-21.9 23.7-34.5 33.8L272.2 330c-5-4.3-7.9-10.6-8.2-17.3 0-6.7 2.4-13 7-17.8L391 175zm135.8 89c1.6 16 1.6 32 0 48L480 312c-13.2 0-24-10.8-24-24s10.8-24 24-24l46.8 0zM96 264c13.2 0 24 10.8 24 24s-10.8 24-24 24l-46.8 0c-1.6-16-1.6-32 0-48L96 264zM288 48c8.1 0 16.1 .4 24 1.2L312 96c0 13.2-10.8 24-24 24s-24-10.8-24-24l0-46.8c7.9-.8 15.9-1.2 24-1.2z"]],
    "book": [480, 576, [128212], "f02d", ["M84 0C37.7 0 0 37.7 0 84L0 420c0 46.3 37.7 84 84 84l46.6 0 0-48-46.6 0c-19.9 0-36-16.1-36-36s16.1-36 36-36l46.6 0 0-47.5 133.2-.5 0 48 216.2 0 0-384-396 0zm46.6 384l0 72 133.3 0-.1-72-133.2 0zm133.3 72l0 48 216.1 0 0-48-216.1 0zM130.6 504l0 72 66.7-37 66.7 37-.1-72-133.4 0z", "M263.8 336l-133.2 .5 0 47.5 133.2 0 0-48zM130.6 456l0 48 133.4 0 0-48-133.3 0z"]],
    "alien": [576, 576, [128125], "f8f5", ["M288 0C189.6 0 106.6 73.1 80.6 173.1 184 211.4 259 311.8 264 431.5 197.4 428.5 137 401 90.8 357.5 123.3 456.3 195.7 536 288 576 380.3 536 452.7 456.3 485.2 357.5 439 401 378.6 428.5 312 431.5 317 311.8 392 211.4 495.4 173.1 469.3 73.1 386.4 0 288 0zM0 156.7c3.3 79.7 37.7 150.8 90.8 200.8-12.1-36.9-18.8-76.4-18.8-117.5 0-23.2 3-45.7 8.6-66.9-25.4-9.4-52.4-15.1-80.6-16.4zm576 0c-28.2 1.3-55.2 7-80.6 16.4 5.5 21.2 8.6 43.7 8.6 66.9 0 41.1-6.7 80.7-18.8 117.5 53.1-50 87.5-121.1 90.8-200.8z", "M80.6 173.1c103.4 38.3 178.4 138.7 183.4 258.4-66.6-3-127-30.5-173.2-74-12.1-36.9-18.8-76.4-18.8-117.5 0-23.2 3-45.7 8.6-66.9zm414.9 0c5.5 21.2 8.6 43.7 8.6 66.9 0 41.1-6.7 80.7-18.8 117.5-46.2 43.5-106.6 71-173.2 74 5-119.7 80-220.2 183.4-258.4z"]],
    "paper-plane": [576, 576, [61913], "f1d8", ["M576 0L0 216 189.1 342.1 189.1 342 576 0zm0 0L297.6 414.4 432 504 576 0zM189.1 342.1l0 233.9 108.5-161.6-108.5-72.3z", "M576 0l-386.9 342 0 .1 108.5 72.3 278.4-414.4z"]],
    "heart": [576, 576, [128153, 128154, 128155, 128156, 128420, 129293, 129294, 129505, 9829, 10084, 61578], "f004", ["M288.5 114.7C154.1-106.9-167.4 147.4 109.9 418.3l.1 0 .5-.1 401.5-50.2C705.3 117.6 414.5-93.2 288.5 114.7z", "M109.9 418.3c43.7 42.7 102 85.7 178.6 127.4 106.6-58.1 178.3-119 223.4-177.6l-402 50.2z"]],
    "font-awesome": [528, 576, [62501, 62694, "font-awesome-flag", "font-awesome-logo-full"], "f2b4", ["M60 0C40.1 0 24 16.1 24 36l0 12 72 0 0-12C96 16.1 79.9 0 60 0zM96 48l0 384 432 0-120-192 120-192-432 0zM24 432l0 144 72 0 0-144-72 0z", "M24 48l72 0 0 384-72 0 0-384z"]],
    "clone": [480, 576, [], "f24d", ["M120 0l0 120 96 0 144 144 0 192 120 0 0-456-360 0zM0 120l0 456 360 0 0-120-240 0 0-336-120 0z", "M120 120l0 336 240 0 0-192-144-144-96 0z"]],
    "forward": [576, 576, [9193], "f04e", ["M312 24C207.7 24 117.5 84.5 74.7 172.3l117.3 82.1 0-134.4 240 168-240 168 0-134.4-117.3 82.1C117.5 491.5 207.7 552 312 552 457.8 552 576 433.8 576 288S457.8 24 312 24zM0 120l0 336 74.7-52.3q-.2-.3-.3-.7t-.3-.7q-.1-.2-.2-.5-.1-.3-.3-.6-.2-.4-.4-.8-.1-.2-.2-.5-.1-.3-.3-.5-.1-.3-.3-.6-.2-.4-.3-.7-.2-.4-.4-.8-.2-.5-.4-.9-.1-.2-.2-.5-.1-.3-.2-.5-.1-.3-.2-.6-.1-.3-.3-.6-.1-.3-.3-.6-.1-.3-.3-.7-.2-.4-.3-.7-.2-.4-.3-.8-.2-.4-.3-.8-.2-.4-.4-.9-.2-.5-.4-.9-.1-.2-.2-.5t-.2-.5-.2-.5-.2-.5-.2-.5-.2-.6-.2-.6q-.1-.3-.2-.6-.1-.3-.2-.6-.1-.3-.2-.6-.1-.3-.3-.7-.1-.3-.3-.7-.1-.4-.3-.7-.1-.4-.3-.7-.1-.4-.3-.7-.1-.4-.3-.8-.1-.4-.3-.8-.1-.4-.3-.8-.2-.4-.3-.9-.2-.4-.3-.9-.2-.5-.3-.9-.2-.5-.3-.9-.2-.5-.3-1-.1-.2-.2-.5t-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.7-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.8-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-.9-.2-1-.2-1-.2-1-.2-1-.2-1-.2-1-.2-1q0-.3-.1-.5t-.1-.5-.1-.5-.1-.5-.1-.5-.1-.5-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.8-.1-.8-.1-.8 0-.8 0-.8 0-.8 0-.8 0-.8 0-.8 0-.8 0-.8 0-.8 0-.8 0-.8 0-.8 0-.8 0-.9 0-.9 0-.9 0-.9 0-.9 0-.9 0-.9 0-.9 0-.9 0-.9q0-.3 0-.6 0-.4 0-.8 0-.5 0-1.1 0-.3 0-.6 0-.3 0-.7 0-.4 0-.8 0-.5 0-.9 0-.5 0-1 0-.3 0-.6 0-.3 0-.6 0-.3 0-.6 0-.3 0-.7 0-.4 0-.7 0-.4 0-.8 0-.4 0-.8 0-.4 0-.9 0-.5 .1-.9 0-.5 .1-1 0-.5 .1-1.1 0-.3 0-.5t0-.6 0-.6 0-.6 0-.6q0-.3 0-.6 0-.3 .1-.7 0-.3 .1-.7 0-.4 .1-.7 0-.4 .1-.7 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.9 0-.4 .1-.9 0-.5 .1-.9 .1-.5 .1-.9 .1-.5 .1-1 .1-.5 .1-1 .1-.5 .1-1 .1-.5 .1-1.1 0-.3 .1-.5t.1-.5 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.8 .1-.8 .1-.8 .2-.8 .2-.8 .2-.8 .2-.8 .2-.8 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-1 .2-1 .2-1 .2-1 .3-1q.1-.3 .1-.5t.1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .2-.5 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .4-.8 .4-.8 .4-.8 .4-.8 .4-.8 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9q.1-.2 .2-.5L0 120z", "M192 120l0 134.4-117.3-82.1C57.6 207.2 48 246.5 48 288s9.6 80.8 26.7 115.7L192 321.6 192 456 432 288 192 120z"]],
    "triangle": [576, 576, [9650], "f2ec", ["M280.1 31.4l-227.5 394 439.1-54.9-195.8-339.1 .2 0c-3.6-6.2-12.5-6.2-16.1 0z", "M1.3 514.1c-3.6 6.2 1 13.9 7.9 13.9l557.5 0c7.2 0 11.5-7.7 7.9-13.9l-82.8-143.5-439.4 55-51.1 88.6z"]],
    "folder-open": [576, 576, [128194, 128449, 61717], "f07c", ["M23.8 72C10.8 72 0 82.6 0 95.8L0 504 89.3 259c4.1-11.5 14.9-19 26.9-19l363.8 0 0-74.4c0-12-9.6-21.6-21.6-21.6l-242.4 0 0-48.2c0-13-10.6-23.8-23.8-23.8L23.8 72zM480 240l0 264 90-247.4c2.9-8.2-3.1-16.6-11.5-16.6L480 240z", "M480 240l0 264-480 0 89.3-245c4.1-11.5 14.9-19 26.9-19L480 240z"]],
    "bullseye-arrow": [576, 576, [127919], "f648", ["M264 0C118.1 0 0 118.1 0 264S118.1 528 264 528c42 0 81.6-9.8 116.8-27.2L336 456 339.9 440.3c44.9-19.4 81-55.5 100.4-100.4l15.7-3.9 44.8 44.8c-25.7 52-68 94.3-120 120l75.2 75.2 24-96 96-24-75.2-75.2C518.2 345.6 528 306 528 264 528 118.1 409.9 0 264 0zm0 72c105.8 0 192 86.2 192 192 0 27-5.6 52.6-15.7 75.9l-53.2 13.4-23.1-23.1c12.6-19 20-41.7 20-66.2 0-66.2-53.8-120-120-120s-120 53.8-120 120 53.8 120 120 120c24.5 0 47.2-7.4 66.2-20l-83-83c-9.4-9.4-9.4-24.5 0-33.8s24.5-9.4 33.8 0l83 83c-8.9 13.4-20.4 24.9-33.8 33.8l23.1 23.1-13.4 53.2C316.6 450.4 291 456 264 456 158.2 456 72 369.8 72 264S158.2 72 264 72z", "M500.8 380.8c-25.7 52-68 94.3-120 120L336 456 339.9 440.3c44.9-19.4 81-55.5 100.4-100.4l15.7-3.9 44.8 44.8zM247.2 247.2c9.4-9.4 24.5-9.4 33.8 0l83 83c-8.9 13.4-20.4 24.9-33.8 33.8l-83-83c-9.4-9.4-9.4-24.5 0-33.8z"]],
    "seedling": [576, 576, [127793, "sprout"], "f4d8", ["M72 0c14.2 91 80.4 163.4 166.1 185 15.1 3.8 25.9 17.5 25.9 33.1l0 70.8c7.9-.7 15.9-1 24-1s16.1 .3 24 1l0-70.8c0-15.6 10.6-29.3 25.9-33.1 85.9-21.6 151.9-94.1 166.1-185-98.6 1.4-181.7 68.9-209.3 161.5-2.2 6.9-11.5 6.9-13.7 0-27.4-92.6-110.4-160.1-209-161.5zM264 289C116.1 301.2 0 425 0 576l576 0c0-151-116.1-274.8-264-287l0 119-48 0 0-119z", "M288 288c8.1 0 16.1 .3 24 1l0 119-48 0 0-119c7.9-.7 15.9-1 24-1z"]],
    "star-half": [576, 576, [61731], "f089", ["M288 9.1L199 189.4 0 218.4 144 358.8 109.9 556.8 288 312 288 9.1z", "M109.9 556.8L288 463.2 288 312 109.9 556.8z"]],
    "arrow-down-to-line": [576, 576, ["arrow-to-bottom"], "f33d", ["M0 0l0 168 264 0 0-72c0-13.3 10.7-24 24-24s24 10.7 24 24l0 72 264 0 0-168-576 0zM264 168l0 326.1-55-55c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l96 96 1.8 1.6c9.4 7.7 23.3 7.1 32.1-1.6l96-96c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-55 55 0-326.1-48 0z", "M312 96c0-13.3-10.7-24-24-24s-24 10.7-24 24l0 72 48 0 0-72z"]],
    "fire": [432, 576, [128293], "f06d", ["M189 0c.1 .3 34.8 78.4-81.1 159.6-108.7 76.1-139.9 187.9-71.8 265.4 .5 .5 .7 1 1.2 1.2 3.1 3.4 6.5 6.7 10.1 10.1 17.9 17 38.7 31.4 61.4 42.5-1.8-17.9-.1-36.8 5-55.2 29.6-105.7 118.5-159 119.5-159.6-17.3 109.2 59.8 124.6 79.5 168 6.5 14.3 10.6 30.7 11.2 47.1-31 15.8-67.1 24.9-106 24.9-39.1 0-76.3-9.2-109.2-25.2 5.2 52.8 40 97.2 101.5 97.2 87.1 0 115.4-48.8 113.6-96.9 68.4-34.9 112.3-103 107.9-181.3-3.1-52.3-27.4-100.1-64.8-136.6-8.2 70.3-45.6 76.3-45.6 76.3-12.7-167.4-132-237.3-132.5-237.6z", "M233.3 264c-17.3 109.2 59.8 124.6 79.5 168 6.5 14.3 10.6 30.7 11.2 47.1-31 15.8-67.1 24.9-106 24.9-39.1 0-76.3-9.2-109.2-25.2-1.8-17.9-.1-36.8 5-55.2 29.6-105.7 118.5-159 119.5-159.6z"]],
    "rectangle-vertical": [384, 576, ["rectangle-portrait"], "f2fb", ["M24 24C10.7 24 0 34.7 0 48l0 372 384-48 0-324c0-13.3-10.7-24-24-24L24 24z", "M384 372L0 420 0 528c0 13.3 10.7 24 24 24l336 0c13.3 0 24-10.7 24-24l0-156z"]],
    "print": [576, 576, [128424, 128438, 9113], "f02f", ["M120 0l0 144 336 0 0-48-96-96-240 0zM27.8 144C12.5 144 0 156.5 0 171.8L0 428.2C0 443.5 12.5 456 27.8 456l92.2 0 0-144 336 0 0 144 92.2 0c15.4 0 27.8-12.5 27.8-27.8l0-256.3c0-15.4-12.5-27.8-27.8-27.8l-92.2 0 0 72-336 0 0-72-92.2 0zM120 456l0 120 336 0 0-120-336 0z", "M120 144l0 72 336 0 0-72-336 0zm0 168l0 144 336 0 0-144-336 0z"]],
    "users": [576, 576, [], "f0c0", ["M192 0c-58 0-106.4 35.6-117.6 97.8 3-1.1 6.2-1.8 9.6-1.8 19.9 0 36 21.6 36 48s-16.1 48-36 48l-.1 0c19.4 53.4 60.5 96 108.1 96-106.1 0-192 64.6-192 144l360 0q0 0 0 0t0 0 0 0c66.2 0 120-82.6 120-162 0-79.4-53.8-126-120-126-18 0-35 3.6-50.2 10.3 1.4-9.4 2.2-19 2.2-28.3 0-79.4-53.8-126-120-126zM360 432q0 0 0 0t0 0c-59.7 0-109.1-67.6-118.3-139.1 80.4 16.2 139.9 70.5 142.1 135.5-7.7 2.2-15.6 3.6-23.7 3.6t0 0 0 0 0 0zM168 144c0-26.4 16.1-48 36-48s36 21.6 36 48-16.1 48-36 48-36-21.6-36-48zM74.4 97.8c-15.3 5.6-26.4 24.2-26.4 46.2 0 26.3 16 47.9 35.9 48-7.6-21-11.9-43.6-11.9-66 0-9.9 .8-19.4 2.4-28.2zM360 432c-106.1 0-192 64.6-192 144l384 0c0-79.4-85.9-144-192-144z", "M241.7 292.9c80.4 16.2 139.9 70.5 142.1 135.5-7.7 2.2-15.6 3.6-23.8 3.6-59.7 0-109.2-67.6-118.3-139.1zM84 96c19.9 0 36 21.6 36 48s-16.1 48-36 48l-.1 0c-7.6-21-11.9-43.6-11.9-66 0-9.9 .8-19.4 2.4-28.2 3-1.1 6.2-1.8 9.6-1.8zm120 0c19.9 0 36 21.6 36 48s-16.1 48-36 48-36-21.6-36-48 16.1-48 36-48z"]],
    "alarm-clock": [576, 576, [9200], "f34e", ["M120 0c-29.8 0-57 10.9-78 28.9-2.7 1.5-5.2 3.4-7.5 5.7s-4.2 4.8-5.7 7.5c-18 21-28.8 48.2-28.9 78 0 19.9 16.1 36 36 36 19 0 34.5-14.6 35.9-33.2l33.5 33.5C121.1 138 139.5 122 159.9 109L122.8 71.9C141.4 70.5 156 55 156 36 156 16.1 139.9 0 120 0zM456 0c-19.9 0-36 16.1-36 36 0 18.9 14.6 34.4 33.2 35.9L416 109c-37.1-23.4-81-37-128-37s-91 13.6-128 37.1l9.5 9.5c14.1 14.1 14.1 36.8 0 50.9s-36.8 14.1-50.9 0l-13.1-13.1C69.7 198.2 48 252.6 48 312 48 370 68.6 423.2 102.9 464.7l-74.2 111.3 86.5 0 41.9-62.8C194.8 537.7 239.7 552 288 552s93.2-14.3 130.8-38.8l41.9 62.8 86.5 0-74.2-111.2c11.9-14.4 22.1-30.1 30.4-47l41.3 13.1c12.6 4 26.1-3 30.1-15.6 4-12.6-3-26.1-15.6-30.1l-39-12.4c5.1-19.4 7.8-39.7 7.8-60.7 0-59.4-21.6-113.8-57.4-155.7l-13.1 13.1c-14.1 14.1-36.8 14.1-50.9 0s-14.1-36.8 0-50.9L416 109c20.5 12.9 38.9 28.9 54.5 47.3l33.6-33.6c1.4 18.6 16.9 33.3 35.9 33.3 19.9 0 36-16.1 36-36 0-29.8-10.9-57-28.9-78-1.5-2.7-3.4-5.2-5.7-7.5s-4.8-4.1-7.4-5.7C513 10.9 485.8 0 456 0zM264 168c0-13.3 10.7-24 24-24s24 10.7 24 24l0 138.4 208.2 66.3c-4.1 15.7-9.8 30.7-16.8 45L280.7 346.9c-10-3.2-16.7-12.4-16.7-22.9l0-156z", "M288 144c13.3 0 24 10.7 24 24l0 138.4 208.2 66.3c-4.1 15.7-9.8 30.7-16.8 45L280.7 346.9c-10-3.2-16.7-12.4-16.7-22.9l0-156c0-13.3 10.7-24 24-24zM169.5 118.6c14.1 14.1 14.1 36.8 0 50.9s-36.8 14.1-50.9 0l-13.1-13.1C121.1 138 139.5 122 159.9 109l9.5 9.5zM416 109c20.5 13 38.9 28.9 54.5 47.3l-13.1 13.1c-14.1 14.1-36.8 14.1-50.9 0s-14.1-36.8 0-50.9L416 109z"]],
    "database": [480, 576, [], "f1c0", ["M240 0C107.5 0 0 53.8 0 120 0 152.7 26.2 182.3 68.7 204 112.2 181.8 172.9 168 240 168s127.8 13.8 171.3 36C453.8 182.3 480 152.7 480 120 480 53.8 372.5 0 240 0zM68.7 204C26.2 225.6 0 255.3 0 288s26.2 62.4 68.7 84c43.6-22.2 104.2-36 171.3-36 67.1 0 127.7 13.8 171.3 36 42.5-21.6 68.7-51.3 68.7-84s-26.2-62.4-68.7-84c-43.6 22.2-104.2 36-171.3 36-67.1 0-127.8-13.8-171.3-36zm0 168C26.2 393.7 0 423.3 0 456 0 522.2 107.5 576 240 576s240-53.8 240-120c0-32.7-26.2-62.3-68.7-84-43.6 22.2-104.2 36-171.3 36S112.2 394.2 68.7 372z", "M240 336c67.1 0 127.7 13.8 171.3 36-43.6 22.2-104.2 36-171.3 36S112.2 394.2 68.7 372c43.6-22.2 104.2-36 171.3-36zm0-168c67.1 0 127.8 13.8 171.3 36-43.6 22.2-104.2 36-171.3 36-67.1 0-127.8-13.8-171.3-36 43.6-22.2 104.2-36 171.3-36z"]],
    "newspaper": [576, 576, [128240], "f1ea", ["M72 24l0 96-72 0 0 360c0 39.6 32.4 72 72 72l384 0c39.6 0 72-32.4 72-72l-192 0 0-48 192 0 0-48-192 0 0-48 192 0 0-48-408 0 0-216 408 0 0-48-456 0zM528 72l0 216 48 0 0-216-48 0zM120 480l0-144 168 0 0 144-168 0zM528 336l0 48 48 0 0-48-48 0zm0 96l0 48 48 0 0-48-48 0z", "M120 72l0 216 408 0 0-216-408 0zm0 264l0 144 168 0 0-144-168 0zm216 0l0 48 192 0 0-48-192 0zm0 96l0 48 192 0 0-48-192 0z"]],
    "location-arrow": [528, 576, [], "f124", ["M524.1 22.6L4.2 260.9c-2.9 1.4-2.4 5.8 1 6.2l240 40 283.6-283.6 0-.1c-1.2-1.2-3-1.7-4.8-.8z", "M528.9 23.5L245.2 307.2 285.3 547.4c.5 3.4 5 3.8 6.2 1L529.8 28.3c1-1.9 .2-3.8-1-5l0 .2z"]],
    "arrow-right-to-bracket": [576, 576, ["sign-in"], "f090", ["M312 0l0 96 72 0 0 110.1 65 65 1.6 1.8c7.7 9.4 7.1 23.3-1.6 32.1l-65 65 0 110.1-72 0 0 96 228 0c19.9 0 36-16.1 36-36l0-504c0-19.9-16.1-36-36-36L312 0zm7 175c-9.4 9.4-9.4 24.6 0 33.9l55 55-350.1 0c-13.3 0-24 10.7-24 24s10.7 24 24 24l350.1 0-55 55c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l31-31 0-163.9-31-31c-9.4-9.4-24.6-9.4-33.9 0z", "M449 271l1.6 1.8c7.7 9.4 7.1 23.3-1.6 32.1l-65 65 0-163.9 65 65z"]],
    "strawberry": [480, 576, [], "e32b", ["M240.4 0c-13.2 0-24 10.8-24 24l0 25c-91.9 6.5-180.7 49.9-219.4 127.9 14.7 5.5 30.7 9.5 47.5 12.1-12.5 21.3-19.8 46.2-20.2 74.8l0 3.8c0 130.8 86.6 244.8 216 308.4 129.4-63.6 216-177.6 216-308.4l0-3.8c-.4-28.6-7.7-53.5-20.1-74.8 16.8-2.6 32.8-6.6 47.5-12.1-38.9-78-127.7-121.4-219.4-127.9l0-25c0-13.2-10.8-24-24-24zM44.5 188.9c72.5-123.9 319.3-123.9 391.7 0-12.8 1.9-26.2 3-39.9 3-31.7 0-61.4-5.8-87.4-15.4-15.1 30.7-38.9 56.6-68.6 73.9-29.8-17.3-53.5-43-68.6-73.9-25.9 9.8-55.7 15.4-87.4 15.4-13.7 0-27-1.1-39.8-3z", "M44.5 188.9c72.5-123.9 319.3-123.9 391.7 0-12.8 1.9-26.2 3-39.9 3-31.7 0-61.4-5.8-87.4-15.4-15.1 30.7-38.9 56.6-68.6 73.9-29.8-17.3-53.5-43-68.6-73.9-25.9 9.8-55.7 15.4-87.4 15.4-13.7 0-27-1.1-39.8-3z"]],
    "video-slash": [576, 576, [], "f4e2", ["M437.3 8.9L366 96 408 96c6.1 0 11.9 1.2 17.3 3.3L113.9 480 52.1 480 366 96 48 96C21.5 96 0 117.5 0 144L0 432c0 26.5 21.5 48 48 48l4.1 0-46.5 56.9c-8.4 10.3-7 25.4 3.4 33.8 4.6 3.6 9.8 5.5 15.1 5.5 7 0 13.9-2.9 18.5-8.9L113.9 480 408 480c26.5 0 48-21.5 48-48l0-80 120 80 0-288-120 80 0 128-96-64 96-64 0-80c0-20.4-12.8-37.8-30.7-44.7l49.2-60.1c8.4-10.3 7-25.4-3.4-33.8l0 .2c-10.3-8.4-25.4-6.9-33.8 3.4z", "M408 96c6.1 0 11.9 1.2 17.3 3.3L113.9 480 52.1 480 366 96 408 96zm48 256l-96-64 96-64 0 128z"]],
    "comment": [528, 576, [128489, 61669], "f075", ["M288 72C173.7 72 78 144 53.9 240.4 77.5 243.3 96 263.6 96 288s-18.5 44.6-42.1 47.6C78 432 173.7 504 288 504 331.9 504 372.7 493.2 408.2 474.7L528 528 479.3 418.1C509.8 381.8 528 337 528 288 528 168.7 420.5 72 288 72zM48 240c-26.4 0-48 21.6-48 48s21.6 48 48 48c2 0 4-.2 5.9-.4-3.8-15.3-5.9-31.2-5.9-47.6s2.1-32.3 5.9-47.6c-1.9-.2-3.9-.4-5.9-.4zm216 48a48 48 0 1 1 -96 0 48 48 0 1 1 96 0zm168 0a48 48 0 1 1 -96 0 48 48 0 1 1 96 0z", "M216 336a48 48 0 1 1 0-96 48 48 0 1 1 0 96zm168 0a48 48 0 1 1 0-96 48 48 0 1 1 0 96zM53.9 240.4C77.5 243.3 96 263.6 96 288s-18.5 44.6-42.1 47.6C50.1 320.3 48 304.4 48 288s2.1-32.3 5.9-47.6z"]],
    "video": [576, 576, ["video-camera"], "f03d", ["M48 96C21.5 96 0 117.5 0 144L0 432c0 26.5 21.5 48 48 48l360 0c26.5 0 48-21.5 48-48l0-80 120 80 0-288-120 80 0-80c0-26.5-21.5-48-48-48L48 96zM456 352l-96-64 96-64 0 128z", "M456 224l-96 64 96 64 0-128z"]],
    "mug": [576, 576, [], "f874", ["M0 24L0 456.2C0 509 43 552 95.8 552l264.7 0c52.6 0 95.8-43 95.8-95.8l0-24.2-96.2 0 0-72 96.2 0 0-168-96.2 0 0-72 96.2 0 0-96-456.2 0zm456.2 96l0 72 37 0c7 25.7 10.8 54.5 10.8 84s-3.8 58.3-10.8 84l-37 0 0 72 83.8 0c22.3-40.8 36-95.5 36-156s-13.7-115.2-36-156l-83.8 0z", "M456.2 432l-96.2 0 0-72 96.2 0 0 72zm0-312l0 72-96.2 0 0-72 96.2 0z"]],
    "clipboard": [432, 576, [128203], "f328", ["M216 0c-39.6 0-72 32.4-72 72l0 48 144 0 0-48c0-39.6-32.4-72-72-72zm24 72a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zM41.3 120C18.5 120 0 138.5 0 161.3L0 534.7C0 557.5 18.5 576 41.3 576l349.5 0c22.8 0 41.3-18.5 41.3-41.3l0-373.5c0-22.8-18.5-41.3-41.3-41.3L288 120c39.8 0 72 32.2 72 72L72 192c0-39.8 32.2-72 72-72L41.3 120z", "M288 120c39.8 0 72 32.2 72 72L72 192c0-39.8 32.2-72 72-72l144 0z"]],
    "laptop": [576, 576, [128187], "f109", ["M96 24l0 48 384 0 0-48-384 0zM48 72l0 312 480 0 0-312-48 0 0 264-384 0 0-264-48 0zm0 360l-48 120 576 0-48-120-480 0z", "M96 72l0 264 384 0 0-264-384 0z"]],
    "thumbs-down": [576, 576, [128078, 61576], "f165", ["M427 48c-10.5 0-19 8.5-19 19l0 28.7c-27.7-1.1-54.4-6.1-78-20.8-27.6-16.8-59-25.9-91.4-25.9L108 49C88.3 49 72 66.5 72 87.8s16.3 38.9 36 38.9l-24 0c-19.7 0-36 17.5-36 38.9s16.3 38.9 36 38.9l-24 0c-19.7 0-36 17.5-36 38.9s16.3 38.9 36 38.9l-24 0c-19.7 0-36 17.5-36 38.9S16.3 360 36 360l167.3 0c-13.9 23.8-24.5 49.4-31.2 76.1l-14.9 59.3c-4.8 19.2 7 38.9 26.2 43.7 19.4 5 38.9-7 43.7-26.2l1.2-5c12.5-50.6 42.7-94.8 85-125l91.7-65.5c1.2-.7 3-2.5 3.1-2.6l0 26.4c0 10.5 8.5 19 19 19L557 360c10.5 0 19-8.5 19-19L576 67c0-10.5-8.5-19-19-19L427 48zM408 95.7c4.5 .2 8.9 .3 13.4 .3l82.6 0 0 216.7-96 0 0-217zM228.2 362.2l.7-2.2 1.2 0c-.5 .7-1.7 2.2-1.7 2.2l-.2 0z", "M408 95.7c4.5 .2 8.9 .3 13.4 .3l82.6 0 0 216.7-96 0 0-217z"]],
    "utensils": [576, 576, [127860, 61685, "cutlery"], "f2e7", ["M429.1 0l-77 91.9c-31.9 38.2-40.8 86.4-26.2 122.6l-52.4 58.9-52.7-59.2c13.7-37.4 2.2-89-32.9-130.8-47-55.9-117.8-73.7-158.4-39.6S-6 150.7 40.6 206.4c35 42 84 62.2 123.1 55.2l56.6 71.7 53.2-59.8 53.6 60.2-53.3 67.5-53.5-67.8-137.3 154.4c-17 20.2-14.4 50.6 6 67.7 20.2 17 50.6 14.4 67.7-6l117.1-148.3 116.9 148c17 20.2 47.5 22.8 67.7 6 20.2-17 22.8-47.5 6-67.7l0 .2-137.3-154 56.1-71.1c38.2 8.4 84.2-8.9 116.2-47l77-91.9-21.4-17.8-77 91.9-20.9-17.5 77-91.9-20.9-17.5-77 91.9-20.9-17.5 77-91.9-20.9-17.5-77 91.9-20.9-17.5 77-91.9-21.6-18.2z", "M273.5 273.5l-53.2 59.8 53.5 67.8 53.3-67.5-53.6-60.2z"]],
    "microphone": [432, 576, [], "f130", ["M216 0C149.7 0 96 53.7 96 120l0 168 240 0 0-168C336 53.7 282.3 0 216 0zM0 288l0 72C0 479 97 576 216 576s216-97 216-216l0-72-96 0 0 48 48 0 0 24c0 92.6-75.4 168-168 168S48 452.6 48 360l0-24 48 0 0-48-96 0zm96 48l0 24c0 66.3 53.7 120 120 120s120-53.7 120-120l0-24-240 0z", "M96 288l0 48 240 0 0-48-240 0z"]],
    "crown": [576, 576, [128081], "f521", ["M0 48L59.5 385.1c4.1-.7 8.2-1.1 12.5-1.1l432 0c4.3 0 8.4 .4 12.5 1.1L576 48 391 223 288 48 185 223 0 48zM59.5 385.1C25.7 391 0 420.5 0 456 0 495.8 32.2 528 72 528l432 0c39.8 0 72-32.2 72-72 0-35.5-25.7-65-59.5-70.9L504 456 72 456 59.5 385.1z", "M504 384c4.3 0 8.4 .4 12.5 1.1L504 456 72 456 59.5 385.1c4.1-.7 8.2-1.1 12.5-1.1l432 0z"]],
    "arrow-up-wide-short": [576, 576, ["sort-amount-up"], "f161", ["M79.3 7L7 79c-9.4 9.4-9.4 24.5 0 33.8s24.5 9.4 33.8 0l31-31 0 470.2c0 13.2 10.8 24 24 24s24-10.8 24-24l0-470.2 31 31c4.8 4.8 10.8 7 17 7s12.2-2.4 17-7c9.4-9.4 9.4-24.5 0-33.8l.3 0-72-72c-9.4-9.4-24.5-9.4-33.8 0zm112.8 137l0 96 288 0 0 48 0 0-288 0 0 48 192 0 0 0 0 48 96 0 0-96 96 0 0-144-384 0zm0 240l0 48 96 0 0 48 0 0-96 0 0 96 96 0 0-96 96 0 0-96-192 0z", "M192 240l0 48 288 0 0-48-288 0zm0 96l0 48 192 0 0-48-192 0zm0 96l0 48 96 0 0-48-96 0z"]],
    "sun": [576, 576, [9728], "f185", ["M279.6 4l-60 72.6-91.4-23.3c-6.5-1.7-13 3.1-13.4 9.8l-6 94.2-87.8 35c-6.2 2.4-8.6 10.1-5 15.8L66.2 288 15.8 367.8c-3.8 5.8-1.2 13.4 5 15.8l87.8 35 6 94.2c.5 6.7 7 11.5 13.4 9.8l91.4-23.3 60.2 72.6c4.3 5.3 12.2 5.3 16.6 0l60.2-72.6 91.4 23.3c6.5 1.7 13-3.1 13.4-9.8l6-94.2 87.8-35c6.2-2.4 8.6-10.1 5-15.8L510 288 560.4 208.2c3.8-5.8 1.2-13.4-5-15.8l-87.8-35-6-94.2c-.5-6.7-7-11.5-13.4-9.8l-91.4 23.3-60.2-72.6-.2 0c-4.3-5.3-12.2-5.3-16.6 0zM455.9 288a167.9 167.9 0 1 1 -335.8 0 167.9 167.9 0 1 1 335.8 0z", "M288.1 456a168 168 0 1 0 -.2-336 168 168 0 1 0 .2 336z"]],
    "image": [576, 576, [], "f03e", ["M396 48c-33.4 0-62.4 19.6-75.9 48l151.7 0C458.4 67.6 429.4 48 396 48zM48 96l0 234.7 85.2-102.7 174.5 210 82.8-99.6 97.7 117.6 87.9 0 0-360-104.1 0c5.2 10.9 8.1 23.1 8.1 36 0 46.3-37.7 84-84 84s-84-37.7-84-84c0-12.9 2.9-25.1 8.1-36L48 96zm0 234.7l-48 57.9 0 115.4 528 0-39.9-48-440.1 0 0-125.3z", "M307.7 438L390.5 338.4 488.1 456 48 456 48 330.7 133.2 228 307.7 438zM471.9 96c5.2 10.9 8.1 23.1 8.1 36 0 46.3-37.7 84-84 84s-84-37.7-84-84c0-12.9 2.9-25.1 8.1-36l151.7 0z"]],
    "notdef": [432, 576, [], "e1fe", ["M389.1 9.9L361.3 48c12.9 .4 23.2 11 23.2 24l0 25.8-138.4 190.2 138.4 190.2 0 25.8c0 13-10.3 23.5-23.1 24l27.7 38.2c7.8 10.7 22.8 13.1 33.5 5.3s13.1-22.8 5.3-33.5l-43.4-59.7 0-380.4 43.4-59.7c7.8-10.7 5.4-25.7-5.3-33.5-10.7-7.8-25.7-5.4-33.5 5.3zM10.4 4.6C-.3 12.4-2.7 27.4 5.1 38.1L48.5 97.8 48.5 478.2 186.8 288 48.5 97.8 48.5 72c0-13 10.3-23.5 23.1-24L43.9 9.9C36.1-.8 21.1-3.2 10.4 4.6zM72.5 48c-.3 0-.6 0-.9 0L216.5 247.2 361.3 48c-.3 0-.6 0-.8 0l-288 0zm144 280.8L71.6 527.9c.3 0 .6 .1 .9 .1l288 0c.3 0 .6-.1 .8-.1L216.5 328.8zM48.5 478.2L5.1 537.9c-7.8 10.7-5.4 25.7 5.3 33.5 10.7 7.8 25.7 5.4 33.5-5.3L71.6 528c-12.8-.5-23.1-11-23.1-24l0-25.8z", "M71.6 48c-12.9 .5-23.1 11-23.1 24l0 25.8 138.3 190.2-138.3 190.2 0 25.8c0 13 10.3 23.5 23.1 24L216.5 328.8 361.3 528c12.9-.4 23.2-11 23.2-24l0-25.8-138.4-190.2 138.4-190.2 0-25.8c0-13-10.3-23.5-23.2-24L216.5 247.2 71.6 48z"]],
    "comment-question": [576, 576, [], "e14b", ["M264 0c-145.9 0-264 118.1-264 264 0 125.4 87.2 230.1 204.2 257.1-.1-1.7-.2-3.4-.2-5.1 0-33.1 26.9-60 60-60s60 26.9 60 60c0 1.7-.1 3.4-.3 5.1 24.4-5.7 47.5-14.8 68.9-26.7L576 576 494.4 392.6C515.8 354.5 528 310.8 528 264 528 118.1 409.9 0 264 0zM191.5 113.8c21.6-11.8 47-17.8 75.8-17.8 26.9 0 50.4 5 71 14.9 20.4 9.8 36.3 23.3 47.5 40.3l-.2 .5c11.3 17 16.8 35.5 16.8 55.4 0 15.6-3.1 29.5-9.6 41.3-6.5 12-14.2 22.1-22.8 30.7s-24.5 23.1-47.3 43.5c-6.2 5.8-11.3 10.8-15.1 15.1s-6.5 8.4-8.4 12-3.4 7.2-4.3 10.8-2.6 9.8-4.6 19c-3.6 19.2-14.6 28.8-33.1 28.8-9.6 0-17.8-3.1-24.2-9.4s-9.8-15.6-9.8-28.1c0-15.4 2.4-29.1 7.2-40.3 4.8-11.5 11.3-21.4 19.2-30s18.7-18.9 32.2-30.7c11.8-10.3 20.4-18.2 25.7-23.5s9.9-11 13.5-17.5 5.5-13.4 5.5-21.1c0-14.9-5.5-27.4-16.5-37.5-11-10.3-25.4-15.4-42.7-15.4-20.2 0-35.3 5-44.9 15.4s-17.7 25.5-24.5 45.4c-6.2 20.9-18.2 31.4-35.8 31.4-10.3 0-19-3.8-26.2-11-7.2-7.4-10.8-15.4-10.8-23.8 0-17.8 5.8-35.5 17-53.5s27.8-33.1 49.4-44.9zm12.7 407.4c2.6 30.7 28.4 54.9 59.8 54.9s57.1-24.1 59.7-54.9c-19.2 4.5-39.2 6.9-59.7 6.9-20.6 0-40.6-2.4-59.8-6.9z", "M264 456c33.1 0 60 26.9 60 60 0 1.7-.1 3.4-.3 5.1-19.2 4.5-39.2 6.9-59.7 6.9-20.6 0-40.6-2.4-59.8-6.9-.1-1.7-.2-3.4-.2-5.1 0-33.1 26.9-60 60-60zm3.4-360c26.9 0 50.4 5 71 14.9 20.4 9.8 36.3 23.3 47.5 40.3l-.2 .5c11.3 17 16.8 35.5 16.8 55.4 0 15.6-3.1 29.5-9.6 41.3-6.5 12-14.2 22.1-22.8 30.7s-24.5 23.1-47.3 43.5c-6.2 5.8-11.3 10.8-15.1 15.1s-6.5 8.4-8.4 12-3.4 7.2-4.3 10.8-2.6 9.8-4.6 19c-3.6 19.2-14.6 28.8-33.1 28.8-9.6 0-17.8-3.1-24.2-9.4s-9.8-15.6-9.8-28.1c0-15.4 2.4-29.1 7.2-40.3 4.8-11.5 11.3-21.4 19.2-30s18.7-18.9 32.2-30.7c11.8-10.3 20.4-18.2 25.7-23.5s9.9-11 13.5-17.5 5.5-13.4 5.5-21.1c0-14.9-5.5-27.4-16.5-37.5-11-10.3-25.4-15.4-42.7-15.4-20.2 0-35.3 5-44.9 15.4s-17.7 25.5-24.5 45.4c-6.2 20.9-18.2 31.4-35.8 31.4-10.3 0-19-3.8-26.2-11-7.2-7.4-10.8-15.4-10.8-23.8 0-17.8 5.8-35.5 17-53.5s27.8-33.1 49.4-44.9 47-17.8 75.8-17.8z"]],
    "pencil": [576, 576, [9999, 61504, "pencil-alt"], "f303", ["M482.7 0c-24.7 0-48.5 9.8-66 27.3L383 61 515 193 548.7 159.3c17.5-17.5 27.3-41.2 27.3-66 0-51.5-41.8-93.3-93.3-93.3zM331 43c-9.4 9.4-9.4 24.6 0 33.9L349 95 383 61 365 43c-9.4-9.4-24.6-9.4-33.9 0zM349 95L311 133 443 265 481 227 349 95zM259 115c-9.4 9.4-9.4 24.6 0 33.9l18 18 33.9-33.9-18-18c-9.4-9.4-24.6-9.4-33.9 0zM277 167L120 324 24 552 252 456 409 299 277 167zM515 193L481 227 499 245c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-18-18zm-72 72L409 299 427 317c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9l-18-18z", "M383 61L349 95 481 227 515 193 383 61zm-72 72L277 167 409 299 443 265 311 133z"]],
    "lightbulb": [384, 576, [128161], "f0eb", ["M192 0C85.9 0 0 85.9 0 192 0 263 38.6 325 96 358.1l0 73.9-23.5 0c-13.2 0-24 10.8-24 24s10.8 24 24 24l23.5 0 0-48 72.5 0 0-110.2-65-65c-9.4-9.4-9.4-24.5 0-33.8s24.5-9.4 33.8 0l55 55 55-55c9.4-9.4 24.5-9.4 33.8 0s9.4 24.5 0 33.8l-65 65 0 110.2 72 0 0 48 24.5 0c13.2 0 24-10.8 24-24s-10.8-24-24-24l-24.5 0 0-73.9C345.4 325 384 263 384 192 384 85.9 298.1 0 192 0zM96 480c0 53 43 96 96 96s96-43 96-96L96 480z", "M247.2 222.9c9.4-9.4 24.5-9.4 33.8 0s9.4 24.5 0 33.8l-65 65 0 110.2 72 0 0 48-192 0 0-48 72.5 0 0-110.2-65-65c-9.4-9.4-9.4-24.5 0-33.8s24.5-9.4 33.8 0l55 55 55-55z"]],
    "code": [576, 576, [], "f121", ["M79.9 24C62.3 24 48 38.3 48 55.9l0 224.1 96-64 0 60-90 60 90 60 0 60-96-64 0 128.1C48 537.7 62.3 552 79.9 552l464.2 0c17.6 0 31.9-14.3 31.9-31.9l0-464.2C576 38.3 561.7 24 544.1 24L79.9 24zM336 96a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm96 0a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zm96 0a24 24 0 1 1 -48 0 24 24 0 1 1 48 0zM289.7 207.1c5-12.5 19-18.2 31.2-13.4 12.5 5 18.5 19 13.4 31.2l-96 240c-3.8 9.4-12.7 15.1-22.3 15.1-2.9 0-6-.5-8.9-1.7-12.5-5-18.5-19-13.4-31.2l96-240zM384 276l0-60 144 96 0 48-144 96 0-60 90-60-90-60zM48 280l-48 32 0 48 48 32 0-112z", "M289.7 207.1c5-12.5 19-18.2 31.2-13.4 12.5 5 18.5 19 13.4 31.2l-96 240c-3.8 9.4-12.7 15.1-22.3 15.1-2.9 0-6-.5-8.9-1.7-12.5-5-18.5-19-13.4-31.2l96-240zM144 276l-90 60 90 60 0 60-96-64 0-112 96-64 0 60zm384 36l0 48-144 96 0-60 90-60-90-60 0-60 144 96zM312 120a24 24 0 1 1 0-48 24 24 0 1 1 0 48zm96 0a24 24 0 1 1 0-48 24 24 0 1 1 0 48zm96 0a24 24 0 1 1 0-48 24 24 0 1 1 0 48z"]],
    "address-card": [576, 576, [62140, "contact-card", "vcard"], "f2bb", ["M180 72c-31 0-58.2 19.3-72.7 48l145.5 0C238.2 91.3 211 72 180 72zM29.3 120C13.1 120 0 133.1 0 149.3L0 498.7C0 514.9 13.1 528 29.3 528l517.5 0c16.2 0 29.3-13.1 29.3-29.3l0-349.5c0-16.2-13.1-29.3-29.3-29.3l-294 0c7.2 14.1 11.3 30.5 11.3 48 0 53-37.7 96-84 96s-84-43-84-96c0-17.5 4.1-33.9 11.3-48l-78 0zM180 264l.2 0c68.6 0 125.3 52.8 131.3 120L48.7 384c6-67.2 62.4-120 131.3-120z", "M180.2 264c68.6 0 125.3 52.8 131.3 120L48.7 384c6-67.2 62.4-120 131.3-120l.2 0zm72.5-144c7.2 14.1 11.3 30.5 11.3 48 0 53-37.7 96-84 96s-84-43-84-96c0-17.5 4.1-33.9 11.3-48l145.5 0z"]],
    "angle-right": [432, 576, [8250], "f105", ["M144 8.8L144 192q0 0 0 0t0 0c53 0 96 43 96 96s-43 96-96 96l0-192-4.9 .1C88.3 194.7 48 236.6 48 288s40.3 93.3 91.1 95.9l4.9 .1 0 183.1c0 7.9 9.1 11.8 14.4 6.2L432 287.9 158.4 2.6C153.1-2.9 144 .9 144 8.8z", "M240 288c0 53-43 96-96 96l0-192c53 0 96 43 96 96z"]],
    "face-meh": [576, 576, [128528, "meh"], "f11a", ["M312 24c-96.1 0-180.2 51.3-226.3 128.1 20.3 13.5 34.3 42.5 34.3 75.9 0 46.3-26.9 84-60 84-3.8 0-7.4-.5-11-1.4 2.2 25.7 8 50.3 17.1 73.4L408 384c13.2 0 24 10.8 24 24s-10.8 24-24 24L90.8 432c47.1 72.2 128.6 120 221.2 120 145.8 0 264-118.2 264-264S457.8 24 312 24zM60 144c-33.1 0-60 37.7-60 84 0 41.1 21.1 75.3 49 82.6-.6-7.4-1-15-1-22.6 0-49.7 13.8-96.2 37.7-135.9-7.8-5.2-16.5-8.1-25.7-8.1zm228 84c0-46.3 26.9-84 60-84s60 37.7 60 84-26.9 84-60 84-60-37.7-60-84zM48 384c-13.2 0-24 10.8-24 24s10.8 24 24 24l42.8 0c-9.8-15-18.1-31.1-24.7-48L48 384z", "M408 384c13.2 0 24 10.8 24 24s-10.8 24-24 24L90.8 432c-9.8-15-18.1-31.1-24.7-48L408 384zM85.7 152.1c20.3 13.5 34.3 42.5 34.3 75.9 0 46.3-26.9 84-60 84-3.8 0-7.4-.5-11-1.4-.6-7.4-1-15-1-22.6 0-49.7 13.8-96.2 37.7-135.9zM348 144c33.1 0 60 37.7 60 84s-26.9 84-60 84-60-37.7-60-84 26.9-84 60-84z"]],
    "map": [576, 576, [128506, 62072], "f279", ["M.2 48l0 161 0-113 288.5 0-5-48-283.4 0zm331.9 0l5.1 48 239 0 0 158.6 .2 0 0-206.6-244.3 0zM288.7 96l14.4 137-302.9-24 0 48 113.3 9.1 22.5 213.8 48.3 0-22.1-210 145.9 11.5 20.9 198.5 48.5 0-20.4-194.6 219.1 17.5 0-48.3-224.2-17.7-14.9-140.9-48.5 0zM0 257l.2 0 0 0-.2 0zm.2 0l0 270.9 140.9 0-5.1-48-135.8 0 0-222.9zM184.3 480l5 48 144.7 0-5-48-144.7 0zm193.2 0l5 48 193.7 0 0-48-198.7 0z", "M.2 96L.2 209 303.1 233 288.7 96 .2 96zm337 0l14.9 140.9 224.2 17.7 0-158.6-239 0zM.2 257.1l0 222.9 135.8 0-22.5-213.8-113.3-9.1zm162 12.9l22.1 210 144.7 0-20.9-198.5-145.9-11.5zm194.9 15.4l20.4 194.6 198.7 0 0-177.1-219.1-17.5z"]],
    "thumbtack": [576, 576, [128204, 128392, "thumb-tack"], "f08d", ["M227.5 0l-227.5 227.5 56.4 56.2 41.8-41.8 93.8 94.1 72 216 116-116-98-70 84-84 70 98 116-116-216-72-94.1-93.8 41.8-41.8-56.2-56.4zM436 380l-56 56 196 140-140-196z", "M366 282l-84 84 98 70 56-56-70-98z"]],
    "money-bill-wave": [576, 576, [], "f53a", ["M300 48c-31.7 0-60.2 21.2-80 55 54.7 13.3 109.3 41 164 41 4.4 0 8.9-.1 13.5-.3-17.4-56.6-54.5-95.7-97.5-95.7zM84 72c-19.9 0-36 16.1-36 36 0 .7 .1 1.3 .1 2 20.8-3.9 46-8 70.8-10.8-3.9-15.6-18-27.2-34.9-27.2zm84 24c-15.1 0-32 1.3-49.1 3.2 .7 2.8 1.1 5.7 1.1 8.8 0 19.9-16.1 36-36 36-19.2 0-34.9-15-35.9-34-11.5 2.1-21.6 4.2-29.6 5.9-10.9 2.3-18.5 12-18.5 23.1L0 449.7c0 15.5 14.4 27 29.6 24 35.2-7.1 94.5-17.6 138.4-17.6 72 0 144 48 216 48 22.1 0 47.6-2.1 72.7-5-.4-2.3-.7-4.6-.7-7 0-19.9 16.1-36 36-36 18.8 0 34.2 14.4 35.8 32.8 11.2-1.9 21.1-3.6 29-5.1 11.2-2.1 19.2-11.9 19.2-23.3l0-311c0-15.2-14-26.7-28.9-24-36.1 6.5-99.2 16.6-149.6 18.2 6.7 21.9 10.5 46.4 10.5 72.3 0 92.8-48.4 168-108 168S192 308.8 192 216c0-43.5 10.6-83.1 28-113-17.3-4.2-34.7-7-52-7zM492 264a36 36 0 1 1 0-72 36 36 0 1 1 0 72zM84 408a36 36 0 1 1 0-72 36 36 0 1 1 0 72zm443.8 80.8c-20.5 3.5-45.6 7.3-71.2 10.2 3.3 16.5 17.8 29 35.3 29 19.9 0 36-16.1 36-36 0-1.1-.1-2.2-.2-3.2z", "M492 456c18.8 0 34.2 14.4 35.8 32.8-20.5 3.5-45.6 7.3-71.2 10.2-.4-2.3-.7-4.6-.7-7 0-19.9 16.1-36 36-36zM84 408a36 36 0 1 1 0-72 36 36 0 1 1 0 72zM220 103c54.7 13.3 109.3 41 164 41 4.4 0 8.9-.1 13.5-.3 6.7 21.9 10.5 46.4 10.5 72.3 0 92.8-48.4 168-108 168S192 308.8 192 216c0-43.5 10.6-83.1 28-113zM492 264a36 36 0 1 1 0-72 36 36 0 1 1 0 72zM118.9 99.2c.7 2.8 1.1 5.7 1.1 8.8 0 19.9-16.1 36-36 36-19.2 0-34.9-15-35.9-34 20.8-3.9 46-8 70.8-10.8z"]],
    "siren-on": [576, 576, [], "e02e", ["M120 0l-17.9 214.5 136.2-34 49.7-132.5 0 0 0 0 49.7 132.5 136.2 34-17.9-214.5-336 0zM473.9 214.5l4.2 50 98-24.5-102.1-25.5zm-371.8 0L0 240 98 264.5 102.1 214.5zm375.9 50l-140.4 35.1-49.7 132.5 0 0 0 0-49.7-132.5-140.4-35.1-14 167.5-72 0-12 144 576 0-12-144-72 0-14-167.5z", "M288 48l-49.7 132.5-136.2 34-4.2 50 140.4 35.1 49.7 132.5 49.7-132.5 140.4-35.1-4.2-50-136.2-34-49.7-132.5z"]],
    "folder": [576, 576, [128193, 128447, 61716, "folder-blank"], "f07b", ["M36 24C16.1 24 0 40.1 0 60l0 60 264 0 0-60c0-19.9-16.1-36-36-36L36 24zm228 96l0 96-264 0 0 312 576 0 0-372c0-19.9-16.1-36-36-36l-276 0z", "M264 216l-264 0 0-96 264 0 0 96z"]],
    "arrow-up-from-bracket": [576, 576, [], "e09a", ["M272.9 5.4L271 7 175 103c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l55-55 0 302.1 48 0 0-302.1 55 55c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L305 7c-8.8-8.8-22.7-9.3-32.1-1.6zM0 312L0 540c0 19.9 16.1 36 36 36l504 0c19.9 0 36-16.1 36-36l0-228-96 0 0 72-168 0 0 72c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-72-168 0 0-72-96 0z", "M312 384l0 72c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-72 48 0z"]],
    "cloud": [576, 576, [9729], "f0c2", ["M228 72c-86.2 0-156 69.8-156 156 0 5 .2 10.1 .7 15.1-41.5 10.6-72.7 48-72.7 92.9 0 44.5 30.7 82.1 71.9 92.9-.3 9.2 .8 18.1 3 26.6 3.8 14.4 16.8 24.7 31.7 24.7l363.4 0c16.3 0 30-12 32.4-28.3l.3-.2c1-7.4 1.4-15 1.3-22.7-7.6 2-15.6 3-23.9 3L96 432c-8.3 0-16.4-1.1-24.1-3.1 .3-8.7 1.9-17.7 4.9-26.9 10.1-30.7 35.8-55.2 67-62.9 35-8.6 67.4 2.2 90 23.5 28.1-50.9 85.7-82.8 149.8-72.7 53.8 8.4 98.6 48.7 114.2 100.8 4 13 5.9 25.8 6.1 38.2 41.3-10.7 72.1-48.4 72.1-92.9 0-45.1-31.4-82.8-73.4-93.1 1-4.8 1.4-9.8 1.4-14.9 0-46.3-37.7-84-84-84-19.2 0-36.7 6.7-50.9 17.8-25-53-78.7-89.8-141.1-89.8z", "M233.8 362.6c28.1-50.9 85.7-82.8 149.8-72.7 53.8 8.4 98.6 48.7 114.2 100.8 4 13 5.9 25.8 6.1 38.2-7.6 2-15.6 3-23.9 3L96 432c-8.3 0-16.4-1.1-24.1-3.1 .3-8.7 1.9-17.7 4.9-26.9 10.1-30.7 35.8-55.2 67-62.9 35-8.6 67.4 2.2 90 23.5z"]],
    "circle": [576, 576, [128308, 128309, 128992, 128993, 128994, 128995, 128996, 9679, 9898, 9899, 11044, 61708, 61915], "f111", ["M288 0C128.9 0 0 128.9 0 288 0 338.6 13.1 386.2 36 427.5l0 0c0 0 0 0 0-.1l530.2-66.2c0 0 0 0 0 0l.5-.1c6.1-23.4 9.4-47.9 9.4-73.2 0-159.1-128.9-288-288-288z", "M566.2 361.2L36 427.4C85.2 516 179.5 576 288 576 421.7 576 533.8 484.8 566.2 361.2z"]],
    "block-brick": [576, 576, ["wall-brick"], "e3db", ["M0 24l0 144 72 0 0-96 264 0 0-48-336 0zm384 0l0 48 144 0 0 96 48 0 0-144-192 0zM336 72l0 96-264 0 0 48 120 0 0 144-120 0 0 48 264 0 0 96 48 0 0-96 144 0 0-48-288 0 0-144 288 0 0-48-144 0 0-96-48 0zM0 216l0 144 72 0 0-144-72 0zm528 0l0 144 48 0 0-144-48 0zM0 408l0 144 336 0 0-48-264 0 0-96-72 0zm528 0l0 96-144 0 0 48 192 0 0-144-48 0z", "M72 72l0 96 264 0 0-96-264 0zm312 0l0 96 144 0 0-96-144 0zM72 216l0 144 120 0 0-144-120 0zm168 0l0 144 288 0 0-144-288 0zM72 408l0 96 264 0 0-96-264 0zm312 0l0 96 144 0 0-96-144 0z"]],
    "backward": [576, 576, [9194], "f04a", ["M312 24C178.1 24 67.6 123.6 50.3 252.8L240 120 240 254.4 432 120 432 456 240 321.6 240 456 50.3 323.2C67.6 452.4 178.1 552 312 552 457.8 552 576 433.8 576 288S457.8 24 312 24zM50.3 252.8L0 288 50.3 323.2q-.1-.5-.1-.9t-.1-.9q0-.3-.1-.6 0-.4-.1-.8-.1-.5-.1-1.1 0-.3-.1-.6 0-.3-.1-.7 0-.4-.1-.8 0-.5-.1-.9-.1-.5-.1-1 0-.3-.1-.6 0-.3-.1-.6 0-.3-.1-.6 0-.3-.1-.7 0-.4-.1-.7 0-.4-.1-.8 0-.4-.1-.8 0-.4-.1-.9 0-.5-.1-.9 0-.5-.1-1 0-.5-.1-1.1 0-.3 0-.5t0-.6 0-.6 0-.6 0-.6q0-.3 0-.6 0-.3 0-.7 0-.3 0-.7 0-.4 0-.7 0-.4 0-.7 0-.4 0-.8 0-.4 0-.8 0-.4 0-.8 0-.4 0-.8 0-.4 0-.9 0-.4 0-.9 0-.5 0-.9 0-.5 0-.9 0-.5 0-1 0-.5 0-1 0-.5 0-1 0-.5 0-1.1 0-.6 0-1.1 0-.5 0-.9t0-.9q0-.3 0-.6 0-.4 0-.8 0-.5 0-1.1 0-.3 0-.6 0-.3 0-.7 0-.4 0-.8 0-.5 0-.9 0-.5 0-1 0-.3 0-.6 0-.3 0-.6 0-.3 0-.6 0-.3 0-.7 0-.4 0-.7 0-.4 0-.8 0-.4 0-.8 0-.4 0-.9 0-.5 .1-.9 0-.5 .1-1 0-.5 .1-1.1 0-.3 0-.5t0-.6 0-.6 0-.6 0-.6q0-.3 0-.6 0-.3 .1-.7 0-.3 .1-.7 0-.4 .1-.7 0-.4 .1-.7 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.9 0-.4 .1-.9 0-.5 .1-.9 .1-.5 .1-.9 .1-.5 .1-1 .1-.5 .1-1 .1-.5 .1-1 .1-.5 .1-1.1 0-.3 .1-.5t.1-.6z", "M240 120L50.3 252.8c-4 30-2.1 54.9 0 70.5L240 456 240 321.6 432 456 432 120 240 254.4 240 120z"]],
    "link": [576, 576, [128279, "chain"], "f0c1", ["M420 0c-41.8 0-81.1 16.3-110.4 45.6l-85 85c-16.6 16.6-28.9 36.2-36.6 57.6 16.7-6 34.6-9.1 52.9-9.1 11.6 0 23 1.3 34 3.7 .3-.3 .5-.6 .8-.8l85-85c15.6-15.8 36.7-24.5 59.3-24.5s43.7 8.7 59.5 24.5c15.8 15.6 24.5 37 24.5 59.3s-8.6 43.5-24.5 59.3l-85 84.9c-31.7 31.4-87.4 31.4-118.8 0-13.2-13-21.3-29.9-23.7-48-24.9-3.1-51 4.3-69.4 22.1 6.3 28.9 20.7 55.5 42 76.8 29.5 29.5 68.6 45.6 110.4 45.6s81.1-16.3 110.4-45.6l85-85C559.9 236.9 576 197.8 576 156S559.9 75.1 530.4 45.6 461.8 0 420 0zM275 182.7c-15.3 15.7-23.7 36.5-23.7 58.5 0 3.8 .3 7.5 .8 11.3 18 2.2 35.3 9.9 48.4 23.1 2.4 2.4 4.8 5 7 7.9 12 15.8 34.8 18.7 50.4 6.5 15.8-12 18.7-34.8 6.5-50.4-3.8-5.3-8.4-10.3-13-14.9-21.3-21.3-47.7-35.6-76.4-41.9zm-86.9 5.4c-21.4 7.7-41.1 20-57.5 36.5l-85 85C16.1 339.1 0 378.2 0 420s16.3 81.1 45.6 110.4C75.1 559.9 114.2 576 156 576l.2-.5c41.8 0 81.1-16.3 110.4-45.6l55-55c14.2-13.9 14.2-36.7 0-50.9-13.9-14.2-36.7-14.2-50.9 0l-55.2 55c-31.4 31.4-87.4 31.7-118.8 0-15.8-15.6-24.5-37-24.5-59.3s8.7-43.5 24.5-59.3l85-84.9c.3-.3 .7-.6 1-1-2.4-10.9-3.6-22.2-3.6-33.6 0-18.3 3.1-36.1 9-52.8z", "M241 179c11.6 0 23 1.3 34 3.7-15.3 15.7-23.7 36.5-23.7 58.5 0 3.8 .3 7.5 .8 11.3-24.9-3.1-51 4.3-69.4 22.1-2.4-10.9-3.6-22.2-3.6-33.6 0-18.3 3.1-36.1 9-52.8 16.7-6 34.6-9.1 52.9-9.1z"]],
    "backward-step": [576, 576, ["step-backward"], "f048", ["M312 24C205.2 24 113.5 87.4 72 178.6l0-82.6-72 0 0 384 72 0 0-82.6c41.5 91 133.2 154.6 240 154.6 145.9 0 264-118.1 264-264S457.9 24 312 24zM24 288L360 96 360 480 24 288z", "M360 96L24 288 360 480 360 96z"]],
    "circle-user": [528, 576, [62142, "user-circle"], "f2bd", ["M264 0C118.2 0 0 118.2 0 264 0 343.1 34.8 414 89.9 462.4 129.2 414.8 192.5 384 264 384s134.8 30.9 174.1 78.4C493.2 414 528 343.1 528 264 528 118.2 409.8 0 264 0zm0 384c-66.2 0-120-82.6-120-162s53.8-126 120-126 120 46.6 120 126-53.8 162-120 162zM89.9 462.4C63.6 494.2 48 533.5 48 576l432 0c0-42.5-15.6-81.8-41.9-113.6-46.5 40.8-107.4 65.6-174.1 65.6S136.4 503.2 89.9 462.4z", "M264 384c71.4 0 134.8 30.9 174.1 78.4-46.5 40.8-107.4 65.6-174.1 65.6S136.4 503.2 89.9 462.4C129.2 414.8 192.5 384 264 384zm0-288c66.2 0 120 46.6 120 126S330.2 384 264 384 144 301.4 144 222 197.8 96 264 96z"]],
    "hand": [528, 576, [129306, 9995, "hand-paper"], "f256", ["M288.3 0c-26.4 0-48 21.6-48 48l0 48t0 0 0 0c0-26.4-21.6-48-48-48s-48 21.6-48 48l0 217.5c-.2 .1-.3 .1-.5 .2l-61-53c-49-41.5-114.3 27.6-69.4 73.9l138 138.7c25.9 25.9 43.4 41.7 52.5 49.8-36.7-35-59.7-84.3-59.7-139.1l0-70.5c15-5.4 31.1-8.7 48-8.7l0-.2c79.2 0 144 64.8 144 144l0 127.2c-47.8 0-91.2-17.3-124.8-46.1 0 0-2.4-2.1-7.3-6.4 34.4 32.7 80.9 52.7 132.1 52.7 106.1 0 192-85.9 192-192l0-240c0-26.4-21.6-48-48-48s-48 21.6-48 48t0 0 0 0l0-48c0-26.4-21.6-48-48-48s-48 21.6-48 48t0 0 0 0l0-48c0-26.4-21.6-48-48-48z", "M192.3 304.6c79.2 0 144 64.8 144 144l0 127.2c-47.8 0-91.2-17.3-124.8-46.1 0 0-2.4-2.1-7.3-6.4-36.8-35-59.9-84.4-59.9-139.2l0-70.5c15-5.4 31.1-8.7 48-8.7l0-.2z"]],
    "thumbs-up": [576, 576, [128077, 61575], "f164", ["M183.4 37c-19.2 4.8-31 24.5-26.2 43.7l14.9 59.3c6.7 26.6 17.3 52.3 31.2 76.1L36 216c-19.7 0-36 17.5-36 38.9s16.3 38.9 36 38.9l24 0c-19.7 0-36 17.5-36 38.9s16.3 38.9 36 38.9l24 0c-19.7 0-36 17.5-36 38.9s16.3 38.9 36 38.9l24 0c-19.7 0-36 17.5-36 38.9S88.3 527 108 527l130.6 0c32.4 0 63.8-9.1 91.4-25.9 23.6-14.7 50.3-19.7 78-20.8l0-217 96 0 0 216.7-82.6 0c-4.5 0-9 .1-13.4 .3l0 28.8c0 10.5 8.5 19 19 19L557 528c10.5 0 19-8.5 19-19L576 235c0-10.5-8.5-19-19-19L427 216c-10.5 0-19 8.5-19 19l0 26.4s-1.9-1.9-3.1-2.6l-91.7-65.5c-42.2-30.2-72.5-74.4-85-125l-1.2-5c-4.8-19.2-24.2-31.2-43.7-26.2zM229 216l-.7-2.2 .2 0s1.2 1.4 1.7 2.2l-1.2 0z", "M408 263.3l96 0 0 216.7-82.6 0c-4.5 0-9 .1-13.4 .3l0-217z"]],
    "building": [576, 576, [127970, 61687], "f1ad", ["M395.3 3.4L61.9 92.4C53.8 94.6 48 102 48 110.4l0 81.6 48 0 0 120-48 0 0 48 48 0 0 120-48 0 0 84.7C48 571 53 576 59.3 576l252.7 0 0-360 96 0 0-202.8c0-6.7-6.2-11.5-12.7-9.8zM0 192l0 120 48 0 0-120-48 0zM144 312l0-120 96 0 0 120-96 0zm264-96l0 360 156.7 0c6.2 0 11.3-5 11.3-11.3l0-337.4c0-6.2-5-11.3-11.3-11.3L408 216zM0 360l0 120 48 0 0-120-48 0zM144 480l0-120 96 0 0 120-96 0z", "M48 192l0 120 48 0 0-120-48 0zm96 0l0 120 96 0 0-120-96 0zm168 24l0 360 96 0 0-360-96 0zM48 360l0 120 48 0 0-120-48 0zm96 0l0 120 96 0 0-120-96 0z"]],
    "gear": [576, 576, [9881, "cog"], "f013", ["M240 0l-23.3 116.2-98.4-65.8-67.9 67.9 65.8 98.4-116.2 23.3 0 96 116.2 23.3-65.8 98.4 67.9 67.9 .6-.4-.6 .2 .3-.5-.3 .2 127.7-178.7c-18.1-13.1-30-34.4-30-58.4 0-39.6 32.4-72 72-72 15.5 0 30 5 41.8 13.4L457.7 50.4 359.3 116.2 336 0 240 0zM576 335.8l-.4 .3 .4-.1 0-.2zM239.8 574.9l.2 1.1 96 0 0-.2-95.8 0-.1-.2-.1 0-.1-.4-.2-.3z", "M576 240l-116.2-23.3 65.8-98.4-67.9-67.9-127.9 179c18.2 13 30.2 34.3 30.2 58.3 0 39.6-32.4 72-72 72-15.6 0-30-5-41.8-13.7l-127.9 179 98.4-65.8 23.3 116.2 96 0 23.3-116.2 98.4 65.8 67.9-67.9-65.8-98.4 116.2-23.3 0-96 0 .5z"]],
    "circle-question": [528, 576, [62108, "question-circle"], "f059", ["M264 0c-145.8 0-264 118.2-264 264 0 125.2 87.2 230 204.2 257.1-.1-1.7-.2-3.4-.2-5.1 0-33.1 26.9-60 60-60s60 26.9 60 60c0 1.7-.1 3.4-.3 5.1 117-27.1 204.3-131.9 204.3-257.1 0-145.8-118.2-264-264-264zM191.5 113.8c21.6-11.8 47-17.8 75.8-17.8 26.9 0 50.4 5 71 14.9 20.4 9.8 36.3 23.3 47.5 40.3l-.2 .5c11.3 17 16.8 35.5 16.8 55.4 0 15.6-3.1 29.5-9.6 41.3-6.5 12-14.2 22.1-22.8 30.7s-24.5 23.1-47.3 43.5c-6.2 5.8-11.3 10.8-15.1 15.1s-6.5 8.4-8.4 12-3.4 7.2-4.3 10.8-2.6 9.8-4.6 19c-3.6 19.2-14.6 28.8-33.1 28.8-9.6 0-17.8-3.1-24.2-9.4s-9.8-15.6-9.8-28.1c0-15.4 2.4-29.1 7.2-40.3 4.8-11.5 11.3-21.4 19.2-30s18.7-18.9 32.2-30.7c11.8-10.3 20.4-18.2 25.7-23.5s9.9-11 13.5-17.5 5.5-13.4 5.5-21.1c0-14.9-5.5-27.4-16.5-37.5-11-10.3-25.4-15.4-42.7-15.4-20.2 0-35.3 5-44.9 15.4s-17.7 25.5-24.5 45.4c-6.2 20.9-18.2 31.4-35.8 31.4-10.3 0-19-3.8-26.2-11-7.2-7.4-10.8-15.4-10.8-23.8 0-17.8 5.8-35.5 17-53.5s27.9-33.1 49.5-44.9zm12.7 407.3c2.6 30.7 28.4 54.9 59.8 54.9s57.1-24.2 59.7-54.9c-19.2 4.4-39.2 6.9-59.7 6.9s-40.6-2.4-59.8-6.9z", "M264 456c33.1 0 60 26.9 60 60 0 1.7-.1 3.4-.3 5.1-19.2 4.4-39.2 6.9-59.7 6.9s-40.6-2.4-59.8-6.9c-.1-1.7-.2-3.4-.2-5.1 0-33.1 26.9-60 60-60zm3.4-360c26.9 0 50.4 5 71 14.9 20.4 9.8 36.3 23.3 47.5 40.3l-.2 .5c11.3 17 16.8 35.5 16.8 55.4 0 15.6-3.1 29.5-9.6 41.3-6.5 12-14.2 22.1-22.8 30.7s-24.5 23.1-47.3 43.5c-6.2 5.8-11.3 10.8-15.1 15.1s-6.5 8.4-8.4 12-3.4 7.2-4.3 10.8-2.6 9.8-4.6 19c-3.6 19.2-14.6 28.8-33.1 28.8-9.6 0-17.8-3.1-24.2-9.4s-9.8-15.6-9.8-28.1c0-15.4 2.4-29.1 7.2-40.3 4.8-11.5 11.3-21.4 19.2-30s18.7-18.9 32.2-30.7c11.8-10.3 20.4-18.2 25.7-23.5s9.9-11 13.5-17.5 5.5-13.4 5.5-21.1c0-14.9-5.5-27.4-16.5-37.5-11-10.3-25.4-15.4-42.7-15.4-20.2 0-35.3 5-44.9 15.4s-17.7 25.5-24.5 45.4c-6.2 20.9-18.2 31.4-35.8 31.4-10.3 0-19-3.8-26.2-11-7.2-7.4-10.8-15.4-10.8-23.8 0-17.8 5.8-35.5 17-53.5s27.9-33.1 49.5-44.9 47-17.8 75.8-17.8z"]],
    "bowl-spoon": [576, 576, [129379], "e3e0", ["M441.4 68.6L338.3 264 0 264C0 369.4 56.9 461.5 141.4 511.7l-21.4 64.3 336 0-21.4-64.3C519.1 461.5 576 369.6 576 264l-166.4 0 96.3-158.9C516 87.4 509.8 64.8 492 54.7l-.2 0c-17.8-10.1-40.3-3.8-50.4 13.9zM309.6 318.5l28.7-54.5 71.3 0-50.1 82.6c15.6 26.6 14.1 67.2-6.7 103.9-27.6 48.7-79 72-114.5 51.8-35.5-20.2-42-76.1-14.4-124.8 20.9-36.7 55-59.1 85.7-59.1z", "M409.6 264l-50.1 82.6c15.6 26.6 14.1 67.2-6.7 103.9-27.6 48.7-79 72-114.5 51.8-35.5-20.2-42-76.1-14.4-124.8 20.9-36.7 55-59.1 85.7-59.1l28.7-54.5 71.3 0z"]],
    "file": [432, 576, [128196, 128459, 61462], "f15b", ["M0 0l0 576 432 0 0-408-168 0 0-168-264 0z", "M264 168l168 0-168-168 0 168z"]],
    "volume-slash": [576, 576, [128263], "f2e2", ["M312 0l-192 168 71.8 0 0 199.4 120.2-146.9 0-220.5zM485.3 8.9L425.2 82.3c16 5.1 31.2 12 45.3 20.4l52-63.5c8.4-10.3 7-25.4-3.4-33.8l0 .3c-10.3-8.4-25.4-7-33.8 3.4zM360 97.7c0 12.2 8.9 22.3 20.6 23.7 3.7 .5 7.4 1.1 11 1.8l33.5-41c-12.3-3.9-25.1-6.7-38.3-8.3l0-.2C372.7 72 360 83.3 360 97.7zm110.5 5l-30.8 37.7c52.5 28.5 88.4 84 88.4 147.8 0 85.7-64.3 156.5-147.4 166.8-11.8 1.4-20.6 11.5-20.6 23.5 0 14.4 12.7 25.9 26.9 24 106.6-13.2 189.1-104.2 189.1-214.3 0-78.9-42.4-147.9-105.5-185.6zm-78.8 20.6l-79.6 97.3 0 75.9 64.5-78.8c-9.6-3.7-16.5-12-16.5-22.5 0-15.6 14.9-27.1 30-23.3 6.4 1.6 12.6 3.8 18.6 6.5l31-37.9c-14.8-8-31-13.9-48-17.2zM25.4 168C11.3 168 0 179.5 0 193.4L0 382.6C0 396.7 11.5 408 25.4 408l94.6 0 0-240-94.6 0zm383.2 10.3l-32.2 39.3c.9 .4 1.8 .7 2.7 1 30.5 8.4 52.8 36.2 52.8 69.4s-22.3 61-52.8 69.4c-11 3.1-19.2 12-19.2 23.5 0 15.6 14.9 27.4 30 23.3 51.8-13.4 90-60.5 90-116.2 0-48.7-29.4-91-71.4-109.7zM312 296.5L178.7 459.4 312 576 312 296.5zM120 408l22.7 19.8 16.2-19.8-38.9 0zm22.7 19.8L53.5 536.9c-8.4 10.3-7 25.4 3.4 33.8 4.6 3.6 9.8 5.5 15.1 5.5 7 0 13.9-2.9 18.5-8.9l88.3-108-36.1-31.6z", "M191.8 168l0 199.4 120.2-146.9 0 75.9-133.3 162.9-36.1-31.6 16.2-19.8-38.9 0 0-240 71.8 0zM360 195.1c0-15.6 14.9-27.1 30-23.3 6.4 1.6 12.6 3.8 18.6 6.5l-32.2 39.3c-9.6-3.7-16.5-12-16.5-22.5zM425.2 82.3c16 5.1 31.2 12 45.3 20.4l-30.8 37.7c-14.8-8-31-13.9-48-17.2l33.5-41z"]],
    "arrow-up": [576, 576, [8593], "f062", ["M288.5 0L3.1 273.6C-2.4 278.9 1.4 288 9.3 288l159.1 0 0-96 240 0 0 96 159.1 0c7.9 0 11.8-9.1 6.2-14.4L288.5 0zm-120 288l0 270.2c0 9.8 7.9 17.8 17.8 17.8l204.5 0c9.8 0 17.8-7.9 17.8-17.8l0-270.2-240 0z", "M168.5 192l0 96 240 0 0-96-240 0z"]],
    "rectangle": [528, 576, [9644, "rectangle-landscape"], "f2fa", ["M24 72C10.7 72 0 82.7 0 96l0 309 528-66 0-243c0-13.3-10.7-24-24-24L24 72z", "M528 339L0 405 0 480c0 13.3 10.7 24 24 24l480 0c13.3 0 24-10.7 24-24l0-141z"]],
    "grid": [576, 576, ["grid-3"], "e195", ["M96 0l0 96 48 0 0-96-48 0zM264 0l0 96 48 0 0-96-48 0zM432 0l0 96 48 0 0-96-48 0zM0 96l0 48 96 0 0-48-96 0zm144 0l0 48 120 0 0-48-120 0zm168 0l0 48 120 0 0-48-120 0zm168 0l0 48 96 0 0-48-96 0zM96 144l0 120 48 0 0-120-48 0zm168 0l0 120 48 0 0-120-48 0zm168 0l0 120 48 0 0-120-48 0zM0 264l0 48 96 0 0-48-96 0zm144 0l0 48 120 0 0-48-120 0zm168 0l0 48-48 0 0 120 168 0 0-168-120 0zm168 0l0 168 96 0 0-168-96 0zM96 312l0 120 48 0 0-120-48 0zM0 432l0 48 96 0 0-48-96 0zm144 0l0 48 120 0 0-48-120 0zM96 480l0 96 48 0 0-96-48 0zm168 0l0 96 168 0 0-96-168 0zm216 0l0 96 96 0 0-96-96 0z", "M96 96l0 48 48 0 0-48-48 0zm168 0l0 48 48 0 0-48-48 0zm168 0l0 48 48 0 0-48-48 0zM96 264l0 48 48 0 0-48-48 0zm168 0l0 48 48 0 0-48-48 0zm168 0l0 168-168 0 0 48 168 0 0 96 48 0 0-96 96 0 0-48-96 0 0-168-48 0zM96 432l0 48 48 0 0-48-48 0z"]],
    "shirt": [576, 576, [128085, "t-shirt", "tshirt"], "f553", ["M288 0c-51.8 0-95.9 23-112.7 55.1 27.9-4.7 56.2-7.1 84.7-7.1l56.2 0C344.5 48 372.8 50.4 400.7 55.1 383.9 23 339.8 0 288 0zM175.3 55.1C113.6 65.7 54.1 87.6 0 120L0 253.4C0 259.2 4.8 264 10.6 264l85.4 0 0 312 384 0 0-312 85.4 0c5.8 0 10.6-4.8 10.6-10.6L576 120c-54.1-32.4-113.6-54.3-175.3-64.9 4.7 9 7.3 18.7 7.3 28.9 0 46.4-53.7 84-120 84S168 130.4 168 84c0-10.1 2.6-19.9 7.3-28.9z", "M316.1 48c28.4 0 56.8 2.4 84.6 7.1 4.7 9 7.3 18.7 7.3 28.9 0 46.4-53.7 84-120 84S168 130.4 168 84c0-10.1 2.6-19.9 7.3-28.9 27.9-4.7 56.2-7.1 84.7-7.1l56.2 0z"]],
    "suitcase": [576, 576, [129523], "f0f2", ["M264 0c-39.6 0-72 32.4-72 72l0 48 48 0 0-48c0-13.2 10.8-24 24-24l48 0c13.2 0 24 10.8 24 24l0 48 48 0 0-48c0-39.6-32.4-72-72-72L264 0zM48 120c-26.5 0-48 21.5-48 48L0 480c0 26.5 21.5 48 48 48l24 0 0-360 48 0 0 360 336 0 0-360 48 0 0 360 24 0c26.5 0 48-21.5 48-48l0-312c0-26.5-21.5-48-48-48l-144 0 0 48-48 0 0-48-96 0 0 48-48 0 0-48-144 0zM72 528l0 48 48 0 0-48-48 0zm384 0l0 48 48 0 0-48-48 0z", "M192 120l0 48 48 0 0-48-48 0zm144 0l0 48 48 0 0-48-48 0zM72 168l0 360 48 0 0-360-48 0zm384 0l0 360 48 0 0-360-48 0z"]],
    "play": [576, 576, [9654], "f04b", ["M312 24C218.1 24 135.7 73 88.9 146.8L336 288 88.9 429.2C135.7 503 218.1 552 312 552 457.8 552 576 433.8 576 288S457.8 24 312 24zM0 96l0 384 88.9-50.8q-.2-.3-.4-.6t-.4-.6q-.1-.2-.3-.4-.2-.3-.3-.6-.2-.4-.5-.7-.1-.2-.3-.4-.1-.2-.3-.5-.2-.3-.3-.6-.2-.3-.4-.6-.2-.4-.4-.7-.2-.4-.5-.8-.1-.2-.3-.4-.1-.2-.3-.5-.1-.3-.3-.5-.2-.3-.3-.5-.2-.3-.3-.6-.2-.3-.4-.6-.2-.3-.4-.7-.2-.3-.4-.7-.2-.4-.4-.7-.2-.4-.4-.8-.2-.4-.5-.8-.1-.2-.2-.4t-.2-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5q-.2-.3-.3-.6-.2-.3-.3-.6-.2-.3-.3-.6-.2-.3-.3-.6-.2-.3-.3-.6-.2-.3-.3-.7-.2-.3-.3-.7-.2-.4-.4-.7-.2-.4-.4-.7-.2-.4-.4-.8-.2-.4-.4-.8-.2-.4-.4-.8-.2-.4-.4-.8-.2-.4-.4-.9-.2-.4-.4-.9-.2-.5-.4-.9-.1-.2-.2-.5t-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.6-.2-.6-.2-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.7-.3-.7-.3-.7-.3-.7-.3-.7-.3-.7-.3-.7-.3-.7-.3-.7-.3-.8-.3-.8-.3-.8-.3-.8-.3-.8-.3-.8-.3-.8-.3-.8-.3-.9-.3-.9-.3-.9-.3-.9-.3-.9-.3-.9-.3-.9-.3-1-.3-1-.3-1q-.1-.2-.2-.5t-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.2-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.6-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.7-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.8-.1-.9-.1-.9-.1-.9-.1-.9-.1-.9-.1-.9-.1-.9-.1-.9-.1-.9-.1-.9-.1-.9-.1-.9-.1-.9-.1-.9-.1-1-.1-1-.1-1-.1-1-.1-1-.1-1-.1-1 0-1 0-1 0-1 0-1 0-1 0-1 0-1.1 0-1.1 0-1.1 0-1.1 0-1.1 0-1.1 0-1.1q0-.5 0-.9t0-.9q0-.3 0-.6 0-.4 0-.8 0-.5 0-1.1 0-.3 0-.6 0-.3 0-.7 0-.4 0-.8 0-.5 0-.9 0-.5 0-1 0-.3 0-.6 0-.3 0-.6 0-.3 0-.6 0-.3 0-.7 0-.4 0-.7 0-.4 0-.8 0-.4 0-.8 0-.4 0-.9 0-.5 .1-.9 0-.5 .1-1 0-.5 .1-1.1 0-.3 0-.5t0-.6 0-.6 0-.6 0-.6q0-.3 0-.6 0-.3 .1-.7 0-.3 .1-.7 0-.4 .1-.7 0-.4 .1-.7 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.9 0-.4 .1-.9 0-.5 .1-.9 .1-.5 .1-.9 .1-.5 .1-1 .1-.5 .1-1 .1-.5 .1-1 .1-.5 .1-1.1 0-.3 .1-.5t.1-.5 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.8 .1-.8 .1-.8 .2-.8 .2-.8 .2-.8 .2-.8 .2-.8 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-1 .2-1 .2-1 .2-1 .3-1q.1-.3 .1-.5t.1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .2-.5 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .4-.8 .4-.8 .4-.8 .4-.8 .4-.8 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9q.1-.2 .2-.5t.2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.6L0 96z", "M88.9 146.8C63 187.6 48 236.1 48 288S63 388.4 88.9 429.2L336 288 88.9 146.8z"]],
    "sandwich": [528, 576, [129386], "f81f", ["M216 0C96.7 0 0 64.6 0 144 0 171.4 11.8 191.3 31.7 205.7 12.5 219.1 0 241.4 0 266.4L0 429.6c0 40.2 32.1 73.1 72 74.3 0-.8 0-1.5 0-2.3l0-163.2C72 313.4 84.5 291.1 103.7 277.7 83.8 263.3 72 243.4 72 216 72 136.6 168.7 72 288 72 339.3 72 386.4 84 423.4 103.9 397.3 43.9 314.4 0 216 0zM423.4 103.9c5.5 12.7 8.6 26.2 8.6 40.1 0 27.6-11.8 47.3-31.7 61.7 19.2 13.4 31.7 35.5 31.7 60.7l0 163.2c0 41-33.4 74.4-74.4 74.4L74.4 504c-.8 0-1.6 0-2.3-.1 1.2 40 34.1 72.1 74.3 72.1l283.2 0c41 0 74.4-33.4 74.4-74.4l0-163.2c0-25.2-12.5-47.3-31.7-60.7 19.9-14.4 31.7-34.1 31.7-61.7 0-45.3-31.4-85.7-80.6-112.1z", "M288 72c51.3 0 98.4 12 135.4 31.9 5.5 12.7 8.6 26.2 8.6 40.1 0 27.6-11.8 47.3-31.7 61.7 19.2 13.4 31.7 35.5 31.7 60.7l0 163.2c0 41-33.4 74.4-74.4 74.4L74.4 504c-.8 0-1.6 0-2.3-.1 0-.8 0-1.5 0-2.3l0-163.2c0-25 12.5-47.3 31.7-60.7-19.9-14.4-31.7-34.3-31.7-61.7 0-79.4 96.7-144 216-144z"]],
    "paperclip": [576, 576, [128206], "f0c6", ["M264 0C171.6 0 96 75.6 96 168l0 144 48 0 0-144c0-66.2 53.8-120 120-120s120 53.8 120 120l0 144 48 0 0-144C432 75.6 356.4 0 264 0zm0 120c-39.6 0-72 32.4-72 72l0 120 48 0 0-120c0-13 11-24 24-24s24 11 24 24l0 120 48 0 0-120c0-39.6-32.4-72-72-72zM0 312l0 264 576 0 0-264-96 0 0 144c0 13.2-10.8 24-24 24s-24-10.8-24-24l0-96-48 0 0-48-48 0 0 96c0 66-54 120-120 120S96 474 96 408l0-96-96 0zm144 0l0 96c0 39.6 32.4 72 72 72s72-32.4 72-72l0-96-48 0 0 120-48 0 0-120-48 0z", "M144 312l0 96c0 39.6 32.4 72 72 72s72-32.4 72-72l0-96 48 0 0 96c0 66-54 120-120 120S96 474 96 408l0-96 48 0zm96 0l0 120-48 0 0-120 48 0zm192 0l0 48-48 0 0-48 48 0z"]],
    "signal-bars-weak": [528, 576, ["signal-alt-1"], "f691", ["M24 288c-13.3 0-24 10.7-24 24l0 207 168-21 0-186c0-13.3-10.7-24-24-24L24 288z", "M168 552c0 13.3-10.7 24-24 24L24 576c-13.3 0-24-10.7-24-24l0-33 168-21 0 54z"]],
    "money-bills": [576, 576, [], "e1f3", ["M72 24l0 216 182.2 0c-8.9-17.3-14.2-37.7-14.2-60 0-59.8 37.7-108 84-108s84 48.2 84 108c0 22.3-5.3 42.7-14.2 60l110.2 0 0 96 72 0 0-312-504 0zm120 84a36 36 0 1 1 -72 0 36 36 0 1 1 72 0zm336 0a36 36 0 1 1 -72 0 36 36 0 1 1 72 0zM0 240l0 312 504 0 0-216-182.2 0c8.9 17.3 14.2 37.7 14.2 60 0 59.8-37.7 108-84 108s-84-48.2-84-108c0-22.3 5.3-42.7 14.2-60l-110.2 0 0-96-72 0zM120 468a36 36 0 1 1 -72 0 36 36 0 1 1 72 0zm336 0a36 36 0 1 1 -72 0 36 36 0 1 1 72 0z", "M84 504a36 36 0 1 1 0-72 36 36 0 1 1 0 72zM324 72c46.3 0 84 48.2 84 108 0 22.3-5.3 42.7-14.2 60l110.2 0 0 96-182.2 0c8.9 17.3 14.2 37.7 14.2 60 0 59.8-37.7 108-84 108s-84-48.2-84-108c0-22.3 5.3-42.7 14.2-60l-110.2 0 0-96 182.2 0c-8.9-17.3-14.2-37.7-14.2-60 0-59.8 37.7-108 84-108zm96 432a36 36 0 1 1 0-72 36 36 0 1 1 0 72zM156 144a36 36 0 1 1 0-72 36 36 0 1 1 0 72zm336 0a36 36 0 1 1 0-72 36 36 0 1 1 0 72z"]],
    "wrench": [576, 576, [128295], "f0ad", ["M408.5 .2c-92.9 0-168 75.1-168 168 0 26.5 6.1 51.5 17 73.8L25.7 449c-72.7 69.4 32.6 174.5 101.7 101.8 0 0 107.3-120.3 207-231.8 22.3 11 47.5 17.2 74.1 17.2 92.9 0 168-75.1 168-168 0-17.8-2.6-34.5-7.9-50.6l-73.7 73.7 0-.2-86.4-23-23-86.4 73.7-73.7c-16.1-5-32.9-7.7-50.6-7.7zM257.5 242l55.7-49.8 71 71c-16 17.9-32.8 36.7-49.9 55.8-33.4-16.4-60.6-43.6-76.9-77.1z", "M384.3 263.3c-16 17.9-32.8 36.7-49.9 55.8-33.4-16.4-60.6-43.6-76.9-77.1l55.7-49.8 71 71z"]],
    "life-ring": [576, 576, [], "f1cd", ["M288 0C225.8 0 168.2 19.7 121.2 53.3l98.9 98.9c1.9 1.9 3.6 4.1 5 6.2-29 14.2-52.6 37.7-66.7 66.7-2.2-1.4-4.3-3.1-6.2-5L53.3 121.2C19.7 168.2 0 225.8 0 288 0 350.3 19.8 408 53.5 455.1l99.2-99.2c1.8-1.8 3.9-3.4 5.9-4.8-9.3-19.1-14.6-40.5-14.6-63.1 0-79.4 64.6-144 144-144 22.6 0 43.9 5.2 63 14.5 1.4-2.1 3.1-4.2 5-6.1l99-99C407.9 19.8 350.3 0 288 0zM50.4 50.4c-18.7 18.7-18.7 49.2 0 67.9l2.9 2.9c18.7-26.3 41.7-49.2 67.9-67.9l-2.9-2.9c-18.7-18.7-49.2-18.7-67.9 0zm407.3 .3l-2.7 2.7c26.2 18.7 49.2 41.7 67.9 67.9l2.8-2.7c18.7-18.7 18.7-49.2 0-67.9s-49.2-18.7-67.9 0zm65.2 70.7l-99 99c-1.9 1.9-4.1 3.6-6.2 5 9.2 19 14.4 40.2 14.4 62.7 0 79.4-64.6 144-144 144-22.4 0-43.6-5.1-62.5-14.3-1.4 2.1-3.1 4.2-4.9 6.1l-99.1 99.1c47 33.4 104.5 53.1 166.5 53.1 62.2 0 119.7-19.8 166.8-53.3l-98.6-98.6c-1.9-1.9-3.6-4.1-5-6.2 29-14.2 52.6-37.7 66.7-66.7 2.2 1.4 4.3 3.1 6.2 5l98.6 98.6c33.5-47.1 53.3-104.6 53.3-166.8 0-62.1-19.7-119.6-53.2-166.7zM351 158.5c0 0 0 .1-.1 .1 29 14.2 52.6 37.7 66.7 66.7l0 0c-14.1-29.1-37.7-52.7-66.7-66.8zM158.9 350.9c-.1 .1-.2 .1-.3 .2 14.2 29 37.8 52.6 66.9 66.6 0 0 .1-.1 .1-.1-29-14.2-52.6-37.7-66.7-66.7zM522.7 454.8c-18.7 26.3-41.7 49.2-67.9 67.9l3.1 3.1c18.7 18.7 49.2 18.7 67.9 0s18.7-49.2 0-67.9l-3.1-3.1zm-469.3 .3l-2.6 2.6c-18.7 18.7-18.7 49.2 0 67.9s49.2 18.7 67.9 0l2.6-2.7c-26.3-18.7-49.3-41.6-68-67.9z", "M158.6 351.1c14.2 29 37.8 52.6 66.9 66.6-1.4 2.1-3.1 4.2-4.9 6.1l-99.1 99.1c-26.3-18.7-49.3-41.6-68-67.9l99.2-99.2c1.8-1.8 3.9-3.4 5.9-4.8zm259.3 0c2.2 1.4 4.3 3.1 6.2 5l98.6 98.6c-18.7 26.3-41.7 49.2-67.9 67.9l-98.6-98.6c-1.9-1.9-3.6-4.1-5-6.2 29-14.2 52.6-37.7 66.7-66.7zM454.9 53.4c26.2 18.7 49.2 41.7 67.9 67.9l-99 99c-1.9 1.9-4.1 3.6-6.2 5-14.1-29.1-37.7-52.7-66.7-66.8 1.4-2.1 3.1-4.2 5-6.1l99-99zM220.1 152.2c1.9 1.9 3.6 4.1 5 6.2-29 14.2-52.6 37.7-66.7 66.7-2.2-1.4-4.3-3.1-6.2-5L53.3 121.2c18.7-26.3 41.7-49.2 67.9-67.9l98.9 98.9z"]],
    "calendar": [576, 576, [128197, 128198], "f133", ["M156 0c-19.9 0-36 16.1-36 36l0 60 72 0 0-60c0-19.9-16.1-36-36-36zM420 0c-19.9 0-36 16.1-36 36l0 60 72 0 0-60c0-19.9-16.1-36-36-36zM24 96C10.7 96 0 106.7 0 120L0 432c0 13.3 10.7 24 24 24l246.7 0c6.6-7.5 12.4-14.5 17.5-20.9 12.2-15.6 21.1-28.6 27.1-39.4s9.6-19.4 11-26.2 2.2-12.5 2.2-17c0-5-.7-9.9-2.4-14.4-1.7-4.8-4.1-8.9-7.2-12.5s-7-6.5-11.5-8.6-9.8-3.4-15.8-3.4c-11.5 0-20.7 3.8-27.1 11.3-6.7 7.7-9.8 17-9.8 28.3 0 3.1 .2 7.9 1.2 13.9l-92.9 0c0-19.2 3.1-36.5 9.4-52.1s14.9-29 26.2-40.3c11.3-11.5 24.5-20.2 40.1-26.2s32.9-9.1 51.1-9.1 35.3 2.9 50.6 8.6 28.8 13.7 40.1 24.2 20.2 22.8 26.4 37.2c6.5 14.2 9.6 29.8 9.6 46.5 0 18-3.8 34.6-11.5 49.7s-19.9 30.7-36.7 46.5l.2 .7-3.1 2.9 186.7 0c13.3 0 24-10.7 24-24l0-312c0-13.3-10.7-24-24-24l-96 0 0 36c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-36-192 0 0 36c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-36-96 0zM270.7 456c-9.4 10.7-20.3 22.6-32.9 35.8l-67.9 70.3c-5 5.3-1.4 13.9 5.8 13.9l244.3 0 0-72-105.8 0 51.2-48-94.6 0z", "M289.7 239.5c18.2 0 35.3 2.9 50.6 8.6s28.8 13.7 40.1 24.2 20.2 22.8 26.4 37.2c6.5 14.2 9.6 29.8 9.6 46.5 0 18-3.8 34.6-11.5 49.7s-19.9 30.7-36.7 46.5l.2 .7-3.1 2.9-94.6 0c6.6-7.5 12.4-14.5 17.5-20.9 12.2-15.6 21.1-28.6 27.1-39.4s9.6-19.4 11-26.2 2.2-12.5 2.2-17c0-5-.7-9.9-2.4-14.4-1.7-4.8-4.1-8.9-7.2-12.5s-7-6.5-11.5-8.6-9.8-3.4-15.8-3.4c-11.5 0-20.7 3.8-27.1 11.3-6.7 7.7-9.8 17-9.8 28.3 0 3.1 .2 7.9 1.2 13.9l-92.9 0c0-19.2 3.1-36.5 9.4-52.1s14.9-29 26.2-40.3c11.3-11.5 24.5-20.2 40.1-26.2s32.9-9.1 51.1-9.1zM192 132c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-36 72 0 0 36zm264 0c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-36 72 0 0 36z"]],
    "check": [576, 576, [10003, 10004], "f00c", ["M461.9 88l-233.7 233.7 88.5 88.4c6.7 6.7 7.4 17.2 2 24.8l-77.2 77.2c-2.7 2.7-6.1 4.4-9.6 5.2-6 1.1-12.4-.6-17.1-5.3l-77.6-77.6c-4.9-7.4-4.1-17.6 2.5-24.1L228.2 321.7 114.5 208c-7.5-7.5-19.6-7.5-27.1 0L12.7 282.7c-7.5 7.5-7.5 19.7 0 27.2L137.2 434.4c.7 1.1 1.5 2.1 2.5 3l74.7 74.7c4.8 4.8 11.4 6.5 17.6 5.2 3.7-.7 7.2-2.4 10.1-5.3l74.7-74.7c.8-.8 1.4-1.6 2-2.4L563.8 189.8c7.5-7.5 7.5-19.7 0-27.2L489.1 88c-7.5-7.5-19.7-7.5-27.2 0z", "M316.7 410.2c6.7 6.7 7.4 17.2 2 24.8l-77.2 77.2c-2.7 2.7-6.1 4.4-9.6 5.2-6 1.1-12.4-.6-17.1-5.3l-77.6-77.6c-4.9-7.4-4.1-17.6 2.5-24.1l88.5-88.5 88.5 88.5z"]],
    "house": [576, 576, [127968, 63498, 63500, "home", "home-alt", "home-lg-alt"], "f015", ["M250.4 4.2l-1.7 1.3-240 198C3.2 208 0 214.8 0 222L0 504c0 13.3 10.7 24 24 24l168 0 0-204c0-6.6 5.4-12 12-12l120 0c6.6 0 12 5.4 12 12l0 204 168 0c13.3 0 24-10.7 24-24l0-48-84 0c-6.6 0-12-5.4-12-12l0-120c0-6.6 5.4-12 12-12l84 0 0-90c0-7.2-3.2-14-8.7-18.5l-240-198c-8.3-6.9-20.1-7.3-28.9-1.3zM528 312l0 144 36 0c6.6 0 12-5.4 12-12l0-120c0-6.6-5.4-12-12-12l-36 0zM192 528l0 36c0 6.6 5.4 12 12 12l120 0c6.6 0 12-5.4 12-12l0-36-144 0z", "M324 312c6.6 0 12 5.4 12 12l0 204-144 0 0-204c0-6.6 5.4-12 12-12l120 0zM528 456l-84 0c-6.6 0-12-5.4-12-12l0-120c0-6.6 5.4-12 12-12l84 0 0 144z"]],
    "play-pause": [576, 576, [], "e22f", ["M312 24C218.1 24 135.8 73 88.9 146.8l.1 0 247 141.1-247 141.1-.1 0C135.8 503 218.1 552 312 552 387.7 552 455.9 520.1 504 469.1l0-362.2C455.9 55.9 387.7 24 312 24zM0 96l0 384 88.9-50.9C63.1 388.3 48 339.9 48 288S63 187.7 88.9 146.8L0 96zM360 480l0-384 72 0 0 384-72 0zM504 96l0 10.9c44.6 47.3 72 111 72 181.1q0 0 0 0 0 0 0 0l0-192-72 0zm72 192q0 0 0 0c0 70.1-27.4 133.8-72 181.1l0 10.9 72 0 0-192q0 0 0 0z", "M432 96l0 384-72 0 0-384 72 0zm72 10.9c44.6 47.3 72 111 72 181.1s-27.4 133.8-72 181.1l0-362.2zm-415 40l247 141.1-247 141.1-.1 0C63.1 388.3 48 339.9 48 288S63 187.7 88.9 146.8l.1 0z"]],
    "sliders": [576, 576, ["sliders-h"], "f1de", ["M168 72c-44.8 0-82.3 30.6-93 72l186 0c-10.7-41.4-48.2-72-93-72zM0 144l0 48 75 0c-2-7.7-3-15.7-3-24s1.1-16.3 3-24L0 144zm261 0c2 7.7 3 15.7 3 24s-1.1 16.3-3 24l315 0 0-48-315 0zM75 192c10.7 41.4 48.2 72 93 72s82.3-30.6 93-72L75 192zM408 312c-44.8 0-82.3 30.6-93 72l186 0c-10.7-41.4-48.2-72-93-72zM0 384l0 48 315 0c-2-7.7-3-15.7-3-24s1.1-16.3 3-24L0 384zm501 0c2 7.7 3 15.7 3 24s-1.1 16.3-3 24l75 0 0-48-75 0zM315 432c10.7 41.4 48.2 72 93 72s82.3-30.6 93-72l-186 0z", "M501 384c2 7.7 3 15.7 3 24s-1.1 16.3-3 24l-186 0c-2-7.7-3-15.7-3-24s1.1-16.3 3-24l186 0zM261 144c2 7.7 3 15.7 3 24s-1.1 16.3-3 24L75 192c-2-7.7-3-15.7-3-24s1.1-16.3 3-24l186 0z"]],
    "face-frown": [576, 576, [9785, "frown"], "f119", ["M312 24c-96.1 0-180.2 51.3-226.3 128.1 20.3 13.5 34.3 42.5 34.3 75.9 0 46.3-26.9 84-60 84-3.8 0-7.4-.5-11-1.4 11.5 135.2 124.8 241.4 263 241.4 86.2 0 162.8-41.4 211-105.4-135.1-56.9-238.3 12.9-242.9 16.1-4.1 2.9-8.9 4.3-13.7 4.3-7.7 0-15.1-3.6-19.7-10.3-7.7-10.8-5.1-25.7 5.7-33.4 5.6-4 132.7-91.1 296-18 17.6-35.3 27.5-75.2 27.5-117.3 0-145.8-118.2-264-264-264zM60 144c-33.1 0-60 37.7-60 84 0 41.1 21.1 75.3 49 82.6-.6-7.4-1-15-1-22.6 0-49.7 13.8-96.2 37.7-135.9-7.8-5.2-16.5-8.1-25.7-8.1zm228 84c0-46.3 26.9-84 60-84s60 37.7 60 84-26.9 84-60 84-60-37.7-60-84zM548.5 405.3c-7.3 14.6-15.8 28.4-25.5 41.3 6.1 2.6 12.2 5.3 18.4 8.4 12 6 26.4 1.2 32.2-10.8s1.2-26.2-10.8-32.2c-4.8-2.4-9.6-4.7-14.3-6.8z", "M252.5 423.4c5.6-4 132.7-91.1 296-18-7.3 14.6-15.8 28.4-25.5 41.3-135.1-56.9-238.3 12.9-242.9 16.1-4.1 2.9-8.9 4.3-13.7 4.3-7.7 0-15.1-3.6-19.7-10.3-7.7-10.8-5.1-25.7 5.7-33.4zM85.7 152.1c20.3 13.5 34.3 42.5 34.3 75.9 0 46.3-26.9 84-60 84-3.8 0-7.4-.5-11-1.4-.6-7.4-1-15-1-22.6 0-49.7 13.8-96.2 37.7-135.9zM348 144c33.1 0 60 37.7 60 84s-26.9 84-60 84-60-37.7-60-84 26.9-84 60-84z"]],
    "forward-step": [576, 576, ["step-forward"], "f051", ["M312 24C218.1 24 135.7 73 88.9 146.8l199.1 113.8 0-164.6 72 0 0 384-72 0 0-164.6-199.1 113.8C135.7 503 218.1 552 312 552 457.8 552 576 433.8 576 288S457.8 24 312 24zM0 96l0 384 88.9-50.8q0 0 0 0C64.7 391 50 346.2 48.2 298.1q0-.4 0-.8t0-.8q0-.3 0-.6 0-.4 0-.7 0-.5 0-1 0-.3 0-.6 0-.3 0-.6 0-.4 0-.7 0-.4 0-.8 0-.5 0-1 0-.6 0-1.1 0-.3 0-.6 0-.3 0-.6 0-.5 0-.9t0-.9q0-.3 0-.6 0-.4 0-.8 0-.5 0-1.1 0-.3 0-.6 0-.4 0-.7 0-.4 0-.8 0-.5 0-.9 0-.5 0-1.1 0-.3 0-.6 0-.3 0-.6 0-.3 0-.6 0-.3 0-.7 0-.4 0-.7 0-.4 0-.8 0-.4 0-.8 0-.4 0-.9 0-.5 .1-1 0-.5 .1-1 0-.5 .1-1.1 0-.3 0-.6t0-.6 0-.6 0-.6 0-.6q0-.3 .1-.7 0-.3 .1-.7 0-.4 .1-.7 0-.4 .1-.7 0-.4 .1-.7 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.8 0-.4 .1-.9 0-.5 .1-.9 .1-.5 .1-.9 .1-.5 .1-1 .1-.5 .1-1 .1-.5 .1-1 .1-.5 .1-1.1 0-.3 .1-.5t.1-.5 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.6 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.7 .1-.8 .1-.8 .2-.8 .2-.8 .2-.8 .2-.8 .2-.8 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-.9 .2-1 .2-1 .2-1 .3-1q.1-.3 .1-.5t.1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .1-.5 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.6 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .2-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.7 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .3-.8 .4-.8 .4-.8 .4-.8 .4-.8 .4-.8 .4-.8 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9 .4-.9q.1-.2 .2-.5t.2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .2-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.6L0 96z", "M288 96l0 164.6-199.1-113.8C63 187.6 48 236.1 48 288S63 388.4 88.9 429.2l199.1-113.8 0 164.6 72 0 0-384-72 0z"]],
    "sort": [432, 576, ["unsorted"], "f0dc", ["M153.1 5.6l-144 120c-10.1 8.4-11.5 23.5-3.1 33.8 8.4 10.1 23.5 11.5 33.8 3.1l32.6-27.1 0 224.9 96 0 0 79.7s1 1.2 1.4 1.7l-34.1-28.3c-10.1-8.4-25.2-7.2-33.8 3.1-8.4 10.1-7.2 25.2 3.1 33.8l144 120c4.6 3.6 9.8 5.5 15.4 5.5s10.8-1.9 15.4-5.5l144-120c10.1-8.4 11.5-23.5 3.1-33.8l0 .2c-8.4-10.1-23.5-11.5-33.8-3.1l-32.6 27.1 0-224.9-96 0 0-80.4 32.6 27.1c4.6 3.8 9.8 5.5 15.4 5.5 7 0 13.7-2.9 18.5-8.6 8.4-10.1 7.2-25.2-3.1-33.8l-144-120c-8.9-7.4-21.8-7.4-30.7 0zm15.4 354.7l0-144.5 96 0 0 144.5-96 0z", "M168.5 215.8l0 144.5 96 0 0-144.5-96 0z"]],
    "user": [576, 576, [128100, 62144, 62470, "user-alt", "user-large"], "f007", ["M264 0c-71.4 0-132.2 36.6-156.6 101.7 21.5 10.9 36.6 36.5 36.6 66.3 0 30.6-15.9 56.7-38.3 67.1 23.1 80.8 85.2 148.9 158.3 148.9 92.9 0 168-109.9 168-216S356.9 0 264 0zM84 96c-33.1 0-60 32.2-60 72s26.9 72 60 72c7.6 0 14.9-1.8 21.7-4.9-6.2-21.8-9.7-44.5-9.7-67.1 0-24.6 4.1-46.7 11.4-66.3-7.2-3.7-15.1-5.7-23.4-5.7zm108 72c0-39.8 26.9-72 60-72s60 32.2 60 72-26.9 72-60 72-60-32.2-60-72zm60 216C112.8 384 0 469.9 0 576l336 0c0-66.8 38-123 89.4-139.3-45.2-32.7-106.2-52.7-173.4-52.7zm204 48c-10.6 0-20.8 1.6-30.6 4.7 48.4 35 78.6 84.4 78.6 139.3l72 0c0-79.4-53.8-144-120-144z", "M425.4 436.7c48.4 35 78.6 84.4 78.6 139.3l-168 0c0-66.8 38-123 89.4-139.3zM252 96c33.1 0 60 32.2 60 72s-26.9 72-60 72-60-32.2-60-72 26.9-72 60-72zm-144.6 5.7c21.5 10.9 36.6 36.5 36.6 66.3 0 30.6-15.9 56.7-38.3 67.1-6.2-21.8-9.7-44.5-9.7-67.1 0-24.6 4.1-46.7 11.4-66.3z"]],
    "signal-bars": [528, 576, ["signal-alt", "signal-alt-4", "signal-bars-strong"], "f690", ["M384 0c-13.3 0-24 10.7-24 24l0 72 24 0c13.3 0 24 10.7 24 24l0 432c0 12.4-9.4 22.7-21.5 23.9l-2.5 .1 120 0c13.3 0 24-10.7 24-24l0-528c0-13.3-10.7-24-24-24L384 0zM264 96c-13.3 0-24 10.7-24 24l0 72 24 0c13.3 0 24 10.7 24 24l0 336c0 12.4-9.4 22.7-21.5 23.9l-2.5 .1 120 0c-13.3 0-24-10.7-24-24l0-456-96 0zM144 192c-13.3 0-24 10.7-24 24l0 72 24 0c13.3 0 24 10.7 24 24l0 240c0 12.4-9.4 22.7-21.5 23.9l-2.5 .1 120 0c-13.3 0-24-10.7-24-24l0-360-96 0zM24 288c-13.3 0-24 10.7-24 24L0 552c0 13.3 10.7 24 24 24l120 0c-13.3 0-24-10.7-24-24l0-264-96 0z", "M144 288c13.3 0 24 10.7 24 24l0 240c0 12.4-9.4 22.7-21.5 23.9L144 576c-13.3 0-24-10.7-24-24l0-264 24 0zm120-96c13.3 0 24 10.7 24 24l0 336c0 12.4-9.4 22.7-21.5 23.9L264 576c-13.3 0-24-10.7-24-24l0-360 24 0zM384 96c13.3 0 24 10.7 24 24l0 432c0 12.4-9.4 22.7-21.5 23.9L384 576c-13.3 0-24-10.7-24-24l0-456 24 0z"]],
    "snowflake": [528, 576, [10052, 10054], "f2dc", ["M264.3 0c-13.2 0-24 10.8-24 24l0 72-74.2 0c-7.9 0-15.4 4.3-19.2 11l-37 64.1-62.3-36c-11.5-6.7-26.2-2.6-32.9 8.9s-2.6 26.2 8.9 32.9L85.9 212.8 48.8 277c-4.1 7-4.1 15.4 0 22.1l37.1 64.2-62.2 35.9c-11.5 6.5-15.4 21.4-8.9 32.9s21.4 15.4 32.9 8.9l62.3-36 37 64.1c4.1 7 11.3 11 19.2 11l74.2 0 0 72.2c0 13.2 10.8 24 24 24s24-10.8 24-24l0-72.2-48 0 0-150.2-130.4 75.1-24.1-41.7 130.5-75.2-130.5-75.2 24-41.6 130.4 75.4 0-150.5 48 0 0-72c0-13.2-10.8-24-24-24zm24 96l0 150.2 130.1-75.1 24.1 41.7-130.2 75.1 130.2 75.1-24.1 41.7-130.1-75 0 150.2 73.9 0c7.9 0 15.4-4.3 19.2-11l37.1-64.1 62.6 36.1c11.5 6.7 26.2 2.6 32.9-8.9 6.5-11.5 2.6-26.2-8.9-32.9l-62.5-36 37-64.1c4.1-7 4.1-15.4 0-22.1l-37-64.1 62.5-36c11.5-6.5 15.4-21.4 8.9-32.9-6.7-11.5-21.4-15.4-32.9-8.9l-62.6 36-37.1-64.1c-4.1-7-11.3-11-19.2-11l-73.9 0z", "M288.3 96l0 150.2 130.1-75.1 24.1 41.7-130.2 75.1 130.2 75.1-24.1 41.7-130.1-75 0 150.2-48 0 0-150.2-130.4 75.1-24.1-41.7 130.5-75.2-130.5-75.2 24-41.6 130.4 75.4 0-150.5 48 0z"]],
    "skull-crossbones": [528, 576, [128369, 9760], "f714", ["M231.9 0C170.2 0 119.5 50.4 119.5 112.3l0 7.7 37 0c6.5 0 11.8 5.3 11.8 11.8l0 21.4c0 18.2-12.5 33.3-29.2 37.6 7.7 11.2 17.4 21 28.5 28.9l.5 0 0 77.5c0 8.4 6.7 14.9 14.9 14.9l162 0c8.4 0 14.9-6.7 14.9-14.9l0-58.5c54-7.9 96-54.5 96-110.6l0-15.6C455.8 50.6 405.4 0 343.4 0L231.9 0zM84.2 120c-6.5 0-11.7 5.3-11.7 11.8l0 21.4c0 21.4 17.3 38.9 38.9 38.9l18 0c3.3 0 6.6-.5 9.7-1.3-12.3-17.9-19.5-39.5-19.5-62.8l0-7.9-35.3 0zm180.2 11.8c0-6.5 5.3-11.8 11.8-11.8l72.2 0c6.5 0 11.8 5.3 11.8 11.8l0 21.4c0 21.6-17.5 38.9-38.9 38.9l-18 0c-21.6 0-38.9-17.5-38.9-38.9l0-21.4zM192 216c0-13.2 10.8-24 24-24s24 10.8 24 24l0 24c0 13.2-10.8 24-24 24s-24-10.8-24-24l0-24zm251 39.8c-18.2 8.2-26.4 29.3-18.2 47.5l-160.9 71.6 88.5 39.4 101.7-45.3c8.2 18.2 29.3 26.4 47.5 18.2s26.4-29.3 18.2-47.5-29.3-26.4-47.5-18.2t0 0 0 0c18.2-8.2 26.4-29.3 18.3-47.5s-29.3-26.4-47.5-18.2zM37.4 274.1c-8.2 18.2 0 39.4 18.3 47.5t0 0 0 0c-18.2-8.2-39.4 0-47.5 18.2s0 39.3 18.2 47.5 39.4 0 47.5-18.2l101.6 45.2 88.5-39.4-160.7-71.6c8.2-18.2 0-39.3-18.2-47.5s-39.4 0-47.5 18.2zm138 140.2L73.9 459.6c-8.2-18.2-29.3-26.4-47.5-18.3S0 470.6 8.2 488.9 37.5 515.3 55.7 507.1t0 0 0 0c-18.2 8.2-26.4 29.3-18.2 47.5s29.3 26.4 47.5 18.2 26.4-29.3 18.2-47.5l160.7-71.6-88.5-39.4zm176.9 0l-88.5 39.4 160.9 71.6c-8.2 18.2 0 39.4 18.2 47.5s39.3 0 47.5-18.2 0-39.4-18.2-47.5t0 0 0 0c18.2 8.2 39.4 0 47.5-18.2s0-39.4-18.3-47.5c-18.2-8.1-39.4 0-47.5 18.3L352.4 414.4z", "M352.4 414.4l-88.5 39.4-88.5-39.4 88.5-39.4 88.5 39.4zM216 192c13.2 0 24 10.8 24 24l0 24c0 13.2-10.8 24-24 24s-24-10.8-24-24l0-24c0-13.2 10.8-24 24-24zm132.5-72c6.5 0 11.8 5.3 11.8 11.8l0 21.4c0 21.6-17.5 38.9-38.9 38.9l-18 0c-21.6 0-38.9-17.5-38.9-38.9l0-21.4c0-6.5 5.3-11.8 11.8-11.8l72.2 0zm-192 0c6.5 0 11.8 5.3 11.8 11.8l0 21.4c0 18.2-12.5 33.3-29.2 37.6-12.3-17.9-19.5-39.5-19.5-62.8l0-7.9 37 0z"]],
    "ticket": [576, 576, [127903], "f145", ["M384 0l-101.8 101.8 11 11c9.4 9.1 9.4 24.5 0 33.8-9.1 9.4-24.5 9.4-33.8 0L248.4 135.6 0 384 62.2 446.2c8.6-8.6 20.6-14.2 33.8-14.2 26.4 0 48 21.6 48 48 0 13.2-5.3 25.2-14.2 33.8l62.2 62.2 248.4-248.4-11-11c-9.4-9.1-9.1-24.5 0-33.8s24.5-9.4 33.8 0l11 11 101.8-101.8-62.2-62.2c-8.6 8.6-20.6 14.2-33.8 14.2-26.4 0-48-21.6-48-48 0-13.2 5.3-25.2 14.2-33.8L384 0zM225.6 79c-9.4 9.4-9.4 24.7 0 33.8l22.8 22.8 33.8-33.8-22.8-22.8c-9.4-9.4-24.7-9.4-33.8 0zM327.4 180.7c9.1-9.4 24.5-9.4 33.8 0L395 214.6c9.4 9.1 9.1 24.5 0 33.8s-24.5 9.4-33.8 0l-33.8-33.8c-9.4-9.1-9.1-24.5 0-33.8zm146.9 113l-33.8 33.8 22.8 22.8c9.4 9.4 24.7 9.4 33.8 0s9.4-24.7 0-33.8l-22.8-22.8z", "M429.4 282.7c9.1-9.4 24.5-9.4 33.8 0l11 11-33.8 33.8-11-11c-9.4-9.1-9.1-24.5 0-33.8zm-102-102c9.1-9.4 24.5-9.4 33.8 0L395 214.6c9.4 9.1 9.1 24.5 0 33.8s-24.5 9.4-33.8 0l-33.8-33.8c-9.4-9.1-9.1-24.5 0-33.8zm-34.1-67.9c9.4 9.1 9.4 24.5 0 33.8-9.1 9.4-24.5 9.4-33.8 0l-11-11.1 33.8-33.8 11 11z"]],
    "wheelchair": [576, 576, [], "f193", ["M136.1 .7c-26.2 4.3-43.7 29-39.4 55.2l24.9 149.4C50.4 233.4 0 302.8 0 384 0 490.1 85.9 576 192 576 294.8 576 378.6 495.4 383.7 393.9l.3-9.9 96 0c26.4 0 48-21.6 48-48s-21.6-48-48-48l-121.7 0c16.3 28.2 25.7 61 25.7 96l-192 0c-23.5 0-43.4-17-47.3-40.1L121.6 205.4c21.8-8.6 45.5-13.4 70.4-13.4 8.4 0 16.7 .6 24.8 1.6L191.3 40.1C187 13.9 162-3.6 136.1 .7zm80.8 192.9l15.7 94.4 125.7 0c-29.3-50.6-80.9-86.5-141.4-94.4zM480 432a72 72 0 1 0 0 144 72 72 0 1 0 0-144z", "M192 192c8.4 0 16.7 .6 24.8 1.6l15.7 94.4 125.7 0c16.3 28.2 25.7 61 25.7 96l-192 0c-23.5 0-43.4-17-47.3-40.1L121.6 205.4c21.8-8.6 45.5-13.4 70.4-13.4z"]],
    "bookmark": [480, 576, [128278, 61591], "f02e", ["M96 0C69.6 0 48 21.6 48 48l0 522.7c0 4.6 5.3 7 8.9 4.1L216 438.5 375.1 574.8c3.6 2.9 8.9 .5 8.9-4.1l0-426.7-240 0 0-96c0-26.4-21.6-48-48-48zM432 0c-26.4 0-48 21.6-48 48l0 96 96 0 0-96c0-26.4-21.6-48-48-48z", "M432 0c-26.4 0-48 21.6-48 48l0 96-240 0 0-96c0-26.4-21.6-48-48-48L432 0z"]],
    "bomb": [576, 576, [128163], "f1e2", ["M432 0l-48 96-96 48 73.4 36.7-31.2 31.2C295.4 184.6 251.8 168 204 168 91.4 168 0 259.4 0 372s91.4 204 204 204 204-91.4 204-204c0-47.8-16.6-91.4-43.9-126.2l31.2-31.2-11.3-22.5-22.6-11.3 53.8-53.8c9.4-9.4 24.5-9.4 33.8 0s9.4 24.5 0 33.8l-53.8 53.8 36.7 73.4 48-96 96-48-96-48-48-96z", "M415.2 126.9c9.4-9.4 24.5-9.4 33.8 0s9.4 24.5 0 33.8l-53.8 53.8-11.3-22.5-22.6-11.3 53.8-53.8z"]],
    "arrow-right": [576, 576, [8594], "f061", ["M288 8.9l0 159.1 96 0 0 240-96 0 0 159.1c0 7.9 9.1 11.8 14.4 6.2L576 288 302.4 2.6C297.1-2.9 288 1 288 8.9zM17.8 168C7.9 168 0 175.9 0 185.8L0 390.2C0 400.1 7.9 408 17.8 408l270.2 0 0-240-270.2 0z", "M288 168l0 240 96 0 0-240-96 0z"]],
    "battery-bolt": [576, 576, [], "f376", ["M288 48l-85.3 96 74.6 0 10.7-96zM46.1 144C20.6 144 0 164.6 0 190.1L0 433.9C0 459.4 20.6 480 46.1 480l435.8 0c25.4 0 46.1-20.6 46.1-46.1l0-73.9 48 0 0-96-48 0 0-73.9c0-25.4-20.6-46.1-46.1-46.1l-204.6 0-8 72 114.7 0-192 216 18.7-168-114.7 0 106.7-120-156.6 0z", "M202.7 144l-106.7 120 114.7 0-18.7 168 192-216-114.7 0 8-72-74.6 0z"]],
    "mushroom": [576, 576, [127812], "e425", ["M288 0c-52.3 0-100.2 18.6-137.5 49.6 50.9 8.8 89.5 53 89.5 106.4 0 59.8-48.2 108-108 108-29.4 0-56-11.7-75.5-30.7-7.4 15.2-14.7 22.6-22.4 29.5l.5 0C13.7 280.6 0 306.7 0 336 0 388.8 43.2 432 96 432l120 0 0 121c0 12.7 10.3 23 23 23l97.9 0c12.7 0 23-10.3 23-23l0-121 120 0c52.8 0 96-43.2 96-96 0-29.3-13.7-55.4-34.6-73l.5 0c-12.8-11.8-24.6-24.7-37.6-72.7-15.3 15.8-36.7 25.6-60.3 25.6-46.3 0-84-37.7-84-84 0-40.1 28.3-73.8 66-82.1-37.4-31.2-85.5-49.9-138-49.9zM132 48c-59.8 0-108 48.2-108 108 0 30.3 12.5 57.7 32.5 77.3 6.9-14.1 14-34.9 21.5-68.4 .5-1.9 .9-3.1 1.4-4.6 11.8-44 37.1-82.5 71.1-110.7-6-1-12.2-1.6-18.5-1.6zm312 0c-6.2 0-12.2 .7-18 1.9 33.9 28.2 59 66.6 70.6 110.4 .5 1.7 1 2.7 1.4 4.6 2.1 9.5 4.2 17.9 6.3 25.5 14.6-15.1 23.7-35.7 23.7-58.4 0-46.3-37.7-84-84-84zM408 312a48 48 0 1 1 -96 0 48 48 0 1 1 96 0z", "M360 360a48 48 0 1 1 0-96 48 48 0 1 1 0 96zM150.5 49.6c50.9 8.8 89.5 53 89.5 106.4 0 59.8-48.2 108-108 108-29.4 0-56-11.7-75.5-30.7 6.9-14.1 14-34.9 21.5-68.4 .5-1.9 .9-3.1 1.4-4.6 11.8-44 37.1-82.5 71.1-110.7zM426 49.9c33.9 28.2 59 66.6 70.6 110.4 .5 1.7 1 2.7 1.4 4.6 2.1 9.5 4.2 17.9 6.3 25.5-15.3 15.8-36.7 25.6-60.3 25.6-46.3 0-84-37.7-84-84 0-40.1 28.3-73.8 66-82.1z"]],
    "buildings": [576, 576, [], "e0cc", ["M155 0c-6 0-11 5-11 11l0 277 72 0 0 288 96 0 0-360 72-19.6 0-185.3c0-6-5-11-11-11L155 0zM570 145.7l-186 50.7 0 379.6 179.5 0c7 0 12.5-5.5 12.5-12.5l0-413.3c0-3.1-2.9-5.3-6-4.6zM10.6 288C4.8 288 0 292.8 0 298.6L0 564.2C0 570.7 5.3 576 11.8 576l132.2 0 0-288-133.4 0z", "M384 196.4l-72 19.6 0 360 72 0 0-379.6zM144 288l0 288 72 0 0-288-72 0z"]],
    "xmark": [576, 576, [128473, 10005, 10006, 10060, 215, "close", "multiply", "remove", "times"], "f00d", ["M90.8 16L16.2 90.6c-7.5 7.5-7.5 19.7 0 27.2L186.4 288 288.2 186.2 390 288 560.2 117.8c7.5-7.5 7.5-19.7 0-27.2L485.5 16c-7.5-7.5-19.7-7.5-27.2 0L288.2 186.2 118 16c-7.5-7.5-19.7-7.5-27.2 0zm95.5 272L16.1 458.2c-7.5 7.5-7.5 19.7 0 27.2l74.7 74.7c7.5 7.5 19.7 7.5 27.2 0L288.2 389.8 186.4 288zM390 288L288.2 389.8 458.4 560c7.5 7.5 19.7 7.5 27.2 0l74.7-74.7c7.5-7.5 7.5-19.7 0-27.2L390 288z", "M288.2 186.2L186.4 288 288.2 389.8 390 288 288.2 186.2z"]],
    "lock-open": [576, 576, [], "f3c1", ["M432 0C352.8 0 288 64.8 288 144l0 96 72 0 0-96c0-39.6 32.4-72 72-72s72 32.4 72 72l0 192 72 0 0-192C576 64.8 511.2 0 432 0zM43.7 240C19.6 240 0 259.6 0 283.7L0 532.3C0 556.4 19.6 576 43.7 576l344.6 0c24.1 0 43.7-19.6 43.7-43.7l0-248.6c0-24.1-19.6-43.7-43.7-43.7l-28.3 0 0 96-72 0 0-96-244.3 0z", "M288 240l0 96 72 0 0-96-72 0z"]],
    "droplet": [384, 576, [128167, "tint"], "f043", ["M184.3 5.4C150.2 98.3 15.6 244 1.4 372.6 .5 379.6 0 386.5 0 393.7 0 467 45.6 530.2 111.4 559.1t0 0 0 0C53.7 533.7 11.5 481.9 2 420.1l380.5-47.5c.6 4.4 1 8.8 1.3 13.3t0 0 0 0c-.2-4.5-.6-8.9-1.2-13.3l.2 0C368.6 244 234 98.3 199.9 5.4 197.3-1.8 187-1.8 184.3 5.4z", "M382.6 372.6c1 7 1.5 13.9 1.5 21.1 0 100.6-85.9 182.2-192 182.2-96.6 0-176.5-67.7-190-155.7l380.5-47.5z"]],
    "shop": [576, 576, ["store-alt"], "f54f", ["M108 0L0 216c0 29 20.6 53.2 48 58.8l0-58.8 72 0 60-216-72 0zM252 0l-24 216 120 0-24-216-72 0zM396 0l60 216 72 0 0 58.8c27.4-5.6 48-29.8 48-58.8L468 0 396 0zM120 216c0 33.1-26.9 60-60 60-4.1 0-8.1-.4-12-1.2l0 253.2 72 0 0-192 120 0 0 192 288 0 0-253.2c-3.9 .8-7.9 1.2-12 1.2-33.1 0-60-26.9-60-60l-108 0c0 33.1-26.9 60-60 60s-60-26.9-60-60l-108 0zM288 456l0-120 168 0 0 120-168 0zM120 528l0 48 120 0 0-48-120 0z", "M240 336l0 192-120 0 0-192 120 0zm216 0l0 120-168 0 0-120 168 0zM120 216c0 33.1-26.9 60-60 60-4.1 0-8.1-.4-12-1.2l0-58.8 72 0zm228 0c0 33.1-26.9 60-60 60s-60-26.9-60-60l120 0zm180 0l0 58.8c-3.9 .8-7.9 1.2-12 1.2-33.1 0-60-26.9-60-60l72 0z"]],
    "film": [576, 576, [127902, 62368, "film-alt", "film-simple"], "f008", ["M126.7 0C109.7 0 96 13.7 96 30.7l0 17.3 384 0 0-17.3C480 13.7 466.3 0 449.3 0L126.7 0zM0 48l0 480 96 0 0-185.3c0-17 13.7-30.7 30.7-30.7l322.5 0c17 0 30.7 13.7 30.7 30.7l0 185.3 96 0 0-480-96 0 0 185.3c0 17-13.7 30.7-30.7 30.7l-322.5 0c-17 0-30.7-13.7-30.7-30.7L96 48 0 48zM96 528l0 17.3c0 17 13.7 30.7 30.7 30.7l322.5 0c17 0 30.7-13.7 30.7-30.7l0-17.3-384 0z", "M449.3 312c17 0 30.7 13.7 30.7 30.7l0 185.3-384 0 0-185.3c0-17 13.7-30.7 30.7-30.7l322.5 0zM480 48l0 185.3c0 17-13.7 30.7-30.7 30.7l-322.5 0c-17 0-30.7-13.7-30.7-30.7L96 48 480 48z"]],
    "comments": [576, 576, [128490, 61670], "f086", ["M348 0c-126 0-228 91.4-228 204 0 6.9 .4 13.8 1.1 20.6 18.4-5.5 38.2-8.6 58.9-8.6 99.4 0 180 69.8 180 156 0 12.3-1.7 24.3-4.9 35.8 27.9-.8 54.4-6.1 78.8-15L576 456 522.5 335.3C555.8 299.8 576 253.9 576 204 576 91.4 474 0 348 0zM121.1 224.6C50.7 245.7 0 303.7 0 372 0 408 14.2 440.9 37.7 467.3L0 552 95.3 509.5c25.2 11.8 54 18.5 84.7 18.5 85.1 0 156.4-51.3 175.1-120.2-2.4 .1-4.8 .2-7.1 .2-118.2 0-215.3-80.5-226.9-183.4z", "M180 216c99.4 0 180 69.8 180 156 0 12.3-1.7 24.3-4.9 35.8-2.4 .1-4.8 .2-7.1 .2-118.2 0-215.3-80.5-226.9-183.4 18.4-5.5 38.2-8.6 58.9-8.6z"]],
    "moon": [528, 576, [127769, 9214], "f186", ["M240 0c-2.2 0-4.1 .2-6.2 .2 19.2 24 35 51.1 46.1 81.6 18.2 50.2 21.4 102 12.2 151l-169.7 79.7 108.7 50.6c-16.2 19.7-35.2 37.4-56.5 52.5-14.1-5.4-27.8-12-40.9-19.8-11.3-6.7-26.2-3.1-32.9 8.4-6.7 11.3-3.1 26.2 8.4 32.9 4.5 2.7 9 5.2 13.6 7.6-5 2.2-10.1 4.2-15.3 6.1-30.5 11-61.7 16.6-92.4 17 52.8 65.8 133.7 107.8 224.4 107.8 159.1 0 288-128.9 288-288 0-159.1-128.4-287.5-287.5-287.5zM367.5 265.4c5.5-11.8 19.9-17 31.9-11.5 11.8 5.5 17 19.9 11.5 31.9l-20.4 43.5c-5.5 11.8-19.9 17-31.9 11.5-11.8-5.5-17-19.9-11.5-31.9l20.4-43.4zM122.8 444.6c18.6-8 35.9-17.7 51.8-29 55.4 21.2 116.9 23.3 174.1 5.1 12.7-4.1 26.2 2.9 30.2 15.6s-2.9 26.2-15.6 30.2c-30.7 9.8-62.4 14.6-94.1 14.6-50.8 0-101-12.5-146.5-36.6z", "M174.7 415.6c55.4 21.2 116.9 23.3 174.1 5.1 12.7-4.1 26.2 2.9 30.2 15.6s-2.9 26.2-15.6 30.2c-30.7 9.8-62.4 14.6-94.1 14.6-50.8 0-101-12.5-146.5-36.6 18.6-8 35.9-17.7 51.8-29zM367.5 265.4c5.5-11.8 19.9-17 31.9-11.5 11.8 5.5 17 19.9 11.5 31.9l-20.4 43.5c-5.5 11.8-19.9 17-31.9 11.5-11.8-5.5-17-19.9-11.5-31.9l20.4-43.4z"]],
    "plane": [576, 576, [], "f072", ["M168 0l60 240 152 0-140-240-72 0zM0 168l42 168 186 0 12-48-12-48-114 0-42-72-72 0zm380 72l28 48-28 48 177 0c12.7 0 21.6-12.2 18.2-24.5-10.8-41-48.5-71.5-92.9-71.5L380 240zM228 336l-60 240 72 0 140-240-152 0z", "M228 240l12 48-12 48 152 0 28-48-28-48-152 0z"]],
    "images": [528, 576, [], "f302", ["M408 0c-31.4 0-58 20-67.8 48l135.7 0C466 20 439.4 0 408 0zM144 48l0 192 288 0 0 96 96 0 0-288-52.2 0c2.6 7.5 4.2 15.6 4.2 24 0 39.8-32.2 72-72 72s-72-32.2-72-72c0-8.4 1.5-16.5 4.2-24L144 48zM48 240l0 197.8 44.6-53.8 119.6 144 3.6 0 55.8-67.2 55.9 67.2 104.5 0 0-192-288 0 0-96-96 0zm0 197.8l-48 57.8 0 80.4 367.4 0-39.9-48-111.7 0-1.8 2.2-1.8-2.2-164.3 0 0-90.2z", "M327.5 528l-111.7 0 55.8-67.2 55.9 67.2zm-115.2 0L48 528 48 437.8 92.6 384 212.3 528zM432 240l0 96-288 0 0-96 288 0zM475.8 48c2.6 7.5 4.2 15.6 4.2 24 0 39.8-32.2 72-72 72s-72-32.2-72-72c0-8.4 1.5-16.5 4.2-24l135.7 0z"]],
    "bag-shopping": [480, 576, ["shopping-bag"], "f290", ["M234.1 .2C171.4 .2 120.3 51.1 120.3 114l0 54 48 0 0 78.2c0 13.2-10.8 24-24 24s-24-10.8-24-24l0-78.2-96.2 0-23 391c-.5 9.4 7 17 16.1 17L463 576c9.4 0 16.6-7.9 16.1-17l-23-391-96 0 0-54C360.1 51.4 309.2 .2 246.3 .2l-12.2 0zM168.3 114c0-36.2 29.5-65.8 65.8-65.8l12.2 0c36.2 0 65.8 29.5 65.8 65.8l0 54 48 0 0 78.2c0 13.2-10.8 24-24 24s-24-10.8-24-24l0-78.2-143.8 0 0-54z", "M168.3 246.2c0 13.2-10.8 24-24 24s-24-10.8-24-24l0-78.2 48 0 0 78.2zm191.8 0c0 13.2-10.8 24-24 24s-24-10.8-24-24l0-78.2 48 0 0 78.2z"]],
    "phone": [576, 576, [128222, 128379], "f095", ["M87.4 3.9L33.1 38.3c-25.4 16.1-37.9 46.3-31.4 75.6 25 113.5 68.4 208.1 160.3 300.2 61.2 61.4 123.7 101.1 192.1 128.1 .1-.1 .1-.2 .1-.2l.2-.2c-.1 0-.1-.1-.2-.1l.2 0 162-115.6c-24.7-15-49-31-72.8-47.8-10.1-7.2-23.3-7.9-34.1-1.4l-45.8 27.6c-11.3 6.7-25.7 7-37.2 .7-34.6-19-53.5-33.8-87.6-67.9s-49-53-67.9-87.6c-6.5-11.8-6.2-25.9 .7-37.2l27.6-45.8c6.5-10.6 5.8-24-1.4-34.1-27.6-38.6-52.6-78.5-74.9-119.5-7.2-13-23.5-16.8-35.8-9.1zM576.1 475.1t0 0c0 .5 0 1 0 1.5t0 0 0 0c0-.5 0-1 0-1.5t0 0z", "M354.3 541.8c34.3 13.7 70.1 24.2 108 32.6 29.3 6.5 59.5-6 75.6-31.4l34.3-54.2c7.7-12.2 3.6-28.6-8.9-35.5-15.6-8.6-31-18-46.3-27.4l-162.5 115.9-.2 0z"]],
    "leaf": [432, 576, [], "f06c", ["M314.2 0c-2.2 0-4.1 .2-6.3 1-9.6 2.9-16.1 12.5-15.6 22.8 0 2 1.8 48.5-79.5 75.4-82.8 27.4-175.2 95.1-194.2 184.6-13.4 63.2 9.3 127.4 67.4 191.1 18.7-50.5 42.1-97.8 69-142.2 30-48.7 62.9-94.3 101.5-136.1l0 .2c4.6-4.8 12.2-5 17-.5 4.3 4.3 4.8 11 1.5 16.1-54.5 89.2-98 192.6-113.2 298.2-37.8-4.7-59.9-20.6-69.5-29.4l-6-6c-.1-.1-.2-.3-.3-.4-1.8 5-3.7 10-5.4 15-9.4 27.8-17 56.6-22.3 86.2l97.9 0c.6-21.8 2.5-43.6 5.6-65.4 .2 0 .4 .1 .6 .1 8.4 .5 16.6 .7 24.5 .7 99.4 0 167.8-31 203.3-92.4 83-143.3-51.4-397-57.4-407.8-3.8-7.2-11-11.3-18.7-11.3z", "M256.6 196.8c4.6-4.8 12.2-5 17-.5 4.3 4.3 4.8 11 1.5 16.1-54.5 89.2-98 192.6-113.2 298.2-37.8-4.7-59.9-20.6-69.5-29.4l-6-6c-.1-.1-.2-.3-.3-.4 18.7-50.5 42.1-97.8 69-142.2 30-48.7 62.9-94.3 101.5-136.1l0 .2z"]],
    "universal-access": [480, 576, [], "f29a", ["M240 0C107.5 0 0 107.5 0 240 0 341.2 62.6 427.7 151.2 463l14.6-175-69.8 0c-13.2 0-24-10.8-24-24s10.8-24 24-24l287.5 0c13.2 0 24 10.8 24 24s-10.8 24-24 24l-69.8 0 14.6 175.1C417.1 428 480 341.4 480 240 480 107.5 372.5 0 240 0zm72 120a72 72 0 1 1 -144 0 72 72 0 1 1 144 0zM151.2 463L144 550.1c-1.2 13.2 8.6 24.7 21.8 25.9l1.9 0c12.2 0 22.8-9.6 24-22.1l6.5-53.8c13.4 2.4 27.4 3.8 41.5 3.8s28.1-1.4 41.5-3.8l6.5 53.8c1 12.5 11.5 22.1 24 22.1l1.9 0c13.2-1.2 23-12.7 21.8-25.9l-7.3-86.9c-27.3 10.8-57.1 16.9-88.3 16.9-31.4 0-61.3-6.1-88.8-17z", "M383.5 240c13.2 0 24 10.8 24 24s-10.8 24-24 24l-69.8 0 14.6 175.1c-27.3 10.8-57.1 16.9-88.3 16.9-31.4 0-61.3-6.1-88.8-17l14.6-175-69.8 0c-13.2 0-24-10.8-24-24s10.8-24 24-24l287.5 0zM240 192a72 72 0 1 1 0-144 72 72 0 1 1 0 144z"]],
    "pizza-slice": [528, 576, [], "f818", ["M264.3 0C171.7 0 83.8 21.1 5.6 58.6l32.2 64.5C106.5 90.4 183.2 72 264.3 72s157.8 18.4 226.5 51.1L523 58.6C444.8 21.1 356.9 0 264.3 0zm0 120c-73.2 0-142.6 16.7-204.8 46.4l23.9 47.8c16.5-13.8 37.6-22.2 60.9-22.2 53 0 96 43 96 96 0 45.2-31.3 83.1-73.4 93.3l97.4 194.7 59-118.1c-21.4-17.6-35-44.1-35-73.9 0-53 43-96 96-96 7.8 0 15.4 .9 22.6 2.7l62.1-124.3C406.9 136.9 337.5 120 264.3 120zM37.8 123.1C23.3 130 9.2 137.5-4.5 145.7l21.8 43.4C31 180.9 45 173.3 59.5 166.4L37.8 123.1zm452.9 0l-21.7 43.4c14.5 6.9 28.6 14.5 42.2 22.7l21.8-43.4c-13.7-8.2-27.9-15.7-42.4-22.6zM83.4 214.2c-14.2 11.9-24.9 27.9-30.5 46.2L111.7 378c10.3 3.8 21.1 6 32.6 6 7.8 0 15.4-1 22.6-2.7L83.4 214.2zm323.6 76.6L323.3 457.9c12.3 10.1 27.2 17.3 43.5 20.4l82.3-164.6c-11.7-10.9-26.2-19-42.2-22.9z", "M384.3 288c7.8 0 15.4 .9 22.6 2.7L323.3 457.9c-21.4-17.6-35-44.1-35-73.9 0-53 43-96 96-96zm-240-96c53 0 96 43 96 96 0 45.2-31.3 83.1-73.4 93.3L83.4 214.2C99.8 200.4 121 192 144.3 192zm120-120c81.1 0 157.8 18.4 226.5 51.1l-21.7 43.4c-62.2-29.6-131.6-46.5-204.7-46.5-73.2 0-142.6 16.7-204.8 46.4L37.8 123.1C106.5 90.4 183.2 72 264.3 72z"]],
    "hourglass": [384, 576, [9203, 62032, "hourglass-empty"], "f254", ["M22.1 0C9.8 0 0 9.8 0 22.1L0 84.7C0 124.3 19.5 162 53.5 187.9l54.2 41.5c16.1 12.5 16.1 32.7 0 45.1L53.5 316.1C19.5 342.2 0 379.7 0 419.3l0 62.6C0 494.2 9.8 504 22.1 504l45.5 0c25.7-57.5 71.7-95.9 124.3-96 52.6 .1 98.7 38.5 124.3 96l45.7 0c12.2 0 22.1-9.8 22.1-22.1l0-62.6c0-39.6-19.5-77.3-53.5-103.2l-54.2-41.5c-16.1-12.5-16.1-32.7 0-45.1l54.2-41.5C364.5 161.8 384 124.3 384 84.7l0-62.6C384 9.8 374.2 0 361.9 0L22.1 0zM192 216c-19.2 0-86.9-41.5-94.6-96l189.1 0c-7.7 54.5-75.4 96-94.6 96zM67.6 504c-6.2 13.8-11.1 28.7-14.8 44.4-3.4 14.2 7.7 27.6 22.1 27.6l234 0c14.4 0 25.4-13.4 22.1-27.6-3.6-15.7-8.6-30.6-14.8-44.4L67.6 504z", "M191.9 408c52.6 .1 98.7 38.5 124.3 96L67.6 504c25.7-57.5 71.7-95.9 124.3-96zm94.7-288c-7.7 54.5-75.4 96-94.6 96s-86.9-41.5-94.6-96l189.1 0z"]],
    "fish": [576, 576, [128031], "f578", ["M420.3 4.8L385.4 134.9c-34.6-4.3-69.8-3.3-104.1 2.9 4.2 9.2 6.7 19.4 6.7 30.2 0 39.8-32.2 72-72 72-31.2 0-57.6-19.8-67.6-47.5 40.7-28 86.1-46.3 132.9-54.7-11.4-24.7-36.3-41.8-65.3-41.8-39.8 0-72 32.2-72 72 0 8.6 1.6 16.9 4.4 24.5-16.9 11.6-33 25-48 40-89.8 89.8-119.3 217.2-88.6 331.7 82.8 22 172.1 12.9 249.2-27.8 25.8 24.5 60.7 39.5 99 39.5 79.4 0 144-64.6 144-144l-123.6 0c51-71.5 71.2-158.2 60.9-241.7l130.1-34.8c4.6-1.2 6.2-7 2.9-10.6l-.3 .2-143.3-143.3c-3.4-3.4-9.1-1.9-10.5 2.9zM261 536.5c-27.7-26.3-45-63.4-45-104.5l164.4 0c-10.9 15.2-23.1 29.8-36.8 43.4-25 25-53 45.4-82.7 61z", "M380.4 432c-10.9 15.2-23.1 29.8-36.8 43.4-25 25-53 45.4-82.7 61-27.7-26.3-45-63.4-45-104.5l164.4 0zM281.3 137.8c4.2 9.2 6.7 19.4 6.7 30.2 0 39.8-32.2 72-72 72-31.2 0-57.6-19.8-67.6-47.5 40.7-28 86.1-46.3 133-54.8z"]],
    "chart-simple": [576, 576, [], "e473", ["M0 0l0 528 120 0 0-48-72 0 0-480-48 0zM456 0l0 480 120 0 0-480-120 0zM288 168l0 312 120 0 0-312-120 0zM120 288l0 192 120 0 0-192-120 0zM240 480l0 48 48 0 0-48-48 0zm168 0l0 48 48 0 0-48-48 0zM120 528l0 48 120 0 0-48-120 0zm168 0l0 48 120 0 0-48-120 0zm168 0l0 48 120 0 0-48-120 0z", "M120 480l0 48 120 0 0-48-120 0zm168 0l0 48 120 0 0-48-120 0zm168 0l0 48 120 0 0-48-120 0z"]],
    "list": [528, 576, ["list-squares"], "f03a", ["M48 0l0 72t0 0 0 0c26.4 0 48 21.6 48 48s-21.6 48-48 48t0 0 0 0l0 72t0 0 0 0c26.4 0 48 21.6 48 48s-21.6 48-48 48t0 0 0 0l0 72t0 0 0 0c26.4 0 48 21.6 48 48s-21.6 48-48 48t0 0 0 0l0 72 480 0 0-576-480 0zm0 72t0 0 0 0C21.6 72 0 93.6 0 120s21.6 48 48 48t0 0 0 0l0-96zm120 72l0-48 264 0 0 48-264 0zM48 240t0 0 0 0c-26.4 0-48 21.6-48 48s21.6 48 48 48t0 0 0 0l0-96zm120 72l0-48 264 0 0 48-264 0zM48 408t0 0 0 0c-26.4 0-48 21.6-48 48s21.6 48 48 48t0 0 0 0l0-96zm120 72l0-48 264 0 0 48-264 0z", "M48 72l0 96c26.4 0 48-21.6 48-48S74.4 72 48 72zM168 96l0 48 264 0 0-48-264 0zM48 240l0 96c26.4 0 48-21.6 48-48s-21.6-48-48-48zm120 24l0 48 264 0 0-48-264 0zM48 408l0 96c26.4 0 48-21.6 48-48s-21.6-48-48-48zm120 24l0 48 264 0 0-48-264 0z"]],
    "headphones": [576, 576, [127911, 62863, "headphones-alt", "headphones-simple"], "f025", ["M288 48C169.2 48 72 145.2 72 264l0 27c7.7-2 15.7-3 24-3l24 0 0-24c0-92.6 75.4-168 168-168s168 75.4 168 168l0 24 24 0c8.3 0 16.3 1.1 24 3l0-27c0-118.8-97.2-216-216-216zM120 288l0 144-48 0 0-141C30.7 301.8 0 339.5 0 384l0 48c0 52.8 43.2 96 96 96l56.9 0c8.4 0 15.1-6.7 15.1-15.1l0-209.8c0-8.4-6.7-15.1-15.1-15.1L120 288zm303.1 0c-8.4 0-15.1 6.7-15.1 15.1l0 209.8c0 8.4 6.7 15.1 15.1 15.1l56.9 0c52.8 0 96-43.2 96-96l0-48c0-44.5-30.7-82.2-72-93l0 141-48 0 0-144-32.9 0z", "M120 288l0 144-48 0 0-141c7.7-2 15.7-3 24-3l24 0zm360 0c8.3 0 16.3 1.1 24 3l0 141-48 0 0-144 24 0z"]],
    "bus": [576, 576, [128653], "f207", ["M62.2 24C27.8 24 0 51.8 0 86.2l0 372c0 12 9.8 21.8 21.8 21.8l27 0c-.6-3.9-.9-7.9-.9-12 0-46.3 37.7-84 84-84s84 37.7 84 84c0 4.1-.3 8.1-.9 12l145.7 0c-.6-3.9-.9-7.9-.9-12 0-46.3 37.7-84 84-84s84 37.7 84 84c0 4.1-.3 8.1-.9 12l27 0c12 0 21.8-9.8 21.8-21.8l0-153.6c0-24.2-15.4-45.6-38.4-53.3l-81.6-27.1 0-8.2-122.9 0c-11.8 0-21.1-9.4-21.1-21.1l0-77.8c0-11.8 9.4-21.1 21.1-21.1l122.9 0 0-9.8C456 51.8 428.2 24 393.8 24L62.2 24zM144 117.1c0-11.8 9.4-21.1 21.1-21.1l77.8 0c11.8 0 21.1 9.4 21.1 21.1l0 77.8c0 11.8-9.4 21.1-21.1 21.1l-77.8 0c-11.8 0-21.1-9.4-21.1-21.1l0-77.8zM456 96l0 120 26.9 0c11.8 0 21.1-9.4 21.1-21.1l0-77.8c0-11.8-9.4-21.1-21.1-21.1L456 96zM48.9 480c5.8 40.7 40.9 72 83.1 72s77.3-31.3 83.1-72L48.9 480zm312 0c5.8 40.7 40.9 72 83.1 72s77.3-31.3 83.1-72l-166.3 0z", "M444 384c46.3 0 84 37.7 84 84 0 4.1-.3 8.1-.9 12l-166.3 0c-.6-3.9-.9-7.9-.9-12 0-46.3 37.7-84 84-84zm-312 0c46.3 0 84 37.7 84 84 0 4.1-.3 8.1-.9 12L48.9 480c-.6-3.9-.9-7.9-.9-12 0-46.3 37.7-84 84-84zM242.9 96c11.8 0 21.1 9.4 21.1 21.1l0 77.8c0 11.8-9.4 21.1-21.1 21.1l-77.8 0c-11.8 0-21.1-9.4-21.1-21.1l0-77.8c0-11.8 9.4-21.1 21.1-21.1l77.8 0zM456 96l0 120-122.9 0c-11.8 0-21.1-9.4-21.1-21.1l0-77.8c0-11.8 9.4-21.1 21.1-21.1L456 96z"]],
    "quote-left": [576, 576, [8220, "quote-left-alt"], "f10d", ["M204 48C91.3 48 0 139.3 0 252l0 12 72 0 0-12c0-72.9 59.1-132 132-132l36 0 0-72-36 0zm336 0c-112.7 0-204 91.3-204 204l0 12 72 0 0-12c0-72.9 59.1-132 132-132l36 0 0-72-36 0zM72 264l0 96-72 0 0 168 240 0 0-264-168 0zm336 0l0 96-72 0 0 168 240 0 0-264-168 0z", "M72 360l-72 0 0-96 72 0 0 96zm336 0l-72 0 0-96 72 0 0 96z"]],
    "martini-glass": [576, 576, [127864, "glass-martini-alt"], "f57b", ["M433.4 39.8L395.6 144 215.3 144c.4-3.9 .7-7.9 .7-12 0-59.8-48.2-108-108-108S0 72.2 0 132 48.2 240 108 240c18.8 0 36.4-4.8 51.7-13.1L96 144 215.3 144c-3.9 35.9-25.4 66.4-55.6 82.9l152.3 197.9 0 103.2-72 0c-26.4 0-48 21.6-48 48l288 0c0-26.4-21.6-48-48-48l-72 0 0-103.2 216-280.8-129.4 0 31.9-87.8c4.6-12.5-1.9-26.1-14.4-30.7S438 27.4 433.4 39.8zm-96 264l58.1-159.8 51.1 0-64.1 176.2c-3.6 9.8-12.7 15.8-22.6 15.8-2.6 0-5.5-.5-8.2-1.4-12.5-4.6-19-18.2-14.4-30.7z", "M446.6 144L382.6 320.2c-3.6 9.8-12.7 15.8-22.6 15.8-2.6 0-5.5-.5-8.2-1.4-12.5-4.6-19-18.2-14.4-30.7l58.1-159.8 51.1 0zm-231.3 0c-3.9 35.9-25.4 66.4-55.6 82.9L96 144 215.3 144z"]],
    "rectangle-wide": [576, 576, [], "f2fc", ["M24 96C10.7 96 0 106.7 0 120l0 264 576-72 0-192c0-13.3-10.7-24-24-24L24 96z", "M576 312L0 384 0 456c0 13.3 10.7 24 24 24l528 0c13.3 0 24-10.7 24-24l0-144z"]],
    "cloud-arrow-down": [576, 576, [62337, "cloud-download", "cloud-download-alt"], "f0ed", ["M228 0c-86.2 0-156 69.8-156 156 0 13.2 1.7 25.7 4.8 37.9-43.7 8.9-76.8 47.8-76.8 94.1 0 52.8 43.2 96 96 96l168.2 0 0-192.2c0-13.2 10.8-24 24-24s24 10.8 24 24l0 192.2 167.8 0c52.8 0 96-43.2 96-96 0-45.1-31.4-82.8-73.4-93.1 1-4.8 1.4-9.8 1.4-14.9 0-46.3-37.7-84-84-84-16.1 0-30.7 4.8-43.4 12.5-20.2-62.9-79-108.5-148.6-108.5zm36.2 384l0 109.9-55-55c-9.4-9.4-24.5-9.4-33.8 0s-9.4 24.5 0 33.8l96 96c4.8 4.8 10.8 7 17 7s12.2-2.4 17-7l96-96c9.4-9.4 9.4-24.5 0-33.8l-.5 0c-9.4-9.4-24.5-9.4-33.8 0l-55 55 0-109.9-48 0z", "M288.2 167.8c13.2 0 24 10.8 24 24l0 192.2-48 0 0-192.2c0-13.2 10.8-24 24-24z"]],
    "angle-down": [576, 576, [8964], "f107", ["M288.5 120c-51.4 0-93.3 40.3-95.9 91.1l-.1 4.9 192 0c0 53-43 96-96 96s-96-43-96-96L9.3 216c-7.9 0-11.8 9.1-6.2 14.4L288.5 504 573.8 230.4c5.5-5.3 1.7-14.4-6.2-14.4l-183.1 0-.1-4.9c-2.6-50.7-44.5-91.1-95.9-91.1z", "M288.5 312c53 0 96-43 96-96l-192 0c0 53 43 96 96 96z"]],
    "ghost": [480, 576, [128123], "f6e2", ["M240 0c-71.1 0-130.5 52.2-142 120.1 25.5 1.3 46 27.6 46 59.9 0 33.1-21.6 60-48 60t0 0 0 0l0 60.2C11.3 341.5 0 432 0 432 0 432 37.9 403.7 95.8 388.6 94.3 452.6 65 510.2 19 548.9 53 566.2 91.2 576 132 576 249.1 576 347.8 495.1 375.8 386.4 438.5 400.8 480 432 480 432 480 432 468.7 341.5 384 300.2L384 144C384 64.8 319.2 0 240 0zM96 120c-26.4 0-48 26.9-48 60s21.6 60 48 60t0 0 0 0l0-96c0-8.1 .7-16.1 2-23.9-.7 0-1.3-.1-2-.1zm144 60c0-33.1 21.6-60 48-60s48 26.9 48 60-21.6 60-48 60-48-26.9-48-60zM168 300c0-19.9 10.8-36 24-36s24 16.1 24 36-10.8 36-24 36-24-16.1-24-36z", "M192 264c13.2 0 24 16.1 24 36s-10.8 36-24 36-24-16.1-24-36 10.8-36 24-36zM98 120.1c25.5 1.3 46 27.6 46 59.9 0 33.1-21.6 60-48 60l0-96c0-8.1 .7-16.1 2-23.9zm190-.1c26.4 0 48 26.9 48 60s-21.6 60-48 60-48-26.9-48-60 21.6-60 48-60z"]],
    "chart-pie": [576, 576, ["pie-chart"], "f200", ["M312 0l0 264 264 0C576 118.1 457.9 0 312 0zM264 48C118.1 48 0 166.1 0 312S118.1 576 264 576t0 0 0 0l0-528z", "M264 576c145.9 0 264-118.1 264-264l-264 0 0 264z"]],
    "inbox": [528, 576, [], "f01c", ["M72 0l0 120 384 0 0-120-384 0zM24 120c-13.3 0-24 10.7-24 24L0 552c0 13.3 10.7 24 24 24l480 0c13.3 0 24-10.7 24-24l0-408c0-13.3-10.7-24-24-24l-48 0 0 288-120 0c0 39.8-32.2 72-72 72s-72-32.2-72-72l-120 0 0-288-48 0z", "M456 408l-120 0c0 39.8-32.2 72-72 72s-72-32.2-72-72l-120 0 0-288 384 0 0 288z"]],
    "hat-cowboy": [576, 576, [], "f8c0", ["M288 48c-48.7 0-88.9 40.8-95.1 93.6-42.8 18.3-72.9 60.8-72.9 110.4l0 194.8c36.1 18.3 89.6 33.2 168 33.2 17.2 0 33.1-.8 48-2.1L336 288c0-55.7 37.9-102.5 89.4-116.1 18.9 21.1 30.5 49 30.6 79.5q0 .3 0 .5 0-.3 0-.5c-.2-49.3-30.2-91.6-72.9-109.8-6.3-52.8-46.4-93.6-95.1-93.6zM24 288c-13.3 0-24 10.7-24 24l0 43c0 20.8 2.7 46.4 18.2 68.3 29.9 42.2 103.1 104.6 269.1 104.7q0 0 .1 0 0 0 .1 0 0 0 .1 0t.1 0q.1 0 .1 0 0 0 .1 0 0 0 .1 0 0 0 0 0 0 0 0 0t0 0q0 0 0 0t0 0q0 0 0 0t0 0q0 0 0 0t0 0q0 0 0 0 0 0-.1 0 0 0-.1 0-.1 0-.1 0 0 0-.1 0t-.1 0q0 0-.1 0-.1 0-.1 0c-71.8-.1-126.2-11.8-167.3-28.5l0-52.7c-34.2-17.3-52.9-37.6-62.6-51.3-6.8-9.6-9.4-22.9-9.4-40.6l0-43c0-13.3-10.7-24-24-24zm528 0c-13.3 0-24 10.7-24 24l0 43c0 17.7-2.6 31-9.4 40.6-9.7 13.7-28.4 34-62.6 51.3l0 52.7c-41.1 16.7-95.5 28.4-167.3 28.5q0 0-.1 0 0 0-.1 0 0 0-.1 0t-.1 0q0 0-.1 0 0 0-.1 0 0 0-.1 0 0 0 0 0 0 0 0 0t0 0q0 0 0 0t0 0q0 0 0 0t0 0q0 0 0 0t0 0q0 0 0 0 0 0 .1 0 0 0 .1 0 .1 0 .1 0 0 0 .1 0t.1 0q0 0 .1 0 .1 0 .1 0c166-.2 239.2-62.5 269.1-104.7 15.5-21.9 18.2-47.5 18.2-68.3l0-43c0-13.3-10.7-24-24-24z", "M425.4 171.9c19 21.2 30.6 49.3 30.6 80.1l0 247.5C414.8 516.3 360.1 528 288 528s-126.8-11.7-168-28.5l0-52.7c36.1 18.3 89.6 33.2 168 33.2 17.2 0 33.1-.8 48-2.1L336 288c0-55.7 37.9-102.5 89.4-116.1z"]],
    "credit-card": [576, 576, [128179, 62083, "credit-card-alt"], "f09d", ["M309.9 13.4L13.4 309.9c-17.9 17.9-17.9 46.9 0 64.8l20.6 20.6-34 34 61.9 61.9 34-34 105.6 105.5c17.9 17.9 46.9 17.9 64.8 0L562.8 266.3c17.9-17.9 17.9-46.9 0-64.8L457.2 95.9 491 62.1 429.1 .2 395.3 34 457.2 95.9 95.9 457.2 34 395.3 395.3 34 374.7 13.4c-17.9-17.9-46.9-17.9-64.8 0zM464.2 196c5.8-5.8 14.9-5.8 20.6 0l33.6 33.6c5.8 5.8 5.8 14.9 0 20.6l-69.6 69.6c-5.8 5.8-14.9 5.8-20.6 0l-33.6-33.6c-5.8-5.8-5.8-14.9 0-20.6L464.2 196z", "M457.2 95.9L95.9 457.2 34 395.3 395.3 34 457.2 95.9zM464.2 196c5.8-5.8 14.9-5.8 20.6 0l33.6 33.6c5.8 5.8 5.8 14.9 0 20.6l-69.6 69.6c-5.8 5.8-14.9 5.8-20.6 0l-33.6-33.6c-5.8-5.8-5.8-14.9 0-20.6L464.2 196z"]],
    "wand-magic-sparkles": [576, 576, ["magic-wand-sparkles"], "e2ca", ["M432 0l-24 48-48 24 48 24 24 48 24-48 48-24-48-24-24-48zM263.5 4.6L172.3 72.5 64.3 36C46.8 30 30 46.8 36 64.3L72.7 172.1 4.6 263.5c-11 14.9-.2 35.8 18.3 35.8l114-1.4 65.7 93.1c10.8 15.1 34.1 11.5 39.6-6.2l22.6-72.7-97.6-105.3-20.8-22.4 37.9-37.9 0 0 0 0 127.7 118.4 72.7-22.6c17.7-5.5 21.3-28.8 6.2-39.6l-93.1-65.8 1.4-114c.2-18.5-20.9-29.3-35.8-18.2zM312 264.8l-36 11.2-2.2 7.2-9 28.8 0 0 0 0 244.7 264 66.5-66.5-75.7-70.2 11.7-23.3 64-32-64-32-32-64-32 64-27.2 13.6-108.8-100.8zM384 384l36.8-18.4 79.5 73.7-20.3 40.7-32-64-64-32z", "M500.3 439.3l-20.3 40.7-32-64-64-32 36.8-18.4 79.5 73.7zM312 264.8l-36 11.2-11.2 36-118.4-127.7 37.9-37.9 127.7 118.4z"]],
    "folders": [576, 576, [], "f660", ["M24 0C10.7 0 0 10.7 0 24l0 360 120 0 0-192c0-13.3 10.7-24 24-24l144 0c13.3 0 24 10.7 24 24l0 48 144 0 0-144c0-13.3-10.7-24-24-24l-240 0 0-48c0-13.3-10.7-24-24-24L24 0zM456 240l0 144-336 0 0 168 456 0 0-288c0-13.3-10.7-24-24-24l-96 0z", "M288 168c13.3 0 24 10.7 24 24l0 48 144 0 0 144-336 0 0-192c0-13.3 10.7-24 24-24l144 0z"]],
    "star": [576, 576, [11088, 61446], "f005", ["M288 9.1l-89 180.2-199 29 144 140.4-34.1 198 178.1-244.8 288-93.6-199-29-89-180.2z", "M466.1 556.8L432 358.8 576 218.4 288 312 109.9 556.8 288 463.2 466.1 556.8z"]],
    "flag": [480, 576, [127988, 61725], "f024", ["M36 0C16.1 0 0 16.1 0 36L0 48 72 76.8 72 36C72 16.1 55.9 0 36 0zM72 76.8L72 403.2 480 240 72 76.8zm0 326.4L0 432 0 576 72 576 72 403.2z", "M0 48L0 432 72 403.2 72 76.8 0 48z"]],
    "triangle-exclamation": [576, 576, [9888, "exclamation-triangle", "warning"], "f071", ["M269 11.3L3.6 471.2C-5.1 486.3 5.7 505 23 505l206.5 0c-.7 3.6-1.1 7.3-1.1 11 0 33.1 26.9 60 60 60s60-26.9 60-60c0-3.8-.4-7.5-1.1-11l206.5 0c17.3 0 28.1-18.7 19.5-33.8l-265.5-459.8 .2 0c-8.9-15.1-30.5-15.1-39.1 0zM246.4 168.1c-2.9-60.2 86.9-60.2 84 0l-18 216c-2.2 29-45.8 28.8-48 0l-18-216zM229.5 505c5.2-27.9 29.6-49 58.9-49s53.8 21.1 58.9 49l-117.9 0z", "M288.4 456.1c29.3 0 53.8 21.1 58.9 49l-117.9 0c5.2-27.9 29.6-49 58.9-49zm-42-288c-2.9-60.2 86.9-60.2 84 0l-18 216c-2.2 29-45.8 28.8-48 0l-18-216z"]],
    "lock": [432, 576, [128274], "f023", ["M216 0C136.8 0 72 64.8 72 144l0 96 72 0 0-96c0-39.6 32.4-72 72-72s72 32.4 72 72l0 96 72 0 0-96C360 64.8 295.2 0 216 0zM43.7 240C19.6 240 0 259.6 0 283.7L0 532.3C0 556.4 19.6 576 43.7 576l344.6 0c24.1 0 43.7-19.6 43.7-43.7l0-248.6c0-24.1-19.6-43.7-43.7-43.7l-28.3 0 0 96-72 0 0-96-144 0 0 96-72 0 0-96-28.3 0z", "M72 240l0 96 72 0 0-96-72 0zm216 0l0 96 72 0 0-96-72 0z"]],
    "mailbox-flag-up": [576, 576, [], "e5bb", ["M120 192q0 0 0 0t0 0c66 0 120 64.8 120 144l0 216 336 0 0-216c0-79.2-54-144-120-144l-48 0 0 192-48 0 0-192-240 0z", "M120 192c66 0 120 64.8 120 144l0 216-240 0 0-216c0-79.2 54-144 120-144zm384-72l-96 0 0 264-48 0 0-360 144 0 0 96z"]],
    "anchor": [576, 576, [9875], "f13d", ["M288.4 0c-53 0-96 43-96 96 0 44.6 30.7 81.8 72 92.6l0 290.3c-67.2-5.5-114.5-34.9-141.6-87.7l46.3-11.6c10.8-2.6 14.6-16.1 6.7-24l-103.9-107.3 .2 .3c-7.7-7.9-21.1-4.6-24.2 6L7.1 398.2c-3.1 10.6 6.7 20.6 17.3 18l50.9-12.8c-6.3-13.7-11.5-28.5-15.6-44.3-3.4-12.7 4.3-25.9 17.3-29.3s25.9 4.3 29.3 17.3c4.2 16.2 9.8 31 16.6 44.3l-47.5 12c34.1 74.3 99.4 117.4 189.1 123.8l0 24.9c0 13.2 10.8 24 24 24s24-10.8 24-24l0-24.8c-7.7 .5-15.5 .8-23.5 .8l-.5 0c-8.2 0-16.2-.3-24-.9l0-48.1c7.8 .6 15.9 1 24.2 1 8.2 0 16.1-.4 23.8-1l0-290.4c41.3-10.8 72-48 72-92.6 0-53-43-96-96-96zm48 96a48 48 0 1 1 -96 0 48 48 0 1 1 96 0zM504.6 248.6L400.7 355.9c-7.7 7.9-3.8 21.4 6.7 24l46.8 11.8C427 444.4 379.6 473.6 312.4 479l0 48.1c89.6-6.3 155.1-49.3 189.3-123.5l50.4 12.7c10.8 2.6 20.4-7.2 17.3-18l.2-.2-40.8-143.5c-3.1-10.6-16.6-13.9-24.3-6zM471 347c3.4-12.7 16.3-20.6 29.3-17.3 12.7 3.4 20.4 16.6 17.3 29.3-4.1 15.9-9.5 30.8-15.9 44.6l-47.5-12c6.9-13.4 12.5-28.3 16.8-44.6z", "M264.4 479c7.8 .6 15.9 1 24.2 1 8.2 0 16.1-.4 23.8-1l0 48.1c-7.7 .5-15.5 .8-23.5 .8l-.5 0c-8.2 0-16.2-.3-24-.9l0-48.1zM471 347c3.4-12.7 16.3-20.6 29.3-17.3 12.7 3.4 20.4 16.6 17.3 29.3-4.1 15.9-9.5 30.8-15.9 44.6l-47.5-12c6.9-13.4 12.5-28.3 16.8-44.6zM76.9 329.8c13-3.4 25.9 4.3 29.3 17.3 4.2 16.2 9.8 31 16.6 44.3l-47.5 12c-6.3-13.7-11.5-28.5-15.6-44.3-3.4-12.7 4.3-25.9 17.3-29.3z"]],
    "cake-slice": [576, 576, [127856, "shortcake"], "e3e5", ["M360 0l-312 144 0 48 456 0 0 144-456 0 0 48 456 0 0 144-456 0 0 48 528 0 0-432C576 24 360.1 0 360 0zM13.9 192C6.2 192 0 198.2 0 205.9L0 322.1C0 329.8 6.2 336 13.9 336l34.1 0 0-144-34.1 0zm0 192C6.2 384 0 390.2 0 397.9L0 514.1C0 521.8 6.2 528 13.9 528l34.1 0 0-144-34.1 0z", "M504 384l0 144-456 0 0-144 456 0zm0-192l0 144-456 0 0-144 456 0z"]],
    "scissors": [576, 576, [9984, 9986, 9988, "cut"], "f0c4", ["M471.4 24c-19 0-38.9 4.1-58.3 12.7-62.6 27.8-94.6 92.6-71.3 144.7 6 13.4 15.1 24.7 26.2 33.6l-60.6 27 76.5 34.1 113.5-50.5c62.6-27.8 94.6-92.6 71.3-144.7l-.2-.2c-16.1-36-54.2-56.6-97-56.6zM432.5 80.4c12.5-5.5 25.9-8.4 38.6-8.4 25.2 0 45.6 10.8 53.3 28.1 7.2 16.1 1.4 32.4-2.6 40.8-8.4 17-24.5 31.9-44.2 40.6-12.5 5.5-25.9 8.4-38.6 8.4-25.2 0-45.6-10.8-53.3-28.1-12.2-27.4 9.4-64.8 46.8-81.4zM0 173L231.2 276 307.3 242 81.8 141.6C50.6 127.7 13.9 141.8 0 173zM231.2 276L0 379c13.9 31.2 50.6 45.4 81.8 31.4L307.6 310 231.2 276zm152.6 .1l-76.2 33.9 60.6 27c-11.3 8.9-20.4 20.2-26.2 33.6-23.3 52.1 8.6 116.9 71.3 144.7 19.2 8.6 39.1 12.7 58.3 12.7 42.7 0 81.1-20.6 97-56.6 23.3-52.1-8.6-116.9-71.3-144.7L383.8 276.1zm2.1 114.2c7.7-17.3 28.1-28.1 53.3-28.1 12.7 0 26.2 2.9 38.6 8.4 19.7 8.9 35.8 23.5 44.2 40.6 4.1 8.4 9.8 24.7 2.6 40.8-7.7 17.3-28.1 28.1-53.3 28.1-12.7 0-26.2-2.9-38.6-8.4-37.7-16.8-59-54-46.8-81.4z", "M307.3 242l-76.2 33.9 76.4 34 76.2-33.9-76.5-34.1z"]],
    "bug": [576, 576, [], "f188", ["M124.6 7c-9.1 9.4-9.4 24.7 0 33.8l55.8 55.8C157.8 122.1 144 155.5 144 192l-25.7 0c-12.2 0-22.3 9.8-22.3 22.3l0 49.7-72 0c-13.2 0-24 10.8-24 24s10.8 24 24 24l72 0 0-48 48 0c13.2 0 24 10.8 24 24s-10.8 24-24 24l-48 0 0 66.2c0 .5 0 1 0 1.5L19.9 400.1c-12.7 3.4-20.4 16.6-17 29.3s16.6 20.4 29.3 17l70-18.7c6 24 16.3 46.4 30.1 66.3L67.9 531.2c-11.5 6.5-15.4 21.4-8.9 32.9s21.4 15.4 32.9 8.9l73.2-42.3c25.6 22.1 57.1 37.5 92.4 43 49.1 7.7 95.6-3.7 133.2-27.8 .4-.3 .8-.6 1.2-.8 1.7-1.1 3.5-2.3 5.2-3.4 .4-.3 .9-.6 1.3-.9-31.3 22-69.4 35.2-110.5 35.2l0-383.7 169.7 0c12.5 0 22.3 10.1 22.3 22.3t0 0 0 0l0 0c0-12.2-9.8-22.3-22.3-22.3L432 192c0-36.5-13.9-69.8-36.5-95.3l55.9-55.9c5.5-5.5 7.8-13 6.8-20.1 .9 7.1-1.4 14.6-6.8 20.1L423.3 69 366.5 125.8c-9.1 9.4-24.5 9.1-33.8 0s-9.4-24.5 0-33.8l85-85c9.1-9.3 24.5-9.1 33.8 0 1 1 2 2.1 2.8 3.3-.8-1.2-1.8-2.3-2.8-3.3-9.4-9.1-24.7-9.4-33.8 0L358.1 66.5C337.2 54.8 313.4 48 288 48s-49.4 6.7-70.2 18.4L158.4 7c-9.4-9.3-24.7-9.3-33.8 0zm55.8 89.6c10.7-12 23.3-22.3 37.5-30.2L243.4 92c9.4 9.1 9.4 24.5 0 33.8-9.1 9.4-24.5 9.4-33.8 0L180.4 96.7zM480 264l0 0 72 0c9.1 0 17 5.1 21.1 12.6 0 .1 .1 .1 .1 .2t0 0 0 0c-4-7.6-12-12.8-21.2-12.8l-72 0zm96 24c0 13.2-10.8 24-24 24l-72 0 0 0 72 0c13.2 0 24-10.8 24-24 0 0 0 0 0 0zM135.8 369.2c12.7-3.4 25.9 4.3 29.3 17s-4.3 25.9-17 29.3l-45.9 12.3c-3.9-15.5-6-31.5-6.1-48l39.8-10.6zM480 379.9l0 0 75.9 20.4 0 0 .2 0-76.1-20.4zm76.1 20.2l0 .3-.1 0-.1 0c12.7 3.4 20.4 16.6 17 29.3-1.2 4.7-3.8 8.7-7.2 11.7-5.8 5-13.9 7.2-21.8 5.1L474.7 428c0 .1-.1 .2-.1 .3l-.2 0c-5.8 24-16.3 46.6-30.2 66.3l63.6 36.7c11.5 6.7 15.4 21.4 8.9 32.9-5 8.6-14.4 12.9-23.7 11.9-3.1-.4-6.1-1.3-9-3l-61.5-35.4-11.5-6.6c-1.5 1.2-3 2.4-4.5 3.6 1.5-1.2 3-2.4 4.5-3.6l11.4 6.6 61.3 35.4c2.9 1.6 6.1 2.6 9.2 3 9.3 1.1 18.9-3.2 23.9-11.8 6.5-11.5 2.6-26.2-8.9-32.9l-63.6-36.7c14.1-19.6 24.4-42.1 30.2-66.2l69 18.4c8 2.1 16.2-.2 22-5.3 3.5-3 6.2-7.1 7.5-11.9 3.4-12.7-4.3-25.9-17-29.3zM171.8 471.2c11.5-6.5 26.2-2.6 32.9 8.9 6.5 11.5 2.6 26.1-8.9 32.9l-30.8 17.7c-12.4-10.7-23.5-23.1-32.9-36.6l39.6-22.9z", "M457.7 192.1c12.5 0 22.3 10.1 22.3 22.3l0 49.7 72 0c9.1 0 17 5.1 21.1 12.6 1.8 3.4 2.9 7.3 2.9 11.4 0 13.2-10.8 24-24 24l-72 0 0 67.9 76 20.4-.1 0c12.7 3.4 20.4 16.6 17 29.3-1.2 4.7-3.8 8.7-7.2 11.7-5.8 5-13.9 7.2-21.8 5.1L474.7 428c0 .1-.1 .2-.1 .3l-.2 0c-5.8 24-16.3 46.6-30.2 66.3l63.6 36.7c11.5 6.7 15.4 21.4 8.9 32.9-5 8.6-14.4 12.9-23.7 11.9-3.1-.4-6.1-1.3-9-3l-61.5-35.4-11.5-6.6c-2.3 2-4.7 3.8-7.2 5.7-32.2 24.5-72.4 39.2-115.9 39.2l0-383.7 169.7 0zM171.8 471.2c11.5-6.5 26.2-2.6 32.9 8.9 6.5 11.5 2.6 26.1-8.9 32.9l-30.8 17.7c-12.4-10.7-23.5-23.1-32.9-36.6l39.6-22.9zm-36-102c12.7-3.4 25.9 4.3 29.3 17s-4.3 25.9-17 29.3l-45.9 12.3c-3.9-15.5-6-31.5-6.1-48l39.8-10.6zM144 264.1c13.2 0 24 10.8 24 24s-10.8 24-24 24l-48 0 0-48 48 0zM243.4 92c9.4 9.1 9.4 24.5 0 33.8-9.1 9.4-24.5 9.4-33.8 0L180.4 96.7c10.7-12 23.3-22.3 37.5-30.2L243.4 92zM417.6 7c9.1-9.3 24.5-9.1 33.8 0 1.8 1.7 3.3 3.7 4.4 5.8 4.7 8.9 3.2 20.4-4.4 28L423.3 69 366.5 125.8c-9.1 9.4-24.5 9.1-33.8 0s-9.4-24.5 0-33.8l85-85z"]],
    "arrow-right-from-bracket": [576, 576, ["sign-out"], "f08b", ["M36 0C16.1 0 0 16.1 0 36L0 540c0 19.9 16.1 36 36 36l228 0 0-96-72 0 0-168-72 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l72 0 0-168 72 0 0-96-228 0zM439 175c-9.4 9.4-9.4 24.6 0 33.9l55 55-302.1 0 0 48 302.1 0-55 55c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l96-96c8.8-8.8 9.3-22.7 1.6-32.1l-1.6-1.8-96-96c-9.4-9.4-24.6-9.4-33.9 0z", "M192 312l-72 0c-13.3 0-24-10.7-24-24s10.7-24 24-24l72 0 0 48z"]],
    "arrow-right-arrow-left": [576, 576, [8644, "exchange"], "f0ec", ["M416.7 77.5c-10.1 8.4-11.5 23.5-3.1 33.8l27.1 32.6-224.9 0 0 96 144.5 0 0 96 80.4 0-27.1 32.6c-8.4 10.1-7.2 25.2 3.1 33.8 4.6 3.8 9.8 5.5 15.4 5.5 7 0 13.7-2.9 18.5-8.6l120-144c7.4-8.9 7.4-21.8 0-30.7l-120-144c-8.4-10.1-23.5-11.5-33.8-3.1zM125.3 176.6L5.6 320.6c-7.4 8.9-7.4 21.8 0 30.7l120 144c4.8 5.8 11.5 8.6 18.5 8.6 5.5 0 10.8-1.9 15.4-5.5 10.1-8.4 11.5-23.5 3.1-33.8l-27.1-32.6 224.9 0 0-96-144.5 0 0-96-79.9 0s-1.2 1-1.9 1.4l28.3-34.1c8.4-10.1 7.2-25.2-3.1-33.8s-25.2-7.2-33.8 3.1z", "M215.8 240l0 96 144.5 0 0-96-144.5 0z"]],
    "arrow-up-from-line": [576, 576, [8613, "arrow-from-bottom"], "f342", ["M272.9 5.4L271 7 175 103c-9.4 9.4-9.4 24.6 0 33.9s24.6 9.4 33.9 0l55-55 0 302.1 48 0 0-302.1 55 55c9.4 9.4 24.6 9.4 33.9 0s9.4-24.6 0-33.9L305 7c-8.8-8.8-22.7-9.3-32.1-1.6zM0 384l0 192 576 0 0-192-264 0 0 96c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-96-264 0z", "M312 480c0 13.3-10.7 24-24 24s-24-10.7-24-24l0-96 48 0 0 96z"]],
    "battery-full": [576, 576, [128267, "battery", "battery-5"], "f240", ["M48 96l0 48 336 0 0-48-336 0zm-1.9 48C20.6 144 0 164.6 0 190.1L0 433.9C0 459.4 20.6 480 46.1 480l435.8 0c25.4 0 46.1-20.6 46.1-46.1l0-73.9 48 0 0-96-48 0 0-73.9c0-25.4-20.6-46.1-46.1-46.1l-97.9 0 0 288-336 0 0-288-1.9 0z", "M48 144l0 288 336 0 0-288-336 0z"]],
    "font": [576, 576, [], "f031", ["M240 0l-160 384 130 0 78-187.2 78 187.2 130 0-160-384-96 0zM79.9 384l-19.9 48 20-48-.1 0zM210 384l-40 96 235.9 0-40-96-155.9 0zm286 0l20 48-19.9-48-.1 0zm20 48l19.9 48-130 0 40 96 130.1 0-60-144zM60 432l-60 144 130.1 0 40-96-130 0 19.9-48z", "M80 384l-20 48-19.9 48 130 0 40-96-130 0zm286 0l40 96 130 0-19.9-48-20-48-130 0z"]],
    "language": [576, 576, [], "f1ab", ["M170.9 13L140.1 72 25.4 72C11.3 72 0 83.5 0 97.4L0 310.3c0 14.2 11.5 25.4 25.4 25.5l166.6 0 0 142.5c0 14.2 11.5 25.4 25.4 25.5l107.4 0c-29.1 16.8-53.8 25.2-54.4 25.4-12.5 4.1-19.4 17.8-15.4 30.2 4.2 12.6 17.8 19.1 30.2 15.4 4.1-1.2 52.8-17.8 98.9-52.3 46.1 34.8 94.8 51.1 98.9 52.3 12.4 3.7 26-2.7 30.2-15.4 4.1-12.5-2.6-26.2-15.4-30.2-.6-.2-25.3-8.6-54.3-25.4l106.6 0c14.2 0 25.5-11.5 25.5-25.5l0-212.9c0-14.2-11.5-25.4-25.5-25.4L384 240 384 97.4C384 83.3 372.5 72 358.6 72l-114.5 0 65.3 125.5c6 11.8 1.4 26.2-10.3 32.4-11.8 5.5-26.1 1.6-32.4-10.3l.3-.3-18.3-35-112.8 0-18.3 35c-6.2 11.8-20.6 16.3-32.4 10.3-11.8-6.2-16.3-20.7-10.3-32.4L140.1 72 244.1 72 213.4 13C205.2-2.9 179-2.9 170.9 13zM192 76.1l-31.5 60.5 62.9 0-31.4-60.5zM360 312.2c0-13.2 10.8-24 24-24s24 10.8 24 24l0 24 96 0c13.2 0 24 10.8 24 24s-10.3 24-23.5 24l-38.2 0c-1.9 42.7-20.6 77.3-45.6 104.9 7.7 5.5 15.5 10.3 23 14.6l-118.9 0c7.5-4.3 15.2-9.2 22.9-14.6-25-27.6-43.7-62.2-45.6-104.9l-38.2 0c-13.2 0-24-10.8-24-24s10.8-24 24-24l96 0 0-24zm-9.8 72c2.2 28.8 15.8 53 33.8 73l.2 0c18-20.2 31.7-44.4 33.8-73l-67.9 0z", "M384 288.2c13.2 0 24 10.8 24 24l0 24 96 0c13.2 0 24 10.8 24 24s-10.3 24-23.5 24l-38.2 0c-1.9 42.7-20.6 77.3-45.6 104.9 7.7 5.5 15.5 10.3 23 14.6l-118.9 0c7.5-4.3 15.2-9.2 22.9-14.6-25-27.6-43.7-62.2-45.6-104.9l-38.2 0c-13.2 0-24-10.8-24-24s10.8-24 24-24l96 0 0-24c0-13.2 10.8-24 24-24zm-33.8 96c2.2 28.8 15.8 53 33.8 73l.2 0c18-20.2 31.7-44.4 33.8-73l-67.9 0zM244.1 72l65.3 125.5c6 11.8 1.4 26.2-10.3 32.4-11.8 5.5-26.1 1.6-32.4-10.3l.3-.3-18.3-35-112.8 0-18.3 35c-6.2 11.8-20.6 16.3-32.4 10.3-11.8-6.2-16.3-20.7-10.3-32.4L140.1 72 244.1 72zm-83.5 64.6l62.9 0-31.4-60.5-31.5 60.5z"]],
    "person-biking": [576, 576, [128692, "biking"], "f84a", ["M324 0c-33.1 0-60 26.9-60 60 0 14.9 5.5 28.3 14.4 38.6l-104.9 126c-4.3 5-6.3 11.8-5.3 18.2 .7 6.5 4.3 12.5 9.6 16.5l88.5 64.8 0 83.8-28.8 0c1.6 7.8 2.4 15.8 2.4 24s-.8 16.2-2.4 24l52.8 0c13.2 0 24-10.8 24-24l0-120c0-7.7-3.6-14.9-9.8-19.4l-77.8-56.9 96.5-115.7 .7 0c33.1 0 60-26.9 60-60S357.1 0 324 0zm35.8 192c-8.2 0-15.6 4.1-20.2 11s-5 15.4-1.9 22.8l48.4 108.8c13-9.4 27.9-16.2 44-19.8l-33.3-74.9 35 0c13.2 0 24-10.8 24-24s-10.8-24-24-24l-72 0zM120 312C54 312 0 366 0 432S54 552 120 552c57.8 0 106.4-41.4 117.6-96L120 456c-13.2 0-24-10.8-24-24s10.8-24 24-24l117.6 0c-11.2-54.6-59.8-96-117.6-96zm336 0c-8.9 0-17.6 1-25.9 2.9l47.8 107.3-.2 0c5.3 12.2-.3 26.4-12.3 31.7-3.4 1.4-6.5 2.2-9.8 2.2-9.1 0-17.8-5.3-21.8-14.2L386.1 334.7c-30.3 21.8-50.1 57.4-50.1 97.3 0 66 54 120 120 120s120-54 120-120-54-120-120-120z", "M477.8 422.2l-.2 0c5.3 12.2-.3 26.4-12.3 31.7-3.4 1.4-6.5 2.2-9.8 2.2-9.1 0-17.8-5.3-21.8-14.2L386.1 334.7c13-9.4 27.9-16.2 44-19.8l47.8 107.3zM237.6 408c1.6 7.8 2.4 15.8 2.4 24s-.8 16.2-2.4 24L120 456c-13.2 0-24-10.8-24-24s10.8-24 24-24l117.6 0z"]],
    "globe": [576, 576, [127760], "f0ac", ["M229.7 6C117.1 29 28.6 117.8 5.8 230.4l43.7 31.2c2.2-19.7 6.7-38.6 13.3-56.6l-.1-.1 .1 0C91.5 127 159.6 68.1 242.9 52.3L229.7 6zM387.6 18L362.5 59.8c96.1 31.3 165.5 121.6 165.5 228.2 0 37.9-8.8 73.7-24.4 105.5L565 366.2c7-25 11-51.1 11-78.2 0-124.1-78.5-229.4-188.4-270zM288 48c-15.4 0-30.5 1.5-45.1 4.3l9.1 31.7-96 72-24 48-69.3 .9c0 0 0 .1 0 .1l69.3 71 72-24 96 96 0 72-72 72 0 28.4c19.2 4.9 39.3 7.6 60 7.6 94.7 0 176.5-54.8 215.6-134.5l-59.6 26.5-24-24 48-48-24-48-72-24-48-24 48-96 72 24 24-48-96-24-24-24 14.5-24.2C339 52.2 314 48 288 48zM49.5 261.6c-.9 8.7-1.5 17.5-1.5 26.4 0 88.8 48.3 166.3 120 207.8l0-39.8-72-96 24-48-70.5-50.4zM168 495.8l0 53.8c19 8.6 39.1 15.6 60 20.2l0-49.3c-21.3-5.5-41.4-13.9-60-24.6z", "M132 276l72-24 96 96 0 72-72 72 0 28.4c-21.3-5.5-41.4-13.9-60-24.6l0-39.8-72-96 24-48-70.5-50.4c2.2-19.7 6.7-38.6 13.3-56.6L132 276zM362.5 59.8c96.1 31.3 165.5 121.6 165.5 228.2 0 37.9-8.8 73.7-24.4 105.5l-59.6 26.5-24-24 48-48-24-48-72-24-48-24 48-96 72 24 24-48-96-24-24-24 14.5-24.2zM252 84l-96 72-24 48-69.3 .9C91.5 127 159.6 68.1 242.9 52.3L252 84z"]],
    "arrow-left": [576, 576, [8592], "f060", ["M273.6 2.6L0 288 273.6 573.4c5.3 5.5 14.4 1.7 14.4-6.2l0-159.1-96 0 0-240 96 0 0-159.1c0-7.9-9.1-11.8-14.4-6.2zM288 168l0 240 270.2 0c9.8 0 17.8-7.9 17.8-17.8l0-204.5c0-9.8-7.9-17.8-17.8-17.8L288 168z", "M192 168l0 240 96 0 0-240-96 0z"]],
    "paw": [576, 576, [], "f1b0", ["M307.7 121.4c-10.8 60 13 114.5 53 121.7s81.1-35.8 91.9-95.8-13-114.5-53-121.7-81.1 35.8-91.9 95.8zM177.1 25.7c-40.1 7.2-63.6 61.7-53.1 121.7 10.8 60 51.8 102.7 91.9 95.8 40.1-7.2 63.6-61.7 53-121.7-10.8-60-51.8-102.7-91.9-95.8zM28.6 211.4c-34.8 20.9-37.7 80.2-6.2 132.5 17.2 28.6 41 49.1 64.8 58.4-9.4 24.2-14.6 50.5-14.6 77.9l0 16.5c0 30.7 25 55.4 55.4 55.5l320.9 0c30.7 0 55.5-25 55.5-55.5l.2-.2 0-9.8c0-29.3-5.7-57.8-16-84 24.2-9.1 48.7-29.8 66.2-58.8 31.4-52.3 28.6-111.6-6.2-132.5s-88.6 4.6-120 56.6c-7.1 11.8-12.4 23.9-16 35.8 34.1 24.6 60.4 59.2 76.1 98.8-19.3 7.2-38.4 7.1-53.8-2.1-27-16.2-34.8-55.4-22.3-96.6-26-18.8-56.4-31.8-89.8-37.1-58.9-9.2-114.4 5.9-158.1 36.7 12.6 41.3 4.9 80.6-22.2 97-15.8 9.6-35.5 9.5-55.2 1.8 15.6-40 42.7-74.4 77.3-98.8-3.6-11.8-8.9-23.8-15.9-35.5-31.4-52.3-85.2-77.8-120-56.6z", "M164.5 303.6c12.6 41.3 4.9 80.6-22.1 97-15.8 9.6-35.5 9.5-55.2 1.8 15.6-40 42.7-74.4 77.3-98.8zm247.9 .3c34.1 24.6 60.4 59.2 76.1 98.8-19.3 7.2-38.4 7.1-53.8-2.1-27-16.2-34.8-55.5-22.3-96.7z"]],
    "bed": [528, 576, [128716], "f236", ["M72 24C58.8 24 48 34.8 48 48l0 50.5C53.6 96.9 59.6 96 65.8 96l174.2 0 0-48c0-13.2-10.8-24-24-24L72 24zm240 0c-13.2 0-24 10.8-24 24l0 48 174.2 0c6.2 0 12.1 .9 17.8 2.5L480 48c0-13.2-10.8-24-24-24L312 24zM240 96l0 48c0 13.2-10.8 24-24 24L72 168c-13.2 0-24-10.8-24-24l0-45.5c-27.8 7.8-48 33.2-48 63.3l0 390.2 72 0 0-72 384 0 0 72 72 0 0-390.2c0-30.3-20.4-55.6-48-63.3l0 45.5c0 13.2-10.8 24-24 24l-144 0c-13.2 0-24-10.8-24-24l0-48-48 0z", "M240 96l0 48c0 13.2-10.8 24-24 24L72 168c-13.2 0-24-10.8-24-24l0-45.5C53.6 96.9 59.6 96 65.8 96L240 96zm222.2 0c6.2 0 12.1 .9 17.8 2.5l0 45.5c0 13.2-10.8 24-24 24l-144 0c-13.2 0-24-10.8-24-24l0-48 174.2 0z"]],
    "landmark": [576, 576, [127963], "f66f", ["M288 0L0 120 0 226.8C0 234 5.8 240 13.2 240l58.8 0 0-72 96 0 0 72 72 0 0-72 96 0 0 72 72 0 0-72 96 0 0 72 59 0c7.2 0 13.2-5.8 13.2-13.2L576.2 120 288 0zM72 240l0 240 96 0 0-240-96 0zm168 0l0 240 96 0 0-240-96 0zm168 0l0 240 96 0 0-240-96 0zM12 480c-6.7 0-12 5.5-12 12l0 84 576 0 0-84c0-6.7-5.5-12-12-12l-60 0 0 48-96 0 0-48-72 0 0 48-96 0 0-48-72 0 0 48-96 0 0-48-60 0z", "M72 168l0 72 96 0 0-72-96 0zm168 0l0 72 96 0 0-72-96 0zm168 0l0 72 96 0 0-72-96 0zM72 480l0 48 96 0 0-48-96 0zm168 0l0 48 96 0 0-48-96 0zm168 0l0 48 96 0 0-48-96 0z"]],
    "music": [576, 576, [127925], "f001", ["M192 0l0 299.9c-15.7-7.6-34.4-11.9-55.2-11.9-65.8 0-126.2 43-135.6 96s36.5 96 102 96c45 0 87.8-20.3 113.2-50.2 10.4-12.2 17.9-26 21.4-40.8l1-5c.8-4.7 1.2-9.4 1.2-13.9l0 0 0-212.4 240 68.6 0 169.6c-15.7-7.6-34.4-11.9-55.2-11.9-65.5 0-126.2 43-135.6 96s36.5 96 102 96c45 0 87.8-20.3 113.2-50.2 11.6-13.5 19.6-29.1 22.4-45.8 0 0 0-.1 0-.1 .8-4.4 1.1-8.8 1.1-13.1l0 0 0-370.8-336-96zm0 451.7l0-151.8c29.4 14.2 47.9 39.9 48 70.2l-.4 0c0 4.6 0 9.1-.7 13.9l-1 4.9c-3.5 14.7-11 28.6-21.4 40.8-6.9 8.1-15.2 15.5-24.4 21.9zm288 96l0-151.8c29.6 14.3 48.2 40.3 48 70.9l-.4 0c0 4.3 0 8.6-.7 13.2-2.9 16.6-10.9 32.2-22.4 45.8-6.9 8.1-15.2 15.5-24.4 21.9z", "M480 395.9c29.6 14.3 48.2 40.3 48 70.9l-.4 0c0 4.3 0 8.6-.7 13.2-2.9 16.6-10.9 32.2-22.4 45.8-6.9 8.1-15.2 15.5-24.4 21.9l0-151.8zm-288-96c29.4 14.2 47.9 39.9 48 70.2l-.4 0c0 4.6 0 9.1-.7 13.9l-1 4.9c-3.5 14.7-11 28.6-21.4 40.8-6.9 8.1-15.2 15.5-24.4 21.9l0-151.8z"]],
    "files": [528, 576, [], "e178", ["M192 0l0 72-96 0 0 72 96 0 144 144 0 216 96 0 0-72 96 0 0-288-144 0 0-144-192 0zM0 144l0 432 336 0 0-72-240 0 0-360-96 0z", "M384 0l0 144 144 0-144-144zM96 144l0 360 240 0 0-216-144-144-96 0z"]],
    "plus": [528, 576, [10133, 61543, "add"], "2b", ["M316.8 24L211.2 24C200.6 24 192 32.6 192 43.2l0 172.8 144 0 0-172.8c0-10.6-8.6-19.2-19.2-19.2zM19.2 216C8.6 216 0 224.6 0 235.2L0 340.8C0 351.4 8.6 360 19.2 360l172.8 0 0-144-172.8 0zM336 216l0 144 172.8 0c10.6 0 19.2-8.6 19.2-19.2l0-105.6c0-10.6-8.6-19.2-19.2-19.2L336 216zM192 360l0 172.8c0 10.6 8.6 19.2 19.2 19.2l105.6 0c10.6 0 19.2-8.6 19.2-19.2l0-172.8-144 0z", "M192 216l0 144 144 0 0-144-144 0z"]],
    "box": [528, 576, [128230], "f466", ["M240 0L0 108 0 420 240 528 288 506.4 288 264 480 177.6 480 108 390.5 67.7 144 177.6 144 268.8 96 247.2 96 146.4 331.8 41.3 240 0zM390.5 15.1l-58.7 26.2 58.7 26.4 58.8-26.2-58.6-26.4-.2 0zM528 156l-48 21.6 0 242.4-192 86.4 0 69.6 240-108 0-312z", "M331.8 41.3l-235.8 105.1 0 100.8 48 21.6 0-91.2 246.5-109.9-58.7-26.4zM480 177.6l-192 86.4 0 242.4 192-86.4 0-242.4z"]],
    "arrow-rotate-right": [576, 576, [8635, "arrow-right-rotate", "arrow-rotate-forward", "redo"], "f01e", ["M218.4 0C203.8 0 192 11.8 192 26.4l0 165.6 182.2 0-55-54.9c-9.4-9.4-9.4-24.5 0-33.8s24.5-9.4 33.8 0l96 96c9.4 9.4 9.4 24.5 0 33.8l-96 96c-4.8 4.6-10.8 6.9-17 6.9s-12.2-2.1-17-6.9l.2-.3c-9.4-9.4-9.4-24.5 0-33.8l55-55-182.2 0 0-48-48 0C64.6 192 0 256.6 0 336S64.6 480 144 480l48 0 0 69.6c0 14.6 11.8 26.4 26.4 26.4l331.2 0c14.6 0 26.4-11.8 26.4-26.4l0-523.2C576 11.8 564.2 0 549.6 0L218.4 0zM48 336c0-53 43-96 96-96l48 0 0 192 153.6 0c13.2 0 24 10.8 24 24 0 13.2-10.8 24-24 24l-153.6 0 0-48-48 0c-53 0-96-43-96-96z", "M345.6 432c13.2 0 24 10.8 24 24 0 13.2-10.8 24-24 24l-153.6 0 0-48 153.6 0zM319.2 103.2c9.4-9.4 24.5-9.4 33.8 0l96 96c9.4 9.4 9.4 24.5 0 33.8l-96 96c-4.8 4.6-10.8 6.9-17 6.9s-12.2-2.1-17-6.9l.2-.3c-9.4-9.4-9.4-24.5 0-33.8l55-55-182.2 0 0-48 182.2 0-55-54.9c-9.4-9.4-9.4-24.5 0-33.8z"]],
    "arrow-down-wide-short": [576, 576, ["sort-amount-asc", "sort-amount-down"], "f160", ["M96.5 0c-13.2 0-24 10.8-24 24l0 470.2-31-31c-9.4-9.4-24.5-9.4-33.8 0s-9.4 24.5 0 33.8l72 72c4.8 4.8 10.8 7 17 7s12.2-2.4 17-7l72-72c9.4-9.4 9.4-24.5 0-33.8s-24.5-9.4-33.8 0l-.5-.2-31 31 0-469.9c0-13.2-10.8-24-24-24zm96 0l0 96 96 0 0-96-96 0zm0 96l0 144 0 0 0-48 192 0 0-96-96 0 0 48-96 0 0-48 0 0zm192 96l0 48-192 0 0 48 288 0 0-96-96 0zm-192 96l0 144 384 0 0-144-96 0 0 48-288 0 0-48 0 0z", "M192.5 96l0 48 96 0 0-48-96 0zm0 96l0 48 192 0 0-48-192 0zm0 96l0 48 288 0 0-48-288 0z"]],
    "compress": [528, 576, [], "f066", ["M144 24l0 144-144 0 0 72 216 0 0-216-72 0zm168 0l0 144 72 0 0-144-72 0zm72 144l0 72 144 0 0-72-144 0zM0 336l0 72 144 0 0-72-144 0zm144 72l0 144 72 0 0-144-72 0z", "M312 168l0 72 72 0 0-72-72 0zM144 336l0 72 72 0 0-72-72 0zm168 0l0 216 72 0 0-144 144 0 0-72-216 0z"]],
    "folder-arrow-down": [576, 576, ["folder-download"], "e053", ["M360 0c-13.3 0-24 10.7-24 24l0 96 48 0 0-96c0-13.3-10.7-24-24-24zM36 24C16.1 24 0 40.1 0 60l0 468 576 0 0-372c0-19.9-16.1-36-36-36l-156 0 0 206.1 55-55c9.4-9.4 24.6-9.4 33.9 0s9.4 24.6 0 33.9l-96 96c-9.4 9.4-24.6 9.4-33.9 0l-96-96c-9.4-9.4-9.4-24.6 0-33.9s24.6-9.4 33.9 0l55 55 0-206.1-72 0 0-60c0-19.9-16.1-36-36-36L36 24z", "M336 120l0 206.1-55-55c-9.4-9.4-24.6-9.4-33.9 0s-9.4 24.6 0 33.9l96 96c9.4 9.4 24.6 9.4 33.9 0l96-96c9.4-9.4 9.4-24.6 0-33.9s-24.6-9.4-33.9 0l-55 55 0-206.1-48 0z"]],
    "atom-simple": [576, 576, ["atom-alt"], "f5d3", ["M137.3 0c-40.6 0-75.6 11.8-100.5 36.7-52.8 52.8-46.8 150.5 5.8 251.2-52.6 100.8-58.6 198.5-5.8 251.3 25 25 60 36.7 100.5 36.7 45.3 0 97.6-14.8 150.7-42.5 53.1 27.8 105.4 42.5 150.7 42.5 40.6 0 75.6-11.8 100.5-36.7 52.8-52.8 46.9-150.6-5.7-251.4-8.5 16.4-18.3 32.9-29.3 49.2-6.9-16-15.3-32.6-25.3-49.3 9.9-16.7 18.3-33.2 25.2-49.3 11 16.4 20.8 32.9 29.4 49.3 52.5-100.7 58.3-198.4 5.6-251.1l.2 0C514.3 11.8 479.3 0 438.7 0 393.5 0 341.1 14.7 288 42.4 234.9 14.7 182.6 0 137.3 0zM238.4 72c16.5-11.1 33.1-21 49.6-29.6 16.5 8.6 33.1 18.5 49.5 29.5 35.8-15.5 70.5-24 101-24 29 0 51.6 7.7 66.7 22.8 30 30 30.5 93.9-1.1 167.7-20.9-31.2-46.1-62-75.3-91.1l-.2 0c-29.1-29.2-59.9-54.4-91.1-75.4-16.4 7.1-33 15.7-49.6 25.5-16.6-9.8-33.2-18.4-49.5-25.5zM70.8 70.8c15.1-15.1 37.4-22.8 66.7-22.8 30.4 0 65 8.5 100.8 24-31.1 20.9-61.9 46.2-91 75.3-29.2 29.2-54.5 60.1-75.4 91.3-31.7-73.9-31.3-137.8-1.1-167.9zM181 181.2c33.3-33.3 70-61.7 106.9-83.7 37 22 73.7 50.4 107.1 83.7 35 35 62.8 71.3 83.9 106.6-21 35.4-48.9 71.9-84 107-33.3 33.3-70.1 61.8-107.1 83.7-36.8-21.9-73.5-50.3-106.8-83.5-35-35.2-62.9-71.7-83.9-107.2 21-35.3 48.9-71.7 83.9-106.7zM276 192c-46.3 0-84 37.7-84 84s37.7 84 84 84c6 0 11.8-.6 17.4-1.8 8 15.4 24.1 26.1 42.6 26.1 26.4 0 48-21.6 48-48 0-18.4-10.5-34.5-25.9-42.5 1.2-5.7 1.9-11.6 1.9-17.7 0-46.3-37.7-84-84-84zM42.6 288c8.6-16.4 18.4-32.9 29.4-49.3 6.9 16 15.2 32.5 25.1 49.2-9.9 16.7-18.4 33.2-25.2 49.2-11-16.3-20.7-32.8-29.3-49.1zM288 336.2c0-26.4 21.6-48 48-48 8 0 15.5 2 22.1 5.5-7 32.2-32.4 57.6-64.7 64.5-3.4-6.6-5.4-14-5.4-21.9zm140.7 92.4c29.3-29.3 54.5-60.3 75.5-91.6 31.9 74 31.4 138 1.2 168.1l-.2 .2c-15.1 15.1-37.4 22.8-66.7 22.8-30.5 0-65.2-8.6-101.1-24.1-16.4 11-32.9 20.8-49.3 29.4-16.5-8.6-33.1-18.5-49.6-29.6 16.3-7.1 32.8-15.6 49.3-25.4 16.6 9.9 33.2 18.5 49.6 25.6 31.2-21 62.1-46.2 91.3-75.4zM70.6 505.2c-30.1-30.1-30.5-94.1 1.3-168.1 21 31.3 46.3 62.2 75.5 91.5 29.1 29.2 59.9 54.3 91 75.3-35.9 15.5-70.6 24.1-101.1 24.1-29 0-51.6-7.7-66.7-22.8z", "M287.8 478.5c16.6 9.9 33.2 18.5 49.6 25.6-16.4 11-32.9 20.8-49.3 29.4-16.5-8.6-33.1-18.5-49.6-29.6 16.3-7.1 32.8-15.6 49.3-25.4zM336 288.2c8 0 15.5 2 22.1 5.5-7 32.2-32.4 57.6-64.7 64.5-3.4-6.6-5.4-14-5.4-21.9 0-26.4 21.6-48 48-48zm-264-49.5c6.9 16 15.2 32.5 25.1 49.2-9.9 16.7-18.4 33.2-25.2 49.2-11-16.3-20.7-32.8-29.3-49.1 8.6-16.4 18.4-32.9 29.4-49.3zm432.1-.2c11 16.4 20.8 32.9 29.4 49.3-8.5 16.4-18.3 32.9-29.3 49.2-6.9-16-15.3-32.6-25.3-49.3 9.9-16.7 18.3-33.2 25.2-49.3zM288 42.4c16.5 8.6 33.1 18.5 49.5 29.5-16.4 7.1-33 15.7-49.6 25.5-16.6-9.8-33.2-18.4-49.5-25.5 16.5-11.1 33.1-21 49.6-29.6z"]],
    "eye-slash": [576, 576, [], "f070", ["M485.4 8.8l-87 106.3c16.2 6 31.1 13.1 44.8 21.1l79.4-97c8.4-10.3 6.9-25.4-3.4-33.8s-25.4-6.9-33.8 3.4zM288 96C72 96 0 288 0 288 .2 288.5 36.1 383.7 132.8 439.8L398.4 115.1C366.7 103.3 330.1 96 288 96zm155.2 40.2L177.5 460.9c31.7 11.8 68.3 19.1 110.5 19.1 215.6 0 287.7-191.3 288-192 0 0-35.8-95.5-132.8-151.8zM132.8 439.8l-79.3 97c-8.4 10.3-6.9 25.4 3.4 33.8 10.3 8.4 25.4 6.9 33.8-3.4l86.9-106.3c-16.2-6-31.1-13.1-44.8-21.1z", "M398.4 115.1c16.2 6 31.1 13.1 44.8 21.1L177.5 460.9c-16.2-6-31.1-13.1-44.8-21.1L398.4 115.1z"]],
    "mug-hot": [576, 576, [9749], "f7b6", ["M120 0l0 62.1c0 15.4-6.1 30.1-17 41-11.6 11.6-20.2 25.7-25.4 41l53.4 0c1.8-2.5 3.7-4.8 5.9-7 19.9-19.9 31-46.8 31-74.9L168 0 120 0zM240 0l0 62.1c0 15.4-6.1 30.1-17 41-11.6 11.6-20.2 25.7-25.4 41l53.4 0c1.8-2.5 3.7-4.8 5.9-7 19.9-19.9 31-46.8 31-74.9L288 0 240 0zM360 0l0 62.1c0 15.4-6.1 30.1-17 41-11.6 11.6-20.2 25.7-25.4 41l53.4 0c1.8-2.5 3.7-4.8 5.9-7 19.9-19.9 31-46.8 31-74.9L408 0 360 0zM0 144L0 480c0 53 43 96 96 96l264 0c53 0 96-43 96-96l81.2 0 10.3-18.5-31.4-17.5c0 0 0 0 0 0t0 0 0 0c0 0 0 0 0 0 31.4 17.5 31.4 17.5 31.4 17.5l0-.1c0 0 .1-.1 .1-.1 .2-.4 .5-1 .5-1 .3-.6 .7-1.3 1.1-2.2 .9-1.8 2.1-4.2 3.4-7.3 2.7-6.1 6.2-14.8 9.7-25.7 6.9-21.7 13.7-52.4 13.7-89.2s-6.8-67.6-13.7-89.2c-3.4-10.9-7-19.5-9.7-25.7-1.4-3.1-2.5-5.5-3.4-7.3-.4-.9-.8-1.6-1.1-2.2-.1-.3-.3-.5-.4-.7-.1-.1-.1-.2-.1-.3 0 0-.1-.1-.1-.1l0-.1c0 0 0 0-31.5 17.5t0 0 0 0 0 0 0 0l31.4-17.5-10.3-18.5-81.2 0 0-48-84.9 0c-7.1 9.8-11.1 21.7-11.1 33.9l0 62.1-48 0 0-62.1c0-11.7 2-23.1 5.6-33.9l-66.6 0c-7.1 9.8-11.1 21.7-11.1 33.9l0 62.1-48 0 0-62.1c0-11.7 2-23.1 5.6-33.9l-66.6 0c-7.1 9.8-11.1 21.7-11.1 33.9l0 62.1-48 0 0-62.1c0-11.7 2-23.1 5.6-33.9L0 144zM456 408l0-144 36.1 0c.5 1.5 1.1 3 1.6 4.6 5.1 16.1 10.3 39.4 10.3 67.4s-5.2 51.3-10.3 67.4c-.5 1.6-1.1 3.1-1.6 4.6L456 408z", "M131.1 144c-7.1 9.8-11.1 21.7-11.1 33.9l0 62.1-48 0 0-62.1c0-11.7 2-23.1 5.6-33.9l53.4 0zm120 0c-7.1 9.8-11.1 21.7-11.1 33.9l0 62.1-48 0 0-62.1c0-11.7 2-23.1 5.6-33.9l53.4 0zm120 0c-7.1 9.8-11.1 21.7-11.1 33.9l0 62.1-48 0 0-62.1c0-11.7 2-23.1 5.6-33.9l53.4 0z"]],
    "bolt": [432, 576, [9889, "zap"], "f0e7", ["M72 0L48 336 178.3 336 192 240 284.6 240 336 0 72 0zM284.6 240l-20.6 96-85.7 0-34.3 240 288-336-147.4 0z", "M192 240l-13.7 96 85.7 0 20.6-96-92.6 0z"]],
    "arrow-rotate-left": [576, 576, [8634, "arrow-left-rotate", "arrow-rotate-back", "arrow-rotate-backward", "undo"], "f0e2", ["M218.4 0c-14.6 0-26.4 11.8-26.4 26.4l0 165.6 120 0c79.4 0 144 64.6 144 144S391.5 480 312 480l-120 0 0 69.6c0 14.6 11.8 26.4 26.4 26.4l331.2 0c14.6 0 26.4-11.8 26.4-26.4l0-523.2C576.1 11.8 564.2 0 549.6 0L218.4 0zM103 103.2L7 199c-9.4 9.4-9.4 24.5 0 33.8l96 96c4.8 4.8 10.8 7 17 7s12.2-2.4 17-7c9.4-9.4 9.4-24.5 0-33.8l-55-55 109.9 0 0-48-110.2 0 55-55c9.4-9.4 9.4-24.5 0-33.8s-24.5-9.3-33.8 0zm89 136.8l0 192 120.2 0c53 0 96-43 96-96s-43-96-96-96l-120.2 0zM110.4 432c-13.2 0-24 10.8-24 24s10.8 24 24 24l81.6 0 0-48-81.6 0z", "M312 192c79.4 0 144 64.6 144 144S391.5 480 312 480l-120 0 0-48 120.2 0c53 0 96-43 96-96s-43-96-96-96l-120.2 0 0-48 120 0z"]],
    "wifi": [576, 576, ["wifi-3", "wifi-strong"], "f1eb", ["M288.2 0c-98.4 0-194.4 35-269.8 98.4-20.4 17-23 47.3-5.7 67.7 9.6 11.3 23 17 36.7 17 10.8 0 21.8-3.6 31-11.3 58.3-49 132-75.8 208.1-75.8s149.8 26.9 208.1 75.8c9.1 7.4 19.9 11.3 31 11.3 13.7 0 27.3-5.8 36.7-17 17-20.4 14.4-50.6-5.8-67.7l-.5 0C482.6 35 386.6 0 288.2 0zm0 144c-61.9 0-122.9 21.1-171.4 59.8-20.9 16.6-24.2 46.5-7.7 67.4 9.6 12 23.5 18.2 37.7 18.2 10.6 0 20.9-3.4 29.8-10.3 32.2-25.4 70.8-38.9 111.6-38.9s79.7 13.4 111.6 38.9c8.9 7 19.4 10.3 29.8 10.3 14.2 0 28.1-6.2 37.7-18.2 16.6-20.9 13-50.9-7.7-67.4-48.5-38.6-109.5-59.8-171.4-59.8zm0 168c-53 0-96 43-96 96l-94.8 0c-13.9 0-25.2 11.3-25.2 25.2l0 117.6c0 13.9 11.3 25.2 25.2 25.2L479 576c13.9 0 25.2-11.3 25.2-25.2l0-117.6c0-13.9-11.3-25.2-25.2-25.2l-94.8 0-.1 4.9c-2.6 50.7-44.5 91.1-95.9 91.1-53 0-96-43-96-96l192 0c0-53-43-96-96-96z", "M384.2 408l-.1 4.9c-2.6 50.7-44.5 91.1-95.9 91.1-53 0-96-43-96-96l192 0z"]],
    "volume": [576, 576, [128265, "volume-medium"], "f6a8", ["M312 0l-192 168 72 0 0 240-72 0 192 168 0-576zm48 97.7c0 12.2 8.9 22.3 20.6 23.8 82.8 10.3 147.4 81.1 147.4 166.8S463.7 444.7 380.6 455c-11.8 1.4-20.6 11.5-20.6 23.5 0 14.4 12.7 25.9 26.9 24 106.6-13.2 189.1-104.2 189.1-214.3S493.4 87.1 386.9 73.9l0-.2C372.7 72 360 83.3 360 97.7zM25.4 168C11.5 168 0 179.5 0 193.4L0 382.6C0 396.5 11.5 408 25.4 408l94.6 0 0-240-94.6 0zM360 195.1c0 11.5 8.2 20.4 19.2 23.5 30.5 8.4 52.8 36.2 52.8 69.4s-22.3 61-52.8 69.4c-11 3.1-19.2 12-19.2 23.5 0 15.6 14.9 27.4 30 23.3 51.8-13.4 90-60.5 90-116.2s-38.4-103-90-116.2c-15.1-3.8-30 7.7-30 23.3z", "M120 168l0 240 72 0 0-240-72 0z"]],
    "tag": [576, 576, [127991], "f02b", ["M264.1 48c-6.5 0-12.5 2.6-17 7L7 295c-9.4 9.4-9.4 24.5 0 33.8l216 216c4.8 4.8 10.8 7 17 7s12.2-2.4 17-7l240-240c4.6-4.6 7-10.6 7-17l0-95.8 48 0c13.2 0 24-10.8 24-24s-10.8-24-24-24l-48 0 0-72c0-13.2-10.8-24-24-24l-216 0zm72 120c0-26.4 21.6-48 48-48 17.7 0 33.1 9.7 41.5 24l-17.5 0c-13.2 0-24 10.8-24 24s10.8 24 24 24l17.5 0c-8.3 14.3-23.8 24-41.5 24-26.4 0-48-21.6-48-48zm96 0c0-8.7-2.4-16.9-6.5-24l78.5 0 0 48-78.5 0c4.1-7.1 6.5-15.3 6.5-24z", "M504 144l0 48-78.5 0c4.1-7.1 6.5-15.3 6.5-24s-2.4-16.9-6.5-24l78.5 0z"]],
    "compact-disc": [528, 576, [128191, 128192, 128440], "f51f", ["M373.6 21.6l.3 .2-18.3 44.3c58.8 24.4 105.8 71.6 130.2 130.5l44.6-18.4C501 107.5 444.6 50.9 373.6 21.6zM264.2 48c-32.4 0-63.1 6.5-91.4 18.2l63.8 155.3c8.4-3.6 17.8-5.5 27.4-5.5 9.8 0 19.1 2 27.6 5.5L355.5 66.2C327.4 54.5 296.5 48 264.2 48zM485.7 196.7l-155.1 64c-7.1-17.5-20.9-31.5-38.3-38.8 25.6 11.1 43.6 36.6 43.6 66.1 0 39.6-32.4 72-72 72-9.5 0-18.6-1.9-26.9-5.3 0 0 0 0 0 0L172.9 510.2c28.1 11.6 58.8 18 91 18 132.2 0 240-107.8 240-240 0-32.4-6.5-63.3-18.2-91.6zm-443.6 .1c-11.8 28.1-18.2 59-18.2 91.4 0 32.3 6.5 63.2 18.1 91.3l155.4-63.9c-3.6-8.5-5.6-17.9-5.6-27.7 0-9.6 1.9-19 5.5-27.4L42.2 196.8zm250 25c0 0 .1 0 .1 .1 0 0-.1 0-.1-.1zm-94.5 93.8l-.2 .1c6.5 15.5 18.3 28.2 33 36-14.7-7.8-26.3-20.5-32.6-36.1l-.3 0zm32.9 36.1c.3 .2 .6 .3 .9 .5-.3-.2-.6-.3-.9-.5zM42 379.6L-2 397.7c14.6 35.5 36 67.4 62.6 94.1s58.6 48 94.1 62.6l18.2-44.2C113.8 485.9 66.5 438.6 42 379.6z", "M197.5 315.7c6.5 15.5 18.3 28.2 33 36 1.3 .7 2.6 1.3 4 1.9 .8 .4 1.6 .7 2.5 1.1 0 0 0 0 .1 0L172.9 510.2C113.8 485.9 66.5 438.6 42 379.6l155.4-63.9zM355.5 66.2c58.8 24.4 105.8 71.6 130.2 130.5l-155.1 64c-7.1-17.5-20.9-31.5-38.3-38.8-.3-.1-.5-.2-.8-.3L355.5 66.2z"]],
    "phone-slash": [576, 576, [], "f3dd", ["M87.4 3.9L33.1 38.2C7.7 54.3-4.8 84.6 1.7 113.9 26.2 225.5 68.7 318.7 157.5 409.4l69.4-84.6c3.8 3.9 7.8 8.1 12.2 12.4 8.1 8.1 15.3 15.1 22.1 21.3l-68.9 84c-10.1-8.9-20.2-18.4-30.3-28.5-1.5-1.5-3-3.1-4.5-4.6L53.5 536.2c-8.4 10.3-7 25.4 3.4 33.8 4.6 3.6 9.8 5.5 15.1 5.5 7 0 13.9-2.9 18.5-8.9L192.3 442.6c82.6 72.9 168.8 109.8 270 131.8 10.9 2.4 22 2.2 32.4-.3t0 0c-10.4 2.5-21.4 2.8-32.3 .3-38.1-8.3-74-18.7-108.4-32.3l162.6-116c-24.7-15-48.9-30.9-72.6-47.7-10.1-7.2-23.3-7.9-34.1-1.4l-45.8 27.6c-11.3 6.7-25.7 7-37.2 .7-26.4-14.5-43.6-26.6-65.5-46.6L522.5 39.9c8.4-10.3 6.9-25.4-3.4-33.8l0 .2c-10.3-8.4-25.4-7-33.8 3.4L226.8 324.9c-25.8-26.8-39.2-45.1-55.7-75.2-6.5-11.8-6.2-25.9 .7-37.2l27.6-45.8c6.5-10.6 5.7-24-1.5-34.1-27.6-38.6-52.6-78.5-74.9-119.5-7.2-13-23.5-16.8-35.7-9.1zM535.6 437.5t0 0c9.2 5.4 18.4 10.6 27.7 15.7 6.8 3.8 11.1 10.4 12.4 17.6t0 0 0 0c-1.3-7.2-5.6-13.8-12.4-17.6-9.3-5.1-18.5-10.3-27.7-15.7t0 0z", "M516.4 426.1c15.4 9.4 31.1 18.5 46.9 27.1 12.5 7 16.6 23.3 8.9 35.5L537.9 543c-16.1 25.4-46.3 37.9-75.6 31.4-38.1-8.3-74-18.7-108.4-32.3l162.6-116zM226.8 324.9c3.8 3.9 7.8 8.1 12.2 12.4 8.1 8.1 15.3 15.1 22.1 21.3l-68.9 84c-10.1-8.9-20.2-18.4-30.3-28.5-1.5-1.5-3-3.1-4.5-4.6l69.4-84.6z"]],
    "arrow-up-right-from-square": [576, 576, ["external-link"], "f08e", ["M416.2 0c-13.2 0-24 10.8-24 24s10.8 24 24 24l77.8 0-96 96 5.8 0c15.6 0 28.3 12.7 28.3 28.3l0 5.5-189.6 189.6c-4.8 4.6-10.8 7-17.1 7s-12.2-2.2-17-7c-9.3-9.4-9.3-24.5 0-33.8L397.9 144 28.3 144C12.7 144 0 156.7 0 172.3L0 547.7C0 563.3 12.7 576 28.3 576l375.4 0c15.6 0 28.3-12.7 28.3-28.3l0-369.9 96-96 0 77.8c0 13.2 10.8 24 24 24s24-10.8 24-24L576 24c0-13.2-10.8-24-24-24L416.2 0z", "M403.7 144c15.6 0 28.3 12.7 28.3 28.3l0 5.5-189.6 189.6c-4.8 4.6-10.8 7-17.1 7s-12.2-2.2-17-7c-9.3-9.4-9.3-24.5 0-33.8l189.6-189.6 5.8 0z"]],
    "dinosaur": [576, 576, [], "e5fe", ["M348 0c-46.3 0-84 26.9-84 60s37.7 60 84 60c25.2 0 47.5-8.2 62.9-20.6 53.3 12.2 93.1 59.8 93.1 116.6l0 131.3c-34.3-63.8-102-107.3-180-107.3-100.6 0-184.1 72.5-200.6 167.5-48.2-2.4-91.4-23.8-122.4-56.9 6.7 77.6 66.7 140.5 143 151.6l0-70.2 72 0 0 72 48.2 0 0 58.1c0 7.7 6.2 13.9 13.9 13.9l44.2 0c7.7 0 13.9-6.2 13.9-13.9l0-58.1 47.8 0 0-72 72 0 0 72 48.2 0 0 58.1c0 7.7 6.2 13.9 13.9 13.9l44.2 0c7.7 0 13.9-6.2 13.9-13.9l0-346.1c0-93.8-68.4-172.6-157.7-188.6l-.3 0C403.4 11 377.5 0 348 0zM144 502.2l0 59.8c0 7.7 6.2 13.9 13.9 13.9l44.2 0c7.7 0 13.9-6.2 13.9-13.9l0-58.1-47.8 0c-8.2 0-16.3-.6-24.2-1.8zM384 504l0 58.1c0 7.7 6.2 13.9 13.9 13.9l44.2 0c7.7 0 13.9-6.2 13.9-13.9l0-58.1-72 0z", "M456 432l0 72-72 0 0-72 72 0zm-240 0l0 72-47.8 0c-8.2 0-16.3-.6-24.2-1.8l0-70.2 72 0z"]],
    "rectangle-tall": [384, 576, [], "e791", ["M0 24l0 420 384-48 0-372c0-13.3-10.7-24-24-24L24 0C10.7 0 0 10.7 0 24zM0 552q0 .1 0 .2 0 .1 0 .2 0 .1 0 .1t0 .1 0 .1q0 .1 0 .2 0 .1 0 .1 0 .1 0 .2t0 .2c.8 12.2 10.6 21.9 22.9 22.4q0 0 0 0t0 0 0 0 0 0 0 0q0 0 .1 0t.1 0 .1 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0q0 0 0 0t0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0-.1 0-.1 0-.1 0q0 0 0 0t0 0 0 0 0 0 0 0C10.7 575.4 .8 565.7 0 553.5q0-.1 0-.2t0-.2q0-.1 0-.1 0-.1 0-.2 0-.1 0-.1t0-.1 0-.1q0-.1 0-.2 0-.1 0-.2z", "M384 396L0 444 0 552c0 13.3 10.7 24 24 24l336 0c13.3 0 24-10.7 24-24l0-156z"]],
    "compass": [576, 576, [129517], "f14e", ["M96 0C43.4 0 0 43 0 96s42.2 95.3 94.8 95.8c-14.4 29-22.8 61.4-22.8 96.2 0 90.1 55.2 167.2 133.5 199.6L195.4 263 316.3 73.9C307 72.7 297.6 72 288 72 253.4 72 220.8 80.4 191.8 94.8 191 42.2 148.6 0 96 0zM355.4 12.7L316.3 73.9c19 2.5 37.3 7.4 54.4 14.5l-3.3-72.4c-.2-6.7-8.4-8.9-12-3.4zM144 96a48 48 0 1 1 -96 0 48 48 0 1 1 96 0zm226.7-7.6l10.2 224.5-121 189.1c9.2 1.2 18.6 1.9 28.1 1.9 119.3 0 216-96.7 216-216 0-90-55.1-167.1-133.3-199.6zM288 240a48 48 0 1 0 0 96 48 48 0 1 0 0-96zM205.5 487.6l3.3 72.3c.2 6.7 8.4 8.9 12 3.4l39.1-61.2c-19-2.5-37.2-7.4-54.4-14.5z", "M316.3 73.9c19 2.5 37.3 7.4 54.4 14.5l10.2 224.5-121 189.1c-19-2.5-37.2-7.4-54.4-14.5L195.4 263 316.3 73.9zM288 240a48 48 0 1 0 0 96 48 48 0 1 0 0-96z"]],
    "square": [528, 576, [9632, 9723, 9724, 61590], "f0c8", ["M24 24C10.7 24 0 34.7 0 48l0 381 528-66 0-315c0-13.3-10.7-24-24-24L24 24z", "M528 528c0 13.3-10.7 24-24 24L24 552c-13.3 0-24-10.7-24-24l0-99 528-66 0 165z"]],
    "face-grin": [576, 576, [128512, "grin"], "f580", ["M312.2 24c-112 0-207.7 69.8-246 168.2 22-1 44.1 3.5 64.6 13.7l0-.2c11.8 6 16.5 20.2 10.8 32.2-4.3 8.6-12.7 13.5-21.6 13.5-3.6 0-7.2-.7-10.6-2.4-18.1-9-38.1-11.1-57.2-6.4 3-17.4 7.7-34.2 14-50.3-18 .8-35.9 5.4-52.8 13.7-12 6-16.8 20.2-10.8 32.2 5.8 11.8 20.2 16.8 32.2 10.8 5.7-2.8 11.5-4.9 17.4-6.4-2.6 14.8-4 30-4 45.5 0 145.8 118.2 264 264 264s264-118.2 264-264-118.2-264-264-264zM277.4 205.7c37.4-18.5 80.2-18.5 117.4 0 11.8 6 16.5 20.2 10.8 32.2-4.3 8.6-12.7 13.5-21.6 13.5-3.6 0-7.2-.7-10.6-2.4-23.8-11.8-50.6-11.8-74.6 0l0-.2c-12 6-26.4 1-32.2-10.8-6-12-1.2-26.2 10.8-32.2zm195.8 57.1c2.2-.7 4.6-1 6.7-1 5 0 10.1 1.7 14.2 4.6 6 4.6 9.6 11.3 9.8 18.7l0 2.4c0 105.8-86.2 192-192 192-66.7 0-127.7-33.8-163-90.7-3.8-6.2-4.6-14.2-1.9-21.1s8.4-12.2 15.6-14.4l310.6-90.5zM338.8 361.2c-32.2 8.6-53.8 31.2-48.7 50.4s35.3 27.8 67.2 19.2c32.2-8.6 53.8-31.2 48.7-50.4s-35.3-27.8-67.2-19.2z", "M480 261.8c5 0 10.1 1.7 14.2 4.6 6 4.6 9.6 11.3 9.8 18.7l0 2.4c0 105.8-86.2 192-192 192-66.7 0-127.7-33.8-163-90.7-3.8-6.2-4.6-14.2-1.9-21.1s8.4-12.2 15.6-14.4l310.6-90.5c2.2-.7 4.6-1 6.7-1zM406 380.4c-5-19.2-35.3-27.8-67.2-19.2-32.2 8.6-53.8 31.2-48.7 50.4s35.3 27.8 67.2 19.2c32.2-8.6 53.8-31.2 48.7-50.4zM66.2 192.2c22-1 44.1 3.5 64.6 13.7l0-.2c11.8 6 16.5 20.2 10.8 32.2-4.3 8.6-12.7 13.5-21.6 13.5-3.6 0-7.2-.7-10.6-2.4-18.1-9-38.1-11.1-57.2-6.4 3-17.4 7.7-34.2 14-50.3zm211.2 13.5c37.4-18.5 80.2-18.5 117.4 0 11.8 6 16.5 20.2 10.8 32.2-4.3 8.6-12.7 13.5-21.6 13.5-3.6 0-7.2-.7-10.6-2.4-23.8-11.8-50.6-11.8-74.6 0l0-.2c-12 6-26.4 1-32.2-10.8-6-12-1.2-26.2 10.8-32.2z"]],
    "angle-up": [576, 576, [8963], "f106", ["M288.5 72L3.1 345.6C-2.4 350.9 1.4 360 9.3 360l183.2 0c0-53 43-96 96-96s96 43 96 96l-192 0 .1 4.9c2.6 50.7 44.5 91.1 95.9 91.1s93.3-40.3 95.9-91.1l.1-4.9 183.1 0c7.9 0 11.8-9.1 6.2-14.4L288.5 72z", "M288.5 264c53 0 96 43 96 96l-192 0c0-53 43-96 96-96z"]],
    "face-smile": [576, 576, [128578, "smile"], "f118", ["M312 24c-96.1 0-180.2 51.3-226.3 128.1 20.3 13.5 34.3 42.5 34.3 75.9 0 46.3-26.9 84-60 84-3.8 0-7.4-.5-11-1.4 11.5 135.2 124.8 241.4 263 241.4 145.8 0 264-118.2 264-264S457.8 24 312 24zM60 144c-33.1 0-60 37.7-60 84 0 41.1 21.1 75.3 49 82.6-.6-7.4-1-15-1-22.6 0-49.7 13.8-96.2 37.7-135.9-7.8-5.2-16.5-8.1-25.7-8.1zm228 84c0-46.3 26.9-84 60-84s60 37.7 60 84-26.9 84-60 84-60-37.7-60-84zm178.1 55.2c5.8-11.8 20.2-16.8 32.2-11 11.8 5.8 16.8 20.2 11 32.2-45.4 93.8-121.7 144-226.8 149.3l-1.2 0c-12.7 0-23.3-10.1-24-22.8-.7-13.2 9.6-24.5 22.8-25.2 87.4-4.6 148.1-44.4 186-122.4z", "M466.1 283.2c5.8-11.8 20.2-16.8 32.2-11 11.8 5.8 16.8 20.2 11 32.2-45.4 93.8-121.7 144-226.8 149.3l-1.2 0c-12.7 0-23.3-10.1-24-22.8-.7-13.2 9.6-24.5 22.8-25.2 87.4-4.6 148.1-44.4 186-122.4zM85.7 152.1c20.3 13.5 34.3 42.5 34.3 75.9 0 46.3-26.9 84-60 84-3.8 0-7.4-.5-11-1.4-.6-7.4-1-15-1-22.6 0-49.7 13.8-96.2 37.7-135.9zM348 144c33.1 0 60 37.7 60 84s-26.9 84-60 84-60-37.7-60-84 26.9-84 60-84z"]],
    "cactus": [528, 576, [127797], "f8a7", ["M264 0C198 0 144 54 144 120l0 264 72 0 0 96-72 0 0 96 240 0 0-192-72 0 0-96 72 0 0-168C384 54 330 0 264 0zM480 120c-26.4 0-48 21.6-48 48l0 120-48 0 0 96 96 0c26.4 0 48-21.6 48-48l0-168c0-26.4-21.6-48-48-48zM48 216c-26.4 0-48 21.6-48 48L0 432c0 26.4 21.6 48 48 48l96 0 0-96-48 0 0-120c0-26.4-21.6-48-48-48z", "M312 288l0 96 72 0 0-96-72 0zM144 384l0 96 72 0 0-96-72 0z"]],
    "umbrella": [576, 576, [], "f0e9", ["M288 0c-13.2 0-24 10.8-24 24l0 49c7.9-.7 15.9-1 24-1s16.1 .3 24 1l0-49c0-13.2-10.8-24-24-24zM264 73C116.1 85.2 0 209 0 360l264 0 0-287zm48 0l0 287 264 0C576 209 459.9 85.2 312 73zM264 360l0 132.2c0 19.9-16.1 36-36 36s-36-16.1-36-36l0-27.1c0-13.2-10.8-24-24-24s-24 10.8-24 24l0 27.1c0 46.1 37.7 83.8 84 83.8s84-37.4 84-83.8l0-132.2-48 0z", "M288 72c8.1 0 16.1 .3 24 1l0 287-48 0 0-287c7.9-.7 15.9-1 24-1z"]],
    "pause": [576, 576, [9208], "f04c", ["M312 24C222.7 24 143.8 68.4 96 136.3l0 303.4C143.8 507.6 222.7 552 312 552 457.8 552 576 433.8 576 288S457.8 24 312 24zM0 120l0 336 96 0 0-16.3C65.8 396.8 48 344.5 48 288S65.8 179.2 96 136.3l0-16.3-96 0zM192 456l0-336 96 0 0 336-96 0z", "M288 120l0 336-96 0 0-336 96 0zM96 439.7C65.8 396.8 48 344.5 48 288S65.8 179.2 96 136.3l0 303.4z"]],
    "desktop": [576, 576, [128421, 61704, "desktop-alt"], "f390", ["M32.2 0C14.4 0 0 14.4 0 32.2L0 424.1c0 17.8 14.4 32.2 32.2 32.2l207.8 0 0 47.8 96 0 0-47.8 207.8 0c17.8 0 32.2-14.4 32.2-32.2l0-391.9C576 14.4 561.6 0 543.8 0L32.2 0zM48 384l0-336 480 0 0 336-480 0zM204 504c-39.6 0-60 32.4-60 72l96 0 0-72-36 0zm132 0l0 72 96 0c0-39.6-20.4-72-60-72l-36 0zm-96 72l0 .2 96 0 0-.2-96 0z", "M336 504l0 72-96 0 0-72 96 0zM528 48l0 336-480 0 0-336 480 0z"]],
    "donut": [576, 576, [127849, "doughnut"], "e406", ["M288 0C128.9 0 0 112.8 0 252 0 261.6 .9 270.8 2.1 280.1 19.2 149.3 140.6 48 288 48S556.8 149.3 573.9 280.2C575.1 271 576 261.6 576 252 576 112.8 447.1 0 288 0zm0 168c-53 0-96 37.7-96 84 0 39.9 31.8 73.3 74.6 81.9-28.8-5.8-52.6-23-64.9-45.9 15.4-28.3 48.2-48 86.4-48s70.8 19.7 86.4 47.8c-12.4 22.9-36.2 40.4-65.2 46.1 42.9-8.4 74.9-41.9 74.9-81.9 0-46.3-43-84-96-84zM2.1 280.1C.7 290.6 0 301.2 0 312 0 457.9 128.9 576 288 576S576 457.9 576 312c0-10.8-.7-21.4-2.1-31.8 0 .2 0 .4 0 .6 1 8.9 1.9 18 1.9 27.1-19.4 22.6-45.8 43-61.2 65.3-26.2 37.9-32.2 102.7-76.3 124.3-41.3 20.2-99.8-12-150.2-12s-109 32.2-150.2 12c-44.2-21.4-50.2-86.4-76.3-124.3-15.4-22.6-41.8-42.7-61.2-65.3 0-9.1 .7-18.2 1.9-27.1 0-.2 0-.4-.1-.7zm264.5 53.7c0 0 0 0 .1 0 0 0 0 0-.1 0zm3.9 .7c1.1 .2 2.2 .4 3.4 .5 .2 0 .3 0 .5 0-1.3-.2-2.6-.4-3.9-.6zm30.2 .6c-1.5 .2-3.1 .3-4.6 .4 1.5-.1 3.1-.3 4.6-.4zm-4.7 .4c-2.4 .2-4.8 .3-7.2 .3t0 0q0 0 0 0c1.8 0 3.6-.1 5.4-.2 .6 0 1.2-.1 1.7-.1z", "M288 48c147.4 0 268.8 101.3 285.9 232.2 0 .2 0 .4 0 .6 1 8.9 1.9 18 1.9 27.1-19.4 22.6-45.8 43-61.2 65.3-26.2 37.9-32.2 102.7-76.3 124.3-41.3 20.2-99.8-12-150.2-12s-109 32.2-150.2 12c-44.2-21.4-50.2-86.4-76.3-124.3-15.4-22.6-41.8-42.7-61.2-65.3 0-9.1 .7-18.2 1.9-27.1 0-.2 0-.4-.1-.7 17.1-130.9 138.6-232.1 285.9-232.1zm0 120c-53 0-96 37.7-96 84 0 39.9 31.8 73.3 74.6 81.9 .3 .1 .7 .1 1 .2 2.1 .4 4.1 .8 6.2 1 .2 0 .5 0 .7 .1 1.8 .2 3.5 .4 5.3 .5 .6 0 1.2 .1 1.8 .1 2.1 .1 4.2 .2 6.3 .2 2.1 0 4.2-.1 6.3-.2 .6 0 1.2-.1 1.8-.1 4.3-.3 8.5-.8 12.6-1.6 .1 0 .3-.1 .4-.1 42.9-8.4 74.9-41.9 74.9-81.9 0-46.3-43-84-96-84z"]],
    "arrow-down": [576, 576, [8595], "f063", ["M186.2 0c-9.8 0-17.8 7.9-17.8 17.8l0 270.2 240 0 0-270.2c0-9.8-7.9-17.8-17.8-17.8L186.2 0zM9.3 288c-7.9 0-11.8 9.1-6.2 14.4L288.5 576 573.8 302.4c5.5-5.3 1.7-14.4-6.2-14.4l-159.1 0 0 96-240 0 0-96-159.1 0z", "M168.5 288l0 96 240 0 0-96-240 0z"]],
    "location-dot": [432, 576, ["map-marker-alt"], "f3c5", ["M216.5 0C97.2 0 .5 96.7 .5 216 .5 266.4 17.8 312.5 46.8 349.2l79.5 106 199.4-24.9-.1 .2 .2 0 60.9-81.3c28.8-36.7 46.3-83 46.3-133.2l-.5 0c0-119.3-96.7-216-216-216zm72 216a72 72 0 1 1 -144 0 72 72 0 1 1 144 0zM217.9 574.4l-1.3 1.4 .1 .1 1.2-1.6z", "M126 455.3L216.5 576 325.7 430.3 126 455.3z"]],
    "bars": [576, 576, ["navicon"], "f0c9", ["M312 24C219.3 24 137.8 71.8 90.7 144l293.3 0 0 48-318 0c-8.8 22.6-14.7 46.8-16.9 72l334.9 0 0 48-334.9 0c2.3 25.2 8.1 49.4 16.9 72l318 0 0 48-293.3 0c47.1 72.2 128.6 120 221.3 120 145.8 0 264-118.2 264-264S457.8 24 312 24zM0 144l0 48 66 0q.1-.4 .3-.8t.3-.8q.1-.3 .2-.5 .1-.3 .3-.7 .2-.5 .4-.9 .1-.3 .2-.5 .1-.3 .2-.6 .1-.3 .3-.7 .2-.4 .3-.8 .2-.4 .4-.9 .1-.2 .2-.5 .1-.3 .2-.5 .1-.3 .2-.5 .1-.3 .2-.6 .1-.3 .3-.6 .1-.3 .3-.7 .2-.3 .3-.7 .2-.4 .3-.7 .2-.4 .4-.8 .2-.4 .4-.8 .2-.5 .4-.9 .1-.2 .2-.5t.2-.5 .2-.5 .2-.5 .2-.5 .3-.5 .3-.6q.1-.3 .3-.6 .1-.3 .3-.6 .2-.3 .3-.6 .2-.3 .3-.6 .2-.3 .3-.7 .2-.3 .3-.7 .2-.4 .4-.7 .2-.4 .4-.7 .2-.4 .4-.7 .2-.4 .4-.8 .2-.4 .4-.8 .2-.4 .4-.8 .2-.4 .4-.9 .2-.4 .5-.9 .1-.2 .2-.4t.2-.5 .2-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.5 .3-.6 .3-.6 .3-.6 .3-.6 .3-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.6 .4-.7 .4-.7 .4-.7 .4-.7 .4-.7 .4-.7 .5-.7 .5-.7 .5-.7 .5-.8L0 144zM0 264l0 48 49.1 0q0-.5-.1-1.1t-.1-1.1q0-.4-.1-.7 0-.5-.1-1 0-.3 0-.6 0-.3 0-.6 0-.4-.1-.7 0-.4-.1-.8 0-.5-.1-.9 0-.5-.1-1.1 0-.3 0-.6 0-.3 0-.6 0-.3 0-.7 0-.3 0-.7 0-.4 0-.7 0-.4 0-.8 0-.4 0-.8 0-.4 0-.9 0-.5 0-1 0-.5 0-1 0-.5 0-1.1 0-.3 0-.6t0-.6 0-.6 0-.6 0-.6q0-.3 0-.7 0-.3 0-.7 0-.4 0-.7 0-.4 0-.7 0-.4 0-.8 0-.5 0-.9t0-.9q0-.3 0-.6 0-.4 0-.8 0-.6 0-1.1 0-.3 0-.6 0-.4 0-.7 0-.4 0-.8 0-.5 0-.9 0-.5 0-1.1 0-.3 0-.6 0-.3 0-.6 0-.3 0-.7 0-.3 0-.7 0-.4 0-.7 0-.4 0-.8 0-.4 0-.8 0-.4 0-.9 0-.5 .1-1 0-.5 .1-1 0-.5 .1-1.1 0-.3 0-.6t0-.6 0-.6 0-.6q0-.3 0-.6 0-.3 .1-.7 0-.3 .1-.7 0-.4 .1-.7 0-.4 .1-.7 0-.4 .1-.8L0 264zM0 384l0 48 90.7 0q-.2-.3-.4-.6t-.4-.6q-.1-.2-.3-.4-.2-.3-.4-.6-.2-.4-.5-.7-.1-.2-.3-.4-.2-.2-.3-.5-.2-.3-.3-.5-.2-.3-.4-.6-.2-.4-.4-.7-.3-.4-.5-.8-.1-.2-.3-.4-.1-.2-.3-.5-.2-.2-.3-.5-.2-.3-.3-.5-.2-.3-.3-.6-.2-.3-.4-.6-.2-.3-.4-.6-.2-.3-.4-.7-.2-.4-.4-.7-.2-.4-.5-.8-.2-.4-.5-.8-.1-.2-.2-.4t-.3-.4-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.5-.3-.6q-.2-.3-.3-.6-.2-.3-.3-.6-.2-.3-.3-.6-.2-.3-.3-.6-.2-.3-.3-.6-.2-.3-.4-.7-.2-.3-.4-.7-.2-.4-.4-.7-.2-.4-.4-.7-.2-.4-.4-.8-.2-.4-.4-.8-.2-.4-.4-.8-.2-.4-.4-.8-.2-.4-.4-.9-.2-.4-.4-.9-.1-.2-.2-.5t-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.2-.5-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.6-.3-.7-.3-.7-.3-.7-.3-.7-.3-.7-.3-.7-.3-.7-.3-.7-.3-.7-.3-.8L0 384z", "M90.7 144c-9.8 15-18.1 31.1-24.7 48l318 0 0-48-293.3 0zM49.1 264c-1.1 12-1.8 28.6 0 48l334.9 0 0-48-334.9 0zM66 384c6.6 16.9 14.9 33 24.7 48l293.3 0 0-48-318 0z"]],
    "stopwatch": [576, 576, [9201], "f2f2", ["M61.4 10.6L10.6 61.5c-13.9 13.9-13.9 36.9 0 50.9s36.9 13.9 50.9 0l40.3 40.3c-29.1 38.4-48 84.7-52.6 135.4l-25.1 0c-13.2 0-24 10.8-24 24s10.8 24 24 24l25.1 0c-.7-7.9-1.1-15.9-1.1-24s.4-16.1 1.1-24l195.2 0c10.1-27.8 36.5-48 67.7-48 39.8 0 72 32.2 72 72s-32.2 72-72 72c-31.4 0-57.8-20.2-67.7-48l-195.2 0c12.1 134.6 125 240 262.9 240 145.9 0 264-118.1 264-264S457.9 48 312 48c-60 0-115 20.2-159.4 53.8L112.3 61.5c13.9-13.9 13.9-37 0-50.9-13.9-14.2-37-14.2-50.9 0z", "M312 240.1c39.8 0 72 32.2 72 72s-32.2 72-72 72c-31.4 0-57.8-20.2-67.7-48l-195.2 0c-.7-7.9-1.1-15.9-1.1-24s.4-16.1 1.1-24l195.2 0c10.1-27.8 36.5-48 67.7-48z"]],
    "bird": [528, 576, [], "e469", ["M336 0c-49 0-90.7 29.3-109.4 71.3l-1 1.9-181.2 406.8 147.6 0 0-72 48 0 0 72 48 0 0-72 48 0 0 64.9c69.2-20.8 120-85.2 120-160.9 0-35.8-11.3-68.6-30.5-96l102.5 0-74.2-74.2c1.2-7.2 2.2-14.4 2.2-21.8 0-66.2-53.8-120-120-120zm0 472.9c-15.2 4.6-31.3 7.1-48 7.1l0 96 48 0 0-103.1zM192 480l0 96 48 0 0-96-48 0z", "M336 408l0 64.9c-15.2 4.6-31.3 7.1-48 7.1l0-72 48 0zm-96 0l0 72-48 0 0-72 48 0z"]],
    "train": [576, 576, [128646], "f238", ["M0 0l0 48 120 0 0 96-120 0 0 240 240 0 54 144 234 0-58.3-142.6C511 357.6 547 322.6 576 282 524.2 209.5 450.2 154.6 364.1 127.2L312 0 0 0zM168 144l0-96 111.6 0 39.4 96-151 0zM96 432a48 48 0 1 0 0 96 48 48 0 1 0 0-96zM0 528l0 48 312 0-18-48-294 0z", "M240 384l54 144-198 0c26.4 0 48-21.6 48-48s-21.6-48-48-48-48 21.6-48 48 21.6 48 48 48l-96 0 0-144 240 0zM120 48l0 96-120 0 0-96 120 0zm159.6 0l39.4 96-151 0 0-96 111.6 0z"]],
    "gamepad": [576, 576, [], "f11b", ["M432 72L143.7 72c-40.8-.5-81.6 23.3-94.3 79L1.2 419.8c-14.4 85.2 106.1 119.3 138.2 38.2 0 0 4.1-10.9 10.7-28.3 5.7 1.5 11.7 2.3 17.9 2.3 38.6 0 70-30.2 71.9-68.3l.1-3.7 96 0 .1 3.7c1.9 38.1 33.3 68.3 71.9 68.3 6.3 0 12.5-.9 18.3-2.5-6.8-18-16.2-42.8-26.2-69.6L336 360c0-39.8 32.2-72 72-72s72 32.2 72 72c0 33.5-22.7 61.5-53.7 69.6 6.6 17.4 10.7 28.4 10.7 28.4 31.9 81.1 152.4 47 138.2-38.2l-.5 0-48.5-268.8C513.6 95.1 472.8 71.3 432 72zM96 360c0-39.8 32.2-72 72-72s72 32.2 72 72l-63.6 0c-10.1 26.8-19.5 51.7-26.3 69.7-31.1-8-54.1-36-54.1-69.7z", "M168 288c39.8 0 72 32.2 72 72l-63.6 0c-10.1 26.8-19.5 51.7-26.3 69.7-31.1-8-54.1-36-54.1-69.7 0-39.8 32.2-72 72-72zm240 0c39.8 0 72 32.2 72 72 0 33.5-22.8 61.5-53.7 69.6-6.8-18-16.2-42.8-26.3-69.6L336 360c0-39.8 32.2-72 72-72z"]],
    "ship": [576, 576, [128674], "f21a", ["M168 48l0 96 144 0 0-96-144 0zm192 0l0 96 144 0 0-96-144 0zM168 192l0 48 144 0 0-48-144 0zm192 0l0 48 144 0 0-48-144 0zM0 240L0 432c28.6 0 41.8-8.9 58.6-19.9 18.7-12.5 42-28.1 85.2-28.1s66.5 15.6 85.2 28.1c16.6 11 29.8 19.9 58.6 19.9 28.8 0 42-8.9 58.8-19.9 19-12.5 42-28.1 85.5-28.1 36 0 58.1 10.7 75.3 21.5l69-165.5-72 0 0 48-144 0 0-48-48 0 0 48-144 0 0-48-168 0zM507 405.5l-18.7 45c.7 .5 1.5 1 2.3 1.5 18.7 12.5 42 28.1 85.4 28.1l0-48c-28.8 0-42-8.9-58.8-19.9-3.2-2.1-6.6-4.3-10.2-6.6zM143.8 432c-28.6 0-41.8 8.9-58.6 19.9-18.7 12.5-42 28.1-85.2 28.1t0 0 0 0l0 48 456 0 32.3-77.5c-15.8-10.3-29-18.5-56.5-18.5-28.8 0-42 8.9-58.8 19.9-19 12.5-42.2 28.1-85.4 28.1s-66.5-15.6-85.2-28.1c-16.6-11-30-19.9-58.5-19.9z", "M431.8 384c36 0 58.1 10.7 75.3 21.5l-18.7 45c-15.8-10.3-29-18.5-56.5-18.5-28.8 0-42 8.9-58.8 19.9-19 12.5-42.2 28.1-85.4 28.1s-66.5-15.6-85.2-28.1c-16.6-11-30-19.9-58.5-19.9s-41.8 8.9-58.6 19.9C66.5 464.4 43.2 480 0 480l0-48c28.6 0 41.8-8.9 58.6-19.9 18.7-12.5 42-28.1 85.2-28.1s66.5 15.6 85.2 28.1c16.6 11 29.8 19.9 58.6 19.9 28.8 0 42-8.9 58.8-19.9 19-12.5 42-28.1 85.5-28.1zM312 240l0 48-144 0 0-48 144 0zm192 0l0 48-144 0 0-48 144 0z"]],
    "arrows-rotate": [576, 576, [128472, "refresh", "sync"], "f021", ["M415.5 7.2c-9.4 9.4-9.4 24.5 0 33.8l31 31-302.4 0c-39.8 0-72 32.2-72 72l0 206.2-64.8 64.8-.3 0c-9.4 9.4-9.4 24.5 0 33.8l120 120c4.8 4.6 10.8 7 17.1 7s12.2-2.2 17-7c9.4-9.4 9.4-24.5 0-33.8l-31-31 302.2 0c39.8 0 72-32.2 72-72l0-206.2 65-65c9.4-9.4 9.4-24.5 0-33.8L449.4 7.2c-9.4-9.4-24.5-9.4-33.8 0zM360.3 216l0-72 144 0 0 81.8-55 55c-4.8 4.8-10.8 7-17 7s-12.2-2.4-17-7c-9.4-9.4-9.4-24.5 0-33.8l31-31-85.9 0 0 143.8-144.3 0 0-143.8 144.2 0zm-233 79c9.4-9.4 24.5-9.4 33.8 0s9.4 24.5 0 33.8l-31 31 85.9 0 0 72.2-144 0 0-81.8 55.2-55.2z", "M127.3 295c9.4-9.4 24.5-9.4 33.8 0s9.4 24.5 0 33.8l-31 31 85.9 0 0 72.2-144 0 0-81.8 55.2-55.2zm377-69.1l-55 55c-4.8 4.8-10.8 7-17 7s-12.2-2.4-17-7c-9.4-9.4-9.4-24.5 0-33.8l31-31-85.9 0 0-72 144 0 0 81.8z"]],
    "quotes": [576, 576, [], "e234", ["M144 48C64.8 48 0 112.8 0 192l0 144 144 0 0-144-96 0c0-53 43-96 96-96l0-48zm192 0c-79.2 0-144 64.8-144 144l0 144 48 0 0-72 96 0 0-72-96 0c0-53 43-96 96-96l0-48zm0 216l0 72-96 0 0 72 96 0c0 53-43 96-96 96l0 48c79.2 0 144-64.8 144-144l0-144-48 0zm96 0l0 144 96 0c0 53-43 96-96 96l0 48c79.2 0 144-64.8 144-144l0-144-144 0z", "M240 264l0 72 96 0 0-72-96 0z"]],
    "book-open": [576, 576, [128214, 128366], "f518", ["M48 24l0 96 480 0 0-96-240 72-240-72zM24 120c-13.3 0-24 10.7-24 24L0 480c0 13.3 10.7 24 24 24l196.2 0c9.9 28 36.5 48 67.8 48s57.9-20 67.8-48L552 504c13.3 0 24-10.7 24-24l0-336c0-13.3-10.7-24-24-24l-24 0 0 288-240 72-240-72 0-288-24 0z", "M528 408l-240 72-240-72 0-288 480 0 0 288z"]],
    "box-archive": [576, 576, ["archive"], "f187", ["M0 24l0 144 48 0 0-72 480 0 0 72 48 0 0-144-576 0zM48 168l0 348c0 19.9 16.1 36 36 36l408 0c19.9 0 36-16.1 36-36l0-348-480 0zM192 276c0-19.9 16.1-36 36-36l120 0c19.9 0 36 16.1 36 36s-16.1 36-36 36l-120 0c-19.9 0-36-16.1-36-36z", "M348 240c19.9 0 36 16.1 36 36s-16.1 36-36 36l-120 0c-19.9 0-36-16.1-36-36s16.1-36 36-36l120 0zm180-72l-480 0 0-72 480 0 0 72z"]],
    "cake-candles": [576, 576, [127874, "birthday-cake", "cake"], "f1fd", ["M144 0L102.3 73.1c-4.1 7.2-6.3 15.3-6.3 23.5 0 17.7 9.7 33 24 41.2l0-41.8 48 0 0 41.8c14.3-8.2 24-23.5 24-41.2 0-8.2-2.2-16.3-6.3-23.5L144 0zM288 0L246.3 73.1c-4.1 7.2-6.3 15.3-6.3 23.5 0 17.7 9.7 33 24 41.2l0-41.8 48 0 0 41.8c14.3-8.2 24-23.5 24-41.2 0-8.2-2.2-16.3-6.3-23.5L288 0zM432 0L390.3 73.1c-4.1 7.2-6.3 15.3-6.3 23.5 0 17.7 9.7 33 24 41.2l0-41.8 48 0 0 41.8c14.3-8.2 24-23.5 24-41.2 0-8.2-2.2-16.3-6.3-23.5L432 0zM120 137.8l0 78.2 48 0 0-78.2c-6.9 3.9-14.9 6.2-23.4 6.2l-1.2 0c-8.5 0-16.5-2.3-23.4-6.2zm144 0l0 78.2 48 0 0-78.2c-6.9 3.9-14.9 6.2-23.4 6.2l-1.2 0c-8.5 0-16.5-2.3-23.4-6.2zm144 0l0 78.2 48 0 0-78.2c-6.9 3.9-14.9 6.2-23.4 6.2l-1.2 0c-8.5 0-16.5-2.3-23.4-6.2zM48 216c-26.5 0-48 21.5-48 48l0 192 48-19.2 0-76.8c0-13.3 10.7-24 24-24l432 0c13.3 0 24 10.7 24 24l0 72 48 24 0-192c0-26.5-21.5-48-48-48l-72 0 0 48-48 0 0-48-96 0 0 48-48 0 0-48-96 0 0 48-48 0 0-48-72 0zm93.6 192c-14.2 0-28.4 2.7-41.6 8l-52 20.8 0 139.2 480 0 0-144-24.4-12.2c-15.5-7.8-32.7-11.8-50.1-11.8-14.2 0-28.4 2.7-41.6 8l-80 32c-13.2 5.3-27.3 8-41.6 8-17.4 0-34.5-4-50.1-11.8l-48.7-24.4C176.1 412 158.9 408 141.6 408z", "M504 336c13.3 0 24 10.7 24 24l0 72-24.4-12.2c-15.5-7.8-32.7-11.8-50.1-11.8-14.2 0-28.4 2.7-41.6 8l-80 32c-13.2 5.3-27.3 8-41.6 8-17.4 0-34.5-4-50.1-11.8l-48.7-24.4c-15.5-7.8-32.7-11.8-50.1-11.8-14.2 0-28.4 2.7-41.6 8L48 436.8 48 360c0-13.3 10.7-24 24-24l432 0zM168 264l-48 0 0-48 48 0 0 48zm144 0l-48 0 0-48 48 0 0 48zm144 0l-48 0 0-48 48 0 0 48zM168 137.8c-6.9 3.9-14.9 6.2-23.4 6.2l-1.2 0c-8.5 0-16.5-2.3-23.4-6.2l0-41.8 48 0 0 41.8zm144 0c-6.9 3.9-14.9 6.2-23.4 6.2l-1.2 0c-8.5 0-16.5-2.3-23.4-6.2l0-41.8 48 0 0 41.8zm144 0c-6.9 3.9-14.9 6.2-23.4 6.2l-1.2 0c-8.5 0-16.5-2.3-23.4-6.2l0-41.8 48 0 0 41.8z"]],
    "signal-bars-good": [528, 576, ["signal-alt-3"], "f693", ["M264 96c-13.3 0-24 10.7-24 24l0 72 24 0c13.3 0 24 10.7 24 24l0 336c0 12.4-9.4 22.7-21.5 23.9l-2.5 .1 120 0c13.3 0 24-10.7 24-24l0-432c0-13.3-10.7-24-24-24L264 96zM144 192c-13.3 0-24 10.7-24 24l0 72 24 0c13.3 0 24 10.7 24 24l0 240c0 12.4-9.4 22.7-21.5 23.9l-2.5 .1 120 0c-13.3 0-24-10.7-24-24l0-360-96 0zM24 288c-13.3 0-24 10.7-24 24L0 552c0 13.3 10.7 24 24 24l120 0c-13.3 0-24-10.7-24-24l0-264-96 0z", "M240 192l0 360c0 13.3 10.7 24 24 24l2.5-.1c12.1-1.2 21.5-11.5 21.5-23.9l0-336c0-13.3-10.7-24-24-24l-24 0zM120 288l0 264c0 13.3 10.7 24 24 24l2.5-.1c12.1-1.2 21.5-11.5 21.5-23.9l0-240c0-13.3-10.7-24-24-24l-24 0z"]],
    "spa": [576, 576, ["lotus"], "f5bb", ["M288 48c-63.1 32.6-111.8 94-132.8 169.3 49.7 14.2 94.8 39.2 132.8 72.1 38-33 83.1-57.9 132.8-72.1-21-75.2-69.7-136.7-132.8-169.3zM60 204c-18.7 0-36.7 1.9-54.5 4.8-3.6 18-5.5 36.5-5.5 55.2 0 159.1 128.9 288 288 288t0 0 0 0c-85-43.9-144-140.2-144-252 0-28.8 3.9-56.6 11.2-82.7-30.2-8.6-62.1-13.3-95.2-13.3zm456 0c-33.1 0-65 4.6-95.2 13.3 7.3 26.1 11.2 53.9 11.2 82.7 0 111.8-59 208.1-144 252q0 0 0 0t0 0c159.1 0 288-128.9 288-288 0-19-1.9-37.4-5.5-55.2-17.8-2.9-36-4.8-54.5-4.8z", "M420.8 217.3c7.3 26.1 11.2 53.9 11.2 82.7 0 111.8-59 208.1-144 252-85-43.9-144-140.2-144-252 0-28.8 3.9-56.6 11.2-82.7 49.7 14.2 94.8 39.2 132.8 72.1 38-33 83.1-57.9 132.8-72.1z"]],
    "circle-info": [528, 576, ["info-circle"], "f05a", ["M264 0C118.2 0 0 118.2 0 264 0 384.8 81.2 486.6 192 518l0-206-24 0c-13.2 0-24-10.8-24-24s10.8-24 24-24l168 0 0 254C446.8 486.6 528 384.8 528 264 528 118.2 409.8 0 264 0zm60 156a60 60 0 1 1 -120 0 60 60 0 1 1 120 0zM192 518l0 58 144 0 0-58c-22.9 6.5-47 10-72 10s-49.1-3.6-72-10z", "M336 264l0 254c-22.9 6.5-47 10-72 10s-49.1-3.6-72-10l0-206-24 0c-13.2 0-24-10.8-24-24s10.8-24 24-24l168 0zm-72-48a60 60 0 1 1 0-120 60 60 0 1 1 0 120z"]],
    "layer-group": [576, 576, [], "f5fd", ["M288.1 0L4.1 114c-5.5 2.2-5.5 9.8 0 12l194.3 78 89.7-36 89.7 36 194.3-78c5.5-2.2 5.5-9.8 0-12L288.1 0zM198.4 204L4.1 282c-5.5 2.2-5.5 9.8 0 12l194.3 78 89.7-36 89.7 36 194.3-78c5.5-2.2 5.5-9.8 0-12l-194.3-78-89.7 36-89.7-36zm0 168L4.1 450c-5.5 2.2-5.5 9.8 0 12L288.1 576 572 462c5.5-2.2 5.5-9.8 0-12l-194.3-78-89.7 36-89.7-36z", "M288.1 168l-89.7 36 89.7 36 89.7-36-89.7-36zm0 168l-89.7 36 89.7 36 89.7-36-89.7-36z"]],
    "shield": [528, 576, [128737, "shield-blank"], "f132", ["M264 0S164.6 126.5 8.9 97.2C3.1 124.1 0 151.7 0 180 0 349.4 106.3 496.8 264 576l0-199.9q0 0 0 0l0-.2C264 261 315.7 158.4 396.6 89.5 313.2 62.6 264 0 264 0z", "M528 180c0-28.3-3.1-55.9-8.9-82.8-46.1 8.6-87.1 3.6-122.2-7.7-81.1 68.9-133 171.6-133 286.6l0 200.2c157.7-79.2 264-226.6 264-396l0-.2z"]],
    "cart-shopping": [576, 576, [128722, "shopping-cart"], "f07a", ["M4.1 10.8c-7.4 11-4.3 25.9 6.7 33.1l63.4 42.2 59.1 354.7c10.3-5.7 22.1-8.9 34.7-8.9 4.3 0 8.5 .4 12.5 1.1l7.9 46.9 47.4 0c5.6 15.8 5.6 32.2 0 48l-67.6 0c-11.8 0-21.8-8.6-23.8-20.2l-11.2-67c-22.3 12.2-37.3 35.9-37.3 63.1 0 39.8 32.2 72 72 72 31.4 0 58-20 67.8-48l128.3 0c9.9 28 36.4 48 67.8 48s58-20 67.8-48l28.4 0c13.2 0 24-10.8 24-24s-10.8-24-24-24l-28.4 0c-9.9-28-36.4-48-67.8-48s-58 20-67.8 48l135.7 0c5.6 15.8 5.6 32.2 0 48l-135.7 0c-2.6-7.5-4.2-15.6-4.2-24s1.5-16.5 4.2-24l-128.3 0c-8.5-24.2-29.5-42.4-55.3-46.9l-8.2-49.1 331.7 0 72-264-447.6 0-8.6-51.8c-1.2-6.5-4.8-12.2-10.3-16.1L37.2 4.1C26.2-3.4 11.3-.2 4.1 10.8z", "M499.8 480c5.6 15.8 5.6 32.2 0 48l-135.7 0c-5.6-15.8-5.6-32.2 0-48l135.7 0zM168 432c4.3 0 8.5 .4 12.5 1.1l7.9 46.9 47.4 0c5.6 15.8 5.6 32.2 0 48l-67.6 0c-11.8 0-21.8-8.6-23.8-20.2l-11.2-67c10.3-5.7 22.1-8.9 34.7-8.9z"]]
  };

  bunker(function () {
    defineIcons('favs', icons);
  });

}());
